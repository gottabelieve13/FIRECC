# FIRE Command Center: validation report

**Date:** November 2026
**Scope:** the tax engine, retirement rules, simulation and Monte Carlo, Quarterly Review sale plans, and the UI.

## Plan

| # | Step | Method |
|---|---|---|
| 1 | Check every 2026 tax parameter against primary sources | IRS IR-2025-103 / Rev. Proc. 2025-32, FTB 2025 rate schedules, CMS 2026 Medicare, SSA 2026 wage base, HHS poverty guidelines |
| 2 | Compare the tax engine with hand calculations | 28 cases, each computed independently with the published formula |
| 3 | Test the retirement rules | Synthetic households isolate one rule each: RMDs, penalties, Roth access, Social Security, survivor, step-up, estate, ACA, IRMAA, FICA |
| 4 | Check simulation invariants | Cash conservation at 0% returns; real results unchanged by inflation; Monte Carlo repeatability; percentile ordering; historical data integrity |
| 5 | Independent code review | A second reviewer with no prior context read the engine and planner code |
| 6 | Fix, rebuild, retest | Every finding fixed or listed under Known limitations; full UI smoke test |

## Result

- **137 automated checks pass, none fail** (9 files in `fire-app-src/tests/`; run with `for f in tests/*.test.js; do node "$f"; done`):
  - 28 federal and California tax golden cases (`golden.test.js`)
  - 13 other-state cases (`states.test.js`) and 11 single-filer cases (`single.test.js`)
  - 29 rule and simulation checks (`sim.test.js`)
  - 7 tax-return feed checks (`returns.test.js`) and 4 return-parsing checks (`parse-return.test.js`)
  - 25 bank/card transaction checks (`spending.test.js`) and 6 W-2 parsing checks (`w2.test.js`)
  - 14 life-event checks (`life.test.js`): event-based phases, moves, inheritances, spending changes
- **Data-dependent checks:** 10 more checks ran against the author's own statement data, so they aren't saved in `tests/`. All passed: 9 Quarterly Review checks (net worth, liquid net worth, the sale plan and the ACA ceiling) and the UI smoke test.
- **UI smoke test:** every tab and Plan sub-tab rendered with no JavaScript errors and no NaN/undefined values.

## Confirmed correct (no change needed)

- **2026 federal law:**
  - MFJ and single brackets
  - $32,200 / $16,100 standard deduction
  - LTCG 0/15/20% thresholds and stacking on top of ordinary income
  - NIIT 3.8% over an unindexed $250k
  - AMT $140,200 exemption, with a 50% phase-out above $1M
  - $15M estate exemption, with portability
- **OBBBA provisions:**
  - SALT cap of $40,400 in 2026, with the 30% phase-down above $505k and a $10k floor; it reverts in 2030
  - $6,000 senior deduction for 2025–2028, with the 6% phase-out
- **California:** taxes capital gains as ordinary income, excludes Social Security, 1% mental-health surtax over $1M, 1.3% SDI.
- **Medicare and payroll:**
  - Part B $202.90
  - IRMAA tiers $218k–$750k MFJ, with a 2-year lookback
  - FICA wage base $184,500, plus 0.9% additional Medicare tax over $250k
- **ACA:** 2026 required-contribution curve (2.10%–9.96%); 400% FPL cliff = $106,600 for a household of 3.
- **Social Security:**
  - Early reduction (5/9% then 5/12% per month; 70% at 62)
  - Delayed credits (8%/yr; 124% at 70)
  - Spousal benefit (32.5% at 62, 50% at full retirement age)
  - Survivor keeps the larger benefit
  - Taxable portion matches the IRS worksheet
- **RMDs:** start at 75 for anyone born 1960 or later; Uniform Lifetime divisors.
- **Mechanics:**
  - First death: switch to single filing, CA community-property full step-up, spousal IRA rollover
  - Roth conversions move money 1:1
  - Tax-loss pairing in the Quarterly Review sale plan stays at or under the ACA ceiling
- **Simulation integrity:**
  - Dollars are conserved each year at 0% returns (within the $50 tax-solver tolerance)
  - Real results are unchanged between 0% and 3% inflation (18.14M vs 18.11M)
  - Monte Carlo is repeatable for a given seed, and percentiles are ordered
  - Historical returns 1928–2025 are complete and spot-checked (2008 −36.55%, 2022 −18.04%, long-run real 6.79%)

## Defects found and fixed

| Severity | Issue | Fix |
|---|---|---|
| High | **Rental sale gain ignored depreciation.** Adjusted basis must be cost minus depreciation taken, so up to the full depreciation was untaxed. | The gain now uses the adjusted basis. Depreciation is taxed as unrecaptured §1250 gain: ordinary rate capped at 25%, plus NIIT. |
| High | **Capital losses over $3,000 disappeared** instead of carrying forward. | Unused losses now go into a permanent carryforward ("loss bank"). |
| High | **The $3,000 capital-loss limit rose with inflation.** It is fixed by law. | Fixed at $3,000. |
| High | **California tax brackets were 2024's** (labeled 2025). | Updated to the FTB 2025 Schedule Y. Verified against FTB's worked example ($125k → $4,768.10). |
| Medium | **Roth money was spendable before 59½,** including the same year's conversion. | Before 59½, only Roth contributions and conversions at least 5 years old can be spent. New setting: "Roth contributions you can withdraw any time." |
| Medium | **IRMAA used full Social Security in MAGI,** overstating surcharges. | IRMAA MAGI = AGI + muni interest. The ACA still uses full Social Security, which is correct for the ACA. |
| Medium | **IRMAA thresholds lagged by 2 years.** | The current year's thresholds are now applied to MAGI from 2 years earlier. |
| Medium | **Muni interest triggered the SALT phase-down and the senior-deduction phase-out.** | Both now use AGI, as the law defines. |
| Medium | **OBBBA's 2026 limit on itemized deductions in the 37% bracket was missing.** | Added: deductions reduced by 2/37 of the lesser of deductions or income above $768,700. |
| Medium | **Survivors filing single got no $25k rental-loss allowance.** | Fixed; the allowance now uses MAGI without Social Security. |
| Medium | **California's 2.5% early-withdrawal tax was missing.** | The early pre-tax withdrawal penalty is now 12.5%. |
| Medium | **529 counted as spendable liquid wealth but vanished from the legacy.** | 529 is now outside liquid net worth, inside net worth, and added to the legacy. |
| Low | **"Use my return assumptions" in Monte Carlo missed the target slightly** (additive shift). | Now multiplicative; it hits the plan rate exactly (4.000%). |
| Low | **RMD table stopped at age 100.** | Extended to 120. |
| Low | **The direct-indexing fee total always showed $0.** | Fixed (found during testing). |
| Medium | **NIIT was charged on wages** in the this-year views (Quarterly Review, Taxes, return comparison). The lifetime Plan was correct. | NIIT now uses investment income only, net of the $3,000 capital-loss deduction (Form 8960). |
| Medium | **Tax-return import read blank lines as their own line numbers** (e.g. "Tax 16"), missed 2025's line 11a/11b AGI, and read AMT from the wrong Schedule 2 line. | Line-number and year echoes are ignored, AGI is cross-checked against total and taxable income, AMT reads line 2; earlier imports are repaired automatically and the fixes listed. |
| Medium | **Marketplace health premiums were charged in working years.** | While anyone has wages, coverage is assumed to be through an employer (its cost is in spending). |
| Low | **Property tax in Analytics and "All taxes" counted only homes** (rentals' tax was netted out of rent and not shown). | Totals now include every property; the itemized-deduction amount is unchanged. A check flags property tax that differs from an imported ProjectionLab file by more than 20%. |
| Low | **Defaults reflected one household** ($350k spending, $150k cash). | New data sets start from a typical U.S. household around age 40 (BLS Consumer Expenditure Survey 2025). |

## Known limitations (not modeled, or approximated)

- **Enhanced ACA subsidies:** the app assumes they expired after 2025 (400% cliff). If Congress extends them, turn off "cliff in effect" in Settings.
- **Not modeled:**
  - CA personal exemption credits (about $300)
  - Charitable deductions
  - Child and other credits
  - Survivor Social Security before the deceased spouse's planned claim age (survivor benefits can start at 60)
  - The 10% penalty exception for an under-59½ survivor using the deceased's IRA
- **Approximations:**
  - The §1250 25% cap is estimated from the marginal rate rather than a full worksheet.
  - The mortgage-interest $750k limit is applied per property rather than combined.
  - The tax solver converges to within $50 per year.
- **Monte Carlo and backtest:**
  - Backtest start years after 1968 wrap around to 1928 data to fill a 57-year plan. They are marked in the grid but counted in the success rate.
  - Monte Carlo resamples U.S. history only. Future returns may be lower; the "use my return assumptions" option addresses this.
- **Direct indexing:** harvest yields are user assumptions, not market-modeled lot by lot.
- **Other states:** 50 states + DC. 13 hand-computed checks (`tests/states.test.js`) cover TX, FL, IL, PA, MA (with surtax), NY, MN and WA's capital-gains excise. States marked *approximate* in Settings apply the top rate to all taxable income (errs high); local/city income taxes, state credits and NY's benefit recapture aren't modeled. California-only rules (Prop 13, SDI, 2.5% early-withdrawal tax, MHST, 30/40/0/30 estimates) switch off elsewhere.
- **Single households:** Settings → Household → Filing status. 11 checks (`tests/single.test.js`): single brackets, deduction and NIIT threshold; no spouse Social Security, jobs or survivor years; spouse-owned IRAs fold into yours. Head of household isn't modeled (single is used).
- **CA tables:** each year's brackets are projected from 2025 at 2.5%. Update Settings → reference tables when FTB publishes them.

## Sources

- IRS IR-2025-103 (2026 inflation adjustments, OBBBA): https://www.irs.gov/newsroom/irs-releases-tax-inflation-adjustments-for-tax-year-2026-including-amendments-from-the-one-big-beautiful-bill
- FTB 2025 California tax rate schedules: https://www.ftb.ca.gov/forms/2025/2025-540-tax-rate-schedules.pdf
- CareScout 2025 Cost of Care Survey (long-term care defaults): https://www.carescout.com/cost-of-care
- Statutes cited in the fixes: IRC §§1016, 1212(b), 164(b)(7), 469(i), 72(t), 408A(d); CA R&TC §17085.
