#!/bin/bash
# FIRE Command Center: one-click portable backup.
# Double-click in Finder. Zips the whole FinancialTest folder (app, source, encrypted data, reports)
# into Backups/FIRE-backup-YYYY-MM-DD_HHMM.zip, then copies it to your *personal* Google Drive if
# Google Drive for desktop is installed. Only personal (@gmail.com) Drive accounts are used automatically;
# set FIRE_DRIVE_ACCOUNT=you@example.com to pick a different personal account. Work accounts are never used.

cd "$(dirname "$0")" || exit 1
HERE="$(pwd)"
STAMP="$(date +%Y-%m-%d_%H%M)"
NAME="FIRE-backup-$STAMP.zip"
mkdir -p Backups

echo "FIRE Command Center backup"
echo "Folder: $HERE"
echo

# Original statements (PDF/CSV) in FIRE-data/statements are NOT encrypted. Ask before including them.
INCLUDE_STATEMENTS="n"
if [ -n "$(ls -A FIRE-data/statements 2>/dev/null)" ]; then
  read -r -p "Include original statements from FIRE-data/statements? They are not encrypted. [y/N] " INCLUDE_STATEMENTS
fi

EXCLUDES=(-x "Backups/*" -x "Releases/*" -x "FIRE-data/ai-review/*" -x "FIRE-data/datasets/*/ai-review/*" -x "*.DS_Store" -x "*/node_modules/*")
case "$INCLUDE_STATEMENTS" in [yY]*) ;; *) EXCLUDES+=(-x "FIRE-data/statements/*") ;; esac

# zip the folder contents (relative paths, so it unzips as a ready-to-use folder)
zip -r -q "Backups/$NAME" . "${EXCLUDES[@]}" || { echo "zip failed"; read -r -p "Press Return to close."; exit 1; }
SIZE="$(du -h "Backups/$NAME" | cut -f1)"
echo "Created Backups/$NAME ($SIZE)"

# keep the 10 newest local backups
ls -1t Backups/FIRE-backup-*.zip 2>/dev/null | tail -n +11 | while read -r old; do rm -f "$old"; done

# copy to a personal Google Drive (Google Drive for desktop), skipping work accounts
DEST=""
for d in "$HOME"/Library/CloudStorage/GoogleDrive-*; do
  [ -d "$d" ] || continue
  ACCT="${d##*/GoogleDrive-}"
  if [ -n "$FIRE_DRIVE_ACCOUNT" ]; then [ "$ACCT" = "$FIRE_DRIVE_ACCOUNT" ] || continue
  else case "$ACCT" in *@gmail.com|*@googlemail.com) ;; *) continue ;; esac; fi
  for md in "$d/My Drive" "$d/Meine Ablage"; do [ -d "$md" ] && DEST="$md" && break; done
  [ -n "$DEST" ] && break
done

if [ -n "$DEST" ]; then
  mkdir -p "$DEST/FIRE Backups"
  cp "Backups/$NAME" "$DEST/FIRE Backups/" && echo "Copied to Google Drive: ${DEST#$HOME/}/FIRE Backups/$NAME"
  open "$DEST/FIRE Backups"
else
  echo
  echo "Google Drive for desktop (personal account) not found."
  echo "Upload Backups/$NAME at https://drive.google.com (drag it into a folder),"
  echo "or install Google Drive for desktop and sign in with your personal account."
  open -R "Backups/$NAME"
fi

echo
echo "To restore on another computer: unzip, open FIRE-Command-Center.html in Chrome,"
echo "Import tab -> Load data file -> FIRE-data/autosave/FIRE-autosave.fire, enter your password."
read -r -p "Done. Press Return to close."
