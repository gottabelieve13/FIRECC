#!/bin/bash
# FIRE Command Center: package the app for sharing, WITHOUT any personal data.
# Double-click in Finder. Makes Releases/FIRE-Command-Center-YYYY-MM-DD.zip containing only:
#   FIRE-Command-Center.html, README.md, Validation-Report.md, Backup to Zip.command,
#   fire-app-src/ (source, tests with made-up sample files, logos) and an EMPTY FIRE-data/ folder.
# Never included: FIRE-data contents (.fire files, statements), Backups/, Releases/.
# (Your data isn't stored in the HTML file; it lives in your browser and FIRE-data/.)

cd "$(dirname "$0")" || exit 1
STAMP="$(date +%Y-%m-%d)"
NAME="FIRE-Command-Center-$STAMP.zip"
fail() { echo; echo "STOPPED: $1"; read -r -p "Press Return to close."; exit 1; }

echo "Packaging FIRE Command Center for sharing (no personal data)"
echo

# --- safety checks on the app file ---
[ -f FIRE-Command-Center.html ] || fail "FIRE-Command-Center.html not found."
grep -q 'window.FIRE_SEED={"id":"seed","asOf":null,"accounts":\[\]' FIRE-Command-Center.html \
  || fail "FIRE-Command-Center.html has starting data built in. Rebuild it without --seed (cd fire-app-src; python3 build.py) and try again."
grep -q 'window.FIRE_PL_SEED=' FIRE-Command-Center.html \
  && fail "FIRE-Command-Center.html has a ProjectionLab file built in. Rebuild it without --pl and try again."

# --- stage a clean copy ---
STAGE="$(mktemp -d)/FIRE-Command-Center"
mkdir -p "$STAGE/FIRE-data/autosave" "$STAGE/FIRE-data/snapshots" "$STAGE/FIRE-data/statements"
cp FIRE-Command-Center.html "$STAGE/"
for f in README.md Validation-Report.md "Backup to Zip.command" "Package App for Sharing.command"; do [ -f "$f" ] && cp "$f" "$STAGE/"; done
[ -f FIRE-data/README.md ] && cp FIRE-data/README.md "$STAGE/FIRE-data/"
# keep empty folders in the zip
for d in autosave snapshots statements; do touch "$STAGE/FIRE-data/$d/.keep"; done

if [ -d fire-app-src ]; then
  mkdir -p "$STAGE/fire-app-src/src/brand" "$STAGE/fire-app-src/src/vendor" "$STAGE/fire-app-src/tests/fixtures"
  cp fire-app-src/README.md fire-app-src/build.py "$STAGE/fire-app-src/" 2>/dev/null
  # only the files the build uses (old drafts like app_v1.js / sec_*.js are left out)
  for f in app.js engine.js planner.js parsers.js hist.js shell.html; do cp "fire-app-src/src/$f" "$STAGE/fire-app-src/src/"; done
  cp fire-app-src/src/brand/*.png "$STAGE/fire-app-src/src/brand/"
  cp fire-app-src/src/vendor/* "$STAGE/fire-app-src/src/vendor/"
  cp fire-app-src/tests/*.test.js "$STAGE/fire-app-src/tests/"
  cp fire-app-src/tests/fixtures/*.csv "$STAGE/fire-app-src/tests/fixtures/"
fi
chmod +x "$STAGE"/*.command 2>/dev/null

# --- final check: no encrypted data files or statements slipped in ---
if find "$STAGE" \( -name '*.fire' -o -path '*/statements/*.pdf' -o -path '*/statements/*.csv' \) | grep -q .; then fail "Found data files in the package. Nothing was written."; fi

mkdir -p Releases
TMPD="$(dirname "$STAGE")"
( cd "$TMPD" && zip -r -q -X "$NAME" "FIRE-Command-Center" -x "*.DS_Store" ) || fail "zip failed."
rm -f "Releases/$NAME"; cp "$TMPD/$NAME" "Releases/$NAME" || fail "couldn't write Releases/$NAME."
rm -rf "$TMPD"

SIZE="$(du -h "Releases/$NAME" | cut -f1)"
echo "Created Releases/$NAME ($SIZE)"
echo "Contains the app, docs, source and an empty FIRE-data folder. No .fire files, statements or backups."
echo "Safe to share. Recipients unzip it and double-click FIRE-Command-Center.html."
open -R "Releases/$NAME"
echo
read -r -p "Done. Press Return to close."
