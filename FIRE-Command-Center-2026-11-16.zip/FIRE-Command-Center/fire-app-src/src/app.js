/* ============================================================
   APP — UI, state, persistence, import flow.
   Everything stays in this browser: no network calls.
   ============================================================ */
(function () {
  const E = window.FireEngine, P = window.FireParsers;
  // ---------- DATA SETS: several independent households in one browser ----------
  // Registry in localStorage; each data set's state lives under its own key. The first ("default") keeps the original
  // key and folder layout so existing data is untouched. Others save to FIRE-data/datasets/<slug>/.
  let wiping = false; // set while clearing this browser so nothing is written back
  const DSREG = 'fireCC.datasets';
  const DS = (() => { let r = null; try { r = JSON.parse(localStorage.getItem(DSREG) || 'null'); } catch (e) { /* ignore */ }
    if (!r || !Array.isArray(r.list) || !r.list.length) r = { active: 'default', list: [{ id: 'default', name: 'My data', slug: '', created: new Date().toISOString() }] };
    if (!r.list.some((x) => x.id === r.active)) r.active = r.list[0].id; return r; })();
  const dsKey = (id) => (id === 'default' ? 'fireCC.v1' : 'fireCC.v1:' + id);
  const dsSave = () => { if (wiping) return; try { localStorage.setItem(DSREG, JSON.stringify(DS)); } catch (e) { /* ignore */ } };
  const dsCur = () => DS.list.find((x) => x.id === DS.active);
  const dsFolder = (sub) => (DS.active === 'default' ? sub : `datasets/${dsCur().slug}/${sub}`);
  const dsSlug = (name) => (String(name).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30) || 'data') + '-' + Math.random().toString(36).slice(2, 6);
  const LS = dsKey(DS.active);
  dsCur().lastOpened = new Date().toISOString(); dsSave();
  const $ = (s, el = document) => el.querySelector(s);
  const esc = (s) => String(s ?? '').replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  const usd = (v, d = 0) => (v == null || isNaN(v) ? '—' : (v < 0 ? '-' : '') + '$' + Math.abs(v).toLocaleString(undefined, { minimumFractionDigits: d, maximumFractionDigits: d }));
  const k = E.$k;
  const pct = (v, d = 1) => (v == null || isNaN(v) ? '—' : v.toFixed(d) + '%');
  const clone = (o) => JSON.parse(JSON.stringify(o));
  const deepMerge = (base, over) => {
    if (Array.isArray(base) || typeof base !== 'object' || base == null) return over ?? base;
    const out = { ...base };
    for (const key in over || {}) out[key] = (typeof base[key] === 'object' && base[key] && !Array.isArray(base[key])) ? deepMerge(base[key], over[key]) : over[key];
    return out;
  };
  const CS = () => E.cs();
  // the household's state: California has extra rules (Prop 13, MHST, SDI, 2.5% early-withdrawal tax, 30/40/0/30 estimates, Form 540)
  const ST = () => E.stateOf(state.settings); const STN = () => ST().name; const STC = () => ST().code; const isCA = () => ST().type === 'ca';
  const SOLO = () => state.settings.household.filing === 'single';
  const MKTN = () => (isCA() ? 'Covered California' : 'the ACA marketplace');
  const CLASS_LABEL = { us_stock: 'US stock', intl_stock: 'Intl stock', goog: 'GOOG', bond: 'Bonds', muni: 'Muni bonds', cash: 'Brokerage cash / money market', bank: 'Bank cash (checking, savings, CDs)', gold: 'Gold & precious metals', crypto: 'Crypto', private: 'Venture capital / private', balanced: 'Target-date', real_estate: 'Real estate', other: 'Other' };
  const CLASS_COLOR = { us_stock: '#3b6fd8', intl_stock: '#6aa5f0', goog: '#e2733a', bond: '#3aa17e', muni: '#7cc7a4', cash: '#c9b458', bank: '#8fb339', gold: '#d4af37', crypto: '#f7931a', private: '#6a4c93', balanced: '#8d7ad6', real_estate: '#a0785a', other: '#9aa3ad' };
  const TAX_LABEL = { taxable: 'Taxable', pretax: 'Pre-tax (401k/IRA)', roth: 'Roth', hsa: 'HSA', edu: '529 college savings', property: 'Property', liability: 'Debt' };
  const TAX_COLOR = { taxable: '#3b6fd8', pretax: '#e2733a', roth: '#3aa17e', hsa: '#8d7ad6', edu: '#d9a520', property: '#a0785a', liability: '#c94c43' };

  // ---------- state ----------
  // v2 model: one editable "working" copy + frozen, dated snapshots + planner scenarios
  const L = window.FirePlanner;
  let state;
  const TAX_TYPES = ['taxable', 'pretax', 'roth', 'hsa', 'edu', 'property', 'liability'];
  function migrateManualAccounts(w) {
    const m = w.manual || {};
    (m.manualAccounts || []).forEach((x, i) => w.accounts.push({ key: 'manual:' + Date.now() + i, institution: 'Manual', name: x.name, taxType: x.taxType || 'taxable', asOf: w.asOf, manual: true, holdings: [{ symbol: x.symbol || 'MANUAL', desc: x.name, value: +x.value || 0, cost: x.cost === '' || x.cost == null ? null : +x.cost, assetClass: x.assetClass || 'other' }] }));
    m.manualAccounts = [];
  }
  // ----- account ownership (you / spouse / joint) -----
  const RETIRE = (t) => t === 'pretax' || t === 'roth' || t === 'hsa';
  const ownerName = (o, st = state) => { const h = (st || {}).settings?.household || E.DEFAULT_SETTINGS.household; return o === 'self' ? (h.selfName || 'You') : o === 'spouse' ? (h.spouseName || 'Spouse') : 'Joint'; };
  function inferOwner(a, settings, prev) {
    if (a.owner) return a;
    if (prev) { a.owner = prev; return a; }
    const h = settings.household; const first = (n) => (n || '').trim().split(/\s+/)[0].toLowerCase();
    const txt = `${a.holder || ''} ${a.name || ''}`.toLowerCase();
    if (/trust|joint|community| & /.test(txt) || a.holder === 'joint') a.owner = 'joint';
    else if (first(h.spouseName) && txt.includes(first(h.spouseName))) a.owner = 'spouse';
    else if (first(h.selfName) && txt.includes(first(h.selfName))) a.owner = 'self';
    else { a.owner = RETIRE(a.taxType) || /^ms:/.test(a.key) ? 'self' : 'joint'; a.ownerGuessed = true; }
    return a;
  }
  const inferAll = (w, settings) => { (w.accounts || []).forEach((a) => inferOwner(a, settings)); return w; };
  function freshState() {
    const seed = DS.active === 'default' ? clone(window.FIRE_SEED) : { id: 'seed', asOf: null, accounts: [], manual: {}, sources: [] };
    const settings = clone(E.DEFAULT_SETTINGS);
    if (!seed.asOf) seed.asOf = new Date().toISOString().slice(0, 10);
    const working = { asOf: seed.asOf, accounts: seed.accounts || [], manual: { ...E.DEFAULT_MANUAL, ...seed.manual }, sources: seed.sources };
    const plan = L.newPlan(settings);
    // starter household (typical U.S. couple ~40): income, spending, retirement age and Social Security, all editable
    const SX = E.STARTER;
    plan.work = SX.wages.map(([who, name, salary]) => ({ who, name, salary, growth: 1, pretax401k: Math.round(salary * 0.06 / 100) * 100, match: Math.round(salary * 0.03 / 100) * 100, rothContrib: 0, startAge: '', endAge: '' }));
    plan.spending.categories = SX.spending.map(([name, amount, kind, endAge]) => ({ name, amount, kind, startAge: '', endAge: endAge ? endAge - 1 : '' }));
    plan.spending.categoriesDefault = true; plan.spending.starter = 'us40';
    plan.allocation = { ...plan.allocation, mode: 'target', stockNow: 80 }; // new money is invested (no accounts yet to copy a mix from)
    plan.people = { ...plan.people, retireAgeSelf: SX.retireAge, retireAgeSpouse: SX.retireAge };
    plan.ss = { ...plan.ss, selfPIA: SX.ss.selfPIA, spousePIA: SX.ss.spousePIA, selfClaim: 67, spouseClaim: 67 };
    if (window.FIRE_PL_SEED && DS.active === 'default') { try { plan.pl = { file: window.FIRE_PL_SEED.file, ...L.parsePL(window.FIRE_PL_SEED.text) }; } catch (e) { } }
    const st = { v: 2, settings, working, snapshots: [], plans: [plan], activePlanId: plan.id, tab: 'home', planTab: 'setup', planReal: true, basisOverrides: {}, dirty: false };
    inferAll(st.working, settings);
    unifyRealEstate(st);
    if ((seed.accounts || []).length) st.snapshots.push(makeSnapshot(st, seed.asOf, 'Initial import'));
    return st;
  }
  function makeSnapshot(st, asOf, note) {
    const data = clone({ ...st.working, asOf });
    return { id: 's' + Date.now() + Math.floor(Math.random() * 1e4), savedAt: new Date().toISOString(), asOf, note: note || '', data, summary: E.snapshotSummary(data, st.settings) };
  }
  function load() {
    let saved = null;
    try { saved = JSON.parse(localStorage.getItem(LS) || 'null'); } catch (e) { }
    if (!saved) return freshState();
    const settings = deepMerge(clone(E.DEFAULT_SETTINGS), saved.settings); settings.ref = deepMerge(clone(E.DEFAULT_REF), saved.settings?.ref);
    if (!saved.settings?.consolidatedV) { settings.consolidatedV = 1;
      const ap = (saved.plans || []).find((p) => p.id === saved.activePlanId) || (saved.plans || [])[0]; const os = saved.settings || {};
      if (ap) { ap.healthcare = ap.healthcare || {}; if (+os.aca?.benchmarkPremium && (!+ap.healthcare.acaBenchmark || ap.healthcare.acaBenchmark === 30000)) ap.healthcare.acaBenchmark = +os.aca.benchmarkPremium;
        ap.people = ap.people || {}; if (os.household?.retireDate && !ap.people.retireAgeSelf) ap.people.retireAgeSelf = +os.household.retireDate.slice(0, 4) - (+os.household.birthYearSelf || 1978);
        ap.allocation = ap.allocation || {}; if (os.alloc) { if (os.alloc.stock != null) { ap.allocation.stockNow = +os.alloc.stock; if (!ap.allocation.mode || ap.allocation.mode === 'current') ap.allocation.mode = 'target'; } if (os.alloc.alt != null) ap.allocation.alt = +os.alloc.alt; if (os.alloc.intlShare != null) ap.allocation.intlShare = +os.alloc.intlShare; } }
      if (os.working?.emergencyMonths && os.household?.retireDate) settings.buffer.emergencyMonths = settings.buffer.emergencyMonths || +os.working.emergencyMonths;
      if (settings.household) delete settings.household.retireDate; if (settings.working) delete settings.working.emergencyMonths; delete settings.projection;
      if (saved.working?.manual) { if (+saved.working.manual.wageIncome) saved.working.manual.wageIncomeEdited = true; if (+saved.working.manual.lossCarryforward) saved.working.manual.lossCarryforwardEdited = true; }
      for (const p of saved.plans || []) if (+p.rothBasis) p.rothBasisEdited = true; }
    if (!saved.settings?.spending?.sourceV) { settings.spending.sourceV = 1; settings.spending.source = 'plan';
      const ap = (saved.plans || []).find((p) => p.id === saved.activePlanId) || (saved.plans || [])[0];
      if (ap && ap.spending && ap.spending.categoriesDefault && +settings.spending.annual > 0) { const homes = (saved.working?.realEstate || []).filter((p) => !['rental', 'str'].includes(p.kind)).reduce((a, p) => a + (+p.mtgPayment || 0) * 12 + (+p.propertyTax || 0) + (+p.insurance || 0) + (+p.hoa || 0) + (+p.maintAmt || 0), 0);
        const target = Math.max(0, +settings.spending.annual - homes); const cur0 = (ap.spending.categories || []).filter((c) => (c.startAge === '' || c.startAge == null) && (c.endAge === '' || c.endAge == null)).reduce((a, c) => a + (+c.amount || 0), 0);
        if (cur0 > 0) for (const c of ap.spending.categories) if ((c.startAge === '' || c.startAge == null) && (c.endAge === '' || c.endAge == null)) c.amount = Math.round((+c.amount || 0) * target / cur0 / 100) * 100; } }
    // reference tables v2 (Nov 2026 validation): corrected CA 2025 brackets; added 2024/2025 federal, CA and AMT tables
    if ((saved.settings?.refVersion || 1) < 2) { for (const k2 of ['ca', 'fed', 'fedSingle', 'amt', 'irmaa', 'acaCurve']) settings.ref[k2] = clone(E.DEFAULT_REF[k2]); settings.refVersion = 2; }
    if (saved.v !== 2) { // migrate v1 (snapshots were raw imports)
      const st = freshState(); st.settings = settings;
      const cur1 = saved.snapshots.find((s) => s.id === saved.currentId) || saved.snapshots[saved.snapshots.length - 1];
      st.working = { asOf: cur1.asOf, accounts: cur1.accounts, manual: { ...E.DEFAULT_MANUAL, ...cur1.manual }, sources: cur1.sources };
      migrateManualAccounts(st.working);
      st.snapshots = saved.snapshots.map((s) => { const w = { asOf: s.asOf, accounts: s.accounts, manual: { ...E.DEFAULT_MANUAL, ...s.manual }, sources: s.sources }; migrateManualAccounts(w); return { id: s.id, savedAt: new Date().toISOString(), asOf: s.asOf, note: 'Migrated from v1', data: w, summary: E.snapshotSummary(w, settings) }; });
      unifyRealEstate(st);
      return st;
    }
    saved.settings = settings;
    // backfill account-holder names from the bundled statements so owners aren't just guesses
    const seedHolders = Object.fromEntries((window.FIRE_SEED.accounts || []).map((x) => [x.key, x.holder]));
    const backfill = (w) => (w.accounts || []).forEach((x) => { if (!x.holder && seedHolders[x.key]) { x.holder = seedHolders[x.key]; if (x.ownerGuessed) { delete x.owner; delete x.ownerGuessed; } } });
    backfill(saved.working); (saved.snapshots || []).forEach((x) => backfill(x.data));
    for (const a of saved.working.accounts || []) if (a.manual) for (const h of a.holdings) if (h.assetClass === 'cash' && /check|saving|\bcd\b|cds|bank|certificate/i.test(`${a.name} ${h.desc || ''}`)) h.assetClass = 'bank';
    inferAll(saved.working, settings); (saved.snapshots || []).forEach((x) => { inferAll(x.data, settings); if (x.summary && !x.summary.byOwner) x.summary = E.snapshotSummary(x.data, settings); });
    saved.plans = (saved.plans || []).map((p) => {
      if (p.healthcare && p.healthcare.medigapPartD == null) p.healthcare = { ...p.healthcare, model: true, medigapPartD: 3500, growth: 1.5 }; // healthcare now on by default
      if (!p.tax && p.roth) p.tax = { convert: p.roth.strategy === 'magi' ? 'aca' : (p.roth.strategy || 'none'), convertBracket: +p.roth.bracketTop || 0.22, convertFixed: +p.roth.fixed || 50000, convertStart: '', convertEnd: +p.roth.endAge || 74 };
      return L.normalizePlan(deepMerge(L.newPlan(settings), p), settings);
    });
    unifyRealEstate(saved);
    // ProjectionLab is comparison-only: never drive spending from its export
    saved.plans.forEach((p) => { if (p.spending.source === 'schedule') { p.spending.source = 'flat'; p.spending.schedule = []; } });
    if (!saved.plans.length) { const p = L.newPlan(settings); saved.plans = [p]; saved.activePlanId = p.id; }
    return saved;
  }
  function unifyRealEstate(st) {
    const W = st.working; W.realEstate = W.realEstate || [];
    // one-time: the "Ranch" house is a vacation rental (short-term) managed on the Rentals tab
    st.migrations = st.migrations || {};
    st.migrations.ranchStr = true; // (old one-time migration retired)
    st.migrations.edu529 = true; // (old one-time migration retired)
    // repairs & maintenance: % of value → fixed $/yr in today's dollars (then inflated by the plan)
    for (const p of W.realEstate) if ((p.maintAmt == null || p.maintAmt === '') && p.maintPct != null) { p.maintAmt = Math.round((+p.value || 0) * (+p.maintPct || 0) / 100); delete p.maintPct; }
    for (const pl of st.plans || []) for (const b of pl.purchases || []) if ((b.maintAmt == null || b.maintAmt === '') && b.maintPct != null) { b.maintAmt = Math.round((+b.price || 0) * (+b.maintPct || 0) / 100); delete b.maintPct; }
    // legacy "property" accounts become real estate entries
    for (const acc of W.accounts.filter((x) => x.taxType === 'property' && x.manual)) W.realEstate.push({ id: 'r' + Math.random().toString(36).slice(2, 9), name: acc.name, kind: 'primary', value: sum(acc.holdings, (h) => h.value), basis: null, purchaseYear: null, appreciation: 1, propertyTax: 0, insurance: 0, hoa: 0, maintAmt: Math.round(sum(acc.holdings, (h) => h.value) * 0.01), mtgBalance: 0 });
    W.accounts = W.accounts.filter((x) => !(x.taxType === 'property' && x.manual));
    // plan decisions (sell year, sale cost, costs-in-spending) move from the property into every plan
    for (const p of W.realEstate) {
      for (const pl of st.plans || []) { pl.reSale = pl.reSale || {}; const o = (pl.reSale[p.id] = pl.reSale[p.id] || {});
        if (o.sellYear == null && p.sellYear) o.sellYear = p.sellYear; if (o.sellCostPct == null && p.sellCostPct != null && p.sellCostPct !== 6) o.sellCostPct = p.sellCostPct;
        if (o.costsInSpending == null || o.costsInSpending === '') o.costsInSpending = o.costsInSpending === 'true' || !!p.costsInSpending; else o.costsInSpending = o.costsInSpending === true || o.costsInSpending === 'true'; }
      delete p.sellYear; delete p.sellCostPct; delete p.costsInSpending;
    }
  }
  function save() { if (wiping) return; autoQueue(); try { localStorage.setItem(LS, JSON.stringify(state)); $('#saveState').textContent = 'Auto-saved working copy · ' + new Date().toLocaleTimeString(); } catch (e) { $('#saveState').textContent = 'Browser storage unavailable. Use Export data.'; } }
  const cur = () => state.working;
  const plan = () => state.plans.find((p) => p.id === state.activePlanId) || state.plans[0];
  const getPath = (obj, path) => path.split('.').reduce((o, p) => (o == null ? o : o[p]), obj);
  const setPath = (obj, path, val) => { const ps = path.split('.'); let o = obj; for (let i = 0; i < ps.length - 1; i++) { o[ps[i]] = o[ps[i]] ?? {}; o = o[ps[i]]; } o[ps[ps.length - 1]] = val; };
  function saveSnapshotDialog() {
    const w = cur();
    const date = prompt('Save a snapshot of the current balances.\nSnapshot date (YYYY-MM-DD):', w.asOf);
    if (!date || !/^\d{4}-\d{2}-\d{2}$/.test(date)) return;
    const note = prompt('Optional note (e.g. "Q4 review, refill executed"):', '') || '';
    const existing = state.snapshots.find((s) => s.asOf === date);
    if (existing && !confirm(`A snapshot for ${date} already exists. Replace it?`)) return;
    if (existing) state.snapshots = state.snapshots.filter((s) => s !== existing);
    state.snapshots.push(makeSnapshot(state, date, note));
    state.snapshots.sort((a, b) => a.asOf.localeCompare(b.asOf));
    state.dirty = false; save(); render();
    const sn = state.snapshots.find((x) => x.asOf === date);
    if (state.snapshots.length >= 2) nudgeLater('snap2', 4000);
    writeSnapshotFile(sn).then((ok) => toast(`Snapshot saved for ${date}. ${state.snapshots.length} in history.${ok ? ` File written to ${AUTO.dir.name}/${dsFolder('snapshots')}.` : AUTO.dir ? ' (Resume auto-save to also write the snapshot file.)' : ''}`));
  }
  function toast(msg) { const t = $('#toast'); t.textContent = msg; t.classList.add('on'); clearTimeout(t._h); t._h = setTimeout(() => t.classList.remove('on'), 3500); }

  // ---------- input helpers ----------
  const root = (scope) => (scope === 'manual' ? cur().manual : scope === 'plan' ? plan() : scope === 'working' ? cur() : scope === 'ui' ? state : state.settings);
  function field(label, scope, path, opts = {}) {
    const v = getPath(root(scope), path);
    const id = 'f_' + scope + '_' + path.replace(/\./g, '_');
    const hint = opts.hint ? `<span class="hint">${opts.hint}</span>` : '';
    if (opts.type === 'select') return `<label class="fld"><span>${label}</span><select id="${id}" data-scope="${scope}" data-path="${path}">${opts.options.map(([val, l]) => `<option value="${val}" ${String(v) === String(val) ? 'selected' : ''}>${l}</option>`).join('')}</select>${hint}</label>`;
    if (opts.type === 'check') return `<label class="fld chk"><input type="checkbox" id="${id}" data-scope="${scope}" data-path="${path}" ${v ? 'checked' : ''}><span>${label}</span>${hint}</label>`;
    return `<label class="fld ${opts.warn ? 'warn' : ''}"><span>${label}</span><input id="${id}" type="${opts.text ? 'text' : 'number'}" step="any" data-scope="${scope}" data-path="${path}" value="${esc(v ?? '')}" placeholder="${opts.ph || ''}">${hint}</label>`;
  }
  // compact cell input for list editors
  const cell = (scope, path, type = 'number', opts = {}) => {
    const v = getPath(root(scope), path);
    if (opts.options) return `<select data-scope="${scope}" data-path="${path}">${opts.options.map(([val, l]) => `<option value="${val}" ${String(v) === String(val) ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
    if (type === 'check') return `<input type="checkbox" data-scope="${scope}" data-path="${path}" ${v ? 'checked' : ''}>`;
    return `<input type="${type}" step="any" data-scope="${scope}" data-path="${path}" value="${esc(v ?? '')}" ${opts.ph ? `placeholder="${opts.ph}"` : ''}>`;
  };
  const acctCell = (key, hi, fieldName, type = 'number', opts = {}) => {
    const a = cur().accounts.find((x) => x.key === key); const v = hi == null ? a[fieldName] : a.holdings[hi][fieldName];
    const attrs = `data-scope="acct" data-key="${esc(key)}" ${hi == null ? '' : `data-hi="${hi}"`} data-field="${fieldName}"`;
    if (opts.options) return `<select ${attrs}>${opts.options.map(([val, l]) => `<option value="${val}" ${String(v) === String(val) ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
    return `<input type="${type}" step="any" ${attrs} value="${esc(v ?? '')}" ${opts.ph ? `placeholder="${opts.ph}"` : ''} ${opts.ro ? 'readonly' : ''}>`;
  };
  document.addEventListener('toggle', (e) => { if (e.target && e.target.id === 'whyGap') state.whyOpen = e.target.open; if (e.target && e.target.id === 'rebalDetails') state.rebalOpen = e.target.open; if (e.target && e.target.id === 'mktLog') mktLogOpen = e.target.open; if (e.target && e.target.id === 'spManualBox') state.spManualOpen = e.target.open; if (e.target && e.target.id === 'spTables' && state.spending) { if (state.spending.tablesOpen !== e.target.open) { state.spending.tablesOpen = e.target.open; save(); } } }, true);
  document.addEventListener('change', (e) => {
    const t = e.target; if (!t.dataset) return;
    if (t.dataset.spCat || t.dataset.spKind || t.dataset.spOne) { const D = SPD(); const x = D.txns.find((y) => y.id === (t.dataset.spCat || t.dataset.spKind || t.dataset.spOne)); if (x) { if (t.dataset.spCat) { x.category = t.value; x.userCat = true; } if (t.dataset.spKind) { x.kind = t.value; x.userKind = true; if ((x.kind === 'spend' || x.kind === 'refund') && !x.category) x.category = P.categorize(x.desc); } if (t.dataset.spOne) x.oneTime = t.checked; save(); render(); } return; }
    if (t.dataset.spF) { state.spFilter = { ...(state.spFilter || {}), [t.dataset.spF]: t.value }; save(); render(); return; }
    if (t.dataset.spAcctType) { const D = SPD(); D.acctTypes[t.dataset.spAcctType] = t.value; spReclass(D, t.dataset.spAcctType); spDedupe(D); save(); render(); toast(`${t.dataset.spAcctType} is now treated as a ${t.value === 'card' ? 'credit card' : 'bank account'}.`); return; }
    if (t.dataset.spOpt) { const D = SPD(); if (t.dataset.spOpt === 'viewAll') D.view = t.checked ? 'all' : 'spending'; else D[t.dataset.spOpt] = t.checked; save(); render(); return; }
    if (t.dataset.rebalAcct) { state.rebal = state.rebal || { acct: {}, cls: {} }; state.rebal.acct[t.dataset.rebalAcct] = t.value; state.rebalOpen = true; save(); render(); return; }
    if (t.dataset.rebalCls) { state.rebal = state.rebal || { acct: {}, cls: {} }; state.rebal.cls = state.rebal.cls || {}; state.rebal.cls[t.dataset.rebalCls] = t.value; state.rebalOpen = true; save(); render(); return; }
    if (t.dataset.scope === 'manual' && (t.dataset.path === 'wageIncome' || t.dataset.path === 'lossCarryforward')) cur().manual[t.dataset.path + 'Edited'] = true;
    if (t.dataset.scope === 'plan' && t.dataset.path === 'rothBasis') plan().rothBasisEdited = true;
    if (t.dataset.scope === 'settings' && t.dataset.path === 'household.filing') { const H = state.settings.household; const was = H.filing; H.filing = t.value; if (was !== t.value) H.size = Math.max(1, (+H.size || 2) + (t.value === 'single' ? -1 : 1)); save(); render(); toast(t.value === 'single' ? `Single: spouse fields hidden, single brackets and thresholds used. Household size set to ${H.size}.` : `Married filing jointly. Household size set to ${H.size}.`); return; }
    if (t.dataset.scope === 'settings' && t.dataset.path === 'household.state') { state.settings.household.state = t.value; const cp = !!(E.STATES[t.value] || {}).cp; for (const p of state.plans) { p.estate = p.estate || {}; p.estate.communityProperty = cp; if (t.value !== 'CA') p.estate.prop13 = false; } save(); render(); toast(`State set to ${E.STATES[t.value].name}. Taxes and Plan now use its rules.`); return; }
    if (t.id === 'dsSel') { const v = t.value; if (v === '__new') { t.value = DS.active; dsNew(); } else if (v === '__manage') { t.value = DS.active; state.tab = 'import'; save(); render(); } else if (v !== DS.active) dsSwitch(v); return; }
    if (t.dataset.w2) { const x = W2S().find((y) => y.id === t.dataset.w2); if (!x) return; const f = t.dataset.f;
      if (f === 'who' || f === 'employer') x[f] = t.value; else { const [grp, key] = f.split('.'); x[grp] = x[grp] || {}; const v = t.value.trim() === '' ? null : P.money(t.value); if (v == null) delete x[grp][key]; else x[grp][key] = v; }
      x.edited = x.edited || {}; x.edited[f] = true; save(); render(); return; }
    if (t.dataset.air) { const R = AIR(); R[t.dataset.air] = t.checked; save(); if (t.dataset.air === 'auto' && t.checked) { toast('FIRE-data/ai-review/ will be refreshed on auto-save (not encrypted).'); aiExport('folder'); } else render(); return; }
    if (t.dataset.stOv) { const c = STC(); const ov = (state.settings.ref.stateOverrides = state.settings.ref.stateOverrides || {}); ov[c] = ov[c] || {}; const f = t.dataset.stOv; if (t.value.trim() === '') delete ov[c][f]; else ov[c][f] = f === 'type' ? t.value : +t.value / (f === 'rate' ? 100 : 1); save(); render(); return; }
    if (t.dataset.ck) { const st = (state[t.dataset.ck] = state[t.dataset.ck] || {}); if (t.checked) st[t.dataset.id] = new Date().toISOString().slice(0, 10); else delete st[t.dataset.id]; save(); render(); if (t.checked && ['review', 'annual', 'yearend', 'filing'].reduce((n, k2) => n + Object.keys(state[k2] || {}).length, 0) >= 8) nudgeLater('checklist'); return; }
    if (t.dataset.ret) { const r = state.taxReturns[t.dataset.ret]; const v = t.value.trim() === '' ? null : P.money(t.value); if (v == null) delete r.fields[t.dataset.f]; else r.fields[t.dataset.f] = v; r.edited = r.edited || {}; r.edited[t.dataset.f] = true;
      if (/^schD/.test(t.dataset.f) && r.fields.schDNet < 0) r.fields.capLossCarryOut = Math.max(0, -r.fields.schDNet - Math.abs(r.fields.schDLimited ?? 3000)); save(); render(); return; }
    if (t.dataset.est) { const e = (state.estTax = state.estTax || {}); e[t.dataset.est] = e[t.dataset.est] || {}; e[t.dataset.est][t.dataset.f] = t.value.trim() === '' ? '' : P.money(t.value); save(); render(); return; }
    if (t.dataset.re) { const p = (cur().realEstate || []).find((x) => x.id === t.dataset.re); if (p) { p[t.dataset.f] = t.value.trim() === '' ? '' : P.money(t.value); save(); render(); } return; }
    if (t.id === 'plIncYSel') { state.plIncYear = +t.value; save(); render(); return; }
    if (t.id === 'nwZoomFrom' || t.id === 'nwZoomTo') { state.nwZoom = { ...(state.nwZoom || {}), [t.id === 'nwZoomFrom' ? 'from' : 'to']: t.value === '' ? '' : +t.value }; save(); render(); return; }
    let v = t.type === 'checkbox' ? t.checked : t.value;
    if (t.type === 'number') v = v === '' ? null : +v;
    if (t.tagName === 'SELECT' && /^-?\d+(\.\d+)?$/.test(v)) v = +v;
    if (t.dataset.scope === 'acct') {
      const a = cur().accounts.find((x) => x.key === t.dataset.key); if (!a) return;
      const f = t.dataset.field;
      if (t.dataset.hi == null) { a[f] = v; if (f === 'owner') { a.ownerGuessed = false; if (RETIRE(a.taxType) && v === 'joint') toast('Retirement accounts (IRA, 401k, Roth, HSA) belong to one person. They can’t be joint.'); } }
      else {
        const h = a.holdings[+t.dataset.hi]; h[f] = v; h.edited = true;
        if (f === 'symbol' || f === 'desc') { if (!h.assetClassSet) h.assetClass = P.classify(h.symbol, h.desc); }
        if (f === 'assetClass') h.assetClassSet = true;
        if (f === 'cost' && !a.manual) state.basisOverrides[a.key + '|' + h.symbol] = { cost: v, qty: h.qty ?? null };
        if (f === 'qty' && h.price && !a.manual) h.value = v * h.price;
        if (f === 'qty') h.qtyEstimated = false;
        if (f === 'priceRef' && !v) h.priceRefOff = true;
        if ((f === 'symbol' || f === 'desc' || f === 'assetClass') && !h.priceRef && !h.priceRefOff) { const ref = autoPriceRef(h); if (ref && ['gold', 'crypto'].includes(h.assetClass)) h.priceRef = ref; }
        if ((f === 'qty' || f === 'priceRef' || f === 'symbol') && h.priceRef) revalueHoldings(cur());
      }
      a.edited = true; state.dirty = true; save(); render(); return;
    }
    if (t.dataset.pl === 'file') return;
    if (!t.dataset.path) return;
    setPath(root(t.dataset.scope), t.dataset.path, v);
    if (t.dataset.scope === 'manual' && /^market\.\w+\.price$/.test(t.dataset.path)) { const kk = t.dataset.path.split('.')[1]; const q = cur().manual.market[kk]; if (v == null) delete cur().manual.market[kk]; else Object.assign(q, { src: 'manual', t: new Date().toISOString(), prev: null }); if (kk === 'spx' && q && q.price) { const mk = cur().manual.market; mk.spxATH = Math.max(+mk.spxATH || 0, q.price); if (cur().manual.spAuto !== false) cur().manual.spDrawdownPct = Math.round((mk.spxATH - q.price) / mk.spxATH * 1000) / 10; } revalueHoldings(cur()); }
    if (t.dataset.scope === 'manual' && /^market\.spx(Proxy)?ATH$/.test(t.dataset.path)) { const mk = cur().manual.market; const ath = mk.spx?.proxy ? mk.spxProxyATH : mk.spxATH; if (mk.spx?.price && ath && cur().manual.spAuto !== false) cur().manual.spDrawdownPct = Math.max(0, Math.round((ath - mk.spx.price) / ath * 1000) / 10); }
    if (t.dataset.scope === 'plan' && /^spending\.categories\.\d+\.endAt$/.test(t.dataset.path) && v && v !== 'end' && v !== 'now') {
      // keep every category accounted for through life: add the next phase, starting where this one ends
      const P0 = plan(); const cats = P0.spending.categories; const i = +t.dataset.path.split('.')[2]; const c = cats[i]; const nm = String(c.name || '').trim().toLowerCase();
      if (!cats.some((x, j) => j !== i && String(x.name || '').trim().toLowerCase() === nm && x.startAt === v)) {
        cats.splice(i + 1, 0, { ...c, startAt: v, startAge: '', endAt: 'end', endAge: '', auto: true });
        const lab = (L.anchorOptions(P0, state.settings, SOLO()).find((o) => o[0] === v) || [, v])[1];
        toast(`Added the next phase: "${c.name}" from ${lab} to the end of the plan. Change its amount, or give it its own end to add another phase.`);
      }
      P0.spending.categoriesDefault = false;
    }
    if (t.dataset.scope === 'manual' && t.dataset.path === 'spDrawdownPct') cur().manual.spAuto = false;
    if (t.dataset.scope === 'manual' || t.dataset.scope === 'working') state.dirty = true;
    save(); render();
  });

  // ---------- charts (inline SVG) ----------
  function frame({ w, h, x0, x1, y0, y1, yFmt, xLabels, markers, xStep }) {
    const pad = { l: 64, r: 34, t: 14, b: 28 };
    const X = (x) => pad.l + (x - x0) / Math.max(1e-9, x1 - x0) * (w - pad.l - pad.r);
    const Y = (y) => h - pad.b - (y - y0) / Math.max(1e-9, y1 - y0) * (h - pad.t - pad.b);
    let g = '';
    for (let i = 0; i <= 4; i++) { const yv = y0 + (y1 - y0) * i / 4; g += `<line x1="${pad.l}" x2="${w - pad.r}" y1="${Y(yv)}" y2="${Y(yv)}" class="grid"/><text x="${pad.l - 6}" y="${Y(yv) + 4}" class="axis" text-anchor="end">${yFmt(yv)}</text>`; }
    const step = xStep || Math.ceil((x1 - x0) / 10) || 1;
    for (let x = Math.ceil(x0); x <= x1; x += step) g += `<text x="${X(x)}" y="${h - 8}" class="axis" text-anchor="middle">${xLabels ? (xLabels[x] ?? '') : x}</text>`;
    for (const m of markers || []) if (m.x >= x0 && m.x <= x1) g += `<line x1="${X(m.x)}" x2="${X(m.x)}" y1="${pad.t}" y2="${h - pad.b}" class="mark"/><text x="${X(m.x) + 4}" y="${pad.t + 10}" class="axis">${m.label}</text>`;
    return { X, Y, g, pad };
  }
  const legendHTML = (items) => `<div class="legend">${items.map((s) => `<span class="lg"><i style="background:${s.color}"></i>${s.name}</span>`).join('')}</div>`;
  function lineChart(series, { w = 760, h = 260, yFmt = k, xLabels = null, markers = [], hlines = [], points = [] } = {}) {
    const all = series.flatMap((s) => s.pts.map((p) => p[1])).concat(points.flatMap((s) => s.pts.map((p) => p[1]))).concat(hlines.map((l) => l.y));
    const xs = series.flatMap((s) => s.pts.map((p) => p[0])).concat(points.flatMap((s) => s.pts.map((p) => p[0])));
    if (!xs.length) return '';
    const x0 = Math.min(...xs), x1 = Math.max(...xs), y1 = Math.max(1, ...all) * 1.05, y0 = Math.min(0, ...all);
    const { X, Y, g: g0 } = frame({ w, h, x0, x1, y0, y1, yFmt, xLabels, markers });
    let g = g0;
    for (const l of hlines) g += `<line x1="${X(x0)}" x2="${X(x1)}" y1="${Y(l.y)}" y2="${Y(l.y)}" stroke="${l.color}" stroke-dasharray="4 3"/><text x="${X(x1) - 4}" y="${Y(l.y) - 4}" class="axis" text-anchor="end">${l.label}</text>`;
    for (const s of series) g += `<polyline fill="none" stroke="${s.color}" stroke-width="${s.width || 2.5}" ${s.dash ? 'stroke-dasharray="5 4"' : ''} points="${s.pts.map((p) => X(p[0]) + ',' + Y(p[1])).join(' ')}"/>`;
    for (const s of points) for (const p of s.pts.filter(inX)) g += `<circle cx="${X(p[0])}" cy="${Y(p[1])}" r="4.5" fill="${s.color}" stroke="#fff" stroke-width="1.5"><title>${s.name}: ${k(p[1])}</title></circle>`;
    return `<svg viewBox="0 0 ${w} ${h}" class="chart">${g}</svg>` + legendHTML([...series, ...points]);
  }
  function bandChart(bandsAll, { w = 760, h = 280, lines = [], points = [], markers = [], zoom = null } = {}) {
    const zf = zoom?.from != null && zoom.from !== '' ? +zoom.from : -Infinity, zt = zoom?.to != null && zoom.to !== '' ? +zoom.to : Infinity;
    let bands = bandsAll.filter((b) => b.age >= zf && b.age <= zt); if (bands.length < 2) bands = bandsAll;
    const x0 = bands[0].age, x1 = bands[bands.length - 1].age;
    const inX = (p) => p[0] >= x0 && p[0] <= x1;
    const all = bands.flatMap((b) => [b.p90]).concat(lines.flatMap((s) => s.pts.filter(inX).map((p) => p[1]))).concat(points.flatMap((s) => s.pts.filter(inX).map((p) => p[1])));
    // keep the chart readable: the 90th percentile can explode, so cap the axis and clip
    const capBase = Math.max(...bands.map((b) => b.p75)) * 1.25;
    const other = Math.max(1, ...lines.flatMap((s) => s.pts.filter(inX).map((p) => p[1])), ...points.flatMap((s) => s.pts.filter(inX).map((p) => p[1])));
    const mode = zoom?.mode || 'auto';
    const y1 = mode === 'all' ? Math.max(1, ...all) * 1.05
      : mode === 'plan' ? Math.max(1, ...(lines[0]?.pts || []).filter(inX).map((p) => p[1]), ...points.flatMap((s) => s.pts.filter(inX).map((p) => p[1])), ...bands.map((b) => b.p10)) * 1.15
      : mode === 'median' ? Math.max(1, ...bands.map((b) => b.p50), other) * 1.1
      : Math.min(Math.max(1, ...all) * 1.05, Math.max(capBase, other * 1.15));
    markers = markers.filter((m) => m.x >= x0 && m.x <= x1);
    const { X, Y: Y0, g: g0 } = frame({ w, h, x0, x1, y0: 0, y1, yFmt: k, markers });
    const Y = (v) => Y0(Math.min(v, y1));
    const area = (lo, hi, col, op) => `<polygon fill="${col}" fill-opacity="${op}" points="${bands.map((b) => X(b.age) + ',' + Y(b[hi])).join(' ')} ${bands.slice().reverse().map((b) => X(b.age) + ',' + Y(b[lo])).join(' ')}"/>`;
    let g = g0 + area('p10', 'p90', '#3b6fd8', 0.12) + area('p25', 'p75', '#3b6fd8', 0.22);
    g += `<polyline fill="none" stroke="#2b56b3" stroke-width="2.5" points="${bands.map((b) => X(b.age) + ',' + Y(b.p50)).join(' ')}"/>`;
    for (const s of lines) g += `<polyline fill="none" stroke="${s.color}" stroke-width="2" ${s.dash ? 'stroke-dasharray="5 4"' : ''} points="${s.pts.filter((p) => p[0] >= x0 && p[0] <= x1).map((p) => X(p[0]) + ',' + Y(p[1])).join(' ')}"/>`;
    for (const s of points) for (const p of s.pts) g += `<circle cx="${X(p[0])}" cy="${Y(p[1])}" r="4.5" fill="${s.color}" stroke="#fff" stroke-width="1.5"><title>${s.name}: ${k(p[1])}</title></circle>`;
    return `<svg viewBox="0 0 ${w} ${h}" class="chart">${g}</svg>` + legendHTML([{ name: 'Median (Monte Carlo)', color: '#2b56b3' }, { name: '25th–75th pct', color: 'rgba(59,111,216,.35)' }, { name: '10th–90th pct', color: 'rgba(59,111,216,.15)' }, ...lines, ...points]);
  }
  function stackBars(rows, keys, { w = 760, h = 280, line = null, pick = null, sel = null } = {}) {
    const tots = rows.map((r) => keys.reduce((s, kk) => s + Math.max(0, r[kk.key]), 0));
    const y1 = Math.max(1, ...tots, ...(line ? rows.map((r) => r[line.key]) : [])) * 1.08;
    const x0 = rows[0].age, x1 = rows[rows.length - 1].age;
    const { X, Y, g: g0 } = frame({ w, h, x0: x0 - 0.5, x1: x1 + 0.5, y0: 0, y1, yFmt: k, xStep: 5 });
    const bw = Math.max(2, (X(x0 + 1) - X(x0)) * 0.75);
    let g = g0;
    const sr = sel != null ? rows.find((r) => r.year === sel) : null;
    if (sr) g += `<rect x="${X(sr.age) - bw * 0.75}" y="${Y(y1)}" width="${bw * 1.5}" height="${Y(0) - Y(y1)}" fill="#ffd54f" fill-opacity=".35"/>`;
    for (const r of rows) { let acc = 0; for (const kk of keys) { const v = Math.max(0, r[kk.key]); if (!v) continue; g += `<rect x="${X(r.age) - bw / 2}" y="${Y(acc + v)}" width="${bw}" height="${Y(acc) - Y(acc + v)}" fill="${kk.color}"><title>${r.year} · ${kk.name}: ${k(v)}</title></rect>`; acc += v; } }
    if (line) g += `<polyline fill="none" stroke="${line.color}" stroke-width="2" points="${rows.map((r) => X(r.age) + ',' + Y(r[line.key])).join(' ')}"/>`;
    // clickable year columns (transparent, on top): click a year to show its details
    if (pick) { const cw = X(x0 + 1) - X(x0); for (const r of rows) g += `<rect data-act="${pick}" data-y="${r.year}" x="${X(r.age) - cw / 2}" y="${Y(y1)}" width="${cw}" height="${Y(0) - Y(y1)}" fill="#000" fill-opacity="0" style="cursor:pointer"><title>${r.year} (age ${r.age}) · ${keys.filter((kk) => r[kk.key] > 0.5).map((kk) => `${kk.name}: ${k(r[kk.key])}`).join('\n')}\nClick to show this year</title></rect>`; }
    return `<svg viewBox="0 0 ${w} ${h}" class="chart">${g}</svg>` + legendHTML([...keys, ...(line ? [line] : [])]);
  }
  function stackBar(parts, total, ticks = []) {
    const max = Math.max(total, ...ticks.map((t) => t.v)) * 1.08;
    let x = 0; let segs = '';
    for (const p of parts) { if (p.v <= 0) continue; const wv = p.v / max * 100; segs += `<div class="seg" style="left:${x}%;width:${wv}%;background:${p.color}" title="${esc(p.label)}: ${usd(p.v)}"></div>`; x += wv; }
    const tk = ticks.map((t) => `<div class="tick ${t.cls || ''}" style="left:${t.v / max * 100}%"><span>${t.label}<br>${k(t.v)}</span></div>`).join('');
    const lg = parts.filter((p) => p.v > 0).map((p) => `<span class="lg"><i style="background:${p.color}"></i>${p.label} ${k(p.v)}</span>`).join('');
    return `<div class="sbar">${segs}${tk}</div><div class="legend">${lg}</div>`;
  }
  function hbars(obj, labels, colors, total) {
    return Object.entries(obj).filter(([, v]) => Math.abs(v) > 0.5).sort((a, b) => b[1] - a[1]).map(([key, v]) => `<div class="hb"><span class="hbl">${labels[key] || key}</span><div class="hbt"><div style="width:${Math.max(0, v) / total * 100}%;background:${colors[key] || '#999'}"></div></div><span class="hbv">${k(v)} · ${pct(v / total * 100, 0)}</span></div>`).join('');
  }

  // ---------- tabs ----------
  const TABS = [['review', 'Quarterly Review'], ['annual', 'Annual Review'], ['accounts', 'Net Worth'], ['spending', 'Spending'], ['rentals', 'Rentals'], ['taxes', 'Taxes & ACA'], ['returns', 'Tax returns'], ['filing', 'File taxes'], ['plan', 'Plan'], ['history', 'History'], ['import', 'Import'], ['settings', 'Settings']];

  // retirement date: Settings value, else derived from the active plan's retirement age
  // homes you live in: mortgage, property tax, insurance, HOA, upkeep (today's $/yr) — rentals are netted against rent elsewhere
  function homeCosts() { return (cur().realEstate || []).filter((p) => !L.isRental(p.kind) && !(p.costsInSpending === true || p.costsInSpending === 'true')).reduce((a, p) => a + (+p.mtgBalance ? (+p.mtgPayment || L.pmt(+p.mtgBalance, p.mtgRate, p.mtgYearsLeft)) * 12 : 0) + (+p.propertyTax || 0) + (+p.insurance || 0) + (+p.hoa || 0) + (L.maintAmt ? L.maintAmt(p) : +p.maintAmt || 0), 0); }
  // the Plan's target stock % for today (glide path → today's age)
  function allocTarget() {
    const P0 = plan(); const A0 = P0.allocation || {}; 
    let stock = +A0.stockNow || 0;
    // a glide path starts at today's stock % (the Plan starts now), so today's target is stockNow
    const alt = +A0.alt || 0; return { stock, alt, bond: Math.max(0, 100 - stock - alt), intlShare: A0.intlShare ?? 30, band: state.settings.alloc?.band ?? 5, countSingles: !!state.settings.alloc?.countSingles, mode: A0.mode, planName: P0.name };
  }
  // values that live in one place and are copied where the older code reads them
  // concentrated stock: tickers from Settings; holdings re-tagged so every page uses the same definition
  function syncConc() {
    const S = state.settings; S.trim = S.trim || {};
    if (S.trim.concSymbols == null) { const found = new Set(); for (const a of cur().accounts) for (const h of a.holdings) if (h.assetClass === 'goog' && h.symbol) found.add(String(h.symbol).toUpperCase()); S.trim.concSymbols = [...found].join(', '); }
    const syms = String(S.trim.concSymbols || '').toUpperCase().split(/[\s,;]+/).filter(Boolean);
    E._conc = { symbols: syms, label: syms[0] || 'your single stock' }; P.isConc = E.isConc; CLASS_LABEL.goog = syms[0] || 'Concentrated stock';
    for (const a of cur().accounts) for (const h of a.holdings) { const sym = String(h.symbol || '').toUpperCase(); if (h.assetClassSet && a.manual) continue;
      if (syms.includes(sym)) { if (h.assetClass !== 'goog') h.assetClass = 'goog'; } else if (h.assetClass === 'goog') h.assetClass = 'us_stock'; }
  }
  function syncDerived() {
    // returns imported before the line-number fix: clean them up once (edited fields untouched)
    for (const r of Object.values(state.taxReturns || {})) if (!r.sanV) { r.fixes = P.sanitizeReturn(r.fields, r.edited || {}); if (r.fields.schDNet != null && r.fields.schDNet < 0 && !(r.edited || {}).capLossCarryOut) r.fields.capLossCarryOut = Math.max(0, -r.fields.schDNet - Math.abs(r.fields.schDLimited ?? 3000)); r.sanV = 1; }
    if (Object.values(state.taxReturns || {}).some((r) => r.sanV === 1 && !r.sanSaved)) { for (const r of Object.values(state.taxReturns || {})) r.sanSaved = true; setTimeout(save, 0); }
    const S = state.settings; const P0 = plan(); if (!P0) return; const m = cur().manual; const Y = +String(cur().asOf || new Date().toISOString()).slice(0, 4);
    S.aca.benchmarkPremium = +P0.healthcare?.acaBenchmark || 0; // ACA premium: Assumptions → Healthcare
    S.ref.indexRate = (+P0.inflation || 2.5) / 100; // future tax tables roll forward at the Plan's inflation
    // wages this year: from Assumptions → work income unless overridden
    const h = S.household; const wagesPlan = (P0.work || []).reduce((a2, j) => { if (SOLO() && j.who === 'spouse') return a2; const by = j.who === 'spouse' ? h.birthYearSpouse : h.birthYearSelf; const age = Y - by; const st = j.startAge === '' || j.startAge == null ? -1 : +j.startAge; const en = j.endAge !== '' && j.endAge != null ? +j.endAge : (j.who === 'spouse' ? P0.people.retireAgeSpouse : P0.people.retireAgeSelf); return a2 + (age >= st && (en == null || age < +en) ? +j.salary || 0 : 0); }, 0);
    m.wageFromPlan = wagesPlan; if (!m.wageIncomeEdited) m.wageIncome = wagesPlan;
    // capital-loss carryforward into this year: from last year's return unless overridden
    const ret = (state.taxReturns || {})[Y - 1]?.fields; m.cfFromReturn = ret && ret.capLossCarryOut != null ? +ret.capLossCarryOut : null;
    if (m.cfFromReturn != null && !m.lossCarryforwardEdited) m.lossCarryforward = m.cfFromReturn;
    // Roth contribution basis: from the latest return that has it, unless overridden in the plan
    const lr = retYears().map((y) => state.taxReturns[y].fields).find((f) => f.rothBasis != null);
    for (const pl of state.plans) { pl.rothBasisFromReturn = lr ? +lr.rothBasis : null; if (lr && !pl.rothBasisEdited) pl.rothBasis = +lr.rothBasis; }
  }
  function syncSpending() {
    const S = state.settings; S.spending.source = 'plan';
    const P0 = plan(); if (!P0) return; const living = catTotal(P0), homes = homeCosts();
    S.spending.annual = Math.round((living + homes) / 1000) * 1000; S.spending.fromPlan = { living, homes, plan: P0.name }; S.spending.confirmed = !P0.spending.categoriesDefault;
  }
  function phaseSettings() {
    const S = state.settings; const h = S.household; if (h.phase !== 'auto') return S;
    const ra = +plan()?.people?.retireAgeSelf; if (!ra) return S;
    return { ...S, household: { ...h, retireDate: `${h.birthYearSelf + Math.ceil(ra)}-01-01`, retireDerived: true } };
  }
  function render() {
    const snap = cur();
    snap.manual = { ...E.DEFAULT_MANUAL, ...(snap.manual || {}) };
    ensureLivePricing(snap); revalueHoldings(snap);
    syncConc(); syncSpending(); syncDerived(); const an = E.analyze(snap, phaseSettings());
    window.__an = an;
    if (!GROUPS.some(([, , L]) => L.some(([id]) => id === state.tab))) state.tab = 'home';
    const subnav = navHTML(an); state.lastLeaf = state.lastLeaf || {}; state.lastLeaf[groupOfLeaf(state.tab)] = state.tab; if (groupOfLeaf(state.tab) === 'review') state.reviewSession = sessionId;
    const last = state.snapshots[state.snapshots.length - 1];
    { const sel = $('#dsSel'); if (sel) sel.innerHTML = DS.list.map((x) => `<option value="${x.id}" ${x.id === DS.active ? 'selected' : ''}>${esc(x.name)}</option>`).join('') + '<option value="__new">+ New data set…</option><option value="__manage">Manage data sets…</option>'; }
    $('#snapLabel').innerHTML = `Working copy <b>${snap.asOf}</b> · ${state.snapshots.length} snapshot${state.snapshots.length === 1 ? '' : 's'}${last ? ` · last saved ${last.asOf}` : ''}${state.dirty ? ' · <span class="dirty">unsaved changes</span>' : ''}`;
    const views = { home: vHome, yearend: (s0, a0) => vAnnual(s0, a0, 'yearend'), review: vReview, accounts: vAccounts, rentals: vRentals, taxes: (s0, a0) => vTaxes(s0, a0) + estCard(Math.max(a0.Y, (retYears()[0] || a0.Y - 1) + 1), a0), spending: vSpending, returns: vReturns, annual: vAnnual, filing: vFiling, plan: vPlan, history: vHistory, import: vImport, settings: vSettings, help: vHelp };
    try { $('#view').innerHTML = subnav + views[state.tab](snap, an) + (NEXT[state.tab] ? NEXT[state.tab](an) : ''); } catch (err) { console.error(err); $('#view').innerHTML = `<div class="card"><h3>This tab hit an error</h3><p>${esc(err.message)}</p><p class="note">Your data is safe. Other tabs still work; tell Claude the message above.</p></div>`; }
    if (state.tab === 'import') bindImport();
    if (state.tab === 'returns') bindReturns();
    if (state.tab === 'spending') bindSpending();
    bindGlobalImport();
  }
  // "next step" links that walk through each workflow
  const NEXT = {
    review: (an) => nextStep(an.working ? 'pay estimated tax if one is due, then save a snapshot' : 'estimated tax payments', 'taxes'),
    yearend: () => nextStep('after Jan 1, the annual reset', 'annual'),
    annual: () => nextStep('Plan → Assumptions', 'plan', 'data-ptab-go="setup"'),
    filing: () => nextStep('import the filed return', 'returns'),
    returns: () => nextStep('this year\'s estimated payments', 'taxes'),
    spending: () => nextStep('use actual spending in the Plan (projection section above) or review Assumptions', 'plan', 'data-ptab-go="setup"'),
  };
  function bindReturns() {
    const drop = $('#trDrop'), inp = $('#trIn'); if (!drop) return;
    ['dragover', 'dragenter'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, () => drop.classList.remove('over')));
    drop.addEventListener('drop', (e) => { e.preventDefault(); handleFiles(e.dataTransfer.files); });
    inp.addEventListener('change', () => handleFiles(inp.files));
  }
  document.addEventListener('click', (e) => {
    const gt = e.target.closest('[data-group]'); if (gt) { e.preventDefault(); state.tab = goGroup(gt.dataset.group); save(); render(); try { window.scrollTo(0, 0); } catch (_) { } return; }
    const t = e.target.closest('[data-tab]'); if (t) { e.preventDefault(); state.tab = t.dataset.tab; if (t.dataset.ptabGo) { const go = t.dataset.ptabGo; state.planTab = go === 'di' ? 'strategies' : go; if (go === 'di') state.stratView = 'di'; } save(); render(); try { window.scrollTo(0, 0); } catch (_) { } return; }
    const pt = e.target.closest('[data-ptab]'); if (pt) { state.planTab = pt.dataset.ptab; save(); render(); return; }
    const a = e.target.closest('[data-act]'); if (!a) return;
    e.preventDefault();
    const act = a.dataset.act, W = cur(), PL = plan();
    const acct = () => W.accounts.find((x) => x.key === a.dataset.key);
    switch (act) {
      case 'print': state.tab = 'review'; render(); setTimeout(() => window.print(), 50); break;
      case 'export': exportData(false); break;
      case 'exportPlain': exportData(true); break;
      case 'autosave': autoToggle(); break;
      case 'pickDataDir': autoToggle(true); break;
      case 'aiExportFolder': aiExport('folder'); break;
      case 'dsSwitch': dsSwitch(a.dataset.id); break;
      case 'w2Del': if (confirm('Remove this W-2?')) { state.w2s = W2S().filter((x) => x.id !== a.dataset.id); save(); render(); } break;
      case 'globalImport': { const gi = $('#globalIn'); if (gi) gi.click(); break; }
      case 'w2Add': { const y = +prompt('Tax year of the W-2:', String(new Date().getFullYear() - 1)); if (!y) break; W2S().push({ id: 'w' + Date.now().toString(36), year: y, who: 'self', employer: '', state: '', boxes: {}, codes: {}, box14: [], file: 'entered by hand', edited: {} }); state.retYear = y; save(); render(); break; }
      case 'w2Plan': { const y = +a.dataset.y; const L = W2S().filter((x) => x.year === y && ((x.boxes.box5 || x.boxes.box1) > 0)); if (!L.length) break;
        const P = plan(); P.work = P.work || []; const plans = L.map((x) => { const nm = x.employer || 'Job'; const ex = P.work.find((j) => j.who === x.who && j.name && nm && j.name.toLowerCase() === nm.toLowerCase()) || (P.work.filter((j) => j.who === x.who).length === 1 && L.filter((z) => z.who === x.who).length === 1 ? P.work.find((j) => j.who === x.who) : null);
          return { x, ex, salary: Math.round(x.boxes.box5 || x.boxes.box1), k: Math.round((x.codes || {}).D || 0), r: Math.round((x.codes || {}).AA || 0), nm }; });
        if (!confirm('Update Plan → Work income from your ' + y + ' W-2s?\n\n' + plans.map((p) => `${ownerName(p.x.who)} · ${p.nm}: salary ${usd(p.salary)}, pre-tax 401(k) ${usd(p.k)}, Roth 401(k) ${usd(p.r)}${p.ex ? ` (updates "${p.ex.name}")` : ' (new job)'}`).join('\n') + '\n\nSalary uses box 5 (Medicare wages), which includes your pre-tax 401(k). Other current jobs for the same person are replaced; future jobs stay. Raises, match and end ages are kept for matched jobs.')) break;
        // a person's current jobs that no W-2 matches (e.g. the starter "Job") are replaced; future jobs (a start age ahead) stay
        const H0 = state.settings.household; const ageOf = (who) => new Date().getFullYear() - (who === 'spouse' ? H0.birthYearSpouse : H0.birthYearSelf);
        const used = new Set(plans.map((p) => p.ex).filter(Boolean)); const whos = new Set(plans.map((p) => p.x.who));
        P.work = P.work.filter((j) => used.has(j) || !whos.has(j.who) || (j.startAge !== '' && j.startAge != null && +j.startAge > ageOf(j.who)));
        for (const p of plans) { if (p.ex) Object.assign(p.ex, { name: p.nm, salary: p.salary, pretax401k: p.k, rothContrib: p.r }); else P.work.push({ who: p.x.who, name: p.nm, salary: p.salary, growth: 1, pretax401k: p.k, match: 0, rothContrib: p.r, startAge: '', endAge: '' }); }
        if (P.spending.starter) delete P.spending.starter; save(); render(); toast('Plan → Work income updated from W-2s.'); break; }
      case 'dsNew': dsNew(); break;
      case 'dsRename': dsRename(a.dataset.id); break;
      case 'dsUnload': dsUnload(a.dataset.id); break;
      case 'dsLoadNew': asNewDataset = true; $('#jsonIn').click(); break;
      case 'aiExportDl': aiExport('download'); break;
      case 'allocModel': { const A0 = plan().allocation; A0.stockNow = +a.dataset.s; A0.alt = +a.dataset.a; if (A0.mode === 'current') A0.mode = 'target'; save(); render(); break; }
      case 'resetDerived': { const k0 = a.dataset.k; if (k0 === 'rothBasis') delete plan().rothBasisEdited; else delete cur().manual[k0 + 'Edited']; save(); render(); toast('Back to the automatic value.'); break; }
      case 'spMonth': state.spFilter = { ...(state.spFilter || {}), month: a.dataset.m, kind: 'spending' }; save(); render(); setTimeout(() => { const el = $('#spTx'); if (el && el.scrollIntoView) el.scrollIntoView(); }, 0); break;
      case 'spAcct': SPD().acctView = a.dataset.a || null; state.spAcctMethod = ''; save(); render(); setTimeout(() => { const el = $('#spAcct'); if (el && el.scrollIntoView) el.scrollIntoView(); }, 0); break;
      case 'spUndup': { const D = SPD(); const x = D.txns.find((y) => y.id === a.dataset.id); if (x) { x.kind = x.kindBeforeDup || 'spend'; x.userKind = true; save(); render(); } break; }
      case 'spDelAcct': { const D = SPD(); const a2 = a.dataset.a; const n = D.txns.filter((t) => t.acct === a2).length;
        if (!confirm(`Delete “${a2}” and all ${n} of its transactions from this app?\n\nYour bank files aren't touched; you can re-import them later. This can't be undone (except by loading an earlier backup).`)) break;
        D.txns = D.txns.filter((t) => t.acct !== a2); D.imports = D.imports.filter((x) => x.acct !== a2); delete D.acctTypes[a2]; if (D.acctView === a2) D.acctView = null;
        spDedupe(D); save(); render(); toast(`Deleted ${a2} (${n} transactions).`); break; }
      case 'spRenameAcct': { const D = SPD(); const a2 = a.dataset.a; const nn = (prompt(`New name for “${a2}” (use an existing name to merge the two):`, a2) || '').trim(); if (!nn || nn === a2) break;
        for (const t of D.txns) if (t.acct === a2) t.acct = nn; for (const x of D.imports) if (x.acct === a2) x.acct = nn; if (!D.acctTypes[nn]) D.acctTypes[nn] = D.acctTypes[a2]; delete D.acctTypes[a2]; if (D.acctView === a2) D.acctView = nn;
        spReclass(D, nn); spDedupe(D); save(); render(); toast(`Renamed to ${nn}.`); break; }
      case 'spMethod': state.spAcctMethod = a.dataset.m || ''; save(); render(); break;
      case 'spDir': state.spAcctDir = a.dataset.d; save(); render(); break;
      case 'spChartView': SPD().chartView = a.dataset.v; save(); render(); break;
      case 'spTableView': SPD().tableView = a.dataset.v; save(); render(); break;
      case 'spCat': { const D = SPD(); const yv = D.yearView; state.spFilter = { ...(state.spFilter || {}), cat: a.dataset.c, month: '', kind: 'spending', year: /^\d{4}$/.test(yv || '') ? yv : '' }; save(); render(); setTimeout(() => { const el = $('#spTx'); if (el && el.scrollIntoView) el.scrollIntoView(); }, 0); break; }
      case 'planSeg': state[a.dataset.k] = a.dataset.v; save(); render(); break;
      case 'spSource': SPD().source = a.dataset.s; save(); render(); break;
      case 'spYear': SPD().yearView = a.dataset.y; save(); render(); break;
      case 'spRule': { const D = SPD(); const t = D.txns.find((x) => x.id === a.dataset.id); if (!t) break; const key = merchantKey(t.desc); D.rules[key] = t.category; let n = 0; for (const x of D.txns) if (merchantKey(x.desc) === key && (x.kind === 'spend' || x.kind === 'refund')) { x.category = t.category; n++; } save(); render(); toast(`“${key}” → ${t.category} (${n} transactions, and future imports).`); break; }
      case 'spDel': { const D = SPD(); D.txns = D.txns.filter((x) => x.id !== a.dataset.id); save(); render(); break; }
      case 'spDelImp': { const D = SPD(); const im = D.imports[+a.dataset.i]; if (im && confirm(`Remove all ${im.added} transactions imported from ${im.file}?`)) { D.txns = D.txns.filter((x) => !(x.src === im.file && x.acct === im.acct)); D.imports.splice(+a.dataset.i, 1); save(); render(); } break; }
      case 'spFlip': { const D = SPD(); const im = D.imports[+a.dataset.i]; if (!im) break; for (const x of D.txns) if (x.src === im.file && x.acct === im.acct) { x.amount = -x.amount; if (x.kind === 'spend') { x.kind = im.isCard ? 'refund' : 'income'; if (x.kind === 'income') x.category = null; } else if (x.kind === 'income' || x.kind === 'refund') { x.kind = x.amount > 0 ? 'spend' : x.kind; x.category = x.category || P.categorize(x.desc); } } spMatchTransfers(); save(); render(); toast('Signs flipped for ' + im.file); break; }
      case 'spAdd': { const D = SPD(); const amt = P.money($('#spmA').value); const d = $('#spmD').value; if (!amt || !d) { toast('Enter a date and an amount.'); break; } const n = Math.max(1, +$('#spmR').value || 1);
        for (let i = 0; i < n; i++) { const dt = new Date(d + 'T12:00:00'); dt.setMonth(dt.getMonth() + i); const ds = dt.toISOString().slice(0, 10); D.txns.push({ id: `manual|${Date.now()}|${i}`, date: ds, desc: $('#spmT').value || 'Manual entry', amount: amt, category: $('#spmC').value, kind: 'spend', acct: 'Manual', src: 'manual', manual: true, oneTime: $('#spmO').checked }); }
        save(); render(); toast(n > 1 ? `Added ${n} monthly entries.` : 'Added.'); break; }
      case 'spToPlan': { const PJ = spProjection(spAgg()); if (!PJ) break; const mapped = {}; for (const [c, v] of Object.entries(PJ.proj)) { if (SP_MODELED.includes(c)) continue; const pc = SP_TO_PLAN[c] || 'Other discretionary'; mapped[pc] = (mapped[pc] || 0) + v; }
        const PL2 = plan(); if (!confirm(`Set ${Object.keys(mapped).length} spending categories in “${PL2.name}” from your projected ${PJ.year} spending (${k(Object.values(mapped).reduce((a, b) => a + b, 0))}/yr)? Matching categories with no spending are set to $0; your own custom categories are left as they are.`)) break;
        const targetsAll = new Set(Object.values(SP_TO_PLAN));
        for (const c of PL2.spending.categories) if (targetsAll.has(c.name) && (c.startAge === '' || c.startAge == null) && (c.endAge === '' || c.endAge == null) && !(c.name in mapped)) c.amount = 0; // no matching spending → $0
        for (const [n, v] of Object.entries(mapped)) { const ex = PL2.spending.categories.find((c) => c.name === n); const amt = Math.round(v / 100) * 100; if (ex) ex.amount = amt; else PL2.spending.categories.push({ name: n, amount: amt, kind: /Essentials|medical|Kids/.test(n) ? 'essential' : 'discretionary', startAge: '', endAge: '' }); }
        PL2.spending.categoriesDefault = false; save(); render(); toast('Plan spending updated from your actual spending.'); break; }
      case 'spToSettings': { const PJ = spProjection(spAgg()); if (!PJ) break; const v = Math.round(Object.entries(PJ.proj).filter(([c]) => !SP_MODELED.includes(c)).reduce((a, [, x]) => a + x, 0) / 1000) * 1000; state.settings.spending.annual = v; state.settings.spending.confirmed = true; save(); render(); toast(`Cash-buffer spending set to ${usd(v)}/yr.`); break; }
      case 'retFixW': { const r = state.taxReturns[a.dataset.y]; r.fields.wages = +a.dataset.v; r.edited = r.edited || {}; r.edited.wages = true; r.src.wages = 'computed: line 9 minus the other income lines'; save(); render(); toast('Wages set from total income.'); break; }
      case 'retMove': { const from = +a.dataset.y; const to = +(a.dataset.to || prompt(`Move the ${from} return to which tax year?`, String(from - 1))); if (!to || to === from || to < 2000) break; const T = state.taxReturns;
        if (T[to] && !confirm(`There's already a ${to} return. Merge (lines from the ${from} entry fill only what ${to} is missing)?`)) break;
        if (T[to]) { for (const [k2, v] of Object.entries(T[from].fields)) if (T[to].fields[k2] == null) { T[to].fields[k2] = v; T[to].src[k2] = T[from].src[k2]; } T[to].files = [...new Set([...(T[to].files || []), ...(T[from].files || [])])]; } else T[to] = T[from];
        delete T[from]; state.retYear = to; save(); render(); toast(`Moved to ${to}.`); break; }
      case 'retYear': state.retYear = +a.dataset.y; save(); render(); break;
      case 'retAdd': { const y = +prompt('Tax year to enter by hand:', String(new Date().getFullYear() - 1)); if (y > 2000) { state.taxReturns = state.taxReturns || {}; state.taxReturns[y] = state.taxReturns[y] || { fields: {}, src: {}, files: [], edited: {} }; state.retYear = y; save(); render(); } break; }
      case 'retDel': if (confirm(`Remove the ${a.dataset.y} return from the app?`)) { delete state.taxReturns[a.dataset.y]; save(); render(); } break;
      case 'retApplyCF': { const v = +state.taxReturns[a.dataset.y].fields.capLossCarryOut || 0; cur().manual.lossCarryforward = v; save(); render(); toast(`Quarterly Review now offsets this year's gains with ${usd(v)} of carried-forward losses.`); break; }
      case 'retApplyRoth': { const v = +state.taxReturns[a.dataset.y].fields.rothBasis || 0; state.plans.forEach((p) => (p.rothBasis = v)); save(); render(); toast(`Roth contribution basis of ${usd(v)} set in all plans.`); break; }
      case 'writeSnaps': (async () => { let n = 0; for (const sn of state.snapshots) if (await writeSnapshotFile(sn)) n++; await autoWrite(); toast(n ? `${n} snapshot file(s) + auto-save written to ${AUTO.dir.name}.` : 'Turn on auto-save to a data folder first.'); })(); break;
      case 'lockNow': sessionPw = null; AUTO.active = false; autoStatus(); toast('Password forgotten for this session. Auto-save paused.'); break;
      case 'importData': $('#jsonIn').click(); break;
      case 'saveSnap': saveSnapshotDialog(); break;
      case 'restoreSnap': { const s = state.snapshots.find((x) => x.id === a.dataset.id); if (s && confirm(`Replace the working copy with the ${s.asOf} snapshot? Unsaved edits will be lost.`)) { state.working = clone(s.data); state.dirty = false; state.tab = 'review'; save(); render(); } break; }
      case 'delSnap': { const s = state.snapshots.find((x) => x.id === a.dataset.id); if (s && confirm(`Delete the ${s.asOf} snapshot?`)) { state.snapshots = state.snapshots.filter((x) => x !== s); save(); render(); } break; }
      case 'noteSnap': { const s = state.snapshots.find((x) => x.id === a.dataset.id); const n = prompt('Note for this snapshot:', s.note || ''); if (n != null) { s.note = n; save(); render(); } break; }
      case 'resummarize': state.snapshots.forEach((s) => (s.summary = E.snapshotSummary(s.data, state.settings))); save(); render(); toast('Snapshot summaries recalculated with current settings.'); break;
      case 'addAcct': {
        const tpl = a.dataset.tpl;
        const T = { brokerage: ['New brokerage account', 'taxable', 'us_stock'], ira: ['New IRA', 'pretax', 'us_stock'], roth: ['New Roth IRA', 'roth', 'us_stock'], edu: ['529 college savings', 'edu', 'balanced'], cash: ['Savings / CDs', 'taxable', 'bank'], crypto: ['Bitcoin', 'taxable', 'crypto'], eth: ['Ethereum', 'taxable', 'crypto'], gold: ['Gold', 'taxable', 'gold'], silver: ['Silver', 'taxable', 'gold'], home: ['Home', 'property', 'real_estate'], loan: ['Loan', 'liability', 'other'], card: ['Credit card', 'liability', 'other'], venture: ['Venture / private investment', 'taxable', 'private'], hsa: ['HSA', 'hsa', 'us_stock'] }[tpl] || ['New account', 'taxable', 'us_stock'];
        W.accounts.push({ key: 'manual:' + Date.now(), institution: 'Manual', name: T[0], taxType: T[1], debtKind: tpl === 'card' ? 'card' : tpl === 'loan' ? 'loan' : undefined, owner: RETIRE(T[1]) ? 'self' : 'joint', ownerGuessed: true, asOf: W.asOf, manual: true, holdings: [{ symbol: tpl === 'crypto' ? 'BTC' : tpl === 'eth' ? 'ETH' : tpl === 'gold' ? 'XAU' : tpl === 'silver' ? 'XAG' : tpl === 'loan' ? 'LOAN' : tpl === 'card' ? 'CARD' : tpl === 'venture' ? 'PRIVATE' : '', desc: T[0], qty: null, price: null, value: 0, cost: null, assetClass: T[2], assetClassSet: true, priceRef: { crypto: 'btc', eth: 'eth', gold: 'xau', silver: 'xag' }[tpl] || '' }] });
        state.dirty = true; state.openAcct = W.accounts[W.accounts.length - 1].key; save(); render(); break;
      }
      case 'delAcct': if (confirm('Remove this account from the working copy?')) { W.accounts = W.accounts.filter((x) => x.key !== a.dataset.key); state.dirty = true; save(); render(); } break;
      case 'addHolding': acct().holdings.push({ symbol: '', desc: '', qty: null, price: null, value: 0, cost: null, assetClass: 'us_stock', edited: true }); state.openAcct = a.dataset.key; state.dirty = true; save(); render(); break;
      case 'delHolding': acct().holdings.splice(+a.dataset.hi, 1); state.openAcct = a.dataset.key; state.dirty = true; save(); render(); break;
      case 'addProp': {
        const kind = a.dataset.kind; W.realEstate = W.realEstate || [];
        const nm = { primary: 'Primary home', vacation: 'Vacation home', rental: 'Long-term rental', str: 'Vacation rental' }[kind];
        W.realEstate.push({ id: 'r' + Date.now(), name: nm, kind, value: 0, basis: null, purchaseYear: null, appreciation: kind === 'rental' ? 1 : 1, propertyTax: 0, insurance: 0, hoa: 0, maintAmt: 0, rentMonthly: 0, vacancyPct: 5, mgmtPct: kind === 'str' ? 20 : 8, buildingPct: 60, nightlyRate: 0, occupancyPct: 50, avgStay: 4, personalDays: 0, platformPct: kind === 'str' ? 3 : 0, cleaning: 0, utilities: 0, supplies: 0, mtgBalance: 0, mtgRate: null, mtgPayment: null, mtgYearsLeft: null, mtgExtra: 0 });
        if (L.isRental(kind)) { state.tab = 'rentals'; }
        state.openProp = W.realEstate[W.realEstate.length - 1].id; state.dirty = true; save(); render(); break;
      }
      case 'quickAddProp': {
        const val = +$('#qaValue').value || 0, mtg = +$('#qaMtg').value || 0, kind = $('#qaKind').value;
        if (!val) { toast('Enter the current value first.'); break; }
        W.realEstate = W.realEstate || [];
        W.realEstate.push({ id: 'r' + Date.now(), name: $('#qaName').value || { primary: 'Primary home', vacation: 'Vacation home', rental: 'Rental property' }[kind], kind, value: val, basis: null, purchaseYear: null, appreciation: 1, propertyTax: 0, insurance: 0, hoa: 0, maintAmt: Math.round(val * 0.01), rentMonthly: 0, vacancyPct: 5, mgmtPct: 0, mtgBalance: mtg, mtgRate: null, mtgPayment: null, mtgYearsLeft: null, mtgExtra: 0 });
        state.dirty = true; save(); render(); toast('Property added. Click Details to add costs, rent, and the mortgage rate and term.'); break;
      }
      case 'quickAddBuy': {
        const price = +$('#qbPrice').value || 0, yr = +$('#qbYear').value, kind = $('#qbKind').value;
        if (!price || !yr) { toast('Enter a year and a price.'); break; }
        PL.purchases.push({ name: $('#qbName').value || 'Future ' + KIND_LABEL[kind].toLowerCase(), kind, year: yr, price, downPct: $('#qbDown').value === '' ? 20 : +$('#qbDown').value, rate: 6.5, termYears: 30, propertyTax: Math.round(price * 0.011), insurance: Math.round(price * 0.003), hoa: 0, maintAmt: Math.round(price * 0.01), rentMonthly: 0, vacancyPct: 5, mgmtPct: 0, appreciation: 1, sellYear: '', sellCostPct: 6, costsInSpending: false });
        state.openProp = 'buy:' + (PL.purchases.length - 1); save(); render(); toast(`Added to plan "${PL.name}". Defaults: 6.5% 30-yr mortgage, 1.1% property tax. Edit them in Details.`); break;
      }
      case 'delProp': if (confirm('Remove this property?')) { W.realEstate = (W.realEstate || []).filter((x) => x.id !== a.dataset.id); state.dirty = true; save(); render(); } break;
      case 'openProp': state.openProp = state.openProp === a.dataset.id ? null : a.dataset.id; render(); break;
      case 'openAcct': state.openAcct = state.openAcct === a.dataset.key ? null : a.dataset.key; render(); break;
      case 'commitImport': commitImport(); break;
      case 'clearImport': pending = []; render(); break;
      case 'clearBrowser': clearBrowserData(); break;
      case 'resetAll': if (confirm(`Reset "${dsCur().name}"? Its snapshots, plans and settings in this browser are erased and it starts over with the starter household. Other data sets and files in your data folder aren't touched.`)) { localStorage.removeItem(LS); state = load(); render(); } break;
      case 'spendFromPlan': state.settings.spending.source = 'plan'; save(); render(); toast('Annual spending now comes from the Plan.'); break;
      case 'confirmAssump': state.settings.spending.confirmed = true; state.settings.household.agesConfirmed = true; save(); render(); break;
      // planner
      case 'newPlan': { const p = L.newPlan(state.settings, 'Plan ' + (state.plans.length + 1)); state.plans.push(p); state.activePlanId = p.id; save(); render(); break; }
      case 'dupPlan': { const p = clone(PL); p.id = 'p' + Date.now(); p.name = PL.name + ' (copy)'; state.plans.push(p); state.activePlanId = p.id; save(); render(); break; }
      case 'delPlan': if (state.plans.length > 1 && confirm(`Delete plan "${PL.name}"?`)) { state.plans = state.plans.filter((p) => p !== PL); state.activePlanId = state.plans[0].id; save(); render(); } break;
      case 'renamePlan': { const n = prompt('Plan name:', PL.name); if (n) { PL.name = n; save(); render(); } break; }
      case 'selPlan': state.activePlanId = a.dataset.id; save(); render(); break;
      case 'addItem': {
        const list = a.dataset.list; const age0 = (cur().asOf.slice(0, 4) | 0) + 1 - state.settings.household.birthYearSelf;
        const T = { work: { who: 'self', name: 'Job', salary: 150000, growth: 1, pretax401k: 24500, match: 0, rothContrib: 0, startAge: '', endAge: '' }, purchases: { name: 'Future home', kind: 'vacation', year: (cur().asOf.slice(0, 4) | 0) + 3, price: 1000000, downPct: 20, rate: 6.5, termYears: 30, propertyTax: 12000, insurance: 3000, hoa: 0, maintAmt: 10000, rentMonthly: 0, vacancyPct: 5, mgmtPct: 0, appreciation: 1, sellYear: '' }, expenses: { name: 'New expense', amount: 10000, startYear: '', endYear: '', startAge: age0, endAge: age0 + 4, real: true, from529: false }, incomes: { name: 'New income', amount: 20000, startAge: age0, endAge: age0 + 9, real: true, taxable: 'ordinary' }, events: { name: 'One-time event', year: (cur().asOf.slice(0, 4) | 0) + 2, amount: -50000, taxable: 'none', basis: 0, real: true, propertyDelta: 0, debtDelta: 0 } };
        const yNow = cur().asOf.slice(0, 4) | 0; const ageNow = yNow - +state.settings.household.birthYearSelf;
        T.moves = { id: 'mv' + Date.now().toString(36), name: 'Retirement home', age: Math.max(ageNow + 1, 75), year: '', state: '', spendPct: 0, acaBenchmark: '', sellHome: false, newHomePrice: '', newHomeDownPct: '', newHomeTaxPct: '' };
        T.inheritances = { name: 'Parents', age: ageNow + 10, year: '', amount: 250000, kind: 'cash' };
        T.spendChanges = { name: 'Kids leave home', age: ageNow + 10, year: '', pct: -15, endYear: '' };
        T['spending.categories'] = { name: 'New category', amount: 10000, kind: 'discretionary', startAge: '', endAge: '' };
        getPath(PL, list).push(T[list]); if (list === 'spending.categories') PL.spending.categoriesDefault = false; save(); render(); break;
      }
      case 'delItem': getPath(PL, a.dataset.list).splice(+a.dataset.i, 1); save(); render(); break;
      case 'runMax': { $('#maxOut').textContent = 'Running about 3,000 simulations…'; setTimeout(() => { const init = L.initFromSnapshot(cur(), state.settings, window.__an); const r = L.maxSpending(PL, init, state.settings, (+a.dataset.target || 90) / 100, 250); PL._max = { ...r, target: +a.dataset.target || 90, at: Date.now() }; save(); render(); }, 30); break; }
      case 'runCompare': { $('#cmpOut').textContent = 'Running…'; setTimeout(() => { const init = L.initFromSnapshot(cur(), state.settings, window.__an); state._cmp = state.plans.map((p) => { const mc = L.monteCarlo(p, init, state.settings, 400); const bt = L.backtest(p, init, state.settings); const d = L.deterministic(p, init, state.settings); return { id: p.id, name: p.name, mc: mc.success, bt: bt.success, medEnd: mc.medianEnd, p10End: mc.p10End, detEnd: d.endReal, tax: d.totals.tax, conv: d.totals.conv, failed: d.failed }; }); render(); }, 30); break; }
      case 'clearPL': PL.pl = null; save(); render(); break;
      case 'nwZoom': state.nwZoom = { ...(state.nwZoom || {}), mode: a.dataset.m }; save(); render(); break;
      case 'nwZoomReset': state.nwZoom = { ...(state.nwZoom || {}), from: '', to: '' }; save(); render(); break;
      case 'clearPLJ': state.plImport = null; save(); render(); break;
      case 'clearPLI': PL.plInc = null; save(); render(); break;
      case 'plPlan': state.plPlanIdx = +a.dataset.i; save(); render(); break;
      case 'loadPL': $('#plIn').click(); break;
      case 'skYear': { const ys = planResults(window.__an).det.rows.map((r) => r.year); let y = +state.sankeyYear || ys[0]; y = Math.min(ys[ys.length - 1], Math.max(ys[0], y + +a.dataset.d)); state.sankeyYear = y; save(); render(); break; }
      case 'runOpt': { $('#optOut').textContent = 'Fixed returns + historical backtest for ' + L.STRATEGIES.length + ' strategies…';
        setTimeout(() => { const R = planResults(window.__an); const rows = L.compareStrategies(PL, R.init, state.settings);
          $('#optOut').textContent = 'Monte Carlo scenarios (same 200 market paths for every strategy)…';
          setTimeout(() => { const mc = L.compareStrategiesMC(PL, R.init, state.settings); state._opt = { key: planCache.key, rows, mc, ranAt: new Date().toLocaleTimeString() }; render(); }, 30); }, 30); break; }
      case 'optScen': state.optScen = a.dataset.s; save(); render(); break;
      case 'applyStrat': { const st = L.STRATEGIES.find((x) => x.id === a.dataset.id); if (st && st.tax) { PL.tax = { ...PL.tax, ...st.tax, convertStart: '', convertEnd: 74 }; save(); render(); toast(`Applied "${st.name}" to ${PL.name}.`); } break; }
      case 'anaView': state.anaView = a.dataset.v; save(); render(); break;
      case 'anaYear': state.anaYear = a.dataset.y ? +a.dataset.y : null; save(); render(); break;
      case 'anaYearStep': { const ys = planResults(window.__an).det.rows.map((r) => r.year); const i = ys.indexOf(state.anaYear); state.anaYear = ys[Math.max(0, Math.min(ys.length - 1, i + +a.dataset.d))]; save(); render(); break; }
      case 'refreshMkt': refreshMarket(true); break;
      case 'testMkt': refreshMarket(true, true); break;
      case 'recalc': planCache = { key: null }; state._forceRecalc = true; render(); toast('Model recalculated.'); break;
      case 'realToggle': state.planReal = !state.planReal; save(); render(); break;
    }
  });

  // ---------- REVIEW ----------
  // ---------- live market data (opt-in; sends only ticker symbols, never your data) ----------
  // Each quote tries a chain of sources; the first that answers wins. "Test price sources" shows exactly what failed and why.
  const MKT = [
    { k: 'spx', name: 'S&P 500', idx: { cboe: '_SPX', yahoo: '^GSPC', fmp: '^GSPC', td: 'SPX' }, etf: 'SPY', dec: 2 },
    { k: 'dji', name: 'Dow Jones', idx: { cboe: '_DJX', cboeMult: 100, yahoo: '^DJI', fmp: '^DJI', td: 'DJI' }, etf: 'DIA', dec: 2 },
    { k: 'ndx', name: 'Nasdaq-100', idx: { cboe: '_NDX', yahoo: '^NDX', fmp: '^NDX', td: 'NDX' }, etf: 'QQQ', dec: 2 },
    { k: 'xau', name: 'Gold (per troy oz)', metal: 'XAU', cg: 'pax-gold', dec: 2 },
    { k: 'xag', name: 'Silver (per troy oz)', metal: 'XAG', cg: 'kinesis-silver', dec: 2 },
    { k: 'btc', name: 'Bitcoin', metal: 'BTC', cg: 'bitcoin', cb: 'BTC-USD', dec: 0 },
    { k: 'eth', name: 'Ethereum', metal: 'ETH', cg: 'ethereum', cb: 'ETH-USD', dec: 0 },
  ];
  // external 1-month charts for manual checking (open in a new tab)
  const EXT = {
    spx: [['Google Finance', 'https://www.google.com/finance/quote/.INX:INDEXSP?window=1M'], ['Yahoo', 'https://finance.yahoo.com/quote/%5EGSPC/chart/?range=1mo']],
    dji: [['Google Finance', 'https://www.google.com/finance/quote/.DJI:INDEXDJX?window=1M'], ['Yahoo', 'https://finance.yahoo.com/quote/%5EDJI/chart/?range=1mo']],
    ndx: [['Google Finance', 'https://www.google.com/finance/quote/NDX:INDEXNASDAQ?window=1M'], ['Yahoo', 'https://finance.yahoo.com/quote/%5ENDX/chart/?range=1mo']],
    xau: [['TradingView', 'https://www.tradingview.com/symbols/XAUUSD/'], ['Kitco', 'https://www.kitco.com/charts/gold']],
    xag: [['TradingView', 'https://www.tradingview.com/symbols/XAGUSD/'], ['Kitco', 'https://www.kitco.com/charts/silver']],
    btc: [['Google Finance', 'https://www.google.com/finance/quote/BTC-USD?window=1M'], ['CoinGecko', 'https://www.coingecko.com/en/coins/bitcoin']],
    eth: [['Google Finance', 'https://www.google.com/finance/quote/ETH-USD?window=1M'], ['CoinGecko', 'https://www.coingecko.com/en/coins/ethereum']],
  };
  const extLinks = (k) => (EXT[k] || []).map(([n, u], i) => `<a href="${u}" target="_blank" rel="noopener noreferrer" title="Open the last month on ${n}">${i === 0 ? '↗ ' : ''}${n}</a>`).join(' · ');
  const PRICE_REFS = [['', 'Statement / manual'], ['xau', 'Gold spot × oz'], ['xag', 'Silver spot × oz'], ['btc', 'Bitcoin × coins'], ['eth', 'Ethereum × coins'], ['sheet', 'Ticker price from my Google Sheet × shares']];
  const REF_UNIT = { xau: 'oz', xag: 'oz', btc: 'BTC', eth: 'ETH', sheet: 'shares' };
  let mktBusy = false, mktTried = false;
  async function tfetch(url, ms = 8000, asText = false) {
    const c = new AbortController(); const t = setTimeout(() => c.abort(), ms); const t0 = performance.now();
    try { const r = await fetch(url, { signal: c.signal, credentials: 'omit', referrerPolicy: 'no-referrer' }); if (!r.ok) { const e = new Error('HTTP ' + r.status); e.status = r.status; throw e; } return asText ? await r.text() : await r.json(); }
    catch (e) { if (e.name === 'AbortError') e.message = 'timed out after ' + Math.round(ms / 1000) + 's'; else if (e.name === 'TypeError' || /failed to fetch|load failed|networkerror/i.test(e.message)) e.message = 'blocked before reaching the server (browser CORS policy, an ad/tracker blocker such as Brave Shields, or a VPN/company network filter)'; else if (e.status === 401 || e.status === 402 || e.status === 403) e.message += ': the API key is missing, wrong, or this symbol isn’t on your plan'; else if (e.status === 429) e.message += ': rate limit, try again later'; e.ms = Math.round(performance.now() - t0); throw e; }
    finally { clearTimeout(t); }
  }
  const host = (u) => u.replace(/^https?:\/\/([^/]+).*/, '$1');
  // source list for one quote: [label, url, parse(json) → {price, prev, yearHigh, t, proxy}]
  // Google Sheets: a sheet you own with GOOGLEFINANCE() formulas, published to the web as CSV (free, reliable, ~20-min delay)
  let sheetCache = null;
  // accept any Google Sheets link: published CSV, published web page, or a normal edit/share link
  function sheetCsvUrl(u) {
    u = (u || '').trim(); if (!u) return u;
    let m;
    if ((m = u.match(/docs\.google\.com\/spreadsheets\/d\/e\/([^/]+)\/pub(html)?/))) { const gid = (u.match(/[?&#]gid=(\d+)/) || [])[1]; return `https://docs.google.com/spreadsheets/d/e/${m[1]}/pub?output=csv${gid ? '&gid=' + gid + '&single=true' : ''}`; }
    if ((m = u.match(/docs\.google\.com\/spreadsheets\/d\/([a-zA-Z0-9_-]{20,})/))) { const gid = (u.match(/[?&#]gid=(\d+)/) || [])[1]; return `https://docs.google.com/spreadsheets/d/${m[1]}/gviz/tq?tqx=out:csv${gid ? '&gid=' + gid : ''}`; }
    return u;
  }
  function sheetRow(csv, key) {
    if (/^\s*</.test(csv)) throw new Error(/accounts\.google|signin|ServiceLogin/i.test(csv) ? 'Google asked for a sign-in: publish the sheet (File → Share → Publish to web) or set sharing to “Anyone with the link”' : 'the link returned a web page, not CSV: in Publish to web choose “Comma-separated values (.csv)”');
    const rows = csv.trim().split(/\r?\n/).map((l) => (l.match(/("([^"]|"")*"|[^,]*)(,|$)/g) || []).map((c) => c.replace(/,$/, '').replace(/^"|"$/g, '').replace(/""/g, '"').trim()));
    let r = null; for (const row of rows) { const i = row.findIndex((c) => (c || '').toLowerCase() === key); if (i >= 0) { r = row.slice(i); break; } }
    if (!r) throw new Error(`row "${key}" not found; first line of the sheet is: ${(csv.split(/\r?\n/)[0] || '').slice(0, 80)}`);
    if (/#N\/A|#ERROR|#REF|#VALUE|Loading/i.test(r[1] || '')) throw new Error(`the sheet shows ${r[1]} for ${key}: Google couldn't load that quote; check the formula in that row`);
    const n = (v) => { const x = parseFloat(String(v || '').replace(/[$,\s]/g, '')); return isFinite(x) ? x : null; };
    const price = n(r[1]); if (!price) throw new Error(`no price in sheet row "${key}" (${r[1] || 'blank'})`);
    return { price, prev: n(r[2]), yearHigh: n(r[3]), ath: n(r[4]), t: r[5] && !isNaN(Date.parse(r[5])) ? new Date(r[5]).toISOString() : new Date().toISOString(), hist: r.slice(6).map(n).filter((x) => x != null && x > 0) };
  }
  function sourcesFor(m, Q) {
    const out = [];
    if (Q.prefer === 'finnhub' && Q.fhKey && m.idx) out.push([`Finnhub (${m.etf} ETF)`, `https://finnhub.io/api/v1/quote?symbol=${m.etf}&token=${encodeURIComponent(Q.fhKey)}`, (j) => { if (!j || !j.c) throw new Error('no data (check key)'); return { price: +j.c, prev: +j.pc || null, yearHigh: null, t: j.t ? new Date(j.t * 1000).toISOString() : new Date().toISOString(), proxy: m.etf }; }]);
    if (Q.sheetUrl && Q.prefer !== 'finnhub') out.push(['Google Sheets (GOOGLEFINANCE)', sheetCsvUrl(Q.sheetUrl), (csv) => sheetRow(csv, m.k), 'sheet']);
    if (m.metal) {
      out.push(['gold-api.com', `https://api.gold-api.com/price/${m.metal}`, (j) => ({ price: +j.price, t: j.updatedAt })]);
      out.push(['CoinGecko' + (m.k === 'btc' ? '' : ` (${m.cg} token ≈ 1 oz)`), `https://api.coingecko.com/api/v3/simple/price?ids=${m.cg}&vs_currencies=usd&include_24hr_change=true&include_last_updated_at=true`, (j) => { const x = j[m.cg]; return { price: +x.usd, prev: x.usd_24h_change != null ? x.usd / (1 + x.usd_24h_change / 100) : null, t: x.last_updated_at ? new Date(x.last_updated_at * 1000).toISOString() : null }; }]);
      if (m.cb) out.push(['Coinbase', `https://api.coinbase.com/v2/prices/${m.cb}/spot`, (j) => ({ price: +j.data.amount, t: new Date().toISOString() })]);
      return out;
    }
    // Cboe's public delayed-quote feed (no key, ~15-min delay). Dow comes from DJX (= Dow ÷ 100).
    const mult = m.idx.cboeMult || 1;
    out.push([`Cboe delayed quotes${mult > 1 ? ' (DJX × 100)' : ''}`, `https://cdn.cboe.com/api/global/delayed_quotes/quotes/${m.idx.cboe}.json`, (j) => { const d = j.data || {}; return { price: +d.current_price * mult, prev: d.prev_day_close ? +d.prev_day_close * mult : null, t: d.last_trade_time ? new Date(d.last_trade_time + '-05:00').toISOString() : (j.timestamp ? new Date(j.timestamp.replace(' ', 'T') + 'Z').toISOString() : null) }; }]);
    const yp = (j) => { const mt = j.chart.result[0].meta; return { price: +mt.regularMarketPrice, prev: +mt.chartPreviousClose || +mt.previousClose || null, yearHigh: +mt.fiftyTwoWeekHigh || null, t: new Date(mt.regularMarketTime * 1000).toISOString() }; };
    out.push(['Yahoo Finance', `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(m.idx.yahoo)}?range=5d&interval=1d`, yp]);
    out.push(['Yahoo Finance (alt)', `https://query2.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(m.idx.yahoo)}?range=5d&interval=1d`, yp]);
    const fq = (j) => { const q = Array.isArray(j) ? j[0] : j; if (!q || q.price == null) throw new Error(j && j['Error Message'] ? j['Error Message'] : 'no data'); return { price: +q.price, prev: q.previousClose != null ? +q.previousClose : null, yearHigh: +q.yearHigh || null, t: q.timestamp ? new Date(q.timestamp * 1000).toISOString() : new Date().toISOString() }; };
    if (Q.fmpKey) { out.push(['FinancialModelingPrep', `https://financialmodelingprep.com/stable/quote?symbol=${encodeURIComponent(m.idx.fmp)}&apikey=${encodeURIComponent(Q.fmpKey)}`, fq]);
      out.push([`FinancialModelingPrep (${m.etf} ETF)`, `https://financialmodelingprep.com/stable/quote?symbol=${m.etf}&apikey=${encodeURIComponent(Q.fmpKey)}`, (j) => ({ ...fq(j), proxy: m.etf })]); }
    const tq = (j) => { if (j.status === 'error' || j.close == null) throw new Error(j.message || 'no data'); return { price: +j.close, prev: +j.previous_close || null, yearHigh: +(j.fifty_two_week && j.fifty_two_week.high) || null, t: j.timestamp ? new Date(j.timestamp * 1000).toISOString() : new Date().toISOString() }; };
    if (Q.fhKey) out.push([`Finnhub (${m.etf} ETF)`, `https://finnhub.io/api/v1/quote?symbol=${m.etf}&token=${encodeURIComponent(Q.fhKey)}`, (j) => { if (!j || !j.c) throw new Error('no data (check key)'); return { price: +j.c, prev: +j.pc || null, yearHigh: null, t: j.t ? new Date(j.t * 1000).toISOString() : new Date().toISOString(), proxy: m.etf }; }]);
    if (Q.tdKey) { out.push(['Twelve Data', `https://api.twelvedata.com/quote?symbol=${m.idx.td}&apikey=${encodeURIComponent(Q.tdKey)}`, tq]);
      out.push([`Twelve Data (${m.etf} ETF)`, `https://api.twelvedata.com/quote?symbol=${m.etf}&apikey=${encodeURIComponent(Q.tdKey)}`, (j) => ({ ...tq(j), proxy: m.etf })]); }
    return out;
  }
  async function quoteOne(m, Q, log) {
    let last = null;
    for (const [label, url, parse, kind] of sourcesFor(m, Q)) {
      const t0 = performance.now();
      try { const raw = kind === 'sheet' ? await (sheetCache = sheetCache || tfetch(url + (url.includes('?') ? '&' : '?') + '_=' + Date.now(), 10000, true)) : await tfetch(url); const q = parse(raw); if (!(q.price > 0)) throw new Error('no price in response'); log && log.push({ m: m.name, src: label, host: host(url), ok: true, val: q.price, ms: Math.round(performance.now() - t0), proxy: q.proxy }); return { ...q, src: label }; }
      catch (e) { last = e; log && log.push({ m: m.name, src: label, host: kind === 'sheet' ? url.replace(/(\/d\/e?\/?)([^/]{6})[^/]*/, '$1$2…') : host(url), ok: false, err: e.message, ms: e.ms ?? Math.round(performance.now() - t0) }); }
    }
    throw new Error(m.metal ? (last ? last.message : 'no source') : (last ? last.message : 'no source'));
  }
  const SHEET_TEMPLATE = [
    ['key', 'price', 'prev', 'high52', 'ath', 'updated', 'history (filled daily by the script, oldest → newest)'],
    ['spx', '=GOOGLEFINANCE("INDEXSP:.INX","price")', '=GOOGLEFINANCE("INDEXSP:.INX","closeyest")', '=GOOGLEFINANCE("INDEXSP:.INX","high52")', '', '=TEXT(NOW(),"yyyy-mm-dd hh:mm")'],
    ['dji', '=GOOGLEFINANCE("INDEXDJX:.DJI","price")', '=GOOGLEFINANCE("INDEXDJX:.DJI","closeyest")', '=GOOGLEFINANCE("INDEXDJX:.DJI","high52")', '', '=TEXT(NOW(),"yyyy-mm-dd hh:mm")'],
    ['ndx', '=GOOGLEFINANCE("INDEXNASDAQ:NDX","price")', '=GOOGLEFINANCE("INDEXNASDAQ:NDX","closeyest")', '=GOOGLEFINANCE("INDEXNASDAQ:NDX","high52")', '', '=TEXT(NOW(),"yyyy-mm-dd hh:mm")'],
    ['xau', '=GOOGLEFINANCE("CURRENCY:XAUUSD")', '', '', '', '=TEXT(NOW(),"yyyy-mm-dd hh:mm")'],
    ['xag', '=GOOGLEFINANCE("CURRENCY:XAGUSD")', '', '', '', '=TEXT(NOW(),"yyyy-mm-dd hh:mm")'],
    ['btc', '=GOOGLEFINANCE("CURRENCY:BTCUSD")', '', '', '', '=TEXT(NOW(),"yyyy-mm-dd hh:mm")'],
    ['eth', '=GOOGLEFINANCE("CURRENCY:ETHUSD")', '', '', '', '=TEXT(NOW(),"yyyy-mm-dd hh:mm")'],
    ['gld', '=GOOGLEFINANCE("GLD","price")', '=GOOGLEFINANCE("GLD","closeyest")', '', '', '=TEXT(NOW(),"yyyy-mm-dd hh:mm")'],
    ['ibit', '=GOOGLEFINANCE("IBIT","price")', '=GOOGLEFINANCE("IBIT","closeyest")', '', '', '=TEXT(NOW(),"yyyy-mm-dd hh:mm")'],
  ].map((r) => r.join('\t')).join('\n');
  function autoPriceRef(h) {
    const t = `${h.symbol || ''} ${h.desc || ''}`.toUpperCase();
    if (/^(BTC|XBT)\b|\bBITCOIN\b/.test(t) && !/\b(IBIT|FBTC|GBTC|BITB|ARKB|BITO|ETF|TRUST)\b/.test(t)) return 'btc';
    if (/^ETH\b|\bETHEREUM\b|\bETHER\b/.test(t) && !/\b(ETHA|FETH|ETHE|ETF|TRUST)\b/.test(t)) return 'eth';
    if (/^XAU\b|GOLD (BAR|COIN|BULLION|EAGLE)|\bKRUGERRAND\b|MAPLE LEAF GOLD|PHYSICAL GOLD/.test(t)) return 'xau';
    if (/^XAG\b|SILVER (BAR|COIN|BULLION|EAGLE)|PHYSICAL SILVER|JUNK SILVER/.test(t)) return 'xag';
    return '';
  }
  // make sure gold/silver/crypto holdings are valued from live prices whenever possible
  function ensureLivePricing(W) {
    const mk = (W.manual && W.manual.market) || {};
    for (const a of W.accounts || []) for (const h of a.holdings || []) {
      if (!['gold', 'crypto'].includes(h.assetClass) || h.priceRef || h.priceRefOff) continue;
      const ref = autoPriceRef(h); if (!ref) continue; h.priceRef = ref;
      if ((h.qty == null || h.qty === '') && +h.value > 0 && mk[ref]?.price) { h.qty = Math.round(h.value / mk[ref].price * 1e6) / 1e6; h.qtyEstimated = true; }
    }
  }
  // Google won't export historical GOOGLEFINANCE data, so this Apps Script records today's prices as plain values each day.
  const SHEET_SCRIPT = `// Extensions → Apps Script → paste → Save → select installDailyTrigger → Run (approve once)
const HIST_COL = 7;   // column G
const DAYS = 35;      // keep ~5 weeks (columns G..AO)

function recordDaily() {
  const sh = SpreadsheetApp.getActive().getSheets()[0];
  const n = sh.getLastRow() - 1; if (n < 1) return;
  const keys = sh.getRange(2, 1, n, 1).getValues();
  const prices = sh.getRange(2, 2, n, 1).getValues();
  const hist = sh.getRange(2, HIST_COL, n, DAYS).getValues();
  const out = hist.map((row, i) => {
    const p = prices[i][0];
    if (!keys[i][0] || typeof p !== 'number' || !(p > 0)) return row;
    const r = row.filter((v) => typeof v === 'number');
    r.push(p);
    while (r.length > DAYS) r.shift();
    while (r.length < DAYS) r.unshift('');
    return r;
  });
  sh.getRange(2, HIST_COL, n, DAYS).setValues(out);
  sh.getRange(1, HIST_COL).setValue('history (daily, oldest → newest)');
}

function installDailyTrigger() {
  ScriptApp.getProjectTriggers().forEach((t) => ScriptApp.deleteTrigger(t));
  ScriptApp.newTrigger('recordDaily').timeBased().everyDays(1).atHour(14).create(); // ~2 pm in the sheet's time zone, after the US close
  recordDaily(); // record today right away
}`;
  function revalueHoldings(W) {
    const mk = W.manual.market || {}; let n = 0;
    for (const a of W.accounts || []) for (const h of a.holdings || []) {
      if (!h.priceRef || h.qty == null || h.qty === '') continue;
      const q = h.priceRef === 'sheet' ? (mk.tickers || {})[(h.symbol || '').toLowerCase()] : mk[h.priceRef];
      if (!q || !q.price) continue; h.price = q.price; h.value = +h.qty * h.price; h.priceAsOf = q.t; n++;
    }
    return n;
  }
  let mktLogOpen = false; // source test results: open only right after you click “Test price sources” (not saved)
  async function refreshMarket(manualClick, diag) {
    const Q = state.settings.quotes; if (!Q.enabled && !manualClick) return; if (mktBusy) return; mktBusy = true; mktTried = true;
    const el = $('#mktStatus'); if (el) el.textContent = 'Fetching prices…';
    sheetCache = null; cboeHistCache = {};
    const W = cur(); const mk = (W.manual.market = W.manual.market || {}); const errs = []; const log = []; let ok = 0;
    await Promise.all(MKT.map(async (m) => { try { const q = await quoteOne(m, Q, log); mk[m.k] = { ...q, fetchedAt: new Date().toISOString() }; ok++; } catch (e) { errs.push(`${m.name}: ${e.message}`); } }));
    if (sheetCache) { try { const csv = await sheetCache; const keys = new Set(MKT.map((m) => m.k).concat(['key'])); mk.tickers = mk.tickers || {};
      for (const line of csv.trim().split(/\r?\n/)) { const k0 = (line.split(',')[0] || '').replace(/"/g, '').trim().toLowerCase(); if (!k0 || keys.has(k0)) continue; try { const r = sheetRow(csv, k0); mk.tickers[k0] = { price: r.price, prev: r.prev, t: r.t, src: 'Google Sheets' }; ok++; } catch (e) { } } } catch (e) { } }
    if (ok) mk.asOf = new Date().toISOString();
    const sp = mk.spx;
    if (sp?.price && !sp.proxy && (mk.athCheckedOn || '') !== new Date().toISOString().slice(0, 10)) {
      try { const h = await (cboeHistCache._SPX = cboeHistCache._SPX || tfetch('https://cdn.cboe.com/api/global/delayed_quotes/charts/historical/_SPX.json', 15000)); const hi = Math.max(...(h.data || []).map((r) => +r.high || 0)); if (hi > 1000) { mk.spxATH = Math.max(+mk.spxATH || 0, hi); mk.athCheckedOn = new Date().toISOString().slice(0, 10); log.push({ m: 'S&P 500 all-time high', src: 'Cboe daily history since 1975', host: 'cdn.cboe.com', ok: true, val: hi, ms: 0 }); } }
      catch (e) { log.push({ m: 'S&P 500 all-time high', src: 'Cboe daily history', host: 'cdn.cboe.com', ok: false, err: e.message, ms: e.ms || 0 }); }
    }
    if (sp?.price) {
      const athKey = sp.proxy ? 'spxProxyATH' : 'spxATH';
      mk[athKey] = Math.max(+mk[athKey] || 0, +sp.yearHigh || 0, +sp.ath || 0, sp.price);
      if (W.manual.spAuto !== false) W.manual.spDrawdownPct = Math.max(0, Math.round((mk[athKey] - sp.price) / mk[athKey] * 1000) / 10);
    }
    for (const m of MKT) if (mk[m.k]?.price && mk[m.k].fetchedAt && Date.now() - Date.parse(mk[m.k].fetchedAt) < 120e3) recordPrice(mk, m.k, mk[m.k].price, mk[m.k].proxy, mk[m.k].src);
    if (el) el.textContent = 'Loading 1-month charts…';
    await Promise.all(MKT.map((m) => fetchSeries(m, Q, mk, log).catch(() => {})));
    const n = revalueHoldings(W);
    mktBusy = false; state.mktErrors = errs; state.mktLog = log; state.mktLogAt = new Date().toISOString(); mktLogOpen = !!diag; delete state.showMktLog; if (ok) state.dirty = true; save(); render();
    if (manualClick) toast(!ok ? 'No prices could be fetched. See “Test price sources” for details.' : errs.length ? `Updated ${ok} of ${MKT.length}. ${n ? n + ' holding(s) revalued.' : ''}` : `Prices updated.${n ? ' ' + n + ' holding(s) revalued.' : ''}`);
  }
  function mktLogTable() {
    const L = state.mktLog || []; if (!L.length) return '';
    return `<details id="mktLog" ${mktLogOpen ? 'open' : ''}><summary><b>Source test results</b> <span class="sub">${new Date(state.mktLogAt).toLocaleTimeString()} · opened from ${esc(location.protocol === 'file:' ? 'a local file' : location.origin)} in ${esc((navigator.brave ? 'Brave' : /Edg\//.test(navigator.userAgent) ? 'Edge' : /Chrome\//.test(navigator.userAgent) ? 'Chrome' : /Safari\//.test(navigator.userAgent) ? 'Safari' : 'this browser'))}</span></summary>
      <table class="tbl"><thead><tr><th>Quote</th><th>Source</th><th>Server</th><th>Result</th><th class="n">ms</th></tr></thead><tbody>${L.map((r) => `<tr><td>${esc(r.m)}</td><td>${esc(r.src)}</td><td class="note">${esc(r.host)}</td><td class="${r.ok ? 'pos' : 'neg'}">${r.ok ? '✓ ' + r.val.toLocaleString() + (r.proxy ? ` (${r.proxy} ETF)` : '') : '✗ ' + esc(r.err)}</td><td class="n">${r.ms}</td></tr>`).join('')}</tbody></table>
      <p class="note">If every source says “blocked before reaching the server”, the browser or network is stopping the request: in Brave, click the lion icon and turn Shields off for this page; on a work laptop or VPN, the company filter may block these sites (try your home network). “HTTP 401/403” means the API key is wrong or the symbol needs a paid plan; the app then falls back to the ETF (SPY/DIA/QQQ) and computes the S&P drawdown from the ETF.</p></details>`;
  }
  // ---------- 1-month history per market (for dip charts) ----------
  // Sources, in order: your Google Sheet's history column (G onward), Cboe daily history (indexes), CoinGecko 30-day chart
  // (bitcoin, ether, and gold/silver-backed tokens), then the app's own record of prices it has fetched.
  let cboeHistCache = {};
  async function fetchSeries(m, Q, mk, log) {
    const today = new Date().toISOString().slice(0, 10);
    const cut = Date.now() - 32 * 864e5;
    const done = (pts, src) => { pts = pts.filter((p) => p[1] > 0).sort((a, b) => a[0] - b[0]); if (pts.length < 5) throw new Error('too few points'); mk.series = mk.series || {}; mk.series[m.k] = { pts, src, on: today }; log.push({ m: m.name + ' (1-month chart)', src, host: '', ok: true, val: pts.length + ' days', ms: 0 }); };
    // 1) Google Sheet history columns
    if (Q.sheetUrl && sheetCache) { try { const csv = await sheetCache; const r = sheetRow(csv, m.k); if (r.hist && r.hist.length >= 5) { const n = r.hist.length; return done(r.hist.map((v, i) => [Date.now() - (n - 1 - i) * 864e5, v]), 'Google Sheets (daily script)'); } } catch (e) { } }
    // cached today already?
    if (mk.series && mk.series[m.k] && mk.series[m.k].on === today && !mk.series[m.k].own && (!Q.fhKey || /Finnhub/.test(mk.series[m.k].src) || mk.fhCandleDenied === today)) return;
    // Finnhub daily candles (needs a plan that includes candles; the free plan usually returns 403)
    if (Q.fhKey) {
      const fsym = m.idx ? m.etf : { xau: 'OANDA:XAU_USD', xag: 'OANDA:XAG_USD', btc: 'BINANCE:BTCUSDT', eth: 'BINANCE:ETHUSDT' }[m.k];
      const kind = m.idx ? 'stock' : (m.k === 'btc' || m.k === 'eth') ? 'crypto' : 'forex';
      const to = Math.floor(Date.now() / 1000), from = to - 35 * 86400;
      try {
        const j = await tfetch(`https://finnhub.io/api/v1/${kind}/candle?symbol=${encodeURIComponent(fsym)}&resolution=D&from=${from}&to=${to}&token=${encodeURIComponent(Q.fhKey)}`);
        if (j.s !== 'ok' || !j.c || !j.c.length) throw new Error(j.error || (j.s === 'no_data' ? 'no data' : 'no candles returned'));
        let pts = j.t.map((t, i) => [t * 1000, +j.c[i]]);
        // index tiles: ETF history rescaled to the index level so the chart reads in index points (the % dip is identical)
        const q = mk[m.k]; if (m.idx && q && q.price && !q.proxy) { const r = q.price / pts[pts.length - 1][1]; pts = pts.map(([t, v]) => [t, v * r]); }
        return done(pts, `Finnhub daily candles${m.idx ? ` (${m.etf}${q && q.price && !q.proxy ? ', scaled to index' : ''})` : ''}`);
      } catch (e) { if (e.status === 403) mk.fhCandleDenied = today; log.push({ m: m.name + ' (1-month chart)', src: 'Finnhub candles', host: 'finnhub.io', ok: false, err: e.status === 403 || /access/i.test(e.message) ? 'HTTP 403: your Finnhub plan doesn’t include historical candles (the free plan doesn’t); using the next source' : e.message, ms: e.ms || 0 }); }
    }
    try {
      if (m.idx) {
        const sym = m.idx.cboe, mult = m.idx.cboeMult || 1;
        const h = cboeHistCache[sym] || (cboeHistCache[sym] = tfetch(`https://cdn.cboe.com/api/global/delayed_quotes/charts/historical/${sym}.json`, 15000));
        const j = await h; return done((j.data || []).map((r) => [Date.parse(r.date), +r.close * mult]).filter((p) => p[0] >= cut), 'Cboe daily history');
      }
      const j = await tfetch(`https://api.coingecko.com/api/v3/coins/${m.cg}/market_chart?vs_currency=usd&days=30&interval=daily`);
      return done((j.prices || []).map((p) => [p[0], +p[1]]), m.k === 'btc' || m.k === 'eth' ? 'CoinGecko' : `CoinGecko (${m.cg} token ≈ 1 oz)`);
    } catch (e) { log.push({ m: m.name + ' (1-month chart)', src: m.idx ? 'Cboe daily history' : 'CoinGecko', host: '', ok: false, err: e.message, ms: e.ms || 0 }); }
    // 4) fall back to the app's own record of fetched prices
    const own = ((mk.hist && mk.hist[histKey(m.k, mk[m.k] && mk[m.k].proxy)]) || []).filter((p) => p[0] >= cut); if (own.length >= 2) { mk.series = mk.series || {}; mk.series[m.k] = { pts: own.map((p) => [p[0], p[1]]), src: `your saved daily prices (${own.length} days)`, on: today, own: true }; }
  }
  // Local price log: one point per day per market (the day's latest fetched price), kept for 2 years.
  // It lives in the working copy, so it is saved in browser storage, encrypted auto-save files and backups.
  const histKey = (k, proxy) => (proxy ? `${k}@${proxy}` : k);
  function recordPrice(mk, k, price, proxy, src) {
    mk.hist = mk.hist || {}; const key = histKey(k, proxy); const a = (mk.hist[key] = mk.hist[key] || []); const day = new Date().toLocaleDateString('en-CA');
    const last = a[a.length - 1]; if (last && new Date(last[0]).toLocaleDateString('en-CA') === day) { last[0] = Date.now(); last[1] = price; last[2] = src || last[2]; } else a.push([Date.now(), price, src || '']);
    const cut = Date.now() - 730 * 864e5; while (a.length && a[0][0] < cut) a.shift();
  }
  function sparkline(pts, { w = 220, h = 56, color = '#3b6fd8' } = {}) {
    if (!pts || pts.length < 2) return '<div class="spark-empty">no 1-month history yet</div>';
    const xs = pts.map((p) => p[0]), ys = pts.map((p) => p[1]); const x0 = Math.min(...xs), x1 = Math.max(...xs), y0 = Math.min(...ys), y1 = Math.max(...ys);
    const X = (x) => 2 + (x - x0) / Math.max(1, x1 - x0) * (w - 4), Y = (y) => h - 3 - (y - y0) / Math.max(1e-9, y1 - y0) * (h - 6);
    const line = pts.map((p) => `${X(p[0]).toFixed(1)},${Y(p[1]).toFixed(1)}`).join(' ');
    const iMax = ys.indexOf(y1);
    return `<svg viewBox="0 0 ${w} ${h}" class="spark"><polygon points="${X(xs[0])},${h} ${line} ${X(xs[xs.length - 1])},${h}" fill="${color}" fill-opacity=".10"/><line x1="2" x2="${w - 2}" y1="${Y(y1)}" y2="${Y(y1)}" stroke="#9aa3ad" stroke-dasharray="3 3" stroke-width="1"/><polyline points="${line}" fill="none" stroke="${color}" stroke-width="2"/><circle cx="${X(xs[iMax])}" cy="${Y(y1)}" r="2.5" fill="#9aa3ad"/><circle cx="${X(xs[xs.length - 1])}" cy="${Y(ys[ys.length - 1])}" r="3" fill="${color}"/></svg>`;
  }
  function marketCard(snap) {
    const Q = state.settings.quotes; const mk = snap.manual.market || {};
    const tile = (m) => {
      const q = mk[m.k]; const ser = mk.series && mk.series[m.k]; let pts = ser ? ser.pts.slice() : [];
      if (q && q.price && !q.proxy && pts.length && Math.abs(q.price / pts[pts.length - 1][1] - 1) < 0.15) { const tq = q.t ? Date.parse(q.t) : Date.now(); if (tq - pts[pts.length - 1][0] < 18 * 3600e3) pts[pts.length - 1] = [Math.max(tq, pts[pts.length - 1][0]), q.price]; else pts.push([tq, q.price]); } // the live price is always the latest point
      const last = pts.length ? pts[pts.length - 1][1] : q?.price; const nowPx = q?.price || last; const first = pts.length ? pts[0][1] : null; const hi = pts.length ? Math.max(...pts.map((p) => p[1])) : null;
      const chg = first ? (last / first - 1) * 100 : null, dip = hi ? (last / hi - 1) * 100 : null;
      const hiDate = hi ? new Date(pts.find((p) => p[1] === hi)[0]).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) : '';
      const color = chg == null ? '#9aa3ad' : chg >= 0 ? '#2f9a6e' : '#c94c43';
      const fmt = (v) => v.toLocaleString(undefined, { maximumFractionDigits: m.dec, minimumFractionDigits: m.dec ? 2 : 0 });
      return `<div class="mtile"><div class="mhead"><span class="kl">${m.name}</span>${chg != null ? `<span class="${chg >= 0 ? 'pos' : 'neg'} mchg">${chg >= 0 ? '+' : ''}${chg.toFixed(1)}% <small>1 mo</small></span>` : ''}</div>
        ${pts.length >= 2 ? sparkline(pts, { color }) : `<div class="spark-empty">${(() => { const n = ((mk.hist || {})[histKey(m.k, q && q.proxy)] || []).length; return n ? `building from your saved prices: ${n} day${n > 1 ? 's' : ''} so far` : 'no 1-month history yet'; })()}</div>`}
        <div class="mfoot">${dip != null ? `<span class="${dip <= -5 ? 'neg' : dip <= -2 ? 'warnc' : 'pos'}"><b>${dip > -0.05 ? 'at 1-mo high' : `${dip.toFixed(1)}% from 1-mo high`}</b>${dip <= -0.05 ? ` <small>(${hiDate})</small>` : ''}</span>` : '<span class="note">dip: —</span>'}
          <span class="mnow">${nowPx ? fmt(nowPx) : '—'}${q?.proxy ? ` <small>${esc(q.proxy)}</small>` : ''}</span></div>
        <div class="ks">${ser ? esc(ser.src) : q ? esc(q.src || '') : '<span class="neg">no data</span>'}</div>
        <div class="mlinks">${extLinks(m.k)}</div></div>`;
    };
    const dd = snap.manual.spDrawdownPct;
    return `<div class="card"><h3 class="mkthead">Markets <span class="sub">last month</span> <span class="sub" id="mktStatus">${mk.asOf ? 'updated ' + new Date(mk.asOf).toLocaleString() : (Q.enabled ? 'not fetched yet' : 'live prices off (Settings → Market data)')}</span>
      <span class="mbtns"><button class="btn sm" data-act="testMkt">Test price sources</button> <button class="btn sm" data-act="refreshMkt">↻ Refresh</button></span></h3>
      <div class="mgrid">${MKT.map(tile).join('')}</div>
      <div class="grid4 tight" style="margin-top:10px">
        <label class="fld"><span>S&P 500 all-time high${mk.spx?.proxy ? ` (${mk.spx.proxy} ETF basis)` : ''}</span><input type="number" step="any" data-scope="manual" data-path="${mk.spx?.proxy ? 'market.spxProxyATH' : 'market.spxATH'}" value="${(mk.spx?.proxy ? mk.spxProxyATH : mk.spxATH) ?? ''}"><span class="hint">raised automatically when a new high is fetched</span></label>
        <label class="fld"><span>S&P 500 % below all-time high</span><div class="kv" style="font-size:18px">${dd == null ? '—' : dd + '%'}</div><span class="hint">${snap.manual.spAuto === false ? 'manual value' : 'auto from live price'} · drives the buffer verdict</span></label>
        <label class="fld chk"><input type="checkbox" data-scope="manual" data-path="spAuto" ${snap.manual.spAuto === false ? '' : 'checked'}><span>Calculate the drawdown from live prices</span></label></div>
      ${(state.mktErrors || []).length ? `<p class="note neg">Couldn’t fetch: ${esc(state.mktErrors.join('; '))}. You can enter them manually below meanwhile.</p>` : ''}
      <details><summary>Enter prices manually</summary><div class="grid4 tight">${MKT.map((m) => `<label class="fld"><span>${m.name}</span><input type="number" step="any" data-scope="manual" data-path="market.${m.k}.price" value="${mk[m.k] && mk[m.k].src === 'manual' ? mk[m.k].price : ''}" placeholder="${mk[m.k] ? mk[m.k].price : ''}"></label>`).join('')}</div></details>
      ${mktLogTable()}
      <p class="note">Gold, silver and bitcoin: gold-api.com spot prices (free, no key). Holdings set to “Gold/Silver spot × oz” or “Bitcoin × coins” are revalued from these prices. Requests send only symbols like XAU or ^GSPC, never your data. Prices are saved with each snapshot for History.</p></div>`;
  }

  function vReview(snap, an) {
    if (!snap.accounts.length && !(snap.realEstate || []).some((p) => +p.value)) return `<div class="card welcome"><h3>Welcome to your FIRE Command Center</h3>
      <p>This copy of the app contains no financial data. Your data lives in this browser and, once you set it up, in an encrypted file you choose.</p>
      <ol class="steps"><li><b>Already have a backup?</b> <a href="#" data-act="importData">Load data file</a> (.fire encrypted or .json).</li>
      <li><b>Starting fresh?</b> Go to <a href="#" data-tab="import">Import</a> and drop your Fidelity CSV, Fidelity/Vanguard/Vestwell/Wealthfront PDFs and the Morgan Stanley ${CS()} lot PDF.</li>
      <li>Then click <a href="#" data-act="autosave">Auto-save</a> and pick a file inside your encrypted cloud folder (iCloud Drive with Advanced Data Protection, or a Cryptomator vault).</li></ol></div>`;
    const v = an.verdict; const S = state.settings;
    const unconfirmed = [];
    if (!S.spending.confirmed) unconfirmed.push(S.spending.source === 'manual' ? `annual spending ${usd(S.spending.annual)}` : `the Plan's spending categories (still the starter splits; set them in Plan → Assumptions or from the Spending tab)`);
    if (!S.household.agesConfirmed) unconfirmed.push('birth years (placeholders: 1975)');
    if (snap.manual.checking === 150000) unconfirmed.push('checking balance ($150k is from the spec example)');
    if (snap.manual.spDrawdownPct == null) unconfirmed.push('S&P 500 distance from its all-time high (assumed 0%)');
    if (!snap.manual.ytdRealizedGains && !snap.manual.ytdHarvestedLosses) unconfirmed.push(`${an.Y} YTD realized gains and harvested losses (both $0; check Wealthfront's tax-loss harvesting report and Fidelity's realized gain/loss page)`);
    const assumpt = unconfirmed.length ? `<div class="banner">Assumptions to confirm before acting: ${unconfirmed.join('; ')}. Edit them below or in Settings, then <a href="#" data-act="confirmAssump">mark confirmed</a>.</div>` : '';
    const meterMax = an.target * 1.15;
    const meter = `<div class="meter"><div class="fill ${an.cash < an.floor ? 'red' : an.cash < an.trigger ? 'amber' : 'green'}" style="width:${Math.min(100, an.cash / meterMax * 100)}%"></div>
      <div class="tick" style="left:${an.floor / meterMax * 100}%"><span>floor</span></div><div class="tick" style="left:${an.trigger / meterMax * 100}%"><span>trigger</span></div><div class="tick" style="left:${an.target / meterMax * 100}%"><span>target</span></div></div>`;
    const kpis = `<div class="kpis">
      <div class="kpi"><div class="kl">Net worth</div><div class="kv">${k(an.s.total)}</div><div class="ks">Liquid ${k(an.s.liquid)} · Taxable ${k(an.s.byTax.taxable || 0)} · Pre-tax ${k(an.s.byTax.pretax || 0)} · Roth ${k(an.s.byTax.roth || 0)}</div></div>
      <div class="kpi wide"><div class="kl">Cash buffer</div><div class="kv">${k(an.cash)} <small>of ${k(an.target)} target</small></div>${meter}<div class="ks">Runway ≈ ${an.runwayMonths.toFixed(1)} months at ${k(an.netBurn)}/yr net burn (spending ${k(an.spend)} − ${k(an.inc.total)} dividends/interest)</div></div>
      ${an.working ? `<div class="kpi"><div class="kl">Est. ${an.Y} income tax</div><div class="kv">${k(an.taxAfter.total)}</div><div class="ks">marginal ${pct(an.taxAfter.fedMarginal * 100, 0)} federal + ${pct(an.taxAfter.caMarginal * 100, 1)} CA${+an.m.wageIncome ? '' : ' · <b>add wages below</b>'}</div></div>` : `<div class="kpi"><div class="kl">Est. ${an.Y} MAGI (after plan)</div><div class="kv ${an.magiAfter.value > an.th.ceiling ? 'neg' : ''}">${k(an.magiAfter.value)}</div><div class="ks">${an.th.ceilingLabel}: ${k(an.th.ceiling)} · room left ${k(an.th.ceiling - an.magiAfter.value)}</div></div>`}
      <div class="kpi"><div class="kl">${CS()} concentration</div><div class="kv ${an.s.googPct > S.trim.googConcentrationMax ? 'warnc' : ''}">${pct(an.s.googPct, 0)}</div><div class="ks">${k(an.s.goog)} · limit ${S.trim.googConcentrationMax}%</div></div>
      <div class="kpi"><div class="kl">Withdrawal rate</div><div class="kv ${an.spend / an.s.liquid > 0.045 ? 'warnc' : ''}">${pct(an.spend / an.s.liquid * 100, 1)}</div><div class="ks">spending ÷ liquid net worth · <a href="#" data-tab="plan">see plan</a></div></div>
    </div>`;
    const inputs = `<div class="card"><h3>This quarter's inputs <span class="sub">Statements don't contain these, so update them at each review</span></h3><div class="grid4">
      ${field(`${an.Y} wages + RSU income`, 'manual', 'wageIncome', { hint: snap.manual.wageIncomeEdited ? `your override (Plan says ${k(snap.manual.wageFromPlan || 0)}) · <a href="#" data-act="resetDerived" data-k="wageIncome">use Plan</a>` : `from Plan → Assumptions → work income; type to override (e.g. RSU surprises)` })}
      ${field('Checking / savings balance', 'manual', 'checking', { warn: snap.manual.checking === 150000, hint: 'counts toward buffer' })}
      ${field('S&P 500: % below all-time high', 'manual', 'spDrawdownPct', { warn: snap.manual.spDrawdownPct == null, ph: 'e.g. 2.5', hint: 'today\'s value' })}
      ${field(`${an.Y} YTD realized gains`, 'manual', 'ytdRealizedGains', { hint: 'all taxable accounts incl. Wealthfront' })}
      ${field(`${an.Y} YTD harvested losses`, 'manual', 'ytdHarvestedLosses', { hint: 'Wealthfront / Public TLH reports' })}
      ${field('Capital-loss carryforward', 'manual', 'lossCarryforward', { hint: snap.manual.cfFromReturn == null ? 'from last year\'s Schedule D (import the return to fill this in)' : snap.manual.lossCarryforwardEdited ? `your override (return says ${k(snap.manual.cfFromReturn)}) · <a href="#" data-act="resetDerived" data-k="lossCarryforward">use return</a>` : `from your ${an.Y - 1} return; type to override` })}
      ${field('Other income (MAGI)', 'manual', 'otherIncome', { hint: 'consulting, Roth conversions, IRA withdrawals' })}
      ${field('' + CS() + ' YTD % change', 'manual', 'googYtdPct', { hint: 'optional, triggers trim at ' + S.trim.googYtdTrigger + '%' })}
      ${S.spending.source === 'manual' ? field('Annual spending', 'settings', 'spending.annual', { warn: !S.spending.confirmed, hint: 'drives every buffer target · <a href="#" data-act="spendFromPlan">use the Plan instead</a>' }) : `<label class="fld"><span>Annual spending</span><b style="padding:6px 0;display:block">${usd(S.spending.annual)}</b><span class="hint">from the Plan: living ${k(S.spending.fromPlan?.living || 0)} + homes ${k(S.spending.fromPlan?.homes || 0)} · <a href="#" data-tab="plan" data-ptab-go="setup">edit</a></span></label>`}
    </div></div>`;
    const reasons = `<ul class="reasons">${an.reasons.map((r) => `<li>${esc(r)}</li>`).join('')}<li>${an.Y} MAGI before new sales ≈ ${usd(an.magiNow.value)}. Gain room under the ${an.th.ceilingLabel} (${usd(an.th.ceiling)}, ${usd(S.aca.safetyMargin)} safety margin): ${usd(Math.max(0, an.roomNow))}.</li></ul>`;
    if (!mktTried && state.settings.quotes.enabled) { const a0 = snap.manual.market?.asOf; if (!a0 || Date.now() - new Date(a0) > 15 * 60e3) setTimeout(() => refreshMarket(false), 50); }
    return `${calendarCard(an)}${marketCard(snap)}${assumpt}
      <div class="hero ${v.color}"><div class="hi">${v.icon}</div><div><div class="ht">${v.title}</div><div class="hl">${esc(v.line)}</div>${reasons}</div></div>
      ${kpis}${inputs}
      ${planCard(an)}
      ${portfolioCard(an)}
      ${tlhCard(an)}
      <div class="card"><h3>MAGI tracker <span class="sub">salary, investment income and gains</span></h3>${magiBars(an)}</div>
      <div class="card"><h3>Wash-sale scan</h3>${an.wash.map((w) => `<div class="flag ${w.severity}"><b>${w.ticker}</b> ${esc(w.text)}</div>`).join('')}</div>`;
  }

  function tlhCard(an) {
    const T = an.tlh; if (!T) return '';
    const rows = T.items.map((c) => `<tr><td>${esc(c.account)}</td><td><b>${esc(c.symbol)}</b></td><td class="n">${usd(c.value)}</td><td class="n">${usd(c.cost)}</td><td class="n neg">−${usd(c.loss)}</td>
      <td>${c.inPlan ? '<span class="pill ok">in this quarter’s plan</span>' : '<span class="pill amber">not in plan: swap</span>'}</td><td class="why">${esc(c.replacement)}</td>
      <td class="why">${c.alsoHeldIn.length ? `<span class="neg">Also held in ${esc(c.alsoHeldIn.join(', '))}.</span> Turn off dividend reinvestment and contributions into ${esc(c.symbol)} there from 30 days before to 30 days after the sale.` : 'No other account holds it.'}</td></tr>`).join('');
    return `<div class="card"><h3>Tax-loss harvesting <span class="sub">${usd(T.total)} of unrealized losses in taxable accounts</span></h3>
      <table class="tbl"><thead><tr><th>Account</th><th>Ticker</th><th class="n">Value</th><th class="n">Cost</th><th class="n">Loss</th><th>Status</th><th>Replacement (not substantially identical)</th><th>Wash-sale watch</th></tr></thead><tbody>${rows}</tbody></table>
      <ul class="steps"><li><b>Why it matters for you:</b> a ${usd(T.total)} realized loss lets you sell about <b>${usd(T.googProceeds)}</b> of your highest-basis ${CS()} lots (${T.googLots} lots) with roughly $0 net added to MAGI, which cuts concentration without touching your ACA headroom.</li>
      <li>If you don't use it against gains this year, it offsets $3,000 of ordinary income each year and carries forward indefinitely. ${isCA() ? 'California follows the same rules.' : 'Most states follow the same rules.'}</li>
      <li>When the buffer needs cash, the plan sells it outright (Refill). When the buffer is healthy, sell and immediately buy the replacement so your bond allocation stays the same.</li>
      <li>Fund gains use the average cost from the Fidelity export. Choose Specific ID at Fidelity and sell the highest-cost lots for the largest loss.</li></ul></div>`;
  }
  function planCard(an) {
    if (!an.plan && an.working) return `<div class="card"><h3>Action plan <span class="sub">working years</span></h3><ol class="steps">
        <li>No sales needed: paychecks cover spending.${an.mode === 'diversify' ? ' ' + CS() + ' is over your limit, but there are no tax-free lots or losses to pair right now. Set a yearly gain budget in Settings → Working years if you want to diversify faster.' : ''}</li>
        <li>Invest the monthly surplus in the underweight side of the rebalance check below, not in more ${CS()}.</li>
        <li>Sell RSUs as they vest: the cost basis equals the vest price, so the sale is (nearly) tax-free diversification.</li>
        <li>Re-run this review next quarter.</li></ol></div>`;
    if (!an.plan) {
      return `<div class="card"><h3>Action plan</h3><ol class="steps">
        <li>No equity sales this quarter.</li>
        <li>Move about <b>${usd(Math.round(an.netBurn / 4 / 1000) * 1000)}</b> from the cash buffer to checking for next quarter's spending.</li>
        <li>Leave dividends and money-market interest in cash; they already count toward MAGI.</li>
        <li>Re-run this review next quarter with fresh exports.</li></ol></div>`;
    }
    const p = an.plan;
    const groups = {};
    for (const s of p.steps) (groups[s.tranche] = groups[s.tranche] || []).push(s);
    const yrs = Object.entries(p.byYear).map(([y, v]) => `<div class="ybox"><div class="kl">Sell in ${y}${+y > an.Y ? ' (on/after Jan 2)' : ' (by Dec 31)'}</div><div class="kv">${k(v.proceeds)}</div><div class="ks">net gain ${usd(v.gain)}</div></div>`).join('');
    const tbl = Object.entries(groups).map(([tr, rows]) => {
      const tot = rows.reduce((a, r) => ({ p: a.p + r.proceeds, g: a.g + r.gain }), { p: 0, g: 0 });
      return `<tr class="trh"><td colspan="7">${esc(tr)} <span class="sub">${usd(tot.p)} proceeds · ${usd(tot.g)} gain</span></td></tr>` + rows.map((r) => `<tr>
        <td>${esc(r.account)}</td><td><b>${esc(r.symbol)}</b></td><td>${r.lotId ? esc(r.lotId) : (r.all ? 'entire position' : 'SpecID: highest-cost lots')}</td>
        <td class="n">${r.shares != null ? r.shares.toLocaleString(undefined, { maximumFractionDigits: 3 }) : '—'}</td><td class="n">${usd(r.proceeds)}</td><td class="n ${r.gain < 0 ? 'pos' : ''}">${usd(r.gain)}</td><td class="why">${esc(r.why)}</td></tr>`).join('');
    }).join('');
    const ex = p.excluded.length ? `<details><summary>${p.excluded.length} taxable positions left out (no cost basis on file)</summary><ul>${p.excluded.map((x) => `<li>${esc(x.account)} · ${esc(x.symbol)} · ${usd(x.value)}: ${esc(x.reason)}</li>`).join('')}</ul></details>` : '';
    const short = p.shortfall > 1 && an.mode !== 'trim' && an.mode !== 'diversify' ? `<div class="banner amber">Shortfall ${usd(p.shortfall)}. Options: (a) raise the MAGI ceiling (Settings → ACA) and accept a smaller subsidy, (b) add cost basis for Wealthfront and IOND so they can be used, (c) draw Roth contribution basis, or (d) lower the buffer target.</div>` : '';
    return `<div class="card" id="plan"><h3>${an.mode === 'diversify' ? 'Diversification plan (tax-efficient)' : an.mode === 'trim' ? 'Trim plan' : 'Tax-optimized liquidation plan'} <span class="sub">${an.mode === 'trim' || an.mode === 'diversify' ? `${usd(p.raised)} of sales; loss-fund proceeds go into the replacement fund, ${CS()} proceeds ${an.working ? 'into diversified index funds' : 'to the buffer or diversified funds'}` : usd(an.need) + ' needed'}</span></h3>
      <div class="yrow">${yrs}</div>${short}
      <table class="tbl"><thead><tr><th>Account</th><th>Ticker</th><th>Lot / method</th><th class="n">Shares</th><th class="n">Proceeds</th><th class="n">Est. gain</th><th>Why</th></tr></thead><tbody>${tbl}</tbody></table>
      <p class="note">Mutual-fund gains use average cost from the export. At Fidelity, choose <b>Specific ID</b> and pick the highest-cost lots, which usually gives a smaller gain than shown. ${CS()} lot numbers repeat across months, so use the acquisition date and lot # together. Sell in ${an.Y} by Dec 31 and ${an.Y + 1} sales on or after Jan 2.</p>${ex}</div>`;
  }

  function magiBars(an) {
    const S = state.settings; const m = an.m;
    const planG = an.plan ? an.plan.steps.filter((s) => s.year === an.Y).reduce((a, s) => a + s.gain, 0) : 0;
    const ytdNet = (+m.ytdRealizedGains || 0) - (+m.ytdHarvestedLosses || 0) - (+m.lossCarryforward || 0);
    const capTotal = an.magiAfter.capInc;
    const parts = [
      { label: 'Wages & RSU income', v: +m.wageIncome || 0, color: '#16202e' },
      { label: 'Ordinary div/interest', v: an.inc.ordinary, color: '#9aa3ad' },
      { label: 'Qualified dividends', v: an.inc.qualified, color: '#3b6fd8' },
      { label: 'Tax-exempt (muni)', v: an.inc.taxExempt, color: '#7cc7a4' },
      { label: 'Other income', v: +m.otherIncome || 0, color: '#8d7ad6' },
      { label: 'Net capital gains (YTD + plan)', v: Math.max(0, capTotal), color: '#e2733a' },
    ];
    const ticks = [{ v: an.th.csr87, label: 'CSR-87' }, { v: an.th.csr73, label: 'CSR-73' }, { v: an.th.cliff, label: S.aca.cliffInEffect ? '400% cliff' : '400% FPL', cls: 'red' }];
    let next = '';
    if (an.taxNextAfter) {
      const nm = an.taxNextAfter.magi;
      next = `<h4>${an.Y + 1} (${an.Y + 1} share of the plan + full-year dividends)</h4>` + stackBar([
        { label: 'Dividends/interest', v: an.nonCap, color: '#3b6fd8' }, { label: 'Planned gains', v: Math.max(0, nm.capInc), color: '#e2733a' }], an.nonCap + Math.max(0, nm.capInc),
        [{ v: an.thNext.csr87, label: 'CSR-87' }, { v: an.thNext.cliff, label: '400% cliff', cls: 'red' }]) + `<p class="note">Uses the 2026 poverty guideline (${usd(an.thNext.fpl)} for ${S.household.size}) for 2027 coverage. ${an.carryNext > 0 ? `Loss carryforward into ${an.Y + 1}: ${usd(an.carryNext)}.` : ''}</p>`;
    }
    return `<h4>${an.Y}: estimated MAGI ${usd(an.magiAfter.value)} <span class="sub">YTD net gains ${usd(ytdNet)} + plan ${usd(planG)}</span></h4>` +
      stackBar(parts, parts.reduce((a, p) => a + Math.max(0, p.v), 0), ticks) +
      (an.working ? `<p class="note"><b>While working, the ACA lines are for reference only:</b> your health coverage comes from work. MAGI here matters for the 3.8% investment-income tax (over $250k), the SALT cap phase-down (over $505k) and, two years out, Medicare surcharges.</p>` : '') + `<p class="note">Household of ${S.household.size}, ${an.Y} coverage uses the ${an.Y - 1} poverty guideline (${usd(an.th.fpl)}). Dividends are full-year estimates from current holdings × typical yields (edit in Settings). Tax-exempt muni income counts toward ACA MAGI.</p>` + next;
  }

  // ---------- ACCOUNTS (editable) ----------
  function vAccounts(snap, an) {
    const s = an.s; const asOfD = new Date(snap.asOf);
    const classOpts = Object.entries(CLASS_LABEL);
    const taxOpts = TAX_TYPES.map((t) => [t, TAX_LABEL[t]]);
    const real = snap.accounts.slice().sort((a, b) => sum(b.holdings, (h) => h.value) - sum(a.holdings, (h) => h.value));
    const rowOf = {}; real.forEach((a) => { rowOf[a.key] = (() => {
      const v = sum(a.holdings, (h) => h.value) * (a.taxType === 'liability' ? -1 : 1);
      const stale = (asOfD - new Date(a.asOf)) / 864e5 > 45;
      const open = state.openAcct === a.key;
      const lotsAcct = a.lots && a.lots.length;
      const missingBasis = a.taxType === 'taxable' && a.holdings.some((h) => h.cost == null && h.assetClass !== 'cash');
      const head = `<tr class="arow ${open ? 'open' : ''}"><td><a href="#" data-act="openAcct" data-key="${esc(a.key)}">${open ? '▾' : '▸'} ${esc(a.name)}</a> ${a.manual ? '<span class="pill">manual</span>' : ''} ${a.edited && !a.manual ? '<span class="pill amber">edited</span>' : ''} ${missingBasis ? '<span class="pill red">basis missing</span>' : ''}</td>
        <td class="ownercell">${acctCell(a.key, null, 'owner', null, { options: OWNERS() })}${RETIRE(a.taxType) && a.owner === 'joint' ? '<span class="pill red" title="IRAs, 401(k)s, Roths and HSAs are individually owned">must be one person</span>' : a.ownerGuessed ? '<span class="pill amber" title="Inferred. Pick the owner to confirm.">confirm</span>' : ''}</td>
        <td>${esc(a.institution)}</td><td><span class="pill ${a.taxType}">${TAX_LABEL[a.taxType]}</span></td><td>${a.asOf || "—"}${stale ? ' <span class="pill stale">stale</span>' : ''}</td><td class="n">${usd(v)}</td></tr>`;
      if (!open) return head;
      const hrows = a.holdings.map((h, i) => {
        const ro = lotsAcct; const gain = h.cost != null ? h.value - h.cost : null;
        return `<tr><td>${acctCell(a.key, i, 'symbol', 'text', { ro })}</td><td>${acctCell(a.key, i, 'desc', 'text', { ro })}</td><td>${acctCell(a.key, i, 'assetClass', null, { options: classOpts })}</td>
          <td>${h.qtyEstimated ? '<span class="pill amber" title="Back-solved from your old value ÷ the live price. Enter the exact amount.">confirm qty</span>' : ''}${acctCell(a.key, i, 'qty', 'number', { ro, ph: REF_UNIT[h.priceRef] || '' })}</td><td>${['gold', 'crypto'].includes(h.assetClass) || h.priceRef ? acctCell(a.key, i, 'priceRef', null, { options: PRICE_REFS }) : '<span class="note">—</span>'}</td><td>${acctCell(a.key, i, 'value', 'number', { ro: ro || !!h.priceRef })}</td><td>${acctCell(a.key, i, 'cost', 'number', { ph: 'cost basis', ro })}</td>
          <td class="n ${gain < 0 ? 'neg' : ''}">${gain == null ? '—' : usd(gain)}${h.costEstimated ? ' <span class="pill amber" title="basis carried from your earlier entry, scaled to the new share count">est.</span>' : ''}</td>
          <td>${ro ? '' : `<button class="btn sm" data-act="delHolding" data-key="${esc(a.key)}" data-hi="${i}">✕</button>`}</td></tr>`;
      }).join('');
      const editor = `<tr class="aedit"><td colspan="6"><div class="grid4 tight">
          <label class="fld"><span>Account name</span>${acctCell(a.key, null, 'name', 'text')}</label>
          <label class="fld"><span>Institution</span>${acctCell(a.key, null, 'institution', 'text')}</label>
          <label class="fld"><span>Tax treatment</span>${acctCell(a.key, null, 'taxType', null, { options: taxOpts })}</label>
          <label class="fld"><span>As of</span>${acctCell(a.key, null, 'asOf', 'date')}</label>
          <label class="fld"><span>Show under</span>${acctCell(a.key, null, 'category', null, { options: [['', 'Automatic (' + SECTION_LABEL[acctCategory({ ...a, category: '' })] + ')'], ...Object.entries(SECTION_LABEL)] })}</label>
          ${a.taxType === 'liability' ? `<label class="fld"><span>Debt type</span>${acctCell(a.key, null, 'debtKind', null, { options: [['card', 'Credit card (paid from cash)'], ['loan', 'Other loan (car, HELOC, personal)']] })}</label>` : ''}</div>
        <table class="tbl edit"><thead><tr><th>Ticker</th><th>Description</th><th>Class</th><th>Shares / oz / coins</th><th>Priced by</th><th>Value $</th><th>Cost basis $</th><th class="n">Unrealized</th><th></th></tr></thead><tbody>${hrows}</tbody></table>
        ${lotsAcct ? `<p class="note">${a.lots.length} tax lots on file. Values and basis come from the lot table, so re-import the Morgan Stanley PDF to update them.</p>` : `<button class="btn sm" data-act="addHolding" data-key="${esc(a.key)}">+ Add holding</button>`}
        <button class="btn sm danger" data-act="delAcct" data-key="${esc(a.key)}">Remove account</button>
        ${!a.manual ? '<span class="note"> Cost basis you type here is remembered and reapplied when you re-import this account.</span>' : ''}</td></tr>`;
      return head + editor;
    })(); });
    const totalLiquid = s.liquid;
    const importTip = `<div class="card importtip"><div class="importtip-row"><div><h3 style="margin:0 0 4px">Import everything at once</h3>
      <p style="margin:0">Click <b>Import</b> and select <b>all</b> your files together: brokerage and 401(k) statements (CSV or PDF), bank and credit-card downloads (CSV), tax returns and W-2s (PDF). The app recognizes each file and sends it to the right place: holdings here, transactions to <b>Spending</b>, returns and W-2s to <b>Taxes</b>. Re-importing is safe: accounts are replaced, duplicate transactions are skipped.</p></div>
      <button class="btn primary" data-act="globalImport">Import files…</button></div></div>`;
    return importTip + `<div class="kpis"><div class="kpi"><div class="kl">Net worth</div><div class="kv">${usd(s.total)}</div><div class="ks">working copy as of ${snap.asOf}</div></div>
      <div class="kpi"><div class="kl">Liquid net worth</div><div class="kv">${k(totalLiquid)}</div><div class="ks">excludes property${s.liabilities ? `, after ${k(s.liabilities)} debt` : ''}</div></div>
      <div class="kpi"><div class="kl">Taxable unrealized gain</div><div class="kv">${k(s.taxableUnrealized)}</div><div class="ks">positions with known basis</div></div>
      <div class="kpi"><div class="kl">Est. taxable income/yr</div><div class="kv">${k(an.inc.total)}</div><div class="ks">dividends + interest</div></div></div>
      ${state.dirty ? `<div class="banner">The working copy has changed since your last snapshot. <a href="#" data-act="saveSnap">Save a snapshot</a> to record it in History.</div>` : ''}
      ${auditCard(an)}
      ${realEstateSection('networth')}
      ${ownerCard(s)}
      <div class="two"><div class="card"><h3>By tax treatment</h3>${hbars(s.byTax, TAX_LABEL, TAX_COLOR, Math.max(1, s.total + s.liabilities))}</div>
      <div class="card"><h3>By asset class <span class="sub">liquid only; target-date funds split 50/30/20</span></h3>${hbars(s.byClass, CLASS_LABEL, CLASS_COLOR, Math.max(1, totalLiquid))}</div></div>
      ${accountSections(snap, real, rowOf)}
      <div class="card"><p class="note">401(k)s are split into pre-tax and Roth portions using the source breakdown on each statement. Vestwell uses the vested balance. Accounts more than 45 days older than the working copy are marked stale. Property counts toward net worth but isn't spent in the plan unless you add a sale event.</p></div>`;
  }
  const sum = (a, f = (x) => x) => a.reduce((s, x) => s + (f(x) || 0), 0);
  const SECTION_LABEL = { bank: 'Banks', invest: 'Investments (stocks & venture capital)', retirement: 'Retirement', edu: 'Education (529)', alt: 'Gold / silver / Bitcoin', debt: 'Credit cards & other debt' };
  function acctCategory(a) {
    if (a.category) return a.category;
    if (a.taxType === 'liability') return 'debt';
    if (a.taxType === 'edu') return 'edu';
    if (RETIRE(a.taxType)) return 'retirement';
    const hs = (a.holdings || []).filter((h) => (+h.value || 0) !== 0 || a.holdings.length === 1);
    if (hs.length && hs.every((h) => h.assetClass === 'bank')) return 'bank';
    if (hs.length && hs.every((h) => h.assetClass === 'gold' || h.assetClass === 'crypto')) return 'alt';
    return 'invest';
  }
  function altLiveTable(snap, list) {
    const mk = snap.manual.market || {}; const rows = [];
    for (const a of list) for (const h of a.holdings) {
      const q = h.priceRef === 'sheet' ? (mk.tickers || {})[(h.symbol || '').toLowerCase()] : mk[h.priceRef];
      const live = h.priceRef && q && q.price && h.qty != null && h.qty !== '';
      const status = live ? `<span class="pill ok">live</span>` : !h.priceRef ? '<span class="pill amber" title="Open the account and set Priced by">not live: set “Priced by”</span>' : (h.qty == null || h.qty === '') ? '<span class="pill amber">enter quantity</span>' : '<span class="pill red">no price yet: refresh on Quarterly Review</span>';
      rows.push(`<tr><td>${esc(a.name)}</td><td><b>${esc(h.symbol || '')}</b> ${esc(h.desc || '')}</td><td class="n">${h.qty != null && h.qty !== '' ? (+h.qty).toLocaleString(undefined, { maximumFractionDigits: 6 }) + ' ' + (REF_UNIT[h.priceRef] || '') : '—'}${h.qtyEstimated ? ' <span class="pill amber">confirm</span>' : ''}</td><td class="n">${q && q.price ? usd(q.price, q.price < 100 ? 2 : 0) : '—'}</td><td class="n"><b>${usd(h.value)}</b></td><td>${status} <span class="note">${q && q.t ? new Date(q.t).toLocaleString() : ''}</span></td></tr>`);
    }
    if (!rows.length) return '';
    return `<table class="tbl"><thead><tr><th>Account</th><th>Holding</th><th class="n">Quantity</th><th class="n">Live price</th><th class="n">Value</th><th>Pricing</th></tr></thead><tbody>${rows.join('')}</tbody></table>`;
  }
  function accountSections(snap, real, rowOf) {
    const groups = { bank: [], invest: [], retirement: [], edu: [], alt: [], debt: [] };
    for (const a of real) if (a.taxType !== 'property') (groups[acctCategory(a)] || groups.invest).push(a);
    const val = (a) => sum(a.holdings, (h) => h.value) * (a.taxType === 'liability' ? -1 : 1);
    const btn = (tpl, label) => `<button class="btn sm" data-act="addAcct" data-tpl="${tpl}">+ ${label}</button>`;
    const adds = { bank: btn('cash', 'Bank account (checking, savings, CD)'), invest: btn('brokerage', 'Brokerage') + ' ' + btn('venture', 'Venture / private investment'), retirement: btn('ira', 'Traditional IRA / 401(k)') + ' ' + btn('roth', 'Roth IRA / 401(k)') + ' ' + btn('hsa', 'HSA'), edu: btn('edu', '529 plan'), alt: btn('gold', 'Gold (oz)') + ' ' + btn('silver', 'Silver (oz)') + ' ' + btn('crypto', 'Bitcoin') + ' ' + btn('eth', 'Ethereum'), debt: btn('card', 'Credit card') + ' ' + btn('loan', 'Other loan') };
    const notes = {
      bank: 'Bank cash counts toward the Quarterly Review cash buffer.',
      invest: 'Taxable brokerage, company stock and private/venture holdings. Venture and private positions count in net worth but are never put in a sale plan (they can’t be sold on demand).',
      retirement: 'IRAs, 401(k)s, Roths and HSAs. Each must belong to one person.',
      edu: 'Counted in net worth, but the plan only spends it on expenses marked “Pay from 529” (Assumptions → Extra expenses), tax-free. Growth uses the 529 stock % in Assumptions. ' + (isCA() ? 'California gives no state deduction for contributions.' : 'Many states give a deduction for contributions to their own plan; check yours.') + '',
      alt: 'Values = quantity × live price (gold and silver per troy oz, bitcoin and ether per coin), refreshed with the Markets card on Quarterly Review. Funds like GLD or IBIT can be priced live by adding their ticker rows to your Google Sheet and choosing “Ticker price from my Google Sheet”.',
      debt: 'Credit card balances are subtracted from the cash buffer and paid off from cash at the start of the plan. Mortgages live on their property in Real estate.',
    };
    const head = '<thead><tr><th>Account</th><th>Owner</th><th>Institution</th><th>Type</th><th>As of</th><th class="n">Value</th></tr></thead>';
    const checkingRow = `<tr><td>Checking / savings <span class="note">(same number as on Quarterly Review)</span></td><td class="ownercell">${cell('manual', 'checkingOwner', null, { options: OWNERS() })}</td><td>Bank</td><td><span class="pill taxable">Taxable</span></td><td>${snap.asOf}</td><td class="n"><input class="moneyin" type="number" step="any" data-scope="manual" data-path="checking" value="${esc(snap.manual.checking ?? '')}" placeholder="0"></td></tr>`;
    return Object.entries(groups).map(([k, list]) => {
      const total = sum(list, val) + (k === 'bank' ? (+snap.manual.checking || 0) : 0);
      const rows = (k === 'bank' ? checkingRow : '') + list.map((a) => rowOf[a.key]).join('');
      const live = k === 'alt' ? altLiveTable(snap, list) : '';
      return `<div class="card nwsec"><h3>${SECTION_LABEL[k]} <span class="sectot ${total < 0 ? 'neg' : ''}">${usd(total)}</span></h3>
        ${live}${rows ? `<table class="tbl">${head}<tbody>${rows}</tbody></table>` : '<p class="note">None yet.</p>'}
        <div class="addrow">${adds[k]}</div><p class="note">${notes[k]}</p></div>`;
    }).join('');
  }
  const OWNERS = () => (SOLO() ? [['self', ownerName('self')], ['joint', 'Taxable / other'], ['spouse', 'Spouse (moves to you in the plan)']] : [['self', ownerName('self')], ['spouse', ownerName('spouse')], ['joint', 'Joint']]);
  function ownerCard(s) {
    const H = state.settings.household; const rows = {};
    for (const a of s.accts) { const o = a.owner || 'joint'; const b = a.taxType === 'pretax' ? 'pre' : a.taxType === 'roth' || a.taxType === 'hsa' ? 'roth' : a.taxType === 'taxable' ? 'tax' : a.taxType === 'edu' ? 'edu' : a.taxType === 'property' ? 'prop' : 'debt'; rows[o] = rows[o] || { pre: 0, roth: 0, tax: 0, edu: 0, prop: 0, debt: 0 }; rows[o][b] += a._value; }
    const order = ['self', 'spouse', 'joint'].filter((o) => rows[o]); const hasEdu = s.accts.some((a) => a.taxType === 'edu');
    const bad = s.accts.filter((a) => RETIRE(a.taxType) && a.owner === 'joint');
    const guessed = s.accts.filter((a) => a.ownerGuessed && !a.synthetic && a.key !== 'manual:checking');
    return `<div class="card"><h3>By owner <span class="sub">who owns each account matters for RMDs, the 59½ rule, conversions and inheritance</span></h3>
      <table class="tbl"><thead><tr><th>Owner</th><th class="n">Pre-tax (IRA/401k)</th><th class="n">Roth / HSA</th><th class="n">Taxable</th>${hasEdu ? '<th class="n">529</th>' : ''}<th class="n">Real estate − debt</th><th class="n">Total</th></tr></thead><tbody>
      ${order.map((o) => { const r = rows[o]; return `<tr><td><b>${esc(ownerName(o))}</b></td><td class="n">${usd(r.pre)}</td><td class="n">${usd(r.roth)}</td><td class="n">${usd(r.tax)}</td>${hasEdu ? `<td class="n">${usd(r.edu)}</td>` : ''}<td class="n">${usd(r.prop + r.debt)}</td><td class="n"><b>${usd(r.pre + r.roth + r.tax + r.edu + r.prop + r.debt)}</b></td></tr>`; }).join('')}</tbody></table>
      ${bad.length ? `<div class="banner amber">${bad.length} retirement account(s) are marked Joint. IRAs, 401(k)s, Roths and HSAs belong to one person; pick ${esc(H.selfName)} or ${esc(H.spouseName)}.</div>` : ''}
      ${guessed.length ? `<p class="note">Owner was inferred for ${guessed.length} account(s): ${guessed.map((a) => esc(a.name)).join(', ')}. Choose the owner in the table below to confirm.</p>` : ''}
      <p class="note">In the plan, each person's pre-tax money has its own RMDs (from their own age 73/75) and penalty-free withdrawals start at their own 59½. When one spouse dies, the survivor rolls the IRAs into their own. Taxable and real estate held jointly or in your trust ${ST().cp ? `are community property in ${STN()}, so both halves get a step-up in basis at the first death` : `get a step-up only on the deceased spouse's half (${STN()} isn't a community-property state)`}.</p></div>`;
  }
  const KIND_LABEL = { primary: 'Primary home', vacation: 'Vacation / second home (personal)', rental: 'Long-term rental', str: 'Vacation rental (short-term)' };
  // ===== Unified real estate: one component, shown identically in Net Worth and in Plan → Assumptions =====
  // Facts about homes you own (value, mortgage, costs, rent) live in the working copy and are saved with snapshots.
  // Decisions (sell year, buying a new property, whether costs are already in spending) belong to the active plan.
  function realEstateSection(where) {
    const W = cur(), P = plan(); const list = W.realEstate || []; const buys = P.purchases || [];
    const yr0 = (W.asOf.slice(0, 4) | 0) + 1;
    const fW = (i, key, label, type = 'number', opts = {}) => `<label class="fld"><span>${label}</span>${cell('working', `realEstate.${i}.${key}`, type, opts)}${opts.hint ? `<span class="hint">${opts.hint}</span>` : ''}</label>`;
    const fP = (path, label, type = 'number', opts = {}) => `<label class="fld${type === 'check' ? ' chk' : ''}">${type === 'check' ? cell('plan', path, 'check') + `<span>${label}</span>` : `<span>${label}</span>${cell('plan', path, type, opts)}`}${opts.hint ? `<span class="hint">${opts.hint}</span>` : ''}</label>`;
    const annual = (p, bal, rate, yrs, payOverride) => {
      const pay = +payOverride || L.pmt(+bal, rate, yrs);
      const costs = (+p.propertyTax || 0) + (+p.insurance || 0) + (+p.hoa || 0) + L.maintAmt(p);
      const rent = p.kind === 'rental' ? (+p.rentMonthly || 0) * 12 * (1 - (+p.vacancyPct || 0) / 100) * (1 - (+p.mgmtPct || 0) / 100) : 0;
      return { pay, costs, rent };
    };
    const costBlock = (f) => `<h4>Carrying costs <span class="sub">today's $ per year</span></h4><div class="grid4 tight">${f('propertyTax', 'Property tax $/yr')}${f('insurance', 'Insurance $/yr')}${f('hoa', 'HOA $/yr')}${f('maintAmt', 'Repairs & maintenance $/yr', 'number', { hint: 'today’s $; grows with inflation' })}</div>`;
    const rentBlock = (f) => `<h4>Rental income</h4><div class="grid4 tight">${f('rentMonthly', 'Gross rent $/month')}${f('vacancyPct', 'Vacancy %')}${f('mgmtPct', 'Management %')}</div>`;
    // ---- owned now ----
    const owned = list.map((p, i) => {
      const a = annual(p, p.mtgBalance, p.mtgRate, p.mtgYearsLeft, p.mtgPayment); const o = P.reSale?.[p.id] || {};
      const open = state.openProp === p.id; const sellY = o.sellYear;
      const f = (key, label, type, opts) => fW(i, key, label, type, opts);
      const row = `<tr class="arow ${open ? 'open' : ''}"><td>${cell('working', `realEstate.${i}.name`, 'text')}</td><td>${cell('working', `realEstate.${i}.kind`, null, { options: Object.entries(KIND_LABEL) })}</td>
        <td><span class="pill ok">Owned</span></td><td>${cell('working', `realEstate.${i}.value`, 'number', { ph: 'current value' })}</td><td>${cell('working', `realEstate.${i}.mtgBalance`, 'number', { ph: '0' })}</td>
        <td class="n">${usd((+p.value || 0) - (+p.mtgBalance || 0))}</td><td class="n">${usd(a.costs + a.pay * 12)}</td><td class="n">${L.isRental(p.kind) ? (planResults(window.__an).det.rows[0]?.rentals?.[p.id] ? usd(Math.round(planResults(window.__an).det.rows[0].rentals[p.id].cash / planResults(window.__an).det.rows[0].cpi)) : '—') : '—'}</td>
        <td>${cell('plan', `reSale.${p.id}.sellYear`, 'number', { ph: 'keep' })}</td><td><a href="#" data-act="openProp" data-id="${p.id}">${open ? 'Hide' : 'Details'}</a></td></tr>`;
      if (!open) return row;
      if (L.isRental(p.kind)) return row + `<tr class="aedit"><td colspan="10">Rental details (income, each expense, mortgage amortization, depreciation, passive losses) are managed on the <a href="#" data-tab="rentals">Rentals tab</a>.</td></tr>`;
      return row + `<tr class="aedit"><td colspan="10">
        <h4>Property facts <span class="sub">saved with snapshots</span></h4><div class="grid4 tight">${f('value', 'Current value $')}${f('basis', 'Cost basis $', 'number', { hint: 'purchase price + improvements' })}${f('purchaseYear', 'Year purchased')}${f('appreciation', 'Appreciation % / yr (real)', 'number', { hint: 'fixed-return plan; Monte Carlo uses history' })}</div>
        ${costBlock(f)}${p.kind === 'rental' ? rentBlock(f) : ''}
        <h4>Mortgage</h4><div class="grid4 tight">${f('mtgBalance', 'Balance $')}${f('mtgRate', 'Rate %', 'number', { warn: +p.mtgBalance && p.mtgRate == null })}${f('mtgPayment', 'Monthly P&I $', 'number', { ph: a.pay ? Math.round(a.pay) : '', hint: a.pay ? `blank = computed ${usd(a.pay)}` : 'blank = computed from rate and years left' })}${f('mtgYearsLeft', 'Years left')}${f('mtgExtra', 'Extra principal $/yr')}</div>
        <h4>In plan “${esc(P.name)}” <span class="sub">other plans can choose differently</span></h4><div class="grid4 tight">${fP(`reSale.${p.id}.sellYear`, 'Sell in year', 'number', { ph: 'keep' })}${fP(`reSale.${p.id}.sellCostPct`, 'Selling costs %', 'number', { ph: '6' })}${fP(`reSale.${p.id}.costsInSpending`, 'Costs & mortgage already in base spending', 'check')}</div>
        <button class="btn sm danger" data-act="delProp" data-id="${p.id}">Remove property</button></td></tr>`;
    }).join('');
    // ---- planned purchases (this plan) ----
    const planned = buys.map((b, j) => {
      const loan = (+b.price || 0) * (1 - (+b.downPct || 0) / 100); const a = annual(b, loan, b.rate, b.termYears);
      const id = 'buy:' + j; const open = state.openProp === id;
      const f = (key, label, type = 'number', opts = {}) => fP(`purchases.${j}.${key}`, label, type, opts);
      const row = `<tr class="arow ${open ? 'open' : ''}"><td>${cell('plan', `purchases.${j}.name`, 'text')}</td><td>${cell('plan', `purchases.${j}.kind`, null, { options: Object.entries(KIND_LABEL) })}</td>
        <td><span class="pill amber">Buy ${esc(b.year || '?')}</span></td><td>${cell('plan', `purchases.${j}.price`, 'number', { ph: 'price (today\'s $)' })}</td><td class="n">${usd(loan)}</td>
        <td class="n">${usd((+b.price || 0) - loan)}</td><td class="n">${usd(a.costs + a.pay * 12)}</td><td class="n">${b.kind === 'rental' ? usd(a.rent - a.costs - a.pay * 12) : '—'}</td>
        <td>${cell('plan', `purchases.${j}.sellYear`, 'number', { ph: 'keep' })}</td><td><a href="#" data-act="openProp" data-id="${id}">${open ? 'Hide' : 'Details'}</a></td></tr>`;
      if (!open) return row;
      return row + `<tr class="aedit"><td colspan="10">
        <h4>Purchase <span class="sub">only in plan “${esc(P.name)}”, today's $</span></h4><div class="grid4 tight">${f('year', 'Buy in year')}${f('price', 'Price $')}${f('downPct', 'Down payment %', 'number', { hint: '100 = cash' })}${f('rate', 'Mortgage rate %')}${f('termYears', 'Term (years)')}${f('appreciation', 'Appreciation % / yr (real)')}</div>
        ${costBlock(f)}${b.kind === 'rental' ? rentBlock(f) : ''}
        <h4>Later</h4><div class="grid4 tight">${f('sellYear', 'Sell in year', 'number', { ph: 'keep' })}${f('sellCostPct', 'Selling costs %', 'number', { ph: '6' })}${f('costsInSpending', 'Costs & mortgage already in base spending', 'check')}</div>
        <button class="btn sm danger" data-act="delItem" data-list="purchases" data-i="${j}">Remove planned purchase</button></td></tr>`;
    }).join('');
    const kindOpts = Object.entries(KIND_LABEL).map(([v, l]) => `<option value="${v}">${l}</option>`).join('');
    return `<div class="card" id="realestate"><h3>Real estate & mortgages <span class="sub">same table in Net Worth and Plan → Assumptions</span></h3>
      <p class="note">Plan shown: <b>${esc(P.name)}</b>${state.plans.length > 1 ? ` (switch plans on the Plan tab)` : ''}. Values and mortgages are facts shared by every plan. Sell years and future purchases belong to this plan only.</p>
      ${list.length || buys.length ? `<table class="tbl edit"><thead><tr><th>Property</th><th>Type</th><th>Status</th><th>Value / price $</th><th>Mortgage $</th><th class="n">Equity</th><th class="n">Costs + P&I / yr</th><th class="n">Net rent / yr</th><th>Sell in (plan)</th><th></th></tr></thead><tbody>${owned}${planned}</tbody></table>` : '<p class="note">No properties yet.</p>'}
      <div class="quickadd"><b>I own:</b><input id="qaName" type="text" placeholder="Name"><select id="qaKind">${kindOpts}</select><input id="qaValue" type="number" placeholder="Current value $"><input id="qaMtg" type="number" placeholder="Mortgage balance $ (0 if none)"><button class="btn sm primary" data-act="quickAddProp">Add</button></div>
      <div class="quickadd"><b>Plan to buy:</b><input id="qbName" type="text" placeholder="Name"><select id="qbKind">${kindOpts}</select><input id="qbYear" type="number" placeholder="Year (e.g. ${yr0 + 2})"><input id="qbPrice" type="number" placeholder="Price $ (today's)"><input id="qbDown" type="number" placeholder="Down payment % (100 = cash)"><button class="btn sm primary" data-act="quickAddBuy">Add to plan</button></div>
      <p class="note"><b>What "Costs + P&I" includes</b> for homes you live in: property tax (${isCA() ? 'growing ≤2%/yr under Prop 13' : 'growing with inflation'}) + homeowner's insurance + HOA + repairs & maintenance ($/yr, grows with inflation) + mortgage principal and interest. All of it is counted as <b>Housing</b> in the plan's cash flow, separate from your living-spending categories, unless you tick "Costs & mortgage already in base spending". Rentals' costs (insurance included) are netted against their rent on the Rentals tab instead.</p>
      <p class="note">The plan grows each property's value, pays down mortgages, pays carrying costs, and taxes rent after interest and depreciation. A sale returns net proceeds to your taxable account and taxes the gain, with the $500k exclusion on a primary home and depreciation recapture on a rental. A purchase pays the down payment from your portfolio.${where === 'plan' ? ' To downsize, set a sell year on the current home and add a planned purchase.' : ''}</p></div>`;
  }

  // ---------- RENTALS (passive income) ----------
  const L_amort = (bal, rate, pay, extra = 0, years = 40) => {
    const out = []; let b = +bal || 0; const r = (+rate || 0) / 1200; pay = +pay || 0; let y = 0;
    while (b > 1 && y < years) { let int = 0, prin = 0; for (let m = 0; m < 12 && b > 0.01; m++) { const i = b * r; const p = Math.min(b, Math.max(0, pay - i)); int += i; prin += p; b -= p; } const ex = Math.min(b, +extra || 0); b -= ex; prin += ex; out.push({ yr: ++y, payment: int + prin, interest: int, principal: prin, balance: b }); if (pay - b * r <= 0 && !ex && prin < 1) break; }
    return out;
  };
  // ---------- double-count audit ----------
  function auditDoubleCount(an) {
    const W = cur(), S = state.settings; const out = []; const add = (sev, area, text) => out.push({ sev, area, text });
    const RE = W.realEstate || []; const accts = W.accounts || [];
    const norm = (x) => (x || '').toLowerCase().replace(/[^a-z0-9]/g, '');
    // 1. duplicate properties
    const seen = {}; RE.forEach((p) => { const n = norm(p.name); if (n && seen[n]) add('high', 'Real estate', `“${p.name}” appears twice in Real estate. Remove one, or both values, costs and rents count twice.`); seen[n] = 1; });
    // 2. property also entered as an account
    for (const a of accts.filter((x) => x.taxType === 'property')) add('high', 'Real estate', `Account “${a.name}” is a property account and also counts as real estate. Move it into Real estate & mortgages and delete the account.`);
    for (const a of accts.filter((x) => x.taxType === 'liability')) { const v = Math.abs(sum(a.holdings, (h) => h.value)); const m = RE.find((p) => +p.mtgBalance && Math.abs(+p.mtgBalance - v) / Math.max(1, v) < 0.05); if (m || /mortgage|heloc/i.test(a.name)) add('medium', 'Debts', `Loan account “${a.name}” (${usd(v)}) may duplicate ${m ? `the ${m.name} mortgage (${usd(+m.mtgBalance)})` : 'a mortgage already entered on a property'}. Mortgages belong on the property only.`); }
    for (const a of accts) for (const p of RE) if (norm(p.name).length > 3 && norm(a.name).includes(norm(p.name))) add('medium', 'Real estate', `Account “${a.name}” has the same name as property “${p.name}”. Check it isn't the same asset entered twice.`);
    // 3. accounts: same institution + same value, checking entered twice
    const byVal = {}; for (const a of accts) { const v = Math.round(sum(a.holdings, (h) => h.value)); if (v < 1000 || a.manual) continue; const key = v + '|' + a.institution; if (byVal[key]) add('medium', 'Accounts', `“${a.name}” and “${byVal[key]}” at ${a.institution} have the identical balance ${usd(v)}. Possible duplicate import or manual entry.`); byVal[key] = a.name; }
    if (+W.manual.checking) for (const a of accts.filter((x) => x.manual && x.holdings.some((h) => h.assetClass === 'cash' || h.assetClass === 'bank') && /check|saving|bank/i.test(x.name))) add('high', 'Cash', `Manual account “${a.name}” looks like checking/savings, and the separate Checking / savings balance (${usd(+W.manual.checking)}) also counts. Keep only one.`);
    const goog = accts.filter((a) => a.holdings.some((h) => /^GOOGL?$/.test(h.symbol)));
    if (goog.length > 1) add('medium', 'Accounts', `${CS()} is held in ${goog.length} accounts (${goog.map((a) => a.name).join(', ')}). Fine if they are different shares; a duplicate if one is a manual copy of the Morgan Stanley lots.`);
    // 4. plan-level overlaps
    for (const P of state.plans) {
      const cats = P.spending.categories || [];
      const words = [[/mortgage|\brent\b|property tax|\bhoa\b|home insurance|homeowner/i, 'housing (property tax, insurance, HOA, maintenance, mortgage) is modeled from Real estate'], [/\bhealth (insurance|premium)|medical insurance|premium|medicare|\baca\b|covered ca/i, 'health premiums are modeled under Healthcare'], [/income tax|taxes/i, 'income taxes are calculated by the plan']];
      const hasHome = RE.some((p) => !L.isRental(p.kind));
      for (const c of cats) for (const [re, why] of words) if (re.test(c.name) && !(/out-of-pocket|dental|vision/i.test(c.name) && /health/.test(why)) && !(/housing/.test(why) && !hasHome) && !(/health premiums/.test(why) && (!P.healthcare?.model || /via work|employer/i.test(c.name)))) add('medium', `Plan “${P.name}”`, `Spending category “${c.name}” may double count: ${why}.`);
      const rentals = RE.filter((p) => L.isRental(p.kind));
      for (const s of P.incomes || []) if (/rent|airbnb|vrbo|ranch|cabin|lease/i.test(s.name) && rentals.length) add('high', `Plan “${P.name}”`, `Income stream “${s.name}” looks like rental income, which the Rentals tab already models. Remove it or the rent counts twice.`);
      for (const e of P.events || []) if (/house|home|condo|ranch|cabin|property|sale|sell|purchase|down payment/i.test(e.name)) add('medium', `Plan “${P.name}”`, `One-time event “${e.name}” may duplicate a property sale or purchase handled in Real estate.`);
      if (P.healthcare.model && cats.some((c) => /health insurance|premium/i.test(c.name))) add('high', `Plan “${P.name}”`, 'Healthcare premiums are modeled and also appear in a spending category.');
      for (const p of RE) { const o = P.reSale?.[p.id] || {}; if (!L.isRental(p.kind) && (o.costsInSpending === true || o.costsInSpending === 'true') && !cats.some((c) => /hous|mortgage|property/i.test(c.name))) add('low', `Plan “${P.name}”`, `${p.name}: “costs already in spending” is ticked, but no spending category mentions housing. Its costs may be missing rather than double counted.`); }
    }
    // 5. arithmetic checks on the projection
    try {
      const R = planResults(an); let worst = 0, wy = null;
      for (const r of R.det.rows) { const fl = yearFlows({ ...r }); const d = Math.abs(sum(fl.srcs, (x) => x.v) - sum(fl.uses, (x) => x.v)); const rel = d / Math.max(1, sum(fl.uses, (x) => x.v)); if (rel > worst) { worst = rel; wy = r.year; } }
      const s = an.s; const recon = s.liquid + s.property - s.liabilities - s.total;
      const r0 = R.init; const initLiquid = r0.taxable + r0.pretax + r0.roth;
      const reVal = sum(RE, (p) => +p.value || 0), reDebt = sum(RE, (p) => +p.mtgBalance || 0);
      add(Math.abs(recon) < 1 ? 'ok' : 'high', 'Net worth math', `Liquid ${usd(s.liquid)} + property ${usd(s.property)} − debts ${usd(s.liabilities)} = ${usd(s.liquid + s.property - s.liabilities)} vs. net worth ${usd(s.total)}${Math.abs(recon) < 1 ? ' ✓' : ` (off by ${usd(recon)})`}.`);
      add(Math.abs(initLiquid - s.liquid) < 1 ? 'ok' : 'high', 'Plan starting point', `Plan starts from ${usd(initLiquid)} liquid (taxable ${usd(r0.taxable)}, pre-tax ${usd(r0.pretax)}, Roth ${usd(r0.roth)}) = Net Worth liquid ${usd(s.liquid)}${Math.abs(initLiquid - s.liquid) < 1 ? ' ✓' : ' ✗'}. Real estate ${usd(reVal)} and mortgages ${usd(reDebt)} enter the plan once, from the Real estate table${r0.property || r0.debt ? `, plus ${usd(r0.property)} / ${usd(r0.debt)} from property/loan accounts` : ''}.`);
      add(worst < 0.002 ? 'ok' : 'medium', 'Cash flow math', worst < 0.002 ? 'Every projected year balances: money in = money out (spending, housing, rental shortfalls, healthcare, taxes, contributions, savings) ✓.' : `Largest imbalance ${pct(worst * 100, 2)} in ${wy} (tax-iteration rounding).`);
      // property tax: where each property's tax shows up, and a check against ProjectionLab when imported
      if (RE.length) {
        const homeT = sum(RE.filter((p) => !L.isRental(p.kind)), (p) => +p.propertyTax || 0), rentT = sum(RE.filter((p) => L.isRental(p.kind)), (p) => +p.propertyTax || 0);
        add('ok', 'Property tax', `${usd(homeT + rentT)}/yr across ${RE.length} propert${RE.length === 1 ? 'y' : 'ies'}: ${RE.map((p) => `${esc(p.name)} ${usd(+p.propertyTax || 0)}`).join(', ')}. Homes (${usd(homeT)}) are paid inside Housing and are itemizable; rentals (${usd(rentT)}) are deducted from rent. Analytics → Taxes shows all of it. If a figure looks low, check that it's the full year (California bills come in two installments).`);
        const J = state.plImport; const JP = J ? J.plans[Math.min(J.plans.length - 1, state.plPlanIdx || 0)] : null;
        for (const x of (JP && JP.assets && JP.assets.length ? JP.assets : J ? J.assets || [] : [])) {
          const p = RE.find((q) => String(q.name || '').trim().toLowerCase() === String(x.name || '').trim().toLowerCase()); if (!p || !(x.propertyTax > 0)) continue;
          const mine = +p.propertyTax || 0; if (Math.abs(mine - x.propertyTax) / x.propertyTax > 0.2) add('medium', 'Property tax', `${esc(p.name)}: ${usd(mine)}/yr here vs ${usd(x.propertyTax)}/yr in your ProjectionLab file. Update it under Money → ${L.isRental(p.kind) ? 'Rentals' : 'Net worth → Real estate'} if ProjectionLab is right.`);
        }
      }
      add('ok', 'By design (not double counted)', 'Rental costs are netted inside each rental’s cash flow, not in Housing. Property tax on homes you live in is paid inside Housing and shown again only as an informational line in the tax chart. IRMAA sits in Healthcare, not Taxes. Taxable-account sales count only their realized gain as income. 401(k)s are split pre-tax vs Roth from statement source totals, which sum to the plan balance.');
    } catch (e) { add('medium', 'Checks', 'Projection checks could not run: ' + e.message); }
    return out;
  }
  function auditCard(an) {
    const items = auditDoubleCount(an); const issues = items.filter((x) => x.sev !== 'ok');
    const cls = { high: 'high', medium: 'medium', low: 'low', ok: 'ok' };
    return `<div class="card"><h3>Double-count check <span class="sub">${issues.length ? `${issues.length} item(s) to review` : 'no problems found'}</span></h3>
      ${items.map((x) => `<div class="flag ${cls[x.sev]}"><b>${esc(x.area)}</b> ${esc(x.text)}</div>`).join('')}</div>`;
  }
  function vRentals(snap, an) {
    const W = cur(), P = plan(); const list = (W.realEstate || []).map((p, i) => ({ p, i })).filter((x) => L.isRental(x.p.kind));
    const R = planResults(an); const rows = R.det.rows; const r0 = rows[0];
    const d0 = (p) => (r0 && r0.rentals ? r0.rentals[p.id || p.name] : null);
    const f = (i, key, label, type = 'number', opts = {}) => `<label class="fld"><span>${label}</span>${cell('working', `realEstate.${i}.${key}`, type, opts)}${opts.hint ? `<span class="hint">${opts.hint}</span>` : ''}</label>`;
    const fc = (i, key, label) => `<label class="fld chk">${cell('working', `realEstate.${i}.${key}`, 'check')}<span>${label}</span></label>`;
    const real = (v) => (r0 ? v / r0.cpi : v);
    // portfolio summary
    const tot = { value: 0, debt: 0, gross: 0, cash: 0, net: 0, susp: 0, dep: 0 };
    for (const { p } of list) { const d = d0(p); tot.value += +p.value || 0; tot.debt += +p.mtgBalance || 0; if (d) { tot.gross += real(d.gross); tot.cash += real(d.cash); tot.net += real(d.net); tot.susp += real(d.suspended || 0); tot.dep += real(d.dep); } }
    const head = `<div class="kpis"><div class="kpi"><div class="kl">Rental properties</div><div class="kv">${list.length}</div><div class="ks">${k(tot.value)} value · ${k(tot.debt)} mortgage · ${k(tot.value - tot.debt)} equity</div></div>
      <div class="kpi"><div class="kl">Gross rent (${r0 ? r0.year : ''})</div><div class="kv">${k(tot.gross)}</div><div class="ks">after vacancy / occupancy</div></div>
      <div class="kpi"><div class="kl">Cash flow after mortgage</div><div class="kv ${tot.cash < 0 ? 'neg' : 'pos'}">${k(tot.cash)}</div><div class="ks">per year, today's $</div></div>
      <div class="kpi"><div class="kl">Schedule E net</div><div class="kv ${tot.net < 0 ? 'neg' : ''}">${k(tot.net)}</div><div class="ks">after ${k(tot.dep)} depreciation</div></div>
      <div class="kpi"><div class="kl">Suspended passive losses</div><div class="kv">${k(tot.susp)}</div><div class="ks">carried forward; released on sale</div></div></div>`;
    const cards = list.map(({ p, i }) => {
      const d = d0(p); const str = p.kind === 'str';
      const pay = +p.mtgPayment || L.pmt(+p.mtgBalance, p.mtgRate, p.mtgYearsLeft);
      const am = L_amort(p.mtgBalance, p.mtgRate, pay, p.mtgExtra);
      const equity = (+p.value || 0) - (+p.mtgBalance || 0);
      const line = (label, v, cls = '') => `<tr class="${cls}"><td>${label}</td><td class="n">${v == null ? '—' : usd(Math.round(real(v)))}</td></tr>`;
      const pl = d ? `<table class="tbl pl"><tbody>
        ${line(str ? `Rental income (${Math.round(d.rentalDays)} nights × ${usd(+p.nightlyRate || 0)})` : 'Rent (after vacancy)', d.gross, 'b')}
        ${line('Management', -d.mgmt)}${str ? line('Platform fees (Airbnb/VRBO)', -d.platform) + line('Cleaning', -d.cleaning) + line('Utilities', -d.utilities) + line('Supplies', -d.supplies) : (d.utilities ? line('Utilities', -d.utilities) : '')}
        ${line('Insurance', -d.insurance)}${line(isCA() ? 'Property tax (Prop 13)' : 'Property tax', -d.ptx)}${d.hoa ? line('HOA', -d.hoa) : ''}${line('Repairs & maintenance', -d.repairs)}
        ${line('= Net operating income', d.noi, 'b')}${line('Mortgage interest', -d.interest)}${line('Mortgage principal (amortization)', -d.principal)}
        ${line('= Cash flow', d.cash, 'b ' + (d.cash < 0 ? 'neg' : 'pos'))}
        <tr><td colspan="2" class="sub">Tax view (Schedule E)</td></tr>
        ${d.share < 0.999 ? `<tr><td>Rental-use share (${Math.round(d.rentalDays)} rental / ${d.personalDays} personal days)</td><td class="n">${pct(d.share * 100, 0)}</td></tr>` : ''}
        ${line('Deductible operating expenses', -d.dedOpex)}${line('Deductible interest', -d.intR)}${line('Depreciation (27.5-yr, building only)', -d.dep)}
        ${line('= Net rental income / (loss)', d.net, 'b ' + (d.net < 0 ? 'neg' : ''))}
        ${line('Suspended loss carried forward', d.suspended || 0)}</tbody></table>
        <p class="note">${d.heavyPersonal ? `<b class="neg">Vacation-home rule:</b> personal use (${d.personalDays} days) is over the greater of 14 days or 10% of rental days, so the loss can't offset other income; it carries forward.` : d.nonPassive ? 'Short-term rental with average stay ≤ 7 days and material participation: losses are non-passive and offset your other income.' : str ? 'Short-term rental: the $25k rental-loss allowance does not apply (average stay ≤ 7 days means it isn\'t a "rental activity"). Losses are passive unless you materially participate.' : 'Long-term rental: passive. Up to $25k of losses can offset other income if MAGI is under $100k (phases out by $150k); otherwise losses carry forward until you have passive income or sell.'}</p>` : '<p class="note">No projection yet.</p>';
      const amTbl = am.length ? `<div class="scroll" style="max-height:260px"><table class="tbl"><thead><tr><th>Year</th><th class="n">Payments</th><th class="n">Interest</th><th class="n">Principal</th><th class="n">Balance</th></tr></thead><tbody>${am.map((a) => `<tr><td>${(+W.asOf.slice(0, 4)) + a.yr}</td><td class="n">${usd(Math.round(a.payment))}</td><td class="n">${usd(Math.round(a.interest))}</td><td class="n">${usd(Math.round(a.principal))}</td><td class="n">${usd(Math.round(a.balance))}</td></tr>`).join('')}</tbody></table></div><p class="note">Monthly payment ${usd(Math.round(pay))}${+p.mtgExtra ? ` + ${usd(+p.mtgExtra)}/yr extra principal` : ''}; total interest ${usd(Math.round(am.reduce((t, a) => t + a.interest, 0)))}; paid off in ${(+W.asOf.slice(0, 4)) + am.length}. Nominal dollars (fixed-rate mortgage).</p>` : '<p class="note">No mortgage.</p>';
      const proj = rows.filter((r) => r.rentals && r.rentals[p.id || p.name]).slice(0, 15).map((r) => { const x = r.rentals[p.id || p.name]; const fr = 1 / r.cpi, fb = 1 / r.cpiEnd; return `<tr><td>${r.year}</td><td class="n">${k(x.gross * fr)}</td><td class="n">${k(x.cashOpex * fr)}</td><td class="n">${k(x.interest * fr)}</td><td class="n">${k(x.principal * fr)}</td><td class="n">${k(x.dep * fr)}</td><td class="n ${x.net < 0 ? 'neg' : ''}">${k(x.net * fr)}</td><td class="n ${x.cash < 0 ? 'neg' : ''}">${k(x.cash * fr)}</td><td class="n">${k((x.suspended || 0) * fr)}</td><td class="n">${k(x.value * fb)}</td><td class="n">${k(x.bal * fb)}</td></tr>`; }).join('');
      const capRate = d && +p.value ? real(d.noi) / p.value * 100 : 0, coc = d && equity > 0 ? real(d.cash) / equity * 100 : 0;
      return `${p.needsInput && !+p.value ? `<div class="banner">${esc(p.name)} was added as a vacation rental. Enter its value, basis, nightly rate, occupancy, costs and mortgage below.</div>` : ''}<div class="card rental"><h3>${esc(p.name)} <span class="pill ${str ? 'amber' : 'ok'}">${str ? 'Vacation rental (short-term)' : 'Long-term rental'}</span> <span class="sub">value ${usd(+p.value || 0)} · mortgage ${usd(+p.mtgBalance || 0)} · equity ${usd(equity)} · cap rate ${pct(capRate, 1)} · cash-on-cash ${pct(coc, 1)}</span></h3>
        <div class="anagrid"><div>
        <h4>Property & tax basis</h4><div class="grid4 tight">${f(i, 'name', 'Name', 'text')}${f(i, 'kind', 'Type', null, { options: [['rental', 'Long-term rental'], ['str', 'Vacation rental (short-term)']] })}${f(i, 'value', 'Current value $')}${f(i, 'basis', 'Cost basis $', 'number', { hint: 'purchase price + improvements' })}
          ${f(i, 'purchaseYear', 'Placed in service (year)')}${f(i, 'buildingPct', 'Building % of basis', 'number', { ph: '60', hint: 'land isn’t depreciable; use your county assessor split' })}${f(i, 'priorDepreciation', 'Depreciation taken so far $', 'number', { ph: 'auto', hint: 'from last return; drives recapture' })}${f(i, 'suspendedLoss', 'Suspended passive loss carryforward $', 'number', { hint: 'Form 8582' })}</div>
        <h4>Income</h4><div class="grid4 tight">${str ? `${f(i, 'nightlyRate', 'Average nightly rate $')}${f(i, 'occupancyPct', 'Occupancy % (nights booked / 365)')}${f(i, 'avgStay', 'Average stay (nights)')}${f(i, 'personalDays', 'Personal-use days / yr')}${fc(i, 'materialParticipation', 'I materially participate (100+ hrs, more than anyone else)')}` : `${f(i, 'rentMonthly', 'Monthly rent $')}${f(i, 'vacancyPct', 'Vacancy %')}${f(i, 'personalDays', 'Personal-use days / yr', 'number', { ph: '0' })}`}</div>
        <h4>Operating expenses <span class="sub">today's $ per year</span></h4><div class="grid4 tight">${f(i, 'mgmtPct', 'Management % of rent')}${str ? f(i, 'platformPct', 'Platform fees %') + f(i, 'cleaning', 'Cleaning $/yr') + f(i, 'supplies', 'Supplies & consumables $/yr') : ''}${f(i, 'utilities', 'Utilities $/yr (if you pay)')}
          ${f(i, 'insurance', 'Insurance $/yr', 'number', { hint: str ? 'landlord/STR policy' : 'landlord (DP-3) policy' })}${f(i, 'propertyTax', 'Property tax $/yr', 'number', { hint: isCA() ? 'grows ≤2%/yr under Prop 13' : 'grows with inflation' })}${f(i, 'hoa', 'HOA $/yr')}${f(i, 'maintAmt', 'Repairs & maintenance $/yr', 'number', { hint: 'today’s $; grows with inflation' })}</div>
        <h4>Mortgage</h4><div class="grid4 tight">${f(i, 'mtgBalance', 'Balance $')}${f(i, 'mtgRate', 'Rate %')}${f(i, 'mtgPayment', 'Monthly P&I $', 'number', { ph: pay ? Math.round(pay) : '', hint: 'blank = computed' })}${f(i, 'mtgYearsLeft', 'Years left')}${f(i, 'mtgExtra', 'Extra principal $/yr')}</div>
        <h4>In plan “${esc(P.name)}”</h4><div class="grid4 tight"><label class="fld"><span>Sell in year</span>${cell('plan', `reSale.${p.id}.sellYear`, 'number', { ph: 'keep' })}</label><label class="fld"><span>Selling costs %</span>${cell('plan', `reSale.${p.id}.sellCostPct`, 'number', { ph: '6' })}</label></div>
        </div><div><h4>${r0 ? r0.year : ''} profit & loss <span class="sub">today's $</span></h4>${pl}</div></div>
        <details open><summary><b>Amortization schedule</b></summary>${amTbl}</details>
        <details><summary><b>15-year projection</b> (today's $, fixed returns)</summary><div class="scroll" style="max-height:320px"><table class="tbl"><thead><tr><th>Year</th><th class="n">Rent</th><th class="n">Op. expenses</th><th class="n">Interest</th><th class="n">Principal</th><th class="n">Depreciation</th><th class="n">Sched. E net</th><th class="n">Cash flow</th><th class="n">Suspended</th><th class="n">Value</th><th class="n">Mortgage</th></tr></thead><tbody>${proj}</tbody></table></div></details>
        <p><button class="btn sm danger" data-act="delProp" data-id="${p.id}">Remove property</button></p></div>`;
    }).join('');
    return `${head}${cards || '<div class="card"><p>No rental properties yet. Add your long-term rental and vacation rental below.</p></div>'}
      <div class="card"><h3>Add a rental</h3><button class="btn" data-act="addProp" data-kind="rental">+ Long-term rental</button> <button class="btn" data-act="addProp" data-kind="str">+ Vacation rental (short-term)</button>
        <p class="note">Rentals also appear in Net Worth → Real estate (same data) and flow into every plan: rent and costs in cash flow, Schedule E income in taxes, depreciation recapture and released suspended losses when sold.</p></div>
      <div class="card"><h3>How rentals are taxed here</h3><ul class="steps">
        <li><b>Depreciation:</b> the building share of your basis over 27.5 years (land isn't depreciable). It lowers taxable rent now. When you sell, the depreciation taken is "recaptured" as ordinary income (federal max 25%), and the rest of the gain is a capital gain.</li>
        <li><b>Passive losses:</b> rental losses offset other passive income. Up to $25,000 of long-term-rental losses can offset wages and portfolio income only when MAGI is under $100k (gone at $150k). Anything else is suspended and carried forward, then released in full when you sell that property.</li>
        <li><b>Vacation rental (short-term):</b> if guests' average stay is 7 nights or less, it isn't a "rental activity". The $25k allowance doesn't apply, but if you materially participate the losses become non-passive and offset any income (the "STR loophole").</li>
        <li><b>Personal use:</b> days you use it yourself split expenses between rental and personal. If personal days exceed 14 or 10% of rented days, the property is a residence for tax purposes and the rental can't produce a deductible loss. The personal share of property tax and mortgage interest goes to itemized deductions.</li>
        ${isCA() ? `<li><b>California:</b> follows the federal passive-loss and depreciation rules for rentals, taxes net rent and gains as ordinary income, and doesn't allow federal bonus depreciation. Property tax is limited by Prop 13. Vacation rentals collect local transient occupancy tax (TOT) from guests; that's a pass-through, so it's not modeled.</li>` : ''}
        <li><b>Also counts toward:</b> net rental income is investment income for the 3.8% NIIT and adds to ACA MAGI.</li></ul></div>${auditCard(an)}`;
  }

  // ---------- TAXES ----------
  function vTaxes(snap, an) {
    const S = state.settings;
    const col = (t, magi) => `<td class="n">${usd(magi)}</td><td class="n">${usd(t.fedOrdinary)}</td><td class="n">${usd(t.fedPref)}</td><td class="n">${usd(t.niit)}</td><td class="n">${usd(t.ca)}</td><td class="n"><b>${usd(t.total)}</b></td><td class="n">${pct(t.fedMarginal * 100, 0)} / ${pct(t.caMarginal * 100, 1)}</td><td class="n">${usd(t.ltcgZeroRoom)}</td>`;
    const rows = [`<tr><td>${an.Y} before new sales</td>${col(an.taxNow, an.magiNow.value)}</tr>`, `<tr><td>${an.Y} with plan</td>${col(an.taxAfter, an.magiAfter.value)}</tr>`];
    if (an.taxNextAfter) rows.push(`<tr><td>${an.Y + 1} with plan${an.taxNextAfter.tax.est ? ' *' : ''}</td>${col(an.taxNextAfter.tax, an.taxNextAfter.magi.value)}</tr>`);
    const thRow = (y, t) => `<tr><td>${y}</td><td class="n">${usd(t.fpl)}${t.fplEst ? ' *' : ''}</td><td class="n">${usd(t.csr94)}</td><td class="n">${usd(t.csr87)}</td><td class="n">${usd(t.csr73)}</td><td class="n">${usd(t.cliff)}</td></tr>`;
    const ptcNow = E.ptc(S, an.Y, an.magiAfter.value), ptcOver = E.ptc(S, an.Y, an.th.cliff - 1);
    const ptc = ptcNow ? `<p>Estimated premium tax credit at ${usd(an.magiAfter.value)} MAGI: <b>${usd(ptcNow.credit)}</b> (${pct(ptcNow.pct, 0)} FPL, expected contribution ${pct(ptcNow.appPct * 100, 2)}). One dollar over ${usd(an.th.cliff)}: ${usd(0)}${S.aca.cliffInEffect ? ', because the cliff removes the whole credit' : ''}.</p>` : `<p class="note">Enter your annual benchmark silver premium in Settings → ACA to see the dollar value of staying under the cliff.</p>`;
    const incRows = an.inc.rows.sort((a, b) => b.income - a.income).map((r) => `<tr><td>${esc(r.account)}</td><td>${esc(r.symbol)}</td><td class="n">${usd(r.value)}</td><td class="n">${usd(r.income)}</td><td>${r.kind}</td><td class="note">${esc(r.src)}</td></tr>`).join('');
    return `<div class="card"><h3>Estimated tax (federal MFJ + ${STN()})</h3>
      <table class="tbl"><thead><tr><th>Scenario</th><th class="n">MAGI</th><th class="n">Fed ordinary</th><th class="n">Fed LTCG/QD</th><th class="n">NIIT</th><th class="n">${STC()}</th><th class="n">Total</th><th class="n">Marginal fed/${STC()}</th><th class="n">0% LTCG room left</th></tr></thead><tbody>${rows.join('')}</tbody></table>
      <p class="note">Federal uses the 2026 MFJ brackets and standard deduction ($32,200); 0% LTCG applies up to $98,900 of taxable income. ${isCA() ? 'California taxes capital gains as ordinary income.' : ST().type === 'none' ? `${STN()} has no income tax${ST().cg ? ' (except its capital-gains excise)' : ''}.` : `${STN()} tax is ${ST().q === 'approx' ? '<b>approximate</b> (top rate applied to all taxable income; edit in Settings)' : 'from its published schedule'}.`} * Years without published tables are inflated ${S.ref.indexRate * 100}%/yr. These are planning estimates, not a tax return.</p></div>
      <div class="card"><h3>ACA thresholds <span class="sub">household of ${S.household.size}</span></h3>
      <table class="tbl"><thead><tr><th>Coverage year</th><th class="n">100% FPL</th><th class="n">150% (CSR-94)</th><th class="n">200% (CSR-87)</th><th class="n">250% (CSR-73)</th><th class="n">400%</th></tr></thead><tbody>${thRow(an.Y, an.th)}${thRow(an.Y + 1, an.thNext)}</tbody></table>
      ${ptc}<p class="note">Whether the 400% cliff applies depends on Congress (the enhanced subsidies lapsed after 2025). Check the current rule each fall and set it in Settings. ${isCA() ? 'California also offers its own state subsidies.' : 'Some states add their own subsidies.'}</p></div>
      <div class="card"><h3>Where the baseline MAGI comes from</h3><table class="tbl"><thead><tr><th>Account</th><th>Ticker</th><th class="n">Value</th><th class="n">Est. income/yr</th><th>Type</th><th>Basis</th></tr></thead><tbody>${incRows}</tbody></table>
      <p class="note">Interest on a large money-market buffer adds to MAGI. ${STN()} muni money-market funds avoid federal and ${STC()} tax, but their interest still counts toward ACA MAGI.</p></div>`;
  }

  // ---------- PLAN (ProjectionLab-style) ----------
  let planCache = { key: null };
  function planResults(an) {
    const P = plan(); const S = state.settings;
    const key = JSON.stringify([P, S.household, S.aca, S.ref, state.taxReturns || null, state.useReturns, cur().asOf, cur().manual.checking, cur().manual.checkingOwner, cur().realEstate || [], cur().accounts.map((x) => [x.key, x.taxType, sum(x.holdings, (h) => h.value), sum(x.holdings, (h) => h.cost)])]);
    if (planCache.key === key) return planCache;
    const t0 = performance.now(); const first = planCache.key == null;
    const init = L.initFromSnapshot(cur(), S, an); Object.assign(init, returnsForPlan(init.year));
    const det = L.deterministic(P, init, S);
    const mc = L.monteCarlo(P, init, S, Math.max(100, Math.min(3000, +P.sim.runs || 1000)));
    const bt = L.backtest(P, init, S);
    planCache = { key, init, det, mc, bt, at: new Date(), ms: Math.round(performance.now() - t0), reason: state._forceRecalc ? 'Recalculated on request' : first ? 'Calculated when the Plan opened' : 'Recalculated because inputs changed', runs: mc.runs };
    state._forceRecalc = false;
    return planCache;
  }
  const PTABS = [['setup', 'Assumptions'], ['events', 'Life events'], ['overview', 'Overview'], ['cashflow', 'Cash flow'], ['ptaxes', 'Analytics'], ['strategies', 'Strategies'], ['mc', 'Risk'], ['compare', 'Compare']];
  function vPlan(snap, an) {
    const P = plan(); const S = state.settings;
    const OLD = { optimize: ['strategies', 'stratView', 'tax'], di: ['strategies', 'stratView', 'di'], scenarios: ['compare', 'cmpView', 'plans'], pl: ['compare', 'cmpView', 'pl'] };
    if (OLD[state.planTab]) { const [t0, k0, v0] = OLD[state.planTab]; state.planTab = t0; state[k0] = v0; }
    if (!PTABS.some(([id]) => id === state.planTab)) state.planTab = state.planVisited ? 'overview' : 'setup'; state.planVisited = true;
    const bar = `<div class="planbar"><span>Plan:</span>${state.plans.map((p) => `<button class="chip ${p.id === P.id ? 'on' : ''}" data-act="selPlan" data-id="${p.id}">${esc(p.name)}</button>`).join('')}
      <span class="sp"></span><button class="btn sm" data-act="renamePlan">Rename</button> <button class="btn sm" data-act="dupPlan">Duplicate</button> <button class="btn sm" data-act="newPlan">New</button> ${state.plans.length > 1 ? '<button class="btn sm danger" data-act="delPlan">Delete</button>' : ''}</div>
      <div class="subtabs">${PTABS.map(([id, l]) => `<button class="stab ${state.planTab === id ? 'on' : ''}" data-ptab="${id}">${l}</button>`).join('')}</div>`;
    const warn = !S.household.agesConfirmed ? '<div class="banner">Birth years are still placeholders (1975). Every age-based rule (59½, Medicare, RMDs, Social Security) depends on them. Set them under Assumptions.</div>' : '';
    const R = planResults(an);
    const status = `<div class="modelstatus"><span class="dot"></span><b>Model is current.</b> ${esc(R.reason)} at ${R.at.toLocaleTimeString()} (${(R.ms / 1000).toFixed(2)} s): fixed-return projection, Monte Carlo ${R.runs.toLocaleString()} runs, backtest ${R.bt.runs} start years. Inputs: working copy ${esc(cur().asOf)}${state.dirty ? ' (unsaved edits included)' : ''}. <a href="#" data-act="recalc">Recalculate now</a></div>`;
    const seg = (key, opts) => `<div class="seg" style="margin:0 0 10px">${opts.map(([v, l]) => `<button class="btn sm ${(state[key] || opts[0][0]) === v ? 'primary' : ''}" data-act="planSeg" data-k="${key}" data-v="${v}">${l}</button>`).join(' ')}</div>`;
    const views = { overview: pOverview, setup: pSetup, events: pLife, cashflow: pCashflow, ptaxes: pTaxes, mc: pMC,
      strategies: (...x) => seg('stratView', [['tax', 'Tax strategies'], ['di', 'Direct indexing']]) + (state.stratView === 'di' ? pDI(...x) : pOptimize(...x)),
      compare: (...x) => seg('cmpView', [['plans', 'Compare plans'], ['pl', 'vs ProjectionLab']]) + (state.cmpView === 'pl' ? pPL(...x) : pScenarios(...x)) };
    return bar + status + warn + (views[state.planTab] || pOverview)(P, S, R, an);
  }
  const realRow = (r) => (state.planReal ? { f: 1 / r.cpi, b: 1 / r.cpiEnd } : { f: 1, b: 1 });
  const ageOfYear = (y) => y - state.settings.household.birthYearSelf;
  const succCls = (x) => (x >= 0.85 ? 'pos' : x >= 0.7 ? 'warnc' : 'neg');


  function nwZoomBar(bands) {
    const z = state.nwZoom || {}; const m = z.mode || 'auto';
    const b = (id, label, tip) => `<button class="btn sm ${m === id ? 'primary' : ''}" data-act="nwZoom" data-m="${id}" title="${tip}">${label}</button>`;
    const ages = bands.map((x) => x.age); const opt = (sel, ph) => `<option value="">${ph}</option>` + ages.filter((a) => a % 5 === 0 || a === ages[0] || a === ages[ages.length - 1]).map((a) => `<option ${+sel === a ? 'selected' : ''}>${a}</option>`).join('');
    return `<div class="addrow" style="display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-bottom:6px"><span class="mut">Zoom:</span>
      ${b('plan', 'Fit my plan', 'Scale to the fixed-return projection and the 10th percentile')}${b('median', 'Fit median', 'Scale to the Monte Carlo median')}${b('auto', 'Default', 'Clip the extreme top of the range')}${b('all', 'Show everything', 'Include the full 90th percentile')}
      <span class="mut" style="margin-left:10px">Ages</span><select id="nwZoomFrom">${opt(z.from, 'start')}</select><span class="mut">to</span><select id="nwZoomTo">${opt(z.to, 'end')}</select>
      ${z.from || z.to ? '<button class="btn sm" data-act="nwZoomReset">Reset ages</button>' : ''}</div>`;
  }
  function whyGap(P, R) {
    const { det, mc } = R; const H = L.HIST_REAL; const Rr = P.returns; const mm = !!P.sim.matchMeans;
    const endAge = mc.bands[mc.bands.length - 1].age;
    const row = (name, plan, hist) => `<tr><td>${name}</td><td class="n">${(+plan).toFixed(1)}%</td><td class="n">${hist.toFixed(1)}%</td><td class="n ${!mm && Math.abs(hist - plan) > 0.75 ? 'warnc' : ''}">${mm ? 'matched' : (hist - plan >= 0 ? '+' : '') + (hist - plan).toFixed(1) + ' pts'}</td></tr>`;
    const det10 = det.rows.find((r) => r.age === mc.bands[0].age + 10), b10 = mc.bands.find((b) => b.age === mc.bands[0].age + 10);
    const ratio = det.endReal > 0 ? mc.medianEnd / det.endReal : null; const higher = mc.medianEnd > det.endReal;
    return `<details ${state.whyOpen ? 'open' : ''} id="whyGap" style="margin-top:8px"><summary><b>Why is the dashed "my plan" line ${mc.medianEnd > det.endReal ? 'below' : 'above'} the Monte Carlo median?</b> ${ratio && !mm ? `<span class="mut">At ${endAge}: plan ${k(det.endReal)} vs median ${k(mc.medianEnd)} (${ratio.toFixed(1)}×)</span>` : ''}</summary>
      <p>The dashed line uses <b>your fixed return assumptions</b> every year, with no ups and downs. The blue bands replay <b>real market history (1928–2025)</b> in random 5-year blocks${mm ? ', shifted so each asset averages your assumption' : ''}. A small difference per year compounds a lot over ${mc.bands.length} years.</p>
      <p>${higher ? (mm ? 'With returns matched, the remaining gap comes from the order of good and bad years.' : '<b>Main reason here: history’s average returns are higher than yours</b> (table below), so the typical simulated path grows faster than your plan line.') : `<b>Main reason here: volatility and sequence risk.</b> Even with similar averages, a crash early in retirement while you're withdrawing does lasting damage, and big swings pull the median below the smooth line. Extra ${CS()} volatility (${Rr.googExtraVol || 0}%) adds to this.`}</p>
      <table class="tbl narrow2"><thead><tr><th>Asset (after inflation)</th><th class="n">Your plan</th><th class="n">History avg</th><th class="n">Gap</th></tr></thead><tbody>
      ${row('Stocks', Rr.stock, H.stock)}${row('Bonds', Rr.bond, H.bond)}${row('Cash / T-bills', Rr.cash, H.cash)}${row('Real estate', Rr.re, H.re)}</tbody></table>
      ${det10 && b10 ? `<p class="note">Ten years in (age ${det10.age}): plan ${k(det10.liquid / det10.cpiEnd)} vs Monte Carlo median ${k(b10.p50)} (10th pct ${k(b10.p10)}).</p>` : ''}
      <p class="note">Spending, taxes and income rules are identical in both; only the return path differs.</p>
      <label class="fld" style="display:flex;gap:8px;align-items:center"><input type="checkbox" data-scope="plan" data-path="sim.matchMeans" ${mm ? 'checked' : ''}> <span><b>Use my return assumptions in Monte Carlo and the backtest</b>: keep history's ups, downs and crash sequences, but shift each asset so it averages what you entered. Success rates then reflect your conservative view instead of history's averages.</span></label></details>`;
  }
  function pOverview(P, S, R, an) {
    const { det, mc, bt } = R;
    const detPts = det.rows.map((r) => [r.age, r.liquid / r.cpiEnd]);
    const lines = [{ name: 'Fixed-return projection', color: '#16202e', dash: true, pts: detPts }];
    if (P.pl) lines.push({ name: 'ProjectionLab liquid NW (comparison only)', color: '#e2733a', pts: P.pl.years.map((r) => [ageOfYear(r.Year), r['Liquid Net Worth']]) });
    const actual = state.snapshots.map((s) => [ageOfYear(+s.asOf.slice(0, 4)) + (+s.asOf.slice(5, 7)) / 12 - 1, s.summary.liquid ?? s.summary.netWorth]).filter((p) => p[0] >= mc.bands[0].age - 1.5);
    const pts = actual.length ? [{ name: 'Actual (snapshots)', color: '#c94c43', pts: actual.map(([a, v]) => [Math.max(mc.bands[0].age, a), v]) }] : [];
    const hh = S.household; const marks = [...(P.people.retireAgeSelf ? [{ x: +P.people.retireAgeSelf, label: 'Retire' }] : []), { x: 59.5, label: '59½' }, { x: 65, label: 'Medicare' }, { x: +P.ss.selfClaim, label: 'SS' }, { x: hh.birthYearSelf >= 1960 ? 75 : 73, label: 'RMD' }];
    const firstCliff = det.rows.find((r) => r.age < 65 && r.magi / r.cpi > E.acaThresholds(S, an.Y).cliff);
    const irmaaYrs = det.rows.filter((r) => r.irmaa > 0).length;
    const mx = P._max;
    const spendNow = `${k(catTotal(P))}/yr across ${P.spending.categories.length} categories`;
    return `<div class="kpis">
      <div class="kpi"><div class="kl">Chance of success (Monte Carlo)</div><div class="kv ${succCls(mc.success)}">${pct(mc.success * 100, 0)}</div><div class="ks">${mc.runs} runs · 5-yr blocks of 1928–2025 returns${P.returns.googExtraVol ? ` · ${CS()} +${P.returns.googExtraVol}% vol` : ''}</div></div>
      <div class="kpi"><div class="kl">Historical backtest</div><div class="kv ${succCls(bt.success)}">${pct(bt.success * 100, 0)}</div><div class="ks">${bt.runs} start years, 1928–2025</div></div>
      <div class="kpi"><div class="kl">Fixed-return outcome</div><div class="kv ${det.failed ? 'neg' : ''}">${det.failed ? 'Runs out at ' + det.failed : k(det.endReal)}</div><div class="ks">${det.failed ? 'liquid assets exhausted' : `liquid at age ${P.endAge} (today's $)`}</div></div>
      <div class="kpi"><div class="kl">Median ending liquid</div><div class="kv">${k(mc.medianEnd)}</div><div class="ks">10th pct ${k(mc.p10End)} (today's $)</div></div>
      <div class="kpi"><div class="kl">Sustainable spending</div><div class="kv" id="maxOut">${mx ? k(mx.amount) : '—'}</div><div class="ks">${mx ? `at ${mx.target}% success · now ${spendNow}` : `<a href="#" data-act="runMax" data-target="90">find max at 90%</a> · <a href="#" data-act="runMax" data-target="95">95%</a>`}</div></div></div>
      <div class="card"><h3>Liquid net worth by age <span class="sub">today's dollars</span></h3>${nwZoomBar(mc.bands)}${bandChart(mc.bands, { lines, points: pts, markers: marks, zoom: state.nwZoom })}${whyGap(P, R)}</div>
      <div class="two"><div class="card"><h3>What the plan assumes</h3><ul class="steps">
        <li>Spending: ${spendNow}${P.spending.guardrails.enabled ? ' with guardrails' : ''}, plus ${P.expenses.length} extra expense${P.expenses.length === 1 ? '' : 's'}${P.healthcare.model ? ', with ACA and Medicare premiums modeled' : ''}</li>
        ${P.work.length ? `<li>Work: ${P.work.map((j) => `${esc(j.name)} ${k(+j.salary)} until ${j.endAge || (j.who === 'spouse' ? P.people.retireAgeSpouse : P.people.retireAgeSelf) || '—'}`).join(', ')}</li>` : ''}
        ${(cur().realEstate || []).length || P.purchases.length ? `<li>Real estate: ${(cur().realEstate || []).map((p) => `${esc(p.name)} ${k(+p.value || 0)}${P.reSale[p.id]?.sellYear ? ` (sell ${P.reSale[p.id].sellYear})` : ''}`).join(', ')}${P.purchases.length ? `; buying ${P.purchases.map((b) => `${esc(b.name)} in ${b.year}`).join(', ')}` : ''}</li>` : ''}
        <li>Income: Social Security ${k(L.ssAdj(+P.ss.selfPIA || 0, +P.ss.selfClaim, +P.ss.fra))} at ${P.ss.selfClaim}${+P.ss.spousePIA ? ` + spouse ${k(L.ssAdj(+P.ss.spousePIA, +P.ss.spouseClaim, +P.ss.fra))} at ${P.ss.spouseClaim}` : ''}${P.incomes.length ? `, ${P.incomes.length} other stream(s)` : ''}${P.events.length ? `, ${P.events.length} one-time event(s)` : ''}</li>
        <li>Withdrawal order: ${P.order.replace(/-/g, ' → ')}; taxable sales take the highest-basis lots first</li>
        <li>Tax strategy: ${{ none: 'no conversions', bracket: `convert to the ${P.tax.convertBracket * 100}% bracket`, aca: `ACA-aware conversions, then ${P.tax.convertBracket * 100}%`, irmaa: 'convert to IRMAA tier 1', fixed: k(+P.tax.convertFixed) + '/yr conversions' }[P.tax.convert]}${P.tax.shield ? `, shield at ${P.tax.shieldBracket * 100}%` : ''}${P.tax.harvest ? ', harvest 0% gains' : ''} · <a href="#" data-ptab="optimize">compare strategies</a></li>
        <li>Starting point: liquid ${k(R.init.taxable + R.init.pretax + R.init.roth)} (pre-tax: ${esc(ownerName('self'))} ${k(R.init.pretaxS ?? R.init.pretax)}, ${esc(ownerName('spouse'))} ${k(R.init.pretaxP || 0)})${R.init.property ? `, property ${k(R.init.property)}` : ''}${R.init.debt ? `, debt ${k(R.init.debt)}` : ''} (working copy ${cur().asOf})</li></ul></div>
      <div class="card"><h3>Flags</h3><ul class="steps">
        ${det.failed ? `<li class="neg">Under fixed returns, liquid assets run out at age ${det.failed}.</li>` : ''}
        ${firstCliff ? `<li>MAGI first goes over the ACA 400% cliff in ${firstCliff.year} (age ${firstCliff.age}).</li>` : '<li>MAGI stays under the ACA cliff before 65.</li>'}
        <li>${irmaaYrs} year(s) over the first IRMAA tier (Medicare surcharge, 2-year lookback).</li>
        <li>Lifetime income and payroll taxes (fixed returns): ${k(det.totals.tax)} today's $ (effective ${pct(det.effRate * 100, 1)})${det.totals.conv ? `, Roth conversions ${k(det.totals.conv)}` : ''}. Net legacy ${k(det.legacyReal)}${det.estateTaxReal ? ` after ${k(det.estateTaxReal)} estate tax` : ''}.</li>
        ${mc.failAges.length ? `<li>In failing Monte Carlo runs, money runs out at a median age of ${Math.round(mc.failAges.sort((a, b) => a - b)[Math.floor(mc.failAges.length / 2)])}.</li>` : ''}</ul></div></div>`;
  }

  const catTotal = (P) => { const S = state.settings; const y = +String(cur().asOf || new Date().toISOString()).slice(0, 4); const age = y - +S.household.birthYearSelf; return (P.spending.categories || []).reduce((t, c) => t + (L.inPhase(c, P, S, y, age) ? (+c.amount || 0) : 0), 0); };
  function listEditor(list, cols, P) {
    const rows = (getPath(P, list) || []).map((it, i) => `<tr>${cols.map((c) => `<td>${cell('plan', `${list}.${i}.${c.key}`, c.type || 'number', c)}</td>`).join('')}<td><button class="btn sm" data-act="delItem" data-list="${list}" data-i="${i}">✕</button></td></tr>`).join('');
    return `<table class="tbl edit"><thead><tr>${cols.map((c) => `<th>${c.label}</th>`).join('')}<th></th></tr></thead><tbody>${rows || `<tr><td colspan="${cols.length + 1}" class="note">None yet.</td></tr>`}</tbody></table><button class="btn sm" data-act="addItem" data-list="${list}">+ Add</button>`;
  }

  function eduCard(P, S) {
    const bal = sum(E.allAccounts(cur()).filter((a) => a.taxType === 'edu'), (a) => sum(a.holdings, (h) => h.value));
    const R = planCache.det ? planCache : null; const rows = R ? R.det.rows : [];
    const paid = sum(rows, (r) => (r.eduPaid || 0) / r.cpi), need = sum(rows, (r) => (r.eduNeed || 0) / r.cpi);
    const last = rows.filter((r) => r.eduNeed > 0).pop(); const left = last ? last.edu / last.cpiEnd : null;
    const marked = P.expenses.filter((x) => x.from529 === true || x.from529 === 'true');
    return `<h4>529 college savings <span class="sub">today's $</span></h4><div class="grid4">
      <div class="fld"><span>529 balance now</span><b>${usd(bal)}</b><small>${bal ? 'from Net Worth → Education (529)' : 'add it under Net Worth → Education (529)'}</small></div>
      ${field('529 stock % (rest bonds)', 'plan', 'edu.stockPct', { hint: 'age-based 529s shift to bonds near college' })}
      ${field('Add to 529 per year', 'plan', 'edu.contrib', { hint: "today's $; comes out of cash flow" })}${field('Contributions stop after year', 'plan', 'edu.contribEndYear', { ph: 'never' })}</div>
      ${R && marked.length ? `<p class="note">Fixed-return projection: the 529 pays <b>${k(paid)}</b> of <b>${k(need)}</b> in marked expenses (${marked.map((x) => esc(x.name)).join(', ')}); the portfolio covers ${k(Math.max(0, need - paid))}.${left != null ? ` Left in the 529 after the last one: <b>${k(left)}</b>.` : ''}</p>` : marked.length ? '' : '<p class="note">No expense is marked "Pay from 529" yet.</p>'}
      ${left > 1000 ? `<p class="note">Leftover options: change the beneficiary to another family member, use up to $10k for student loans, or roll up to $35k (lifetime) into a Roth IRA for the beneficiary if the account is 15+ years old. Non-qualified withdrawals pay income tax plus 10% on the earnings.</p>` : ''}`;
  }
  const H2 = (P) => P.healthcare || {};
  // while working: where each year's paycheck goes, from the fixed-return projection
  function savingCard(P, S) {
    const R = planCache.det ? planCache : null; const rows = R ? R.det.rows.filter((r) => r.wages > 1) : [];
    const SV = P.saving || {};
    const tbl = rows.slice(0, 8).map((r) => { const f = 1 / r.cpi; const tax = r.tax; const living = r.spend + r.health + r.housingOut;
      const out = Math.max(0, (r.wages - r.pre401 - r.rothC) - tax + (r.ss || 0) + Math.max(0, r.rentNet) + (r.divs || 0) - living - (r.evOut || 0) - (r.eduContrib || 0) - (r.diFlow || 0));
      return `<tr><td>${r.year}</td><td class="n">${k(r.wages * f)}</td><td class="n">${k(tax * f)}</td><td class="n">${k((r.pre401 + r.match) * f)}</td><td class="n">${k(r.rothC * f)}</td><td class="n">${k(living * f)}</td><td class="n">${k((r.saveRoth || 0) * f)}</td><td class="n">${k((r.diFlow || 0) * f)}</td><td class="n">${k((r.eduContrib || 0) * f)}</td><td class="n"><b>${k((r.reinvest || 0) * f)}</b></td></tr>`; }).join('');
    return `<div class="card"><h3>While working: where your paycheck goes <span class="sub">today's $ per year · surplus after taxes and spending</span></h3>
      <ol class="steps"><li><b>401(k)</b> pre-tax, Roth and match come from each job above (pre-tax lowers this year's tax at your top rate).</li>
      <li><b>Then from what's left after taxes and spending</b> (spending categories, homes and healthcare all apply while you work):</li></ol>
      <div class="grid4">${field('Backdoor Roth IRA / yr (both of you)', 'plan', 'saving.backdoorRoth', { hint: '2026 IRA limit $7,500 each; contribute non-deductible, then convert' })}${field('Mega-backdoor Roth / yr', 'plan', 'saving.megaBackdoor', { hint: 'after-tax 401(k) → Roth, if your plan allows it' })}${field('HSA / yr', 'plan', 'saving.hsa', { hint: 'family limit; HSA grows tax-free like Roth here' })}
      <label class="fld"><span>Other destinations</span><span class="hint">direct indexing (Plan → Strategies), 529 contributions (Spending section above)</span></label></div>
      <p class="note">Everything left over is invested in your taxable account at your current mix. If a year has no surplus, these extra contributions are skipped that year.</p>
      ${rows.length ? `<div class="scroll"><table class="tbl"><thead><tr><th>Year</th><th class="n">Wages</th><th class="n">All taxes</th><th class="n">401(k) pre-tax + match</th><th class="n">Roth 401(k)</th><th class="n">Living + homes + health</th><th class="n">Backdoor/mega/HSA</th><th class="n">Direct indexing</th><th class="n">529</th><th class="n">To taxable account</th></tr></thead><tbody>${tbl}</tbody></table></div>
        <p class="note">From the fixed-return projection. Year-by-year detail, including every source and use, is on Plan → Cash flow.</p>` : `<p class="note">No work income in this plan${P.people.retireAgeSelf ? '' : ' (retirement age is blank = already retired)'}. Add your job above to model the years before retirement.</p>`}</div>`;
  }
  // event anchors for "From"/"To": '' = use the age/year fields
  const ANC = () => [['', 'Age / year →']].concat(L.anchorOptions(plan(), state.settings, SOLO()).filter((o) => o[0] !== 'age'));
  function phaseNote(P, S) {
    // for categories split into phases, show each one's path through life and any uncovered years
    const H = S.household; const Y0 = +String(cur().asOf || new Date().toISOString()).slice(0, 4); const end = +H.birthYearSelf + (+P.people.lifeSelf || 95);
    const groups = {}; for (const c of P.spending.categories || []) { const key = String(c.name || '').trim().toLowerCase(); (groups[key] = groups[key] || []).push(c); }
    const lab = (at) => (L.anchorOptions(P, S, SOLO()).find((o) => o[0] === at) || [, at])[1];
    const out = [];
    for (const list of Object.values(groups)) {
      if (!list.some((c) => (c.startAt && c.startAt !== 'now') || (c.endAt && c.endAt !== 'end'))) continue;
      const span = (c) => { const s0 = c.startAt ? L.anchorYear(P, S, c.startAt) : c.startAge !== '' && c.startAge != null ? +H.birthYearSelf + +c.startAge : -Infinity; const e0 = c.endAt ? L.anchorYear(P, S, c.endAt) : c.endAge !== '' && c.endAge != null ? +H.birthYearSelf + +c.endAge + 1 : Infinity; return [Math.max(Y0, s0), Math.min(end + 1, e0)]; };
      const segs = list.map((c) => ({ c, sp: span(c) })).sort((a, b) => a.sp[0] - b.sp[0]);
      let at = Y0; const gaps = [], over = []; for (const { sp } of segs) { if (sp[1] <= sp[0]) continue; if (sp[0] > at) gaps.push(`${at}–${sp[0] - 1}`); if (sp[0] < at) over.push(`${sp[0]}–${Math.min(at, sp[1]) - 1}`); at = Math.max(at, sp[1]); } if (at <= end) gaps.push(`${at}–${end}`);
      out.push(`<li><b>${esc(list[0].name)}</b>: ${segs.map(({ c, sp }) => `${k(+c.amount)} ${c.startAt ? esc(lab(c.startAt)).toLowerCase() : sp[0]}→${c.endAt ? esc(lab(c.endAt)).toLowerCase() : sp[1] - 1}`).join(' · ')}${over.length ? ` <span class="pill red">counted twice in ${over.join(', ')}</span>` : ''}${gaps.length ? ` <span class="pill amber">nothing in ${gaps.join(', ')}</span>` : over.length ? '' : ' <span class="pill ok">covered through life</span>'}</li>`);
    }
    return out.length ? `<h4>Spending phases</h4><ul class="steps">${out.join('')}</ul><p class="note">Set a category's <b>To</b> to a life event and a follow-on line is added from that event to the end of the plan, so nothing is dropped by accident. Set the next line's amount, or give it its own end to add another phase. Phases are back to back: a line ending at an event stops the year before that event; the next one starts that year.</p>` : `<p class="note">Tip: set <b>From</b>/<b>To</b> to life events (retirement, Social Security, a move) instead of ages. Ending a category at an event adds its next phase automatically.</p>`;
  }
  function pSetup(P, S) {
    const realOpt = [[true, "Today's $"], [false, 'Fixed $']];
    return `<div class="card"><h3>People & horizon</h3><div class="grid4">
        ${field('Your first name', 'settings', 'household.selfName', { text: true })}${SOLO() ? '' : field('Spouse first name', 'settings', 'household.spouseName', { text: true })}
        ${field('Your birth year', 'settings', 'household.birthYearSelf', { warn: !S.household.agesConfirmed })}${SOLO() ? '' : field('Spouse birth year', 'settings', 'household.birthYearSpouse', { warn: !S.household.agesConfirmed })}
        ${field('Your life expectancy (age)', 'plan', 'people.lifeSelf')}${SOLO() ? '' : field('Spouse life expectancy (age)', 'plan', 'people.lifeSpouse')}
        ${SOLO() ? '' : field('Survivor spending % after first death', 'plan', 'spending.survivorPct', { hint: 'filing switches to single the year after' })}${field('Ages confirmed', 'settings', 'household.agesConfirmed', { type: 'check' })}
        ${field('Your retirement age', 'plan', 'people.retireAgeSelf', { ph: 'retired', hint: 'blank = already retired' })}${field('Spouse retirement age', 'plan', 'people.retireAgeSpouse', { ph: 'retired', hint: 'blank = already retired' })}</div>
        <h4>Current work income <span class="sub">paid until that person's retirement age, or the "to age" you set. Today's $.</span></h4>
        ${listEditor('work', [{ key: 'who', label: 'Who', options: SOLO() ? [['self', 'You']] : [['self', 'You'], ['spouse', 'Spouse']] }, { key: 'name', label: 'Job', type: 'text' }, { key: 'salary', label: 'Salary + bonus / yr' }, { key: 'growth', label: 'Real raise %' }, { key: 'pretax401k', label: 'Pre-tax 401k / yr' }, { key: 'match', label: 'Employer match / yr' }, { key: 'rothContrib', label: 'Roth contrib / yr' }, { key: 'startAt', label: 'From', options: ANC() }, { key: 'startAge', label: 'age', ph: 'now' }, { key: 'endAt', label: 'To', options: ANC() }, { key: 'endAge', label: 'age', ph: 'retire' }], P)}
        <p class="note">Wages are taxed as ordinary income, minus pre-tax 401(k), plus FICA (6.2% up to the $184,500 wage base, 1.45% Medicare, and 0.9% over $250k). Contributions and match go into the pre-tax and Roth buckets, and any surplus is invested in the taxable account. Wages also count toward ACA MAGI.</p></div>
      ${savingCard(P, S)}
      ${realEstateSection('plan')}
      <div class="card"><h3>Spending</h3><div class="grid4">
        ${field('Guardrails (Guyton-Klinger)', 'plan', 'spending.guardrails.enabled', { type: 'check' })}
        ${field('Cut / raise spending by %', 'plan', 'spending.guardrails.adjust')}
        ${field('Cut when withdrawal rate rises % above start', 'plan', 'spending.guardrails.upper')}${field('Raise when it falls % below start', 'plan', 'spending.guardrails.lower')}</div>
        <h4>Living spending by category <span class="sub">today's $ per year · total ${k(catTotal(P))}${P.spending.categories.some((c) => c.startAge !== '' || c.endAge !== '') ? ' (plus age-limited items)' : ''}</span></h4>
        ${P.spending.categoriesDefault && P.spending.starter === 'us40' ? `<div class="banner"><b>Starter numbers:</b> income, spending, retirement age and Social Security are set to a typical U.S. married couple around age 40 (${esc(E.STARTER.source)}). Replace them with your own: wages under Work income, spending below (bank and card imports on the Spending tab can fill it in), and your Social Security estimates from ssa.gov.</div>` : P.spending.categoriesDefault ? `<div class="banner">These are starter splits of your previous ${k(catTotal(P))} total. Replace them with your real numbers; Mint/Copilot/Monarch exports or last year's credit-card categories work well. Housing, property tax and health premiums are modeled separately, so leave them out.</div>` : ''}
        ${listEditor('spending.categories', [{ key: 'name', label: 'Category', type: 'text' }, { key: 'amount', label: 'Amount / yr' }, { key: 'kind', label: 'Type', options: [['essential', 'Essential'], ['discretionary', 'Discretionary']] }, { key: 'startAt', label: 'From', options: ANC() }, { key: 'startAge', label: 'age', ph: 'now' }, { key: 'endAt', label: 'To', options: ANC() }, { key: 'endAge', label: 'age', ph: 'end' }], P)}${phaseNote(P, S)}
        <p class="note">Guardrails, when on, only flex the discretionary categories. After the first death, all categories scale to the survivor %. ${state.settings.spending.source === 'manual' ? `The Quarterly Review buffer uses a separate number you entered in Settings (${k(state.settings.spending.annual)}). <a href="#" data-act="spendFromPlan">Use this plan instead</a>.` : `This total plus your home costs (${k(homeCosts())}) is also the annual spending behind the Quarterly Review cash buffer: ${k(state.settings.spending.annual)}.`}</p>
        <h4>Extra expenses <span class="sub">one-off multi-year items (college, a car, long-term care). Added on top.</span></h4>
        ${listEditor('expenses', [{ key: 'name', label: 'Name', type: 'text' }, { key: 'amount', label: 'Amount / yr' }, { key: 'startAt', label: 'From', options: ANC() }, { key: 'startYear', label: 'year', ph: 'or age →' }, { key: 'startAge', label: 'age' }, { key: 'endAt', label: 'To', options: ANC() }, { key: 'endYear', label: 'year' }, { key: 'endAge', label: 'age' }, { key: 'real', label: 'Inflates', options: realOpt }, { key: 'from529', label: 'Pay from 529', options: [[true, 'Yes, 529 first'], [false, 'No']] }], P)}
        <p class="note">Use calendar years (inclusive) or ${esc(S.household.selfName)}'s ages; years win if both are filled. Expenses marked "Pay from 529" are paid from the 529 first, tax-free; anything the 529 can't cover comes from the portfolio.</p>
        ${eduCard(P, S)}</div>
      <div class="card"><h3>Income</h3><div class="grid4">
        ${field("Your benefit at full retirement age / yr (today's $)", 'plan', 'ss.selfPIA', { hint: 'ssa.gov → my Social Security' })}${field('Your claiming age', 'plan', 'ss.selfClaim', { hint: `→ ${k(L.ssAdj(+P.ss.selfPIA || 0, +P.ss.selfClaim || 67, +P.ss.fra || 67))}/yr` })}
        ${SOLO() ? '' : field("Spouse benefit at full retirement age / yr", 'plan', 'ss.spousePIA')}${SOLO() ? '' : field('Spouse claiming age', 'plan', 'ss.spouseClaim', { hint: `→ ${k(L.ssAdj(+P.ss.spousePIA || 0, +P.ss.spouseClaim || 67, +P.ss.fra || 67))}/yr` })}
        ${field('Full retirement age', 'plan', 'ss.fra')}${field('Benefit cut % (trust-fund scenario)', 'plan', 'ss.haircutPct', { hint: 'e.g. 20' })}${field('Cut starts in year', 'plan', 'ss.haircutYear')}</div>
        <p class="note">Claiming before full retirement age lowers the benefit (5/9% per month for 36 months, then 5/12%). Waiting raises it 8%/yr up to 70. Each spouse gets the larger of their own benefit or half the other's, and the survivor keeps the larger of the two benefits.</p>
        <h4>Other income streams <span class="sub">consulting, pension, rental, annuity</span></h4>
        ${listEditor('incomes', [{ key: 'name', label: 'Name', type: 'text' }, { key: 'amount', label: 'Amount / yr' }, { key: 'startAt', label: 'From', options: ANC() }, { key: 'startAge', label: 'age' }, { key: 'endAt', label: 'To', options: ANC() }, { key: 'endAge', label: 'age' }, { key: 'taxable', label: 'Tax', options: [['ordinary', 'Ordinary'], ['none', 'Tax-free']] }, { key: 'real', label: 'Inflates', options: realOpt }], P)}
        <h4>Life events</h4>
        <p class="note">One-time events (windfalls, big purchases), moves to another state, inheritances and spending changes are on <a href="#" data-tab="plan" data-ptab-go="events">Plan → Life events</a>, with a timeline of everything dated in the plan.</p></div>
      <div class="card"><h3>Healthcare</h3><div class="grid4">
        ${field('Model ACA + Medicare premiums', 'plan', 'healthcare.model', { type: 'check', hint: 'turn off only if already in spending' })}
        ${field(`${isCA() ? 'Covered California' : 'ACA'} benchmark silver / yr (household, today's $, current ages)`, 'plan', 'healthcare.acaBenchmark', { hint: 'get a quote at coveredca.com' })}
        ${field('Medigap + Part D per person / yr', 'plan', 'healthcare.medigapPartD', { hint: 'Part B ($202.90/mo in 2026) is added automatically' })}
        ${field('Healthcare cost growth above inflation %', 'plan', 'healthcare.growth')}</div>
        <h4>Optional: costs that rise with age and long-term care <span class="sub">each is off until you turn it on</span></h4>
        <div class="grid4">
        ${field('1. Costs keep rising with age after 65', 'plan', 'healthcare.ageRise', { type: 'check', hint: 'Medicare/Medigap/Part D and, if #2 is on, out-of-pocket medical' })}
        ${H2(P).ageRise ? field('Extra % per year of age', 'plan', 'healthcare.ageRisePct', { hint: `3% ≈ ${Math.pow(1.03, 20).toFixed(1)}× by 85` }) + field('Starting after age', 'plan', 'healthcare.ageRiseFrom') : '<span></span><span></span>'}
        ${field('2. Out-of-pocket medical grows like healthcare', 'plan', 'healthcare.oopGrow', { type: 'check', hint: `spending categories named medical/dental/vision/health grow at +${P.healthcare.growth}%/yr above inflation${P.healthcare.ageRise ? ' and with age' : ''}` })}
        </div>
        <div class="grid4" style="margin-top:6px">
        ${field('3. Long-term care', 'plan', 'healthcare.ltc', { type: 'check', hint: 'off by default; added to healthcare each year it applies' })}</div>
        ${H2(P).ltc ? `<div class="grid4">
        ${field(`${esc(S.household.selfName)}: cost / yr (today's $)`, 'plan', 'healthcare.ltcSelfCost')}${field('Years of care', 'plan', 'healthcare.ltcSelfYears', { hint: 'US average need: men ≈ 2.2, women ≈ 3.7 yrs' })}${field('Starting at age', 'plan', 'healthcare.ltcSelfStart', { ph: `last ${P.healthcare.ltcSelfYears || 0} yrs (${(+P.people.lifeSelf || 95) - (+P.healthcare.ltcSelfYears || 0) + 1})`, hint: 'blank = the final years of life expectancy' })}<span></span>
        ${SOLO() ? '' : field(`${esc(S.household.spouseName)}: cost / yr (today's $)`, 'plan', 'healthcare.ltcSpouseCost')}${SOLO() ? '' : field('Years of care', 'plan', 'healthcare.ltcSpouseYears')}${SOLO() ? '' : field('Starting at age', 'plan', 'healthcare.ltcSpouseStart', { ph: `last ${P.healthcare.ltcSpouseYears || 0} yrs (${(+P.people.lifeSpouse || 95) - (+P.healthcare.ltcSpouseYears || 0) + 1})` })}<span></span></div>
        <p class="note"><b>California median costs, 2025</b>${isCA() ? '' : ' (for reference; look up your state at carescout.com/cost-of-care)'} (CareScout Cost of Care Survey): in-home caregiver 44 hrs/week <b>$91,520/yr</b> · assisted living (residential care) <b>$84,000/yr</b> · nursing home semi-private <b>$146,000/yr</b>, private room <b>$182,135/yr</b>. Bay Area prices typically run above the state median. Costs grow with the healthcare rate above (+${P.healthcare.growth}%/yr over inflation). Medicare doesn't pay for custodial long-term care. LTC costs above 7.5% of income are tax-deductible as medical expenses; that deduction isn't modeled, so taxes are slightly overstated in those years.</p>` : ''}
        <h4>ACA income target <span class="sub">used by Quarterly Review sale plans and the Plan's ACA-aware strategies</span></h4><div class="grid4">
      ${field('Enforce ACA ceiling', 'settings', 'aca.enabled', { type: 'check' })}${field('400% cliff in effect', 'settings', 'aca.cliffInEffect', { type: 'check', hint: 'verify each fall' })}
      ${field('MAGI ceiling', 'settings', 'aca.ceiling', { type: 'select', options: [['cliff', '400% FPL cliff'], ['csr73', '250% FPL (CSR-73)'], ['csr87', '200% FPL (CSR-87)'], ['custom', 'Custom']] })}
      ${field('Custom ceiling', 'settings', 'aca.customCeiling')}${field('Safety margin $', 'settings', 'aca.safetyMargin')}
      </div>
        <p class="note">ACA premiums rise with age on the federal age curve (about 3× at 64 vs 21). The premium tax credit is recalculated every year from that year's MAGI and household size, and the 400% cliff removes it. From 65 each person pays Part B plus Medigap/Part D, and IRMAA surcharges apply in five tiers based on MAGI two years earlier (2026 CMS amounts, Part B + Part D).</p></div>
      <div class="card"><h3>Withdrawals & Roth conversions</h3><div class="grid4">
        ${field('Withdrawal order', 'plan', 'order', { type: 'select', options: [['taxable-pretax-roth', 'Taxable → Pre-tax → Roth'], ['taxable-roth-pretax', 'Taxable → Roth → Pre-tax'], ['pretax-taxable-roth', 'Pre-tax → Taxable → Roth']] })}
        ${field('Roth contributions you can withdraw any time', 'plan', 'rothBasis', { hint: P.rothBasisFromReturn != null ? (P.rothBasisEdited ? `your override (Form 8606 says ${k(P.rothBasisFromReturn)}) · <a href="#" data-act="resetDerived" data-k="rothBasis">use return</a>` : 'from your tax return (Form 8606); type to override') : 'your Roth IRA contribution total (not earnings). Before 59½ only this plus 5-year-old conversions can be spent' })}
        ${field('Roth conversions', 'plan', 'tax.convert', { type: 'select', options: [['none', 'None'], ['bracket', 'Fill a federal bracket'], ['aca', 'ACA-aware: up to the cliff before 65, then bracket'], ['irmaa', 'Up to IRMAA tier 1 (capped at bracket)'], ['fixed', 'Fixed amount / yr']] })}
        ${field('Bracket', 'plan', 'tax.convertBracket', { type: 'select', options: [[0.1, '10%'], [0.12, '12%'], [0.22, '22%'], [0.24, '24%'], [0.32, '32%'], [0.35, '35%']] })}${field('Fixed amount / yr', 'plan', 'tax.convertFixed')}
        ${field('Convert from age', 'plan', 'tax.convertStart', { ph: 'now' })}${field('Convert through age', 'plan', 'tax.convertEnd')}
        ${field('Never break the ACA cliff with conversions', 'plan', 'tax.protectACA', { type: 'check' })}
        ${field('Withdrawal shielding', 'plan', 'tax.shield', { type: 'check', hint: 'cap pre-tax withdrawals at a bracket; use taxable/Roth first' })}${field('Shield bracket', 'plan', 'tax.shieldBracket', { type: 'select', options: [[0.1, '10%'], [0.12, '12%'], [0.22, '22%'], [0.24, '24%'], [0.32, '32%'], [0.35, '35%']] })}
        ${field('Capital-gain harvesting (0% federal bracket)', 'plan', 'tax.harvest', { type: 'check', hint: ST().type === 'none' ? 'no state tax on harvested gains here' : `${STC()} still taxes harvested gains` })}${field('Harvest only under the ACA cliff', 'plan', 'tax.harvestProtectACA', { type: 'check' })}</div>
        <p class="note">Compare these settings side by side on the <a href="#" data-ptab="optimize">Tax strategies</a> tab. Pre-tax withdrawals before 59½ carry the 10% penalty. Rule of 55 and 72(t) aren't modeled.</p></div>
      <div class="card"><h3>Estate & ${STN()}</h3><div class="grid4">
        ${field("Heirs' tax rate on inherited pre-tax %", 'plan', 'estate.heirRate', { hint: '10-year rule; high-earning heirs often 35–50%' })}
        ${ST().cp ? field(`Community property (${STC()}): full step-up at first death`, 'plan', 'estate.communityProperty', { type: 'check' }) : `<label class="fld"><span>Step-up at first death</span><b style="padding:6px 0;display:block">half (not a community-property state)</b></label>`}
        ${field('Federal estate exemption portability (DSUE)', 'plan', 'estate.portability', { type: 'check' })}
        ${isCA() ? field('Prop 13: property tax grows ≤2%/yr', 'plan', 'estate.prop13', { type: 'check' }) : ''}</div>
        <p class="note">Net legacy = taxable (stepped up) + Roth + pre-tax × (1 − heirs' rate) + real estate − debt − federal estate tax (40% above $15M per person in 2026, indexed, ×2 with portability). ${isCA() ? 'California has no estate or inheritance tax.' : 'Some states have their own estate or inheritance tax (not modeled).'}</p></div>
      <div class="card"><h3>Investments & returns</h3><div class="grid4">
        ${field('Allocation', 'plan', 'allocation.mode', { type: 'select', options: [['current', 'Keep my current mix per account type'], ['target', 'Rebalance to my target (stock % below)'], ['glide', 'Glide path']] })}${field('Gold & crypto target %', 'plan', 'allocation.alt')}${field('International share of stocks %', 'plan', 'allocation.intlShare')}${field('Concentrated stock ticker(s)', 'settings', 'trim.concSymbols', { text: true, hint: 'e.g. your employer stock: GOOG, GOOGL · blank = none' })}${field('' + CS() + ' concentration limit %', 'settings', 'trim.googConcentrationMax', { hint: 'sale plans and rebalancing use it' })}${field('' + CS() + ' YTD trim trigger %', 'settings', 'trim.googYtdTrigger')}
        ${field('Target stock % (now)', 'plan', 'allocation.stockNow', { hint: 'also the Quarterly Review rebalance target' })}${field('Stock % at end (glide)', 'plan', 'allocation.stockEnd')}${field('Glide ends at age', 'plan', 'allocation.glideEndAge')}
        ${field('Stock real return % (fixed)', 'plan', 'returns.stock')}${field('Bond real return %', 'plan', 'returns.bond')}${field('Cash real return %', 'plan', 'returns.cash')}${field('Real estate real return %', 'plan', 'returns.re')}
        ${field('Bank cash real return %', 'plan', 'returns.bank', { hint: 'checking/savings usually trail inflation' })}${field('Gold real return % (fixed)', 'plan', 'returns.gold')}${field('Crypto real return % (fixed)', 'plan', 'returns.crypto')}${field('Crypto volatility % (Monte Carlo)', 'plan', 'returns.cryptoVol')}
        ${field('Inflation % (fixed)', 'plan', 'inflation')}${field('' + CS() + ' extra volatility % (Monte Carlo)', 'plan', 'returns.googExtraVol', { hint: 'single-stock risk' })}
        ${field('Monte Carlo runs', 'plan', 'sim.runs')}${field('Bootstrap block (years)', 'plan', 'sim.block')}</div>
        <h4>Dividend & interest yields <span class="sub">% per year, all plans · estimate taxable dividends now and in the Plan</span></h4><div class="grid6">${Object.keys(state.settings.yields).map((s0) => field(s0, 'settings', 'yields.' + s0)).join('')}</div>
      <p class="note">Fallback by class: ${Object.entries(state.settings.classYields).map(([c, v]) => `${CLASS_LABEL[c]} ${v}%`).join(' · ')}</p>
        <p class="note">Monte Carlo and backtests use actual 1928–2025 US returns and inflation: S&P 500 for stocks, a 50/50 mix of 10-year Treasuries and Baa corporates for bonds, T-bills for cash. International stocks use US returns (no long history). Gold uses its 1928–2025 history (Damodaran). Crypto has no long history, so it's modeled as 1.5× stock returns plus extra volatility in Monte Carlo. Bank cash earns about half the T-bill rate. Taxes use 2026 brackets indexed to inflation.</p></div>`;
  }

  // ---------- Sankey (inline SVG): sources → total cash → uses ----------
  function sankey(srcs, uses, { w = 900, h = 400, title = '' } = {}) {
    srcs = srcs.filter((x) => x.v > 0.5); uses = uses.filter((x) => x.v > 0.5);
    const total = Math.max(1, sum(srcs, (x) => x.v)); const totalU = Math.max(1, sum(uses, (x) => x.v));
    const lab = (x) => (x.name.length + k(x.v).length + 1) * 6.4 + 14; // approx. label width at 11px
    const mL = Math.max(120, ...srcs.map(lab)), mR = Math.max(120, ...uses.map(lab));
    w = Math.max(w, mL + mR + 360);
    const padT = 10, padB = 10, gap = 6, nodeW = 14, colL = mL, colM = mL + (w - mL - mR) / 2 - nodeW / 2, colR = w - mR - nodeW;
    const scale = (n, tot) => (h - padT - padB - gap * Math.max(0, n - 1)) / tot;
    const sL = scale(srcs.length, total), sR = scale(uses.length, totalU), sM = Math.min(sL, sR);
    const mH = total * sM, mY = padT + (h - padT - padB - mH) / 2;
    let g = '', y = padT, my = mY;
    const band = (x0, y0, h0, x1, y1, h1, col) => { const cx = (x0 + x1) / 2; return `<path d="M${x0},${y0} C${cx},${y0} ${cx},${y1} ${x1},${y1} L${x1},${y1 + h1} C${cx},${y1 + h1} ${cx},${y0 + h0} ${x0},${y0 + h0} Z" fill="${col}" fill-opacity=".35"/>`; };
    for (const s of srcs) {
      const hh = s.v * sL, hm = s.v * sM;
      g += band(colL + nodeW, y, hh, colM, my, hm, s.color);
      g += `<rect x="${colL}" y="${y}" width="${nodeW}" height="${Math.max(1, hh)}" fill="${s.color}"><title>${esc(s.name)}: ${usd(s.v)}</title></rect>`;
      g += `<text x="${colL - 6}" y="${y + hh / 2 + 4}" text-anchor="end" class="sk">${esc(s.name)} <tspan class="skv">${k(s.v)}</tspan></text>`;
      y += hh + gap; my += hm;
    }
    g += `<rect x="${colM}" y="${mY}" width="${nodeW}" height="${mH}" fill="#16202e"/><text x="${colM + nodeW / 2}" y="${mY - 4}" text-anchor="middle" class="sk"><tspan class="skv">${k(total)}</tspan></text>`;
    y = padT; my = mY;
    for (const u of uses) {
      const hh = u.v * sR, hm = u.v * sM;
      g += band(colM + nodeW, my, hm, colR, y, hh, u.color);
      g += `<rect x="${colR}" y="${y}" width="${nodeW}" height="${Math.max(1, hh)}" fill="${u.color}"><title>${esc(u.name)}: ${usd(u.v)}</title></rect>`;
      g += `<text x="${colR + nodeW + 6}" y="${y + hh / 2 + 4}" class="sk">${esc(u.name)} <tspan class="skv">${k(u.v)}</tspan></text>`;
      y += hh + gap; my += hm;
    }
    return `<svg viewBox="0 0 ${w} ${h}" class="chart sankey" style="overflow:visible">${g}</svg>`;
  }
  const TAX_KEYS = [
    { key: 'tFedOrd', part: 'fedOrd', name: 'Federal income tax', color: '#2a9d8f' },
    { key: 'tFedPref', part: 'fedPref', name: 'Capital gains / qualified dividends tax', color: '#5c6bc0' },
    { key: 'tNiit', part: 'niit', name: 'NIIT 3.8%', color: '#7986cb' },
    { key: 'tAmt', part: 'amt', name: 'Alternative minimum tax', color: '#3949ab' },
    { key: 'tCa', part: 'ca', get name() { return STN() + ' income tax'; }, color: '#7e57c2' },
    { key: 'tMhst', part: 'caMhst', name: 'CA Mental Health Services tax (1% > $1M)', color: '#b39ddb' },
    { key: 'tFica', part: 'fica', name: 'FICA (Social Security + Medicare)', color: '#26c6da' },
    { key: 'tSdi', part: 'casdi', get name() { return isCA() ? 'California SDI' : 'State disability insurance'; }, color: '#9575cd' },
    { key: 'tPen', part: 'penalty', name: 'Early-withdrawal penalties', color: '#ef5350' },
    { key: 'tIrmaa', part: 'irmaa', name: 'IRMAA (Medicare surcharges)', color: '#ffa726' },
    { key: 'tProp', part: 'propTax', get name() { return 'Property tax, all properties' + (isCA() ? ' (Prop 13)' : ''); }, color: '#ec407a' },
  ];
  function yearFlows(r) {
    const f = realRow(r).f, tp = r.taxParts || {};
    const srcs = [
      { name: 'Wages (gross)', v: r.wages * f, color: '#16202e' }, { name: 'Net rent', v: Math.max(0, r.rentNet) * f, color: '#a0785a' },
      { name: 'Social Security', v: r.ss * f, color: '#3aa17e' }, { name: 'Other income', v: ((r.ordInc || 0) + (r.freeInc || 0)) * f, color: '#8d7ad6' },
      { name: 'Dividends / interest', v: r.divs * f, color: '#7cc7a4' }, { name: 'Home sale / events', v: (r.evIn || 0) * f, color: '#9aa3ad' },
      { name: 'Taxable account sales', v: r.fromTax * f, color: '#3b6fd8' }, { name: 'Pre-tax withdrawals + RMD', v: (r.fromPre + r.rmd) * f, color: '#e2733a' },
      { name: 'Roth withdrawals', v: r.fromRoth * f, color: '#c9b458' }, { name: 'Unfunded shortfall', v: (r.short || 0) * f, color: '#c94c43' }, { name: '529 (college, tax-free)', v: (r.eduPaid || 0) * f, color: '#d9a520' }];
    const uses = [
      ...Object.entries(r.spendCats || { 'Living spending': r.spend }).map(([n, v], i) => ({ name: n.replace(/ \(.*\)$/, ''), v: v * f, color: ['#4a5563', '#607d8b', '#78909c', '#8d6e63', '#a1887f', '#90a4ae', '#b0bec5', '#6d4c41', '#546e7a'][i % 9] })), { name: 'Housing (property tax, costs, mortgage)', v: r.housingOut * f, color: '#a0785a' },
      { name: 'Rental shortfall', v: Math.max(0, -r.rentNet) * f, color: '#7d5c43' }, { name: 'Healthcare (ACA, Medicare, IRMAA)', v: r.health * f, color: '#d67aa0' },
      { name: 'Federal income tax', v: ((tp.fedOrd || 0) + (tp.fedPref || 0) + (tp.niit || 0) + (tp.amt || 0)) * f, color: '#2b56b3' }, { name: STN() + ' tax', v: ((tp.ca || 0) + (tp.caMhst || 0)) * f, color: '#e2733a' },
      { name: 'Payroll tax (FICA + SDI)', v: ((tp.fica || 0) + (tp.casdi || 0)) * f, color: '#3aa17e' }, { name: 'Penalties', v: (tp.penalty || 0) * f, color: '#c94c43' },
      { name: '401(k) / Roth contributions', v: ((r.pre401 || 0) + (r.rothC || 0)) * f, color: '#5e9c76' }, { name: 'Purchases / events', v: (r.evOut || 0) * f, color: '#9aa3ad' }, { name: '529 contributions', v: (r.eduContrib || 0) * f, color: '#d9a520' }, { name: 'Direct indexing contributions', v: (r.diFlow || 0) * f, color: '#5b8def' },
      { name: 'Backdoor / mega Roth & HSA', v: (r.saveRoth || 0) * f, color: '#3aa17e' }, { name: 'Saved / reinvested', v: (r.reinvest || 0) * f, color: '#7cc7a4' }];
    const diff = sum(srcs, (x) => x.v) - sum(uses, (x) => x.v); // tax fixed-point rounding
    if (diff > 0) uses[uses.length - 1].v += diff; else srcs[6].v += -diff;
    return { srcs, uses };
  }
  function pCashflow(P, S, R) {
    const rows = R.det.rows.map((r) => { const f = realRow(r).f; return { ...r, aWage: (r.wages - r.pre401) * f, aRent: Math.max(0, r.rentNet) * f, aSS: r.ss * f, aInc: r.ordInc * f, aDiv: r.divs * f, aTax: r.fromTax * f, aPre: (r.fromPre + r.rmd) * f, aRoth: r.fromRoth * f, aEdu: (r.eduPaid || 0) * f, aEv: Math.max(0, r.events) * f, out: (r.spend + r.health + r.tax + r.housingOut + r.rothC + Math.max(0, -r.rentNet)) * f }; });
    const keys = [{ key: 'aWage', name: 'Take-home wages', color: '#16202e' }, { key: 'aRent', name: 'Net rent', color: '#a0785a' }, { key: 'aSS', name: 'Social Security', color: '#3aa17e' }, { key: 'aInc', name: 'Other income', color: '#8d7ad6' }, { key: 'aDiv', name: 'Dividends/interest', color: '#7cc7a4' }, { key: 'aTax', name: 'Taxable sales', color: '#3b6fd8' }, { key: 'aPre', name: 'Pre-tax (incl. RMD)', color: '#e2733a' }, { key: 'aRoth', name: 'Roth', color: '#c9b458' }, { key: 'aEdu', name: '529', color: '#d9a520' }, { key: 'aEv', name: 'Events', color: '#9aa3ad' }];
    const tbl = R.det.rows.map((r) => { const { f, b } = realRow(r); return `<tr class="${r.short > 1 ? 'fail' : ''}"><td>${r.year}</td><td>${r.age}</td><td class="n">${k(r.spend * f)}</td><td class="n">${k(r.housingOut * f)}</td><td class="n">${k(r.health * f)}</td><td class="n">${k(r.tax * f)}</td><td class="n">${k(r.wages * f)}</td><td class="n">${k(r.rentNet * f)}</td><td class="n">${k(r.ss * f)}</td><td class="n">${k(r.ordInc * f)}</td><td class="n">${k(r.divs * f)}</td><td class="n">${k(r.fromTax * f)}</td><td class="n">${k((r.fromPre + r.rmd) * f)}</td><td class="n">${k(r.fromRoth * f)}</td><td class="n">${k(r.conv * f)}</td><td class="n">${k(r.liquid * b)}</td><td class="n">${k(r.nw * b)}</td></tr>`; }).join('');
    const yrs = R.det.rows.map((r) => r.year);
    let sy = +state.sankeyYear; if (!yrs.includes(sy)) sy = yrs[0];
    const sr = R.det.rows.find((r) => r.year === sy); const fl = yearFlows(sr);
    const skCard = `<div class="card"><h3>Cash flow in ${sy} <span class="sub">age ${sr.age}${sr.sAge ? ` / ${sr.sAge}` : ''} · ${state.planReal ? "today's $" : 'future $'} · fixed-return projection</span></h3>
      <div class="skbar"><button class="btn sm" data-act="skYear" data-d="-1">◀</button><input type="range" min="${yrs[0]}" max="${yrs[yrs.length - 1]}" value="${sy}" data-scope="ui" data-path="sankeyYear"><button class="btn sm" data-act="skYear" data-d="1">▶</button>
      <select data-scope="ui" data-path="sankeyYear">${yrs.map((y) => `<option value="${y}" ${y === sy ? 'selected' : ''}>${y}</option>`).join('')}</select></div>
      ${sankey(fl.srcs, fl.uses)}
      <p class="note">Left side: where the year's cash comes from. Right side: where it goes. <b>Housing</b> = property tax + homeowner's insurance + HOA + maintenance + mortgage principal & interest for homes you live in. Rentals' costs and mortgages are netted into <b>Net rent</b> (or <b>Rental shortfall</b> if negative); see the Rentals tab for each line. Roth conversions move money between accounts and aren't cash, so they appear only in their tax effect. ${sr.conv ? `This year converts ${k(sr.conv * realRow(sr).f)} to Roth.` : ''} ${sr.short > 1 ? '<b class="neg">Red "Unfunded shortfall" means the portfolio ran out.</b>' : ''}</p></div>`;
    const hc = R.det.rows; const H = P.healthcare;
    const peak = hc.reduce((b, r) => (r.health / r.cpi > (b ? b.health / b.cpi : -1) ? r : b), null);
    const hRow = (r) => { const f = realRow(r).f; return `<tr class="${r === sr ? 'sel' : ''}"><td>${r.year}</td><td>${r.age}/${r.sAge}</td><td>${(r.acaPeople || []).join(', ') || '—'}</td><td class="n">${k(r.acaGross * f)}</td><td class="n pos">${r.ptc ? '−' + k(r.ptc * f) : '—'}</td><td class="n">${k(r.medicare * f)}</td><td class="n">${r.irmaa ? k(r.irmaa * f) : '—'}</td>${H.ltc ? `<td class="n">${r.ltc ? k(r.ltc * f) : '—'}</td>` : ''}<td class="n"><b>${k(r.health * f)}</b></td><td class="n">${k(r.magi / r.cpi)}</td></tr>`; };
    const a0 = hc[0]; const fNow = (a0.acaPeople || []).reduce((t, a) => t + L.ageFactor(a), 0);
    const why = peak ? (() => { const ff = (peak.acaPeople || []).reduce((t, a) => t + L.ageFactor(a), 0); const t = peak.year - hc[0].year; const g = Math.pow(1 + (+H.growth || 0) / 100, t);
      return `Healthcare peaks in ${peak.year} (ages ${peak.age}/${peak.sAge}) at ${k(peak.health / peak.cpi)} in today's $. Three things stack up: <b>(1) age rating</b>: ACA premiums for ${(peak.acaPeople || []).join(' and ')}-year-olds are ${(ff / Math.max(0.01, fNow)).toFixed(2)}× today's (the federal curve reaches 3× at 64 vs 1× at 21); <b>(2) medical inflation</b>: ${H.growth}%/yr above CPI for ${t} years = ${g.toFixed(2)}×; <b>(3) the subsidy</b>: ${peak.ptc ? `a ${k(peak.ptc / peak.cpi)} credit offsets part of it` : `MAGI of ${k(peak.magi / peak.cpi)} is over the ACA cliff, so the credit is $0 and you pay full price`}. Plain CPI inflation isn't in these numbers because they're in today's dollars. At 65 Medicare replaces the ACA plan and costs drop.`; })() : '';
    const hcCard = H.model || H.ltc ? `<div class="card"><h3>Healthcare detail <span class="sub">today's $ · benchmark ${k(H.acaBenchmark)}/yr for your household now, +${H.growth}%/yr above inflation</span></h3><p>${why}</p>
      <div class="scroll" style="max-height:300px"><table class="tbl"><thead><tr><th>Year</th><th>Ages</th><th>On ACA (ages)</th><th class="n">ACA premium</th><th class="n">ACA credit</th><th class="n">Medicare + Medigap/D</th><th class="n">IRMAA</th>${H.ltc ? '<th class="n">Long-term care</th>' : ''}<th class="n">Net cost</th><th class="n">MAGI</th></tr></thead><tbody>${hc.map(hRow).join('')}</tbody></table></div>
      <p class="note">To lower it: keep MAGI under the 400% FPL cliff before 65 (Tax strategies → ACA-aware), or check the benchmark and growth under Assumptions → Healthcare. Get a real quote from your state's ACA marketplace (HealthCare.gov or your state exchange).</p></div>` : '';
    const catNames = [...new Set(hc.flatMap((r) => Object.keys(r.spendCats || {})))];
    const pal = ['#4a5563', '#607d8b', '#78909c', '#8d6e63', '#a1887f', '#90a4ae', '#b0bec5', '#6d4c41', '#546e7a', '#9e9d24', '#5e35b1'];
    const sKeys = catNames.map((n, i) => ({ key: 'c' + i, name: n.replace(/ \(.*\)$/, ''), color: pal[i % pal.length] })).concat([{ key: 'cH', name: 'Housing', color: '#a0785a' }, { key: 'cHc', name: 'Healthcare', color: '#d67aa0' }]);
    const sRows = hc.map((r) => { const f = realRow(r).f; const o = { year: r.year, age: r.age }; catNames.forEach((n, i) => (o['c' + i] = (r.spendCats?.[n] || 0) * f)); o.cH = r.housingOut * f; o.cHc = r.health * f; return o; });
    const spCard = `<div class="card"><h3>Spending by category <span class="sub">${state.planReal ? "today's $" : 'future $'}</span></h3>${stackBars(sRows, sKeys.filter((kk) => sRows.some((r) => r[kk.key] > 0.5)))}</div>`;
    return skCard + spCard + hcCard + `<div class="card"><h3>Where each year's spending comes from <span class="sub">fixed-return projection · ${state.planReal ? "today's $" : 'future $'} · <a href="#" data-act="realToggle">switch to ${state.planReal ? 'future' : "today's"} $</a></span></h3>
      ${stackBars(rows, keys, { line: { key: 'out', name: 'Spending + housing + healthcare + taxes', color: '#c94c43' } })}</div>
      <div class="card"><h3>Year by year</h3><div class="scroll"><table class="tbl"><thead><tr><th>Year</th><th>Age</th><th class="n">Spending</th><th class="n">Housing</th><th class="n">Health</th><th class="n">Taxes</th><th class="n">Wages</th><th class="n">Net rent</th><th class="n">Soc Sec</th><th class="n">Other inc</th><th class="n">Div/int</th><th class="n">From taxable</th><th class="n">From pre-tax</th><th class="n">From Roth</th><th class="n">Roth conv</th><th class="n">Liquid NW</th><th class="n">Net worth</th></tr></thead><tbody>${tbl}</tbody></table></div></div>`;
  }

  // ---------- PL-style analytics: Income | Taxes | Net worth | Deductions | Credits ----------
  const ANA_VIEWS = [['income', 'Income'], ['taxes', 'Taxes'], ['networth', 'Net worth'], ['deductions', 'Deductions'], ['credits', 'Credits']];
  const INCOME_KEYS = [
    { key: 'iWage', name: 'Wage income', color: '#2a9d8f', f: (r) => r.wages },
    { key: 'iSS', name: 'Social Security (taxable part)', color: '#26c6da', f: (r) => r.ssTax || 0 },
    { key: 'iSSfree', name: 'Social Security (non-taxable part)', color: '#80deea', f: (r) => Math.max(0, r.ss - (r.ssTax || 0)) },
    { key: 'iRmd', name: 'RMDs', color: '#f06292', f: (r) => r.rmd },
    { key: 'iPre', name: 'Pre-tax distributions', color: '#ba68c8', f: (r) => r.fromPre - (r.penalizedPre || 0) },
    { key: 'iPen', name: 'Penalized distributions (before 59½)', color: '#ef5350', f: (r) => r.penalizedPre || 0 },
    { key: 'iConv', name: 'Roth conversions', color: '#ffb74d', f: (r) => r.conv },
    { key: 'iCg', name: 'Capital gains income', color: '#5c6bc0', f: (r) => Math.max(0, r.capGain || 0) },
    { key: 'iQd', name: 'Qualified dividends', color: '#3949ab', f: (r) => r.qd || 0 },
    { key: 'iOd', name: 'Ordinary investment income (interest)', color: '#90a4ae', f: (r) => r.od || 0 },
    { key: 'iEx', name: 'Tax-exempt interest (muni)', color: '#7cc7a4', f: (r) => r.ex || 0 },
    { key: 'iRent', name: 'Net rental income (taxable)', color: '#7986cb', f: (r) => r.rentTaxable || 0 },
    { key: 'iRentFree', name: 'Rental income sheltered by depreciation', color: '#303f9f', f: (r) => r.rentSheltered || 0 },
    { key: 'iOther', name: 'Other income (pension, consulting, events)', color: '#8d6e63', f: (r) => (r.ordInc || 0) + (r.freeInc || 0) + (r.evOrd || 0) },
    { key: 'iRoth', name: 'Tax-free Roth distributions', color: '#1e88e5', f: (r) => r.fromRoth },
  ];
  const NW_KEYS_FN = () => [
    { key: 'nTax', name: 'Taxable brokerage & cash', color: '#3b6fd8', f: (r) => r.taxable, bal: true },
    { key: 'nPreS', name: `Pre-tax (${ownerName('self')})`, color: '#e2733a', f: (r) => r.pretaxS ?? r.pretax, bal: true },
    { key: 'nPreP', name: `Pre-tax (${ownerName('spouse')})`, color: '#f4a261', f: (r) => r.pretaxP || 0, bal: true },
    { key: 'nRoth', name: 'Roth', color: '#3aa17e', f: (r) => r.roth, bal: true },
    { key: 'n529', name: '529 college savings', color: '#d9a520', f: (r) => r.edu || 0, bal: true },
    { key: 'nProp', name: 'Real estate', color: '#a0785a', f: (r) => r.property, bal: true },
  ];
  const DED_KEYS = [
    { key: 'dStd', name: 'Standard deduction', color: '#90a4ae', f: (r) => r.ded?.std || 0 },
    { key: 'dSalt', name: 'State & local taxes (SALT, capped)', color: '#7e57c2', f: (r) => r.ded?.salt || 0 },
    { key: 'dMort', name: 'Mortgage interest (≤ $750k debt)', color: '#a0785a', f: (r) => r.ded?.mort || 0 },
    { key: 'dSenior', name: 'Senior deduction (65+, 2025–28)', color: '#26c6da', f: (r) => r.ded?.senior || 0 },
    { key: 'd401', name: 'Pre-tax 401(k) contributions (above the line)', color: '#e2733a', f: (r) => r.ded?.k401 || 0 },
    { key: 'dDep', name: 'Rental depreciation', color: '#5d4037', f: (r) => r.ded?.depr || 0 },
  ];
  const CRED_KEYS = [
    { key: 'cPtc', name: 'ACA premium tax credit', color: '#43a047', f: (r) => r.ptc || 0 },
  ];
  function anaRows(rows, keys) {
    return rows.map((r) => { const { f, b } = realRow(r); const o = { year: r.year, age: r.age, nw: r.nw * b, debt: r.debt * b }; for (const kk of keys) o[kk.key] = Math.max(0, kk.f(r)) * (kk.bal ? b : f); return o; });
  }
  function legendTotals(arows, keys, { balance = false, label = 'Lifetime', year = null } = {}) {
    const yr = year != null ? arows.find((r) => r.year === year) : null;
    if (yr) label = `${yr.year} · age ${yr.age}`;
    const vals = keys.map((kk) => ({ ...kk, v: yr ? (yr[kk.key] || 0) : balance ? (arows[arows.length - 1]?.[kk.key] || 0) : sum(arows, (r) => r[kk.key]) })).filter((x) => x.v > 0.5);
    const total = sum(vals, (x) => x.v); const max = Math.max(1, ...vals.map((x) => x.v));
    return `<table class="tbl legendtbl"><thead><tr><th>${label}</th><th class="n">Amount</th></tr></thead><tbody>${vals.map((x) => `<tr><td><span class="lg"><i style="background:${x.color}"></i></span>${x.name}</td><td class="n"><span class="lbar" style="width:${x.v / max * 100}%;background:${x.color}"></span>${k(x.v)}</td></tr>`).join('')}
      <tr><td><b>${balance ? 'Total assets' : yr ? 'Total this year' : 'Full plan'}</b></td><td class="n"><b>${k(total)}</b></td></tr>${balance && yr ? `<tr><td>Net worth after debt</td><td class="n">${k(yr.nw)}</td></tr>` : ''}</tbody></table>`;
  }
  function analyticsCard(P, S, R, taxRows, taxGrand) {
    const view = state.anaView || 'income'; const rows = R.det.rows;
    const ys = state.anaYear && rows.some((r) => r.year === state.anaYear) ? state.anaYear : null; const SB = { pick: 'anaYear', sel: ys };
    const yrNav = `<div class="skbar" style="margin:0 0 6px">${ys ? `<button class="btn sm" data-act="anaYearStep" data-d="-1">◀</button><b>${ys} · age ${rows.find((r) => r.year === ys).age}</b><button class="btn sm" data-act="anaYearStep" data-d="1">▶</button><a href="#" data-act="anaYear" data-y="">back to ${view === 'networth' ? 'end of plan' : 'lifetime'}</a>` : `<span class="mut">Click a bar to see that year</span>`}</div>`;
    const tabs = `<div class="anatabs">${ANA_VIEWS.map(([id, l]) => `<button class="anatab ${view === id ? 'on' : ''}" data-act="anaView" data-v="${id}">${l}</button>`).join('')}<span class="sp"></span><span class="sub">${state.planReal ? "today's $" : 'future $'} · <a href="#" data-act="realToggle">switch</a></span></div>`;
    let chart = '', legend = '', note = '';
    const pick = (keys, ar) => keys.filter((kk) => ar.some((r) => r[kk.key] > 0.5));
    if (view === 'income') {
      const ar = anaRows(rows, INCOME_KEYS); const ks = pick(INCOME_KEYS, ar);
      chart = stackBars(ar, ks, SB); legend = legendTotals(ar, ks, { year: ys });
      note = 'Gross income by source, including what isn’t taxed (Roth, muni interest, the untaxed share of Social Security, rent sheltered by depreciation). Taxable-account sales count only their realized gain here; the rest is return of your own basis.';
    } else if (view === 'taxes') {
      chart = stackBars(taxRows, TAX_KEYS.filter((t) => taxRows.some((r) => r[t.key] > 0.5)), SB);
      const tr = ys ? taxRows.find((r) => r.year === ys) : null; const src = tr ? [tr] : taxRows; const grand = tr ? sum(TAX_KEYS, (t) => tr[t.key] || 0) : taxGrand;
      legend = `<table class="tbl legendtbl"><thead><tr><th>${tr ? `${tr.year} · age ${tr.age}` : 'Lifetime'}</th><th class="n">Amount</th><th class="n">Share</th></tr></thead><tbody>${TAX_KEYS.map((t) => { const v = sum(src, (r) => r[t.key] || 0); return v > 0.5 ? `<tr><td><span class="lg"><i style="background:${t.color}"></i></span>${t.name}</td><td class="n">${k(v)}</td><td class="n">${pct(v / Math.max(1, grand) * 100, 0)}</td></tr>` : ''; }).join('')}<tr><td><b>${tr ? 'Total this year' : 'Full plan'}</b></td><td class="n"><b>${k(grand)}</b></td><td></td></tr></tbody></table>`;
    } else if (view === 'networth') {
      const NW_KEYS = NW_KEYS_FN(); const ar = anaRows(rows, NW_KEYS); const ks = pick(NW_KEYS, ar);
      chart = stackBars(ar, ks, { line: { key: 'nw', name: 'Net worth (after debt)', color: '#16202e' }, ...SB });
      legend = legendTotals(ar, ks, { balance: true, label: `At ${rows[rows.length - 1]?.year}`, year: ys }) + (ar.some((r) => r.debt > 1) ? `<p class="note">Mortgage debt is subtracted in the net worth line (today ${k(ar[0].debt)}).</p>` : '');
      note = 'End-of-year balances by account type. The line is net worth after mortgages.';
    } else if (view === 'deductions') {
      const ar = anaRows(rows, DED_KEYS); const ks = pick(DED_KEYS, ar);
      chart = stackBars(ar, ks, SB); legend = legendTotals(ar, ks, { year: ys });
      note = 'Federal deductions each year: the larger of standard or itemized (SALT up to the cap, plus mortgage interest), plus the senior deduction. Pre-tax 401(k) contributions and rental depreciation reduce income before that. State deductions differ (e.g. California uses its own standard deduction and allows property tax without a cap).';
    } else {
      const ar = anaRows(rows, CRED_KEYS); const ks = pick(CRED_KEYS, ar);
      chart = ks.length ? stackBars(ar, ks, SB) : '<p class="note">No credits in this plan. Turn on healthcare modeling, or keep MAGI under the ACA cliff before 65, to receive the premium tax credit.</p>';
      legend = ks.length ? legendTotals(ar, ks, { year: ys }) : '';
      note = 'The ACA premium tax credit is the only credit modeled (it’s usually the largest for early retirees). Child, dependent-care, foreign-tax and state exemption credits aren’t modeled.';
    }
    return `<div class="card">${tabs}${yrNav}<div class="anagrid"><div>${chart}</div><div>${legend}</div></div>${note ? `<p class="note">${note}</p>` : ''}</div>`;
  }
  function pTaxes(P, S, R, an) {
    const rows = R.det.rows;
    const taxRows = rows.map((r) => { const f = realRow(r).f, tp = r.taxParts || {}; const o = { year: r.year, age: r.age }; for (const t of TAX_KEYS) o[t.key] = (tp[t.part] || 0) * f; return o; });
    const taxGrand = sum(taxRows, (r) => sum(TAX_KEYS, (t) => r[t.key]));
    const D = R.det; const wdr = rows.filter((r) => r.liquid > 0).map((r) => (r.fromTax + r.fromPre + r.rmd + r.fromRoth) / Math.max(1, r.liquid + r.fromTax + r.fromPre + r.rmd + r.fromRoth));
    const avgWdr = wdr.length ? wdr.reduce((a, b) => a + b, 0) / wdr.length : 0;
    const cards = `<div class="kpis"><div class="kpi"><div class="kl">Net legacy</div><div class="kv">${k(D.legacyReal)}</div><div class="ks">${D.estateTaxReal ? `after ${k(D.estateTaxReal)} estate tax` : 'no federal estate tax'} · today's $</div></div>
      <div class="kpi"><div class="kl">Effective tax rate</div><div class="kv">${pct(D.effRate * 100, 1)}</div><div class="ks">income + payroll tax ÷ gross income</div></div>
      <div class="kpi"><div class="kl">Avg withdrawal rate</div><div class="kv">${pct(avgWdr * 100, 2)}</div><div class="ks">portfolio draws ÷ liquid assets</div></div>
      <div class="kpi"><div class="kl">All taxes</div><div class="kv">${k(taxGrand)}</div><div class="ks">incl. property tax ${k(D.totals.propTax)} and IRMAA ${k(D.totals.irmaa)}</div></div></div>`;
    const yrs = (fn) => rows.filter(fn).map((r) => r.year);
    const span = (a) => (a.length ? `${a.length} yr${a.length > 1 ? 's' : ''} (${a[0]}${a.length > 1 ? '–' + a[a.length - 1] : ''})` : 'none');
    const fd = D.firstDeath;
    const checks = [
      ['ACA cliff (pre-65)', span(yrs((r) => (r.age < 65 || r.sAge < 65) && r.magi / r.cpi > E.acaThresholds(S, an.Y).cliff)), `ACA credits received: ${k(D.totals.ptc)}`],
      ['IRMAA surcharge years', span(yrs((r) => r.irmaa > 0)), `total ${k(D.totals.irmaa)}`],
      ['NIIT (3.8%) years', span(yrs((r) => r.taxParts.niit > 1)), 'thresholds $250k MFJ / $200k single are not inflation-indexed'],
      ['AMT years', span(yrs((r) => r.taxParts.amt > 1)), `total ${k(D.totals.amt)}; OBBBA phases the exemption out at 50% above $1M MFJ`],
      ...(isCA() ? [['CA Mental Health tax years', span(yrs((r) => r.taxParts.caMhst > 1)), '1% on California taxable income over $1M (single or joint); triggered by big gains years']] : []),
      ['Itemizing years', span(yrs((r) => r.itemized)), `SALT cap $40k (2025–29, phased down above $500k MAGI) then $10k${isCA() ? '; CA allows property tax without a cap' : ''}`],
      [SOLO() ? 'Filing status' : 'Single filer after first death', SOLO() ? 'single every year' : fd ? `from ${fd.year + 1} (${fd.who === 'self' ? 'you' : 'spouse'} at ${fd.who === 'self' ? P.people.lifeSelf : P.people.lifeSpouse})` : 'not within plan', 'brackets roughly halve while income often doesn\'t: the "widow\'s penalty"'],
      ['Step-up in basis', fd ? (P.estate.communityProperty ? 'full step-up at first death (community property)' : 'half step-up at first death') : '—', (ST().cp ? `${STN()} community property resets basis on both halves. ` : 'Only the deceased spouse\'s half gets a new basis. ') + 'Large gains in ' + CS() + ' lots can disappear at the first death.'],
      ['Federal estate tax', D.estateTaxReal ? k(D.estateTaxReal) : 'none', `exemption $15M/person (2026), ${P.estate.portability ? '×2 with portability' : 'no portability'}${isCA() ? '; CA has no estate tax' : ''}`],
      [`${STN()} capital gains`, isCA() ? 'taxed as ordinary income (up to 13.3%)' : ST().type === 'none' ? (ST().cg ? 'capital-gains excise above the threshold' : 'no state income tax') : 'taxed by the state', isCA() ? '0% federal harvesting still costs CA tax; muni interest is CA-exempt only for California bonds; CA doesn\'t tax Social Security' : `muni interest is usually exempt only for ${STN()} bonds${ST().ssTax ? '; this state taxes some Social Security' : ''}`],
    ];
    const checkCard = `<div class="card"><h3>${STN()} & high-net-worth checks <span class="sub">this plan, fixed returns</span></h3><table class="tbl"><tbody>${checks.map(([a, b, c]) => `<tr><td><b>${a}</b></td><td>${b}</td><td class="note">${c}</td></tr>`).join('')}</tbody></table></div>`;
    const cliff = E.acaThresholds(S, an.Y).cliff;
    const ch = lineChart([
      { name: 'MAGI', color: '#8d7ad6', pts: rows.map((r) => [r.age, r.magi / r.cpi]) },
      { name: 'Total tax', color: '#c94c43', pts: rows.map((r) => [r.age, r.tax / r.cpi]) },
      { name: 'Roth conversions', color: '#3aa17e', dash: true, pts: rows.map((r) => [r.age, r.conv / r.cpi]) },
      { name: 'RMD', color: '#e2733a', dash: true, pts: rows.map((r) => [r.age, r.rmd / r.cpi]) }], { hlines: [{ y: cliff, label: 'ACA 400% cliff', color: '#c94c43' }, { y: S.ref.irmaaMFJ, label: 'IRMAA tier 1', color: '#d08a1e' }], markers: [{ x: 65, label: '65' }] });
    const tot = (f) => rows.reduce((s, r) => s + f(r) / r.cpi, 0);
    const tbl = rows.map((r) => `<tr><td>${r.year}</td><td>${r.age}</td><td class="n">${k(r.magi / r.cpi)}</td><td class="n">${k(r.tax / r.cpi)}</td><td class="n">${k(((r.taxParts?.fedOrd || 0) + (r.taxParts?.fedPref || 0) + (r.taxParts?.niit || 0)) / r.cpi)}</td><td class="n">${k((r.taxParts?.ca || 0) / r.cpi)}</td><td class="n">${k((r.taxParts?.fica || 0) / r.cpi)}</td><td class="n">${pct(r.magi > 0 ? r.tax / r.magi * 100 : 0, 1)}</td><td class="n">${k(r.realized / r.cpi)}</td><td class="n">${k(r.conv / r.cpi)}</td><td class="n">${k(r.rmd / r.cpi)}</td><td class="n">${k(r.ptc / r.cpi)}</td><td class="n">${k(r.irmaa / r.cpi)}</td><td class="n">${r.penalty ? k(r.penalty / r.cpi) : ''}</td><td>${r.age < 65 && r.magi / r.cpi > cliff ? '<span class="pill red">over cliff</span>' : ''}</td></tr>`).join('');
    return cards + `<div class="kpis"><div class="kpi"><div class="kl">Lifetime tax</div><div class="kv">${k(tot((r) => r.tax))}</div><div class="ks">today's $, fixed returns</div></div>
      <div class="kpi"><div class="kl">Roth converted</div><div class="kv">${k(tot((r) => r.conv))}</div><div class="ks">${P.tax.convert === 'none' ? 'conversions off' : 'strategy: ' + P.tax.convert}</div></div>
      <div class="kpi"><div class="kl">Pre-tax at RMD age</div><div class="kv">${k((rows.find((r) => r.rmd > 0) || rows[rows.length - 1]).pretax / ((rows.find((r) => r.rmd > 0) || rows[rows.length - 1]).cpiEnd))}</div><div class="ks">drives forced income later</div></div>
      <div class="kpi"><div class="kl">ACA credits received</div><div class="kv">${k(tot((r) => r.ptc))}</div><div class="ks">${P.healthcare.model ? 'modeled' : 'turn on healthcare modeling'}</div></div></div>
      ${analyticsCard(P, S, R, taxRows, taxGrand)}
      ${checkCard}
      <div class="card"><h3>MAGI, taxes, conversions <span class="sub">today's $</span></h3>${ch}<p class="note">Try the conversion strategies under Assumptions and compare lifetime tax under Compare plans. Bracket-filling before 65 competes with ACA subsidies, so check the over-cliff flags.</p></div>
      <div class="card"><h3>By year</h3><div class="scroll"><table class="tbl"><thead><tr><th>Year</th><th>Age</th><th class="n">MAGI</th><th class="n">Total tax</th><th class="n">Federal</th><th class="n">${STC()}</th><th class="n">FICA</th><th class="n">Eff.</th><th class="n">Realized gains</th><th class="n">Roth conv</th><th class="n">RMD</th><th class="n">ACA credit</th><th class="n">IRMAA</th><th class="n">Penalty</th><th></th></tr></thead><tbody>${tbl}</tbody></table></div></div>`;
  }

  function pOptimize(P, S, R, an) {
    const key = planCache.key; const O = state._opt && state._opt.key === key ? state._opt : null;
    const goal = state.optGoal || 'legacy';
    const goals = { legacy: ['Net legacy', 'legacy', 1], tax: ['Lowest lifetime tax', 'lifetimeTax', -1], endNW: ['Ending net worth', 'endNW', 1], success: ['Historical success', 'success', 1], aca: ['ACA subsidies', 'aca', 1] };
    const cols = [['Lifetime tax', 'lifetimeTax', -1], ['Net legacy', 'legacy', 1], ['Effective rate', 'effRate', -1, (v) => pct(v * 100, 1)], ['Ending net worth', 'endNW', 1], ['ACA subsidies', 'aca', 1], ['RMDs', 'rmd', -1], ['IRMAA', 'irmaa', -1], ['Roth converted', 'conv', 0], ['Historical success', 'success', 1, (v) => pct(v * 100, 0)]];
    let body = `<p class="note">Click <b>Run</b> to simulate every strategy on this plan under four market scenarios: fixed returns, and Monte Carlo weak (25th percentile), median and strong (75th percentile) markets. Historical success uses all 98 start years. Takes several seconds.</p>`;
    const SC = [['fixed', 'Fixed returns'], ['p25', 'Weak markets (MC 25th)'], ['p50', 'Median (MC 50th)'], ['p75', 'Strong markets (MC 75th)']];
    const scen = O && O.mc && SC.some(([s]) => s === state.optScen) ? state.optScen : 'fixed';
    if (O) {
      const succ = Object.fromEntries(O.rows.map((r) => [r.id, r.success]));
      const rowsFor = (s) => (s === 'fixed' || !O.mc ? O.rows : O.mc[s].rows.map((r) => ({ ...r, success: succ[r.id] })));
      const rows = rowsFor(scen); const [, gk, gdir] = goals[goal];
      const bestOf = (rs) => rs.reduce((b, r) => (b == null || (r[gk] - b[gk]) * gdir > 1e-9 ? r : b), null);
      const curId = 'current';
      const fmtG = (v) => (gk === 'effRate' ? pct(v * 100, 1) : gk === 'success' ? pct(v * 100, 0) : k(v));
      const summary = O.mc ? `<h4>Best strategy for “${goals[goal][0]}” in each scenario</h4><table class="tbl narrow2"><thead><tr><th>Scenario</th><th>Best</th><th class="n">${goals[goal][0]}</th><th class="n">vs your current settings</th><th class="n">Plan ends with</th></tr></thead><tbody>${SC.map(([s, lab]) => {
          const rs = rowsFor(s); const b = bestOf(rs); const ref = rs.find((r) => r.id === (curId || 'none')) || rs[0]; const d = (b[gk] - ref[gk]) * (gdir || 1);
          const tie = Math.max(...rs.map((r) => r[gk])) - Math.min(...rs.map((r) => r[gk])) < 1e-6 * Math.max(1, Math.abs(b[gk])) + 1e-9; const fails = rs.every((r) => r.failPct >= 0.5 || r.failed);
          return `<tr class="${s === scen ? 'sel' : ''}"><td><a href="#" data-act="optScen" data-s="${s}">${lab}</a></td><td><b>${tie ? (fails ? 'No difference: the plan runs out' : 'No difference') : esc(b.name)}</b></td><td class="n">${fmtG(b[gk])}</td><td class="n ${d > 0 ? 'pos' : ''}">${Math.abs(d) < 1e-6 ? '—' : (gk === 'effRate' || gk === 'success' ? (d >= 0 ? '+' : '') + (Math.abs(b[gk] - ref[gk]) * 100).toFixed(1) + ' pts' : (d >= 0 ? '+' : '−') + k(Math.abs(b[gk] - ref[gk])))}</td><td class="n">${s === 'fixed' ? k(rs.find((r) => r.id === (curId || 'none'))?.endNW ?? rs[0].endNW) : k(O.mc[s].baseEnd)}</td></tr>`; }).join('')}</tbody></table>
        ${(() => { const ids = SC.map(([s]) => bestOf(rowsFor(s)).id); if (SC.some(([s]) => rowsFor(s).every((r) => r.failPct >= 0.5 || r.failed))) return `<p class="note">In some scenarios every strategy runs out of money, so tax strategy can't fix those; spending, retirement timing or returns are the levers there.</p>`; return ids.every((x) => x === ids[0]) ? `<p class="pos">Same winner in every scenario: the choice holds up whether markets are weak or strong.</p>` : `<p class="note">The winner changes with markets. Strategies that convert a lot to Roth tend to win when markets are strong (bigger future RMDs and heir taxes to avoid); lighter strategies often win when markets are weak. Pick one that does well in the weak and median rows if you'd rather be safe.</p>`; })()}` : '';
      const tabs = O.mc ? `<div class="seg" style="margin:10px 0">${SC.map(([s, lab]) => `<button class="btn sm ${s === scen ? 'primary' : ''}" data-act="optScen" data-s="${s}">${lab}</button>`).join(' ')}</div>` : '';
      const best = rows.reduce((b, r) => (b == null || (r[gk] - b[gk]) * gdir > 1e-9 ? r : b), null);
      const heat = (c, v) => { const vals = rows.map((r) => r[c[1]]); const lo = Math.min(...vals), hi = Math.max(...vals); if (!c[2] || hi - lo < 1e-9) return ''; const t = (v - lo) / (hi - lo); const g = c[2] > 0 ? t : 1 - t; return `background:rgba(59,111,216,${(0.06 + 0.32 * g).toFixed(2)})`; };
      body = `${summary}${tabs}${scen !== 'fixed' ? `<p class="note">${SC.find(([s]) => s === scen)[1]}: averages of the ${O.mc[scen].paths} simulated markets ranked ${Math.round(O.mc[scen].q * 100 - 5)}th–${Math.round(O.mc[scen].q * 100 + 5)}th percentile for how your current plan ends (around ${k(O.mc[scen].baseEnd)} net worth, today's $). Every strategy is run on exactly those markets.</p>` : ''}<table class="tbl opt"><thead><tr><th>Strategy</th>${cols.map((c) => `<th class="n">${c[0]}</th>`).join('')}<th></th></tr></thead><tbody>${rows.map((r) => `<tr class="${r === best ? 'best' : ''}"><td>${r === best ? '★ ' : ''}<b>${esc(r.name)}</b><div class="note">${esc(r.desc)}</div>${r.failPct ? `<span class="pill ${r.failPct >= 0.5 ? 'red' : 'amber'}">runs out in ${Math.round(r.failPct * 100)}% of these markets</span>` : r.failed ? `<span class="pill red">runs out at ${r.failed}</span>` : ''}</td>${cols.map((c) => `<td class="n" style="${heat(c, r[c[1]])}">${c[3] ? c[3](r[c[1]]) : k(r[c[1]])}</td>`).join('')}<td>${r.id === 'current' ? '' : `<button class="btn sm" data-act="applyStrat" data-id="${r.id}">Apply</button>`}</td></tr>`).join('')}</tbody></table>
      <p class="note">Dollar figures are lifetime totals in today's dollars. Lifetime tax = federal + ${STN()} income tax, NIIT, AMT, payroll tax and penalties; IRMAA and property tax are shown separately. Net legacy subtracts heirs' tax on inherited pre-tax money (${P.estate.heirRate}%) and federal estate tax. Historical success (all 98 start years) is the same in every scenario tab. The ★ marks the best strategy for your goal in the selected scenario. Apply copies its settings into this plan (Assumptions → Withdrawals & Roth conversions).</p>`;
    }
    return `<div class="card"><h3>Compare tax strategies <span class="sub">plan “${esc(P.name)}”</span></h3>
      <div class="skbar"><span>Optimize for</span><select data-scope="ui" data-path="optGoal">${Object.entries(goals).map(([k2, g]) => `<option value="${k2}" ${k2 === goal ? 'selected' : ''}>${g[0]}</option>`).join('')}</select><button class="btn primary sm" data-act="runOpt">Run</button><span id="optOut" class="note"></span></div>
      ${body}</div>
      <div class="card"><h3>How the strategies work</h3><ul class="steps">
        <li><b>Roth conversions</b> move pre-tax money to Roth while your bracket is low (before Social Security and RMDs), shrinking forced RMD income later and the ${P.estate.heirRate}% tax your heirs would pay.</li>
        <li><b>Withdrawal shielding</b> caps how much pre-tax money you draw each year at the chosen bracket and covers the rest from taxable and Roth.</li>
        <li><b>Gain harvesting</b> sells and rebuys appreciated lots to use the 0% federal capital-gains bracket. ${isCA() ? 'In California those gains are still taxed (up to 13.3%), so it pays less here than in no-tax states.' : ST().type === 'none' ? `${STN()} doesn't tax them, so harvesting is close to free here.` : `${STN()} still taxes those gains.`}</li>
        <li><b>ACA-aware</b> variants keep MAGI under the 400% FPL cliff before 65, because losing the premium credit can cost more than the tax saved.</li>
        <li><b>IRMAA-aware</b> keeps MAGI under the first Medicare surcharge tier, which is based on income two years earlier, starting at 63.</li>
        <li>Conversions also interact with your <b>step-up</b>: taxable ${CS()} lots reset their basis at death${ST().cp ? ` in ${STN()} (community property: both halves)` : ' (the deceased\'s half)'}, so spending them down early to fund conversions can waste a free step-up.</li></ul></div>`;
  }

  // ---------- Direct indexing ----------
  let diCache = { key: null };
  function pDI(P, S, R) {
    const D = P.di; const an = window.__an;
    const cashNow = sum(an.s.accts.filter((a) => a.taxType === 'taxable'), (a) => sum(a.holdings.filter((h) => h.assetClass === 'cash' || h.assetClass === 'bank'), (h) => h.value));
    const flat = D.feeType === 'flat';
    const setup = `<div class="card"><h3>Direct indexing <span class="sub">plan “${esc(P.name)}” · today's $</span></h3>
      <p>Direct indexing holds the individual stocks of an index instead of a fund, so losers can be sold for tax losses and replaced with similar stocks. The losses go into a <b>loss bank</b> that offsets capital gains (for example, from selling ${CS()}), then up to $3,000 a year of ordinary income, and carries forward. Losses are biggest in the first years and fade as the portfolio's cost basis falls.</p>
      <div class="grid4">
        ${field('Use direct indexing in this plan', 'plan', 'di.enabled', { type: 'check', hint: 'affects every Plan calculation, including Monte Carlo' })}
        ${field('How the money gets there', 'plan', 'di.source', { type: 'select', options: [['cash', 'Move existing cash (taxable cash & bank first)'], ['flow', 'New money each year from cash flow']] })}
        ${field('Lump sum now', 'plan', 'di.initial', { hint: `moved from existing cash · taxable cash today ${k(cashNow)}` })}
        ${field('Add per year', 'plan', 'di.annual', { hint: D.source === 'flow' ? 'paid from this year’s cash flow (paycheck surplus, or withdrawals once retired)' : 'moved from cash each year while it lasts' })}
        ${field('For how many years', 'plan', 'di.years')}
        ${field('Losses harvested in year 1 (% of value)', 'plan', 'di.harvestPct', { hint: 'typical 5–15%; more in volatile years' })}
        ${field('Harvest fades each year by %', 'plan', 'di.decayPct', { hint: `total over time ≈ ${Math.round((+D.harvestPct || 0) / Math.max(0.01, (+D.decayPct || 1) / 100))}% of each dollar invested (fixed returns)` })}
        ${field('Fee type', 'plan', 'di.feeType', { type: 'select', options: [['pct', 'Expense ratio (% per year)'], ['flat', 'Flat fee ($ per year)']] })}
        ${flat ? field("Flat fee per year (today's $)", 'plan', 'di.feeFlat', { hint: 'taken from the direct-indexing account' }) : field('Expense ratio %', 'plan', 'di.feePct', { hint: 'typical 0.10–0.40%; an index ETF ≈ 0.03%' })}
        ${field('Fee stops after N years', 'plan', 'di.feeYears', { ph: 'never', hint: 'e.g. if you move to a free provider once harvesting fades' })}
        ${field('Use leftover losses to diversify', 'plan', 'di.diversify', { type: 'check', hint: 'sell & rebuy low-basis lots (e.g. ' + CS() + ') with the gain fully offset' })}
        ${D.diversify ? field('Start diversifying at age', 'plan', 'di.diversifyFromAge', { hint: 'before 65 the losses may be worth more keeping MAGI under the ACA cliff' }) : '<span></span>'}
      </div>
      </div><div class="card"><h3>Which index? <span class="sub">general guidance, not a recommendation</span></h3>
      <ul class="steps"><li><b>Use a broad US index, and exclude your concentrated stock (${CS()}).</b> A Russell 1000/3000 or total-market index holds more stocks, so more of them fall in any given month and there are more losses to harvest. An S&P 500 index is the most common and cheapest. Either way, exclude ${CS()}/GOOGL (and optionally hold less big tech) so the account adds US market exposure without adding to your largest risk.</li>
      <li><b>Build around your ${CS()}:</b> some providers (e.g. Parametric, Aperio, Frec, Schwab Personalized Indexing; check current offerings) can hold the rest of the market around existing shares and use harvested losses to sell ${CS()} gradually with little tax.</li>
      <li><b>International and bonds:</b> direct indexing doesn't fix those. Hold international as plain index funds in taxable (foreign tax credit) and bonds in pre-tax 401(k)s.</li>
      <li><b>Wash sales:</b> after a harvest, don't buy the same individual stocks elsewhere within 30 days. S&P 500 funds in your 401(k)s generally aren't "substantially identical" to individual stocks, but keep the overlap in mind.</li></ul>
      <p class="note">In Monte Carlo and the backtest, harvests are larger in down years and smaller in strong years. ${isCA() ? 'California follows' : 'Most states follow'} the federal capital-loss rules ($3,000/yr against income, unlimited carryforward). Half of any unused losses expire at the first death; the rest at the second.</p></div>`;
    if (!D.enabled) return setup + `<div class="card"><p class="note">Turn on “Use direct indexing in this plan” to see the impact.</p></div>`;
    const key = planCache.key; if (diCache.key !== key) diCache = { key, ...L.diCompare(P, R.init, S) };
    const X = diCache; const rows = X.di.rows;
    const m = (d) => ({ tax: d.totals.tax, end: d.endNWReal, legacy: d.legacyReal, aca: d.totals.ptc, irmaa: d.totals.irmaa });
    const a = m(X.cash), b = m(X.fund), c = m(X.di);
    const dlt = (x, y, lowGood) => { const d = y - x; const good = lowGood ? d < 0 : d > 0; return `<span class="${Math.abs(d) < 500 ? '' : good ? 'pos' : 'neg'}">${Math.abs(d) < 500 ? '—' : (d > 0 ? '+' : '−') + k(Math.abs(d))}</span>`; };
    const T = X.di.totals;
    const firstHarv = rows.find((r) => r.diHarvest > 0);
    const kpis = `<div class="kpis">
      <div class="kpi"><div class="kl">Losses harvested</div><div class="kv">${k(T.diHarvest || 0)}</div><div class="ks">contributed ${k(T.diContrib || 0)}</div></div>
      <div class="kpi"><div class="kl">Losses used</div><div class="kv">${k(T.diUsed || 0)}</div><div class="ks">${k((T.diUsed || 0) - (T.diUseO || 0))} vs gains · ${k(T.diUseO || 0)} vs income${D.diversify ? ` · ${k(T.diDiversified || 0)} to diversify` : ''}</div></div>
      <div class="kpi"><div class="kl">Harvesting fades</div><div class="kv">${X.fadeYear || '—'}</div><div class="ks">${X.fadeYear ? `${X.fadeYear - (firstHarv?.year || X.fadeYear)} years in; new losses < 0.5%/yr` : 'still harvesting at plan end'}</div></div>
      <div class="kpi"><div class="kl">Loss bank used up</div><div class="kv">${X.emptyYear || '—'}</div><div class="ks">${X.emptyYear ? `losses stop being useful after ${X.emptyYear}` : `${k(X.unusedEnd)} never used`}</div></div>
      <div class="kpi"><div class="kl">Fees paid</div><div class="kv">${k(T.diFee || 0)}</div><div class="ks">${flat ? `flat ${k(+D.feeFlat || 0)}/yr` : `${D.feePct}%/yr`}${D.feeYears ? `, for ${D.feeYears} yrs` : ''}</div></div></div>`;
    const cmp = `<div class="card"><h3>Impact on the plan <span class="sub">fixed returns · lifetime totals, today's $</span></h3>
      <table class="tbl narrow2"><thead><tr><th></th><th class="n">${D.source === 'flow' ? "Don't invest it" : 'Keep it as cash'}</th><th class="n">Plain index fund (0.03%)</th><th class="n">Direct indexing</th><th class="n">DI vs ${D.source === 'flow' ? 'not investing' : 'cash'}</th><th class="n">DI vs index fund</th></tr></thead><tbody>
      <tr><td>Lifetime tax</td><td class="n">${k(a.tax)}</td><td class="n">${k(b.tax)}</td><td class="n">${k(c.tax)}</td><td class="n">${dlt(a.tax, c.tax, true)}</td><td class="n">${dlt(b.tax, c.tax, true)}</td></tr>
      <tr><td>ACA credits received</td><td class="n">${k(a.aca)}</td><td class="n">${k(b.aca)}</td><td class="n">${k(c.aca)}</td><td class="n">${dlt(a.aca, c.aca)}</td><td class="n">${dlt(b.aca, c.aca)}</td></tr>
      <tr><td>IRMAA</td><td class="n">${k(a.irmaa)}</td><td class="n">${k(b.irmaa)}</td><td class="n">${k(c.irmaa)}</td><td class="n">${dlt(a.irmaa, c.irmaa, true)}</td><td class="n">${dlt(b.irmaa, c.irmaa, true)}</td></tr>
      <tr><td>Ending net worth</td><td class="n">${k(a.end)}</td><td class="n">${k(b.end)}</td><td class="n">${k(c.end)}</td><td class="n">${dlt(a.end, c.end)}</td><td class="n">${dlt(b.end, c.end)}</td></tr>
      <tr><td>Net legacy</td><td class="n">${k(a.legacy)}</td><td class="n">${k(b.legacy)}</td><td class="n">${k(c.legacy)}</td><td class="n">${dlt(a.legacy, c.legacy)}</td><td class="n">${dlt(b.legacy, c.legacy)}</td></tr></tbody></table>
      <p class="note"><b>DI vs index fund</b> is the tax-loss-harvesting effect alone: tax saved minus the extra fee. <b>DI vs ${D.source === 'flow' ? 'not investing' : 'cash'}</b> also includes putting the money in stocks at all. Harvested losses lower your basis, so part of the saving comes back as larger gains when those shares are sold later. It becomes permanent if they're held until death (step-up) or used to diversify. Before 65, losses that keep MAGI under the ACA cliff can be worth far more than their tax rate.</p></div>`;
    const ch = lineChart([
      { name: 'Direct-indexing value', color: '#3b6fd8', pts: rows.map((r) => [r.year, r.diValue / r.cpiEnd]) },
      { name: 'Its cost basis', color: '#9aa3ad', dash: true, pts: rows.map((r) => [r.year, r.diBasis / r.cpiEnd]) },
      { name: 'Loss bank (unused losses)', color: '#c94c43', pts: rows.map((r) => [r.year, r.diPool / r.cpiEnd]) }]);
    const show = rows.filter((r, i) => i < 25 || r.diHarvest > 1 || r.diUseG + r.diUseO > 1);
    const tbl = show.map((r) => { const f = 1 / r.cpi, b2 = 1 / r.cpiEnd; return `<tr><td>${r.year}</td><td>${r.age}</td><td class="n">${r.diContrib ? k(r.diContrib * f) : '—'}</td><td class="n">${k(r.diValue * b2)}</td><td class="n">${k(r.diBasis * b2)}</td><td class="n">${r.diHarvest > 1 ? k(r.diHarvest * f) : '—'}</td><td class="n">${k(Math.max(0, r.gainsRaw) * f)}</td><td class="n">${r.diUseG > 1 ? k(r.diUseG * f) : '—'}</td><td class="n">${r.diUseO > 1 ? k(r.diUseO * f) : '—'}</td>${D.diversify ? `<td class="n">${r.diDiversified > 1 ? k(r.diDiversified * f) : '—'}</td>` : ''}<td class="n">${k(r.diPool * b2)}</td><td class="n">${r.diFee ? k(r.diFee * f) : '—'}</td></tr>`; }).join('');
    return setup + kpis + cmp + `<div class="card"><h3>Direct-indexing account and loss bank <span class="sub">today's $</span></h3>${ch}</div>
      <div class="card"><h3>Year by year</h3><div class="scroll" style="max-height:380px"><table class="tbl"><thead><tr><th>Year</th><th>Age</th><th class="n">Added</th><th class="n">Value</th><th class="n">Basis</th><th class="n">Losses harvested</th><th class="n">Gains realized</th><th class="n">Offset gains</th><th class="n">Offset income</th>${D.diversify ? '<th class="n">Diversified</th>' : ''}<th class="n">Loss bank</th><th class="n">Fee</th></tr></thead><tbody>${tbl}</tbody></table></div>
      <p class="note">“Gains realized” are this plan's capital gains before the offset: selling taxable lots for spending, home sales and the cost of moving appreciated holdings into direct indexing. Watch for wash sales: don't buy the same stocks in other accounts (including IRAs) within 30 days of a harvest.</p></div>`;
  }
  function pMC(P, S, R) {
    const { mc, bt } = R;
    const keyAges = [0, 10, 20, 30, 40].map((d) => mc.bands[Math.min(mc.bands.length - 1, d)]).filter((b, i, a) => a.indexOf(b) === i);
    const ptbl = keyAges.map((b) => `<tr><td>${b.age}</td><td class="n">${k(b.p10)}</td><td class="n">${k(b.p25)}</td><td class="n">${k(b.p50)}</td><td class="n">${k(b.p75)}</td><td class="n">${k(b.p90)}</td></tr>`).join('');
    const grid = bt.byStart.map((x) => `<span class="yc ${x.success ? 'ok' : 'bad'}" title="${x.year}: ${x.success ? 'lasts, ends ' + k(x.endReal) : 'runs out at ' + x.failed}${x.wrapped ? ' (wraps to 1928)' : ''}">${x.year}</span>`).join('');
    const fails = mc.failAges.slice().sort((a, b) => a - b); const bins = {}; fails.forEach((a) => { const b = Math.floor(a / 5) * 5; bins[b] = (bins[b] || 0) + 1; });
    return `<div class="kpis"><div class="kpi"><div class="kl">Monte Carlo success</div><div class="kv ${succCls(mc.success)}">${pct(mc.success * 100, 1)}</div><div class="ks">${mc.runs} runs</div></div>
      <div class="kpi"><div class="kl">Backtest success</div><div class="kv ${succCls(bt.success)}">${pct(bt.success * 100, 1)}</div><div class="ks">${bt.byStart.filter((x) => !x.success).length} failing start years</div></div>
      <div class="kpi"><div class="kl">Failure ages (MC)</div><div class="kv">${fails.length ? Math.round(fails[Math.floor(fails.length / 2)]) : '—'}</div><div class="ks">${Object.entries(bins).map(([b, n]) => `${b}s: ${n}`).join(' · ') || 'no failures'}</div></div></div>
      <div class="card"><h3>Retiring in each historical year <span class="sub">green lasts to ${P.endAge}; red runs out (hover for detail)</span></h3><div class="ygrid">${grid}</div>
      <p class="note">Sequences longer than the data wrap around to 1928, as in ProjectionLab's historical mode. Watch the late-1960s starts: high inflation plus poor real returns is the classic early-retiree failure.</p></div>
      <div class="card"><h3>Liquid net worth percentiles <span class="sub">today's $</span></h3><table class="tbl"><thead><tr><th>Age</th><th class="n">10th</th><th class="n">25th</th><th class="n">Median</th><th class="n">75th</th><th class="n">90th</th></tr></thead><tbody>${ptbl}</tbody></table></div>`;
  }

  function pScenarios(P, S) {
    const c = state._cmp;
    const rows = c ? c.map((x) => `<tr class="${x.id === P.id ? 'sel' : ''}"><td>${esc(x.name)}</td><td class="n ${succCls(x.mc)}">${pct(x.mc * 100, 0)}</td><td class="n ${succCls(x.bt)}">${pct(x.bt * 100, 0)}</td><td class="n">${k(x.medEnd)}</td><td class="n">${k(x.p10End)}</td><td class="n">${x.failed ? 'runs out ' + x.failed : k(x.detEnd)}</td><td class="n">${k(x.tax)}</td><td class="n">${k(x.conv)}</td></tr>`).join('') : '';
    return `<div class="card"><h3>Compare plans</h3><p>Duplicate a plan, change one thing (spending, conversion strategy, a home sale, Social Security age), then compare the results side by side.</p>
      <button class="btn primary" data-act="runCompare">Run comparison (${state.plans.length} plans)</button> <span id="cmpOut" class="note"></span>
      ${c ? `<table class="tbl" style="margin-top:12px"><thead><tr><th>Plan</th><th class="n">Monte Carlo</th><th class="n">Backtest</th><th class="n">Median end</th><th class="n">10th pct end</th><th class="n">Fixed-return end</th><th class="n">Lifetime tax</th><th class="n">Roth converted</th></tr></thead><tbody>${rows}</tbody></table><p class="note">Ending values are liquid net worth in today's dollars.</p>` : ''}</div>`;
  }

  function pPL(P, S, R, an) {
    const inputs = state.plImport ? plInputsCard(P, S, an) : '';
    const csvPart = pPLcsv(P, S, R, an);
    const incPart = P.plInc ? plIncomeCard(P, S, R) : (P.pl || state.plImport ? `<div class="card"><h3>Income by source <span class="sub">optional</span></h3><p>Load ProjectionLab's <b>Income report CSV</b> to compare income source by source (salary, Social Security, rent, dividends, RMDs, Roth conversions, realized gains, Roth/529 withdrawals) against this plan.</p><button class="btn" data-act="loadPL">Load Income CSV</button></div>` : '');
    return inputs + csvPart + incPart;
  }
  function pPLcsv(P, S, R, an) {
    const intro = `<p>ProjectionLab is a <b>benchmark only</b>. Every number in this plan (spending, drawdown order, taxes, ACA, RMDs, real estate) comes from your own inputs and this app's engine. The ProjectionLab export is overlaid so you can see where the two models disagree, and why.</p>`;
    const kinds = `<ul class="steps"><li><b>Account data (.json)</b>: ProjectionLab → Account settings → Export data. Has your inputs (accounts, homes, retirement dates, Social Security, expenses, assumptions). It's used to check that both tools start from the same place.</li><li><b>Report summary (.csv)</b>: from a plan's report/table view → Export. Has the year-by-year results (net worth, taxes, withdrawals). It's needed for the year-by-year overlay.</li><li><b>Income report (.csv)</b>, optional: income by source each year, used to explain differences in income and taxes.</li></ul>`;
    if (!P.pl) return `<div class="card"><h3>${state.plImport || P.plInc ? 'Year-by-year results' : 'Benchmark against ProjectionLab'}</h3>${state.plImport || P.plInc ? '' : intro}<p>Load any ProjectionLab export. The app detects which one it is.</p>${kinds}<button class="btn primary" data-act="loadPL">Load ProjectionLab file (.json or .csv)</button></div>`;
    const pl = P.pl; const s0 = pl.start;
    const ourNW = an.s.total, ourLiquid = an.s.liquid;
    const gapLiquid = s0['Liquid Net Worth'] - ourLiquid, gapIll = (s0['Net Worth'] - s0['Liquid Net Worth']) - (an.s.property - an.s.liabilities);
    const det = R.det.rows;
    const byYear = Object.fromEntries(det.map((r) => [r.year, r]));
    const common = pl.years.filter((p) => byYear[p.Year]);
    // our computed figures, today's $
    const ours = (p) => { const r = byYear[p.Year]; const f = 1 / r.cpi, b = 1 / r.cpiEnd;
      return { liquid: r.liquid * b, nw: r.nw * b, exp: (r.spend + r.health + r.housingOut) * f, tax: r.tax * f, wd: (r.fromTax + r.fromPre + r.rmd + r.fromRoth + (r.eduPaid || 0)) * f, inc: (r.ss + r.ordInc + r.divs + r.wages + Math.max(0, r.rentNet)) * f }; };
    const tot = (fPL, fUs) => ({ pl: common.reduce((a, p) => a + (fPL(p) || 0), 0), us: common.reduce((a, p) => a + fUs(ours(p)), 0) });
    const T = { exp: tot((p) => p.Expenses, (o) => o.exp), tax: tot((p) => p.Taxes, (o) => o.tax), wd: tot((p) => p.Withdrawals, (o) => o.wd), inc: tot((p) => p.Income, (o) => o.inc) };
    const lastC = common[common.length - 1];
    const endRow = lastC ? { pl: lastC['Liquid Net Worth'], us: ours(lastC).liquid, plNW: lastC['Net Worth'], usNW: ours(lastC).nw } : null;
    const dcell = (a, b) => { const d = b - a; const pc = a ? d / Math.abs(a) * 100 : 0; return `<td class="n ${Math.abs(pc) > 15 ? 'warnc' : ''}">${d >= 0 ? '+' : '−'}${k(Math.abs(d))} (${pc >= 0 ? '+' : ''}${pc.toFixed(0)}%)</td>`; };
    const sumRow = (label, o) => `<tr><td>${label}</td><td class="n">${k(o.pl)}</td><td class="n">${k(o.us)}</td>${dcell(o.pl, o.us)}</tr>`;
    // likely drivers of differences, from our own inputs
    const drivers = [];
    if (Math.abs(gapLiquid) > 5e4) drivers.push(`Starting liquid assets differ by ${k(gapLiquid)}. ProjectionLab includes accounts these statements don't (add them under Net Worth if they're real).`);
    if (Math.abs(gapIll) > 5e4) drivers.push(`Starting property minus debt differs by ${k(gapIll)}. Enter homes, rentals and mortgages under Net Worth → Real estate & mortgages.`);
    if (Math.abs(T.inc.us - T.inc.pl) > 0.15 * T.inc.pl) drivers.push(`Lifetime income differs by ${k(T.inc.us - T.inc.pl)}. ProjectionLab's income is probably Social Security, work, pension or rental streams you haven't entered under Assumptions.`);
    if (Math.abs(T.exp.us - T.exp.pl) > 0.1 * T.exp.pl) drivers.push(`Lifetime spending differs by ${k(T.exp.us - T.exp.pl)}. Check base spending, extra expenses (college, travel), housing costs and healthcare under Assumptions.`);
    if (Math.abs(T.tax.us - T.tax.pl) > 0.2 * T.tax.pl) drivers.push(`Lifetime taxes differ by ${k(T.tax.us - T.tax.pl)}. This app sells highest-basis lots first, adds ${STN()} tax, NIIT, ACA effects and RMDs. Different income or withdrawals also change taxes.`);
    if (!+P.ss.selfPIA && !+P.ss.spousePIA) drivers.push('Social Security is $0 in this plan. Enter your ssa.gov estimates.');
    const ch = lineChart([
      { name: 'PL net worth', color: '#e2733a', pts: pl.years.map((r) => [r.Year, r['Net Worth']]) },
      { name: 'PL liquid', color: '#e2733a', dash: true, pts: pl.years.map((r) => [r.Year, r['Liquid Net Worth']]) },
      { name: 'This app net worth', color: '#16202e', pts: det.map((r) => [r.year, r.nw / r.cpiEnd]) },
      { name: 'This app liquid', color: '#3b6fd8', dash: true, pts: det.map((r) => [r.year, r.liquid / r.cpiEnd]) }]);
    const tbl = pl.years.map((p) => { const r = byYear[p.Year]; const o = r ? ours(p) : null;
      return `<tr><td>${p.Year}</td><td class="n">${k(p['Liquid Net Worth'])}</td><td class="n">${o ? k(o.liquid) : '—'}</td><td class="n">${k(p.Expenses)}</td><td class="n">${o ? k(o.exp) : '—'}</td><td class="n">${k(p.Taxes)}</td><td class="n">${o ? k(o.tax) : '—'}</td><td class="n">${k(p.Withdrawals)}</td><td class="n">${o ? k(o.wd) : '—'}</td><td class="n">${k(p.Income)}</td><td class="n">${o ? k(o.inc) : '—'}</td></tr>`; }).join('');
    return `<div class="card"><h3>Benchmark against ProjectionLab <span class="sub">${esc(pl.file || 'ProjectionLab CSV')}</span></h3>${intro}
      <h4>Starting point</h4><table class="tbl narrow2"><thead><tr><th></th><th class="n">ProjectionLab</th><th class="n">This app</th><th class="n">Gap</th></tr></thead><tbody>
      <tr><td>Net worth</td><td class="n">${usd(s0['Net Worth'])}</td><td class="n">${usd(ourNW)}</td><td class="n">${usd(s0['Net Worth'] - ourNW)}</td></tr>
      <tr><td>Liquid net worth</td><td class="n">${usd(s0['Liquid Net Worth'])}</td><td class="n">${usd(ourLiquid)}</td><td class="n">${usd(gapLiquid)}</td></tr>
      <tr><td>Property − debt</td><td class="n">${usd(s0['Net Worth'] - s0['Liquid Net Worth'])}</td><td class="n">${usd(an.s.property - an.s.liabilities)}</td><td class="n">${usd(gapIll)}</td></tr></tbody></table>
      <h4>Lifetime totals, ${common[0]?.Year}–${lastC?.Year} <span class="sub">today's $; this app uses fixed returns</span></h4>
      <table class="tbl narrow2"><thead><tr><th></th><th class="n">ProjectionLab</th><th class="n">This app</th><th class="n">Difference</th></tr></thead><tbody>
      ${sumRow('Spending (incl. housing, healthcare)', T.exp)}${sumRow('Taxes', T.tax)}${sumRow('Portfolio withdrawals', T.wd)}${sumRow('Income (SS, work, rent, dividends, other)', T.inc)}
      ${endRow ? `<tr><td>Liquid net worth in ${lastC.Year}</td><td class="n">${k(endRow.pl)}</td><td class="n">${k(endRow.us)}</td>${dcell(endRow.pl, endRow.us)}</tr><tr><td>Net worth in ${lastC.Year}</td><td class="n">${k(endRow.plNW)}</td><td class="n">${k(endRow.usNW)}</td>${dcell(endRow.plNW, endRow.usNW)}</tr>` : ''}</tbody></table>
      ${drivers.length ? `<h4>Likely reasons for the gap</h4><ul class="steps">${drivers.map((d) => `<li>${d}</li>`).join('')}</ul>` : '<p class="pos">The two models are within normal tolerance.</p>'}
      <p><button class="btn" data-act="loadPL">Load a newer ProjectionLab file (.json or .csv)</button> <button class="btn danger" data-act="clearPL">Remove CSV benchmark</button></p>
      <p class="note">ProjectionLab values are read as today's dollars. Its definitions of income and withdrawals may not match exactly. For example, its "Income" may count dividends differently, so focus on the trends and the big gaps.</p></div>
      <div class="card"><h3>Projection overlay <span class="sub">today's $</span></h3>${ch}</div>
      <div class="card"><h3>Year by year: ProjectionLab vs this app</h3><div class="scroll"><table class="tbl"><thead><tr><th>Year</th><th class="n">PL liquid</th><th class="n">Ours</th><th class="n">PL spending</th><th class="n">Ours</th><th class="n">PL taxes</th><th class="n">Ours</th><th class="n">PL withdrawals</th><th class="n">Ours</th><th class="n">PL income</th><th class="n">Ours</th></tr></thead><tbody>${tbl}</tbody></table></div></div>`;
  }



  // ---------- ProjectionLab Income report vs this plan's income by source ----------
  function plIncomeCard(P, S, R) {
    const I = P.plInc; const G = L.PL_INC_GROUPS; const det = R.det.rows; const byYear = Object.fromEntries(det.map((r) => [r.year, r]));
    // refine "work" using the JSON's income event names when available
    const J = state.plImport; const JP = J ? J.plans[Math.min(J.plans.length - 1, state.plPlanIdx || 0)] : null;
    const workNames = JP ? JP.income.filter((e) => /salary|rsu|bonus|self-employment|wage/.test(e.type)).map((e) => e.name) : [];
    const cols = I.cols.map((c) => ({ ...c, group: L.plIncGroup(c.name, workNames) }));
    const plG = (y) => { const o = Object.fromEntries(G.map(([g]) => [g, 0])); for (const c of cols) o[c.group] += +y[c.name] || 0; return o; };
    const usG = (r) => { const f = 1 / r.cpi; const rent = Object.values(r.rentals || {}).reduce((a, x) => a + (+x.gross || 0), 0);
      return { work: r.wages * f, ss: r.ss * f, rent: rent * f, divs: r.divs * f, rmd: r.rmd * f, conv: r.conv * f, gains: (r.capGain || 0) * f, tfw: (r.fromRoth + (r.eduPaid || 0)) * f, other: ((r.ordInc || 0) + (r.evIn || 0)) * f }; };
    const common = I.years.filter((y) => byYear[y.Year]);
    const T = Object.fromEntries(G.map(([g]) => [g, { pl: 0, us: 0 }]));
    const series = common.map((y) => { const a = plG(y), b = usG(byYear[y.Year]); for (const [g] of G) { T[g].pl += a[g]; T[g].us += b[g]; } return { year: y.Year, pl: a, us: b }; });
    const first = (arr, g, who) => { const x = arr.find((s) => s[who][g] > 1); return x ? x.year : null; };
    const span = (g, who) => { const ys = series.filter((s) => s[who][g] > 1).map((s) => s.year); return ys.length ? (ys[0] === ys[ys.length - 1] ? `${ys[0]}` : `${ys[0]}–${ys[ys.length - 1]}`) : '—'; };
    const dcell = (a, b) => { const d = b - a; const pc = a ? d / Math.abs(a) * 100 : (b ? 100 : 0); return `<td class="n ${Math.abs(d) > 5e4 && Math.abs(pc) > 15 ? 'warnc' : ''}">${Math.abs(d) < 500 ? '—' : `${d >= 0 ? '+' : '−'}${k(Math.abs(d))}`}</td>`; };
    const sumRows = G.filter(([g]) => T[g].pl > 1 || T[g].us > 1).map(([g, label]) => `<tr><td>${label}</td><td class="n">${k(T[g].pl)}</td><td class="mut" style="font-size:11.5px">${span(g, 'pl')}</td><td class="n">${k(T[g].us)}</td><td class="mut" style="font-size:11.5px">${span(g, 'us')}</td>${dcell(T[g].pl, T[g].us)}</tr>`).join('');
    const totPL = G.reduce((a, [g]) => a + T[g].pl, 0), totUS = G.reduce((a, [g]) => a + T[g].us, 0);
    // explanations
    const h = S.household; const notes = [];
    const big = (g) => Math.abs(T[g].us - T[g].pl) > 5e4 && Math.abs(T[g].us - T[g].pl) > 0.15 * Math.max(T[g].pl, T[g].us);
    if (big('conv')) notes.push(T.conv.pl > T.conv.us ? `ProjectionLab does ${k(T.conv.pl)} of Roth conversions (${span('conv', 'pl')}: ${cols.filter((c) => c.group === 'conv').map((c) => esc(c.name.replace(/^Roth Conversion:\s*/, ''))).join(', ')}). This plan's conversion setting is "${esc(P.tax.convert)}". See Tax strategies to compare conversion approaches.` : `This plan converts ${k(T.conv.us)} to Roth; ProjectionLab converts ${k(T.conv.pl)}.`);
    if (big('gains')) notes.push(`Realized capital gains: ProjectionLab ${k(T.gains.pl)} vs this plan ${k(T.gains.us)}. ProjectionLab's gains come from ${cols.filter((c) => c.group === 'gains' && I.years.some((y) => y[c.name] > 0)).map((c) => esc(c.name)).join(', ')}. This app sells the highest-basis lots first and harvests gains only when the setting is on, so it usually realizes less.`);
    if (big('rmd')) notes.push(`RMDs: ProjectionLab ${k(T.rmd.pl)} vs ${k(T.rmd.us)}. RMDs follow pre-tax balances, so they mostly reflect different starting 401(k)/IRA totals (see the account table above) and different growth.`);
    if (big('tfw')) notes.push(`ProjectionLab withdraws ${k(T.tfw.pl)} from Roth and 529 accounts (${cols.filter((c) => c.group === 'tfw' && I.years.some((y) => y[c.name] > 0)).map((c) => esc(c.name)).join(', ')}). ${/529/.test(cols.filter((c) => c.group === 'tfw').map((c) => c.name).join()) ? 'The 529 isn\'t in this app, so college is paid from the regular portfolio here. ' : ''}This app spends Roth money last.`);
    if (big('divs')) notes.push(`Interest & dividends: ProjectionLab ${k(T.divs.pl)} vs ${k(T.divs.us)}. ProjectionLab applies a flat ${JP?.vars?.dividendRate ?? '?'}% dividend yield to every taxable account; this app uses each holding's own yield, and bank cash earns its set rate.`);
    if (big('work')) notes.push(`Work income: ProjectionLab ${k(T.work.pl)} (${span('work', 'pl')}) vs ${k(T.work.us)}. Add salary/RSU under Assumptions → Work if you're still working.`);
    if (big('ss')) notes.push(`Social Security: ProjectionLab ${k(T.ss.pl)} (from ${first(series, 'ss', 'pl') || '—'}) vs ${k(T.ss.us)} (from ${first(series, 'ss', 'us') || '—'}). Check the benefit amounts and claiming ages under Assumptions.`);
    if (big('rent')) notes.push(`Rental income: ProjectionLab ${k(T.rent.pl)} vs ${k(T.rent.us)} (gross rent). Check rents and which properties are rentals on the Rentals tab.`);
    // year detail
    const ys = series.map((s) => s.year); const yy = ys.includes(state.plIncYear) ? state.plIncYear : ys[0]; const sel = series.find((s) => s.year === yy);
    const iy = I.years.find((y) => y.Year === yy);
    const detail = sel ? cols.filter((c) => iy[c.name]).map((c) => `<tr><td>${esc(c.name)}</td><td class="mut">${G.find(([g]) => g === c.group)[1]}</td><td class="n">${k(iy[c.name])}</td></tr>`).join('') : '';
    const yearGroups = sel ? G.filter(([g]) => sel.pl[g] > 1 || sel.us[g] > 1).map(([g, label]) => `<tr><td>${label}</td><td class="n">${k(sel.pl[g])}</td><td class="n">${k(sel.us[g])}</td>${dcell(sel.pl[g], sel.us[g])}</tr>`).join('') : '';
    const yrSel = `<select id="plIncYSel">${ys.map((y) => `<option ${y === yy ? 'selected' : ''}>${y}</option>`).join('')}</select>`;
    const COL = { work: '#3b6fd8', ss: '#22785a', rent: '#8a5cc4', divs: '#6aa7d8', rmd: '#e2733a', conv: '#c4475b', gains: '#d9a520', tfw: '#5aa58a', other: '#9aa3ad' };
    const chart = (who) => { const rows = series.map((s) => ({ age: s.year, year: s.year, ...s[who] })); const keys = G.filter(([g]) => T[g][who] > 1).map(([g, label]) => ({ key: g, name: label, color: COL[g] })); return rows.length ? stackBars(rows, keys, { h: 220 }) : ''; };
    return `<div class="card"><h3>Income by source: ProjectionLab vs this plan <span class="sub">${esc(I.file)} · ${common[0]?.Year}–${common[common.length - 1]?.Year} · today's $</span></h3>
      ${notes.length ? `<h4>Biggest differences</h4><ul class="steps">${notes.map((n) => `<li>${n}</li>`).join('')}</ul>` : '<p class="pos">Income sources line up within tolerance.</p>'}
      <table class="tbl narrow2"><thead><tr><th>Source</th><th class="n">ProjectionLab</th><th>Years</th><th class="n">This plan</th><th>Years</th><th class="n">Difference</th></tr></thead><tbody>${sumRows}
      <tr><td><b>Total</b></td><td class="n"><b>${k(totPL)}</b></td><td></td><td class="n"><b>${k(totUS)}</b></td><td></td>${dcell(totPL, totUS)}</tr></tbody></table>
      <p class="note">ProjectionLab counts Roth/529 withdrawals and realized gains as "income"; this app shows them here the same way only for comparison. Rent is gross rent before expenses. ProjectionLab's figures are read as today's dollars.</p>
      <p><button class="btn" data-act="loadPL">Load a newer Income CSV</button> <button class="btn danger" data-act="clearPLI">Remove income report</button></p></div>
      <div class="two"><div class="card"><h3>ProjectionLab income by source</h3>${chart('pl')}</div><div class="card"><h3>This plan's income by source</h3>${chart('us')}</div></div>
      <div class="card"><h3>One year in detail <span class="sub">${yrSel}</span></h3><div class="two"><div><table class="tbl"><thead><tr><th></th><th class="n">ProjectionLab</th><th class="n">This plan</th><th class="n">Diff</th></tr></thead><tbody>${yearGroups}</tbody></table></div>
      <div><table class="tbl"><thead><tr><th>ProjectionLab line item</th><th>Group</th><th class="n">${yy}</th></tr></thead><tbody>${detail || '<tr><td colspan="3" class="mut">No income this year.</td></tr>'}</tbody></table></div></div></div>`;
  }
  // ---------- ProjectionLab account export (inputs) vs this app ----------
  function plInputsCard(P, S, an) {
    const J = state.plImport; const h = S.household; const yr = +String(cur().asOf || new Date().toISOString()).slice(0, 4);
    const pi = Math.min(J.plans.length - 1, Math.max(0, state.plPlanIdx || 0)); const JP = J.plans[pi];
    const STOP = new Set(['joint', 'account', 'accounts', 'the', 'plan', 'investments', 'investment', 'individual', 'brokerage', 'manual', 'and', h.selfName?.toLowerCase(), h.spouseName?.toLowerCase()]);
    const toks = (str) => new Set(String(str || '').toLowerCase().replace(/goog(l)?\b/g, 'google').split(/[^a-z0-9]+/).filter((w) => w.length > 1 && !STOP.has(w)));
    const BK = { cash: 'Cash & savings', taxable: 'Taxable', pretax: 'Pre-tax', roth: 'Roth', hsa: 'HSA', '529': '529', crypto: 'Crypto' };
    const appBucket = (a) => (a.taxType === 'pretax' ? 'pretax' : a.taxType === 'roth' ? 'roth' : a.taxType === 'hsa' ? 'hsa' : a.taxType === 'edu' || /529/.test(a.name) ? '529' : acctCategory(a) === 'bank' ? 'cash' : 'taxable');
    const apps = an.s.accts.filter((a) => !/^(re|mtg):/.test(a.key) && a.taxType !== 'liability' && a.taxType !== 'property' && Math.abs(a._value) > 0)
      .map((a) => ({ a, b: appBucket(a), o: a.owner || 'joint', v: a._value, t: toks(a.institution + ' ' + a.name + ' ' + (a.holdings.some((x) => /^GOOG/.test(x.symbol || '')) ? 'google' : '')), used: false }));
    // greedy match: same bucket (cash≈taxable allowed), owner compatible, then shared words, then closest balance
    const pairs = [];
    for (const x of J.accounts) {
      const xt = toks(x.name);
      for (const c of apps) {
        const bOk = c.b === x.bucket || (c.b === 'cash' && x.bucket === 'taxable') || (c.b === 'taxable' && x.bucket === 'cash'); if (!bOk) continue;
        const oOk = c.o === x.owner || c.o === 'joint' || x.owner === 'joint' || x.owner === 'dependent'; if (!oOk) continue;
        const words = [...xt].filter((w) => c.t.has(w)).length; const close = 1 - Math.min(1, Math.abs(c.v - x.balance) / Math.max(1, x.balance));
        const score = words * 2 + (c.b === x.bucket ? 0.5 : 0) + (c.o === x.owner ? 0.5 : 0) + close;
        if (words || close > 0.7) pairs.push({ x, c, score, words });
      }
    }
    pairs.sort((p, q) => q.score - p.score); const match = new Map();
    for (const p of pairs) if (!match.has(p.x) && !p.c.used) { match.set(p.x, p); p.c.used = true; }
    const pct = (a, b) => (a ? (b - a) / Math.abs(a) * 100 : 0);
    const gapCell = (a, b) => { const d = b - a, pc = pct(a, b); return `<td class="n ${Math.abs(pc) > 10 ? 'warnc' : ''}">${Math.abs(d) < 1 ? '—' : (d >= 0 ? '+' : '−') + k(Math.abs(d))}</td>`; };
    const rowsA = J.accounts.map((x) => { const m = match.get(x);
      return `<tr><td>${esc(x.name)}</td><td>${esc(x.owner === 'dependent' ? 'Dependent' : ownerName(x.owner))}</td><td><span class="pill ${x.bucket === 'pretax' ? 'pretax' : x.bucket === 'roth' ? 'roth' : 'taxable'}">${BK[x.bucket] || x.bucket}</span></td><td class="n">${usd(x.balance)}</td>
        <td>${m ? esc(m.c.a.name) + (m.words ? '' : ' <span class="pill amber">by balance</span>') + (m.c.o !== x.owner && x.owner !== 'dependent' ? ` <span class="pill amber">owner: ${esc(ownerName(m.c.o))}</span>` : '') : '<span class="pill red">not in this app</span>'}</td><td class="n">${m ? usd(m.c.v) : '—'}</td>${m ? gapCell(x.balance, m.c.v) : `<td class="n warnc">−${k(x.balance)}</td>`}</tr>`; }).join('');
    const extra = apps.filter((c) => !c.used);
    const rowsX = extra.map((c) => `<tr><td class="mut">—</td><td>${esc(ownerName(c.o))}</td><td><span class="pill">${BK[c.b] || c.b}</span></td><td class="n">—</td><td>${esc(c.a.name)} <span class="pill amber">not in ProjectionLab</span></td><td class="n">${usd(c.v)}</td><td class="n warnc">+${k(c.v)}</td></tr>`).join('');
    // bucket × owner totals
    const owners = ['self', 'spouse', 'joint', 'dependent']; const buckets = Object.keys(BK);
    const tPL = {}, tUs = {}; const add = (T, b, o, v) => { T[b] = T[b] || {}; T[b][o] = (T[b][o] || 0) + v; };
    J.accounts.forEach((x) => add(tPL, x.bucket, x.owner, x.balance)); apps.forEach((c) => add(tUs, c.b, c.o, c.v));
    const bRows = buckets.filter((b) => tPL[b] || tUs[b]).map((b) => { const pl = sum(Object.values(tPL[b] || {}), (v) => v), us = sum(Object.values(tUs[b] || {}), (v) => v);
      const by = owners.filter((o) => (tPL[b] || {})[o] || (tUs[b] || {})[o]).map((o) => `${o === 'dependent' ? 'Dep.' : esc(ownerName(o))} ${k((tPL[b] || {})[o] || 0)} / ${k((tUs[b] || {})[o] || 0)}`).join(' · ');
      return `<tr><td>${BK[b]}</td><td class="n">${usd(pl)}</td><td class="n">${usd(us)}</td>${gapCell(pl, us)}<td class="mut" style="font-size:11.5px">${by}</td></tr>`; }).join('');
    const plLiquid = sum(J.accounts, (x) => x.balance), usLiquid = sum(apps, (c) => c.v);
    // real estate
    const props = cur().realEstate || []; const usedP = new Set();
    const reRows = (JP.assets.length ? JP.assets : J.assets).map((x) => {
      const xt = toks(x.name); let best = null, bs = 0;
      for (const p of props) { if (usedP.has(p)) continue; const w = [...xt].filter((t) => toks(p.name).has(t)).length; const close = 1 - Math.min(1, Math.abs((+p.value || 0) - x.value) / Math.max(1, x.value)); const sc = w * 2 + close; if ((w || close > 0.85) && sc > bs) { bs = sc; best = p; } }
      if (best) usedP.add(best);
      const p = best || {}; const pay = best ? (+p.mtgPayment || 0) : null;
      const c = (a, b, fmt = k) => `<td class="n">${a == null ? '—' : fmt(a)}</td><td class="n ${best && b != null && a != null && Math.abs(pct(a, b)) > 10 ? 'warnc' : ''}">${!best || b == null ? '—' : fmt(b)}</td>`;
      return `<tr><td>${esc(x.name)}${best ? `<div class="mut" style="font-size:11px">↔ ${esc(p.name)}</div>` : '<div><span class="pill red">not in this app</span></div>'}</td>${c(x.value, +p.value)}${c(x.loan, +p.mtgBalance || 0)}${c(x.rate || null, best ? +p.mtgRate || null : null, (v) => v + '%')}${c(x.payment || null, pay || null, (v) => usd(v))}
        ${c(x.propertyTax, best ? +p.propertyTax || 0 : null)}${c(x.insurance, best ? +p.insurance || 0 : null)}${c(x.maintenance, best ? +p.maintAmt || 0 : null)}${c(x.income || (x.incomeRaw ? null : 0), best ? (+p.rentMonthly || 0) * 12 || (+p.nightlyRate || 0) * 365 * (+p.occupancyPct || 0) / 100 || 0 : null)}</tr>`; }).join('');
    const reMissing = props.filter((p) => !usedP.has(p));
    // assumptions
    const ms = (id) => JP.milestones.find((m) => m.id === id); const yOf = (m) => (m && m.date ? +m.date.slice(0, 4) + ((+m.date.slice(5, 7) || 1) - 1) / 12 : null);
    const bS = J.people.self.birthYear, bP = J.people.spouse?.birthYear; const mS = (J.people.self.birthMonth || 1) - 1, mP = (J.people.spouse?.birthMonth || 1) - 1;
    const ageAt = (y, b, m) => (y == null || !b ? null : Math.round((y - b - m / 12) * 10) / 10);
    const rS = ageAt(yOf(ms('retirement')), bS, mS), rP = ageAt(yOf(ms('spouseRetirement')), bP, mP);
    const lS = yOf(ms('lifeExpectancy')), lP = yOf(ms('spouseLifeExpectancy'));
    const ssOf = (o) => JP.income.find((e) => e.type === 'social-security' && e.owner === o);
    const ssS = ssOf('self'), ssP = ssOf('spouse');
    const ssAge = (e, b, m) => (e && e.start && e.start.type === 'date' ? ageAt(+e.start.value.slice(0, 4) + (+e.start.value.slice(5, 7) - 1) / 12, b, m) : null);
    const fra = +P.ss.fra || 67;
    const usSS = (who) => { const pia = +(who === 'self' ? P.ss.selfPIA : P.ss.spousePIA) || 0, age = +(who === 'self' ? P.ss.selfClaim : P.ss.spouseClaim) || 67; return pia ? `${k(L.ssAdj(pia, age, fra))}/yr at ${age}` : '$0'; };
    const work = JP.income.filter((e) => /salary|rsu|bonus|self-employment|wage/.test(e.type));
    const usWork = sum(P.work || [], (w) => +w.salary || 0);
    const isNow = (e) => (e.startYear == null || e.startYear <= yr + 1) && (e.endYear == null || e.endYear > yr);
    const spendNow = JP.expenses.filter((e) => !/health|medicare/.test(e.type) && isNow(e) && e.perYear);
    const later = JP.expenses.filter((e) => !/health|medicare/.test(e.type) && !isNow(e) && e.perYear);
    const health = JP.expenses.filter((e) => /health|medicare/.test(e.type) && e.perYear);
    const V = JP.vars; const plReal = V.investmentReturn != null ? ((1 + V.investmentReturn / 100) / (1 + (V.inflation ?? 0) / 100) - 1) * 100 : null;
    const fixedTax = V.incomeTaxMode === 'fixed' || V.estimateTaxes === false;
    const aRow = (label, pl, us, warn) => `<tr><td>${label}</td><td>${pl}</td><td>${us}</td><td>${warn ? `<span class="pill amber">${warn}</span>` : '<span class="pill ok">ok</span>'}</td></tr>`;
    const near = (a, b, tol) => a == null || b == null || Math.abs(a - b) <= tol;
    const wS = P.people.retireAgeSelf, wP = P.people.retireAgeSpouse;
    const aRows = [
      aRow('Birth years', `${esc(J.people.self.name)} ${bS ?? '—'}${bP ? ` · ${esc(J.people.spouse.name)} ${bP}` : ''}`, `${esc(h.selfName)} ${h.birthYearSelf} · ${esc(h.spouseName)} ${h.birthYearSpouse}`, (bS && bS !== +h.birthYearSelf) || (bP && bP !== +h.birthYearSpouse) ? 'different, fix in Settings' : ''),
      aRow('Retirement age', `${rS ?? '—'} · ${rP ?? '—'}${ms('retirement')?.date ? `<div class="mut" style="font-size:11px">${esc(ms('retirement').date)} · ${esc(ms('spouseRetirement')?.date || '')}</div>` : ''}`, `${wS ?? 'retired'} · ${wP ?? 'retired'}`, near(rS, wS ?? (yr - h.birthYearSelf), 1) && near(rP, wP ?? (yr - h.birthYearSpouse), 1) ? '' : 'different'),
      aRow('Life expectancy (plan end)', `${lS ? Math.round(lS - bS) : '—'} · ${lP ? Math.round(lP - bP) : '—'}`, `${P.people.lifeSelf} · ${P.people.lifeSpouse}`, near(lS && lS - bS, +P.people.lifeSelf, 1) && near(lP && lP - bP, +P.people.lifeSpouse, 1) ? '' : 'different'),
      aRow(`Social Security, ${esc(h.selfName)}`, ssS ? `${k(ssS.perYear)}/yr at ${ssAge(ssS, bS, mS) ?? '?'}` : '—', usSS('self'), !+P.ss.selfPIA && ssS ? 'missing here' : ''),
      aRow(`Social Security, ${esc(h.spouseName)}`, ssP ? `${k(ssP.perYear)}/yr at ${ssAge(ssP, bP, mP) ?? '?'}` : '—', usSS('spouse'), !+P.ss.spousePIA && ssP ? 'missing here' : ''),
      aRow('Work income until retirement', work.length ? work.map((e) => `${esc(e.name)} ${k(e.perYear)}/yr`).join('<br>') : '—', P.work?.length ? (P.work || []).map((w) => `${esc(w.name)} ${k(+w.salary || 0)}/yr`).join('<br>') : 'none', work.length && !usWork && (rS == null || rS > yr - bS) ? 'missing here' : ''),
      aRow('Spending now (excl. healthcare)', spendNow.map((e) => `${esc(e.name)} ${k(e.perYear)}`).join('<br>') + `<div><b>${k(sum(spendNow, (e) => e.perYear))}/yr</b></div>`, `<b>${k(catTotal(P))}/yr</b> in ${P.spending.categories.length} categories`, Math.abs(pct(sum(spendNow, (e) => e.perYear), catTotal(P))) > 10 ? 'different' : ''),
      aRow('Later / one-time expenses', later.length ? later.map((e) => `${esc(e.name)} ${k(e.perYear)}/yr ${e.startYear || ''}–${e.endYear || ''}`).join('<br>') : '—', P.expenses.length ? P.expenses.map((e) => `${esc(e.name)} ${k(+e.amount || 0)}/yr ${e.startAge || ''}–${e.endAge || ''}`).join('<br>') : 'none', later.length && !P.expenses.length ? 'missing here' : ''),
      aRow('Healthcare', health.map((e) => `${esc(e.name)} ${k(e.perYear)}/yr${e.endYear ? ` to ${e.endYear}` : ''}${e.growth?.type === 'inflation+' ? ` (inflation + ${e.growth.amount}%)` : ''}`).join('<br>') || '—', P.healthcare.model ? `Modeled: ACA premiums from MAGI (benchmark ${k(P.healthcare.acaBenchmark)}), then Medicare + IRMAA` : 'not modeled', P.healthcare.model && health.length ? 'different method' : ''),
      aRow('Returns', V.investmentReturn != null ? `${V.investmentReturn}% nominal, ${V.inflation}% inflation ≈ <b>${plReal.toFixed(1)}% real</b>` : '—', `Stocks ${P.returns.stock}% real, bonds ${P.returns.bond}% real, ${P.inflation}% inflation`, plReal != null && Math.abs(plReal - P.returns.stock) > 1 ? 'different' : ''),
      aRow('Income tax', fixedTax ? `Flat ${V.effectiveIncomeTaxRate}% on income, ${V.capGainsTaxRate}% on gains${V.localIncomeTaxRate ? `, ${V.localIncomeTaxRate}% local` : ''}` : 'Bracket estimate', `Federal + ${STN()} brackets, NIIT, AMT${isCA() ? ', CA mental-health tax' : ''}`, fixedTax ? 'PL uses flat rates' : ''),
      aRow('Withdrawal strategy', JP.withdrawal ? (JP.withdrawal.enabled ? esc(JP.withdrawal.type || 'on') : 'off (spend what the plan needs)') : '—', 'Spend what the plan needs, with guardrails if on', ''),
    ].join('');
    const notes = [];
    if (Math.abs(plLiquid - usLiquid) > 5e4) notes.push(`This app has ${k(Math.abs(usLiquid - plLiquid))} ${usLiquid < plLiquid ? 'less' : 'more'} in liquid accounts than ProjectionLab (${k(usLiquid)} vs ${k(plLiquid)}). The account table below shows which ones don't match.`);
    J.accounts.filter((x) => !match.get(x)).forEach((x) => notes.push(`"${esc(x.name)}" (${k(x.balance)}, ${x.owner === 'dependent' ? 'dependent' : esc(ownerName(x.owner))}) is in ProjectionLab only. Add it under Net Worth if it's real, or import its statement.`));
    if (fixedTax) notes.push(`ProjectionLab is set to <b>flat tax rates</b> (${V.effectiveIncomeTaxRate}% income, ${V.capGainsTaxRate}% gains) rather than estimating brackets. Expect lifetime taxes to differ a lot. That's a setting difference, not a math error. Turn on "estimate taxes" in ProjectionLab for a fairer comparison.`);
    if (plReal != null && Math.abs(plReal - P.returns.stock) > 1) notes.push(`ProjectionLab's ${V.investmentReturn}% growth is nominal (about ${plReal.toFixed(1)}% after ${V.inflation}% inflation). This plan uses ${P.returns.stock}% real for stocks. Return assumptions usually drive the biggest gap in ending net worth.`);
    if (J.plans.length > 1) notes.push(`The export has ${J.plans.length} plans. Pick the one to compare above. Account balances are the same across them, but dates and expenses may differ.`);
    const tabs = J.plans.length > 1 ? `<div class="seg" style="margin:6px 0 10px">${J.plans.map((p, i) => `<button class="btn sm ${i === pi ? 'primary' : ''}" data-act="plPlan" data-i="${i}">${esc(p.name)}${p.active ? ' ★' : ''}</button>`).join(' ')}</div>` : '';
    const prog = J.progress.length ? `<p class="note">ProjectionLab progress log: ${J.progress.map((r) => `${r.date} net worth ${k(r.netWorth)}`).join(' · ')}. This app tracks its own history under History. These are shown for reference only.</p>` : '';
    return `<div class="card"><h3>ProjectionLab inputs vs this app <span class="sub">${esc(J.file)} · PL ${esc(J.version || '')} · exported ${esc(J.exportedAt || '')}</span></h3>
      <p>This is ProjectionLab's <b>account data export</b>. It has your inputs (accounts, homes, dates, Social Security, expenses, assumptions) but <b>no year-by-year results</b>. Use it to confirm both tools start from the same place. For the year-by-year overlay, also load the plan's <b>Report summary CSV</b> below.${J.droppedSecret ? " The export's settings section, which includes an API key, was <b>not stored</b>." : ''}</p>
      ${tabs}
      ${notes.length ? `<h4>What doesn't line up</h4><ul class="steps">${notes.map((n) => `<li>${n}</li>`).join('')}</ul>` : '<p class="pos">Starting balances and assumptions line up.</p>'}
      <h4>Assumptions: ${esc(JP.name)} vs ${esc(P.name)}</h4>
      <table class="tbl"><thead><tr><th></th><th>ProjectionLab</th><th>This app (${esc(P.name)})</th><th></th></tr></thead><tbody>${aRows}</tbody></table>
      <p class="note">Nothing here changes your plan. Edit Assumptions or Net Worth yourself if ProjectionLab has the right number.</p>
      <p><button class="btn" data-act="loadPL">Load a newer ProjectionLab file</button> <button class="btn danger" data-act="clearPLJ">Remove account data</button></p></div>
      <div class="card"><h3>Starting balances by account type <span class="sub">ProjectionLab / this app by owner</span></h3>
      <table class="tbl narrow2"><thead><tr><th></th><th class="n">ProjectionLab</th><th class="n">This app</th><th class="n">Gap</th><th>By owner (PL / app)</th></tr></thead><tbody>${bRows}
      <tr><td><b>Total liquid</b></td><td class="n"><b>${usd(plLiquid)}</b></td><td class="n"><b>${usd(usLiquid)}</b></td>${gapCell(plLiquid, usLiquid)}<td></td></tr></tbody></table></div>
      <div class="card"><h3>Accounts, matched by name, type and owner</h3><div class="scroll"><table class="tbl"><thead><tr><th>ProjectionLab account</th><th>Owner</th><th>Type</th><th class="n">PL balance</th><th>This app</th><th class="n">App balance</th><th class="n">Gap</th></tr></thead><tbody>${rowsA}${rowsX}</tbody></table></div>
      <p class="note">ProjectionLab balances are whatever was last typed there, so small gaps are normal. "By balance" means no shared name was found and the closest balance of the same type and owner was used. Check it.</p></div>
      <div class="card"><h3>Real estate & mortgages <span class="sub">each pair: ProjectionLab / this app · costs per year</span></h3><div class="scroll"><table class="tbl"><thead><tr><th>Property</th><th class="n" colspan="2">Value</th><th class="n" colspan="2">Mortgage</th><th class="n" colspan="2">Rate</th><th class="n" colspan="2">Payment/mo</th><th class="n" colspan="2">Property tax</th><th class="n" colspan="2">Insurance</th><th class="n" colspan="2">Maintenance</th><th class="n" colspan="2">Rent/yr</th></tr></thead><tbody>${reRows}</tbody></table></div>
      ${reMissing.length ? `<p class="note">In this app only: ${reMissing.map((p) => esc(p.name)).join(', ')}.</p>` : ''}
      <p class="note">ProjectionLab's "% rented" and rent fields are approximate. This app models each rental's Schedule E (vacancy, management, depreciation, passive-loss rules) on the Rentals tab.</p>${prog}</div>`;
  }
  // ---------- TAX RETURNS: import, reconcile, carryforwards, lookback, estimated taxes ----------
  const RET_FIELDS = [
    ['Federal income (Form 1040)', [['wages', 'Wages', '1z'], ['taxableInt', 'Taxable interest', '2b'], ['taxExemptInt', 'Tax-exempt interest', '2a'], ['ordDiv', 'Ordinary dividends', '3b'], ['qualDiv', 'Qualified dividends', '3a'], ['iraDist', 'IRA distributions (taxable)', '4b'], ['pensions', 'Pensions (taxable)', '5b'], ['ssGross', 'Social Security benefits', '6a'], ['ssTaxable', 'Taxable Social Security', '6b'], ['capGain', 'Capital gain or (loss)', '7'], ['otherIncome', 'Other income (Schedule 1)', '8'], ['totalIncome', 'Total income', '9'], ['adjustments', 'Adjustments', '10'], ['agi', 'Adjusted gross income', '11']]],
    ['Federal deductions & tax', [['deduction', 'Standard or itemized deduction', '12'], ['qbi', 'QBI deduction', '13'], ['taxableIncome', 'Taxable income', '15'], ['tax', 'Tax', '16'], ['amt', 'AMT', 'Sch 2 line 1'], ['credits', 'Credits', '21'], ['niit', 'Net investment income tax', 'Sch 2 line 12'], ['addlMedicare', 'Additional Medicare tax', 'Sch 2 line 11'], ['otherTaxes', 'Other taxes', '23'], ['totalTax', 'Total tax', '24']]],
    ['Payments', [['withheld', 'Federal withholding', '25d'], ['estPaid', 'Estimated payments', '26'], ['refund', 'Overpaid', '34'], ['owed', 'Amount owed', '37']]],
    ['Carryforwards into next year', [['capLossCarryOut', 'Capital-loss carryforward', 'Sch D'], ['passiveUnallowed', 'Suspended rental (passive) losses', 'Form 8582'], ['rothBasis', 'Roth IRA contribution basis', '8606 line 22'], ['iraBasis', 'Nondeductible IRA basis', '8606 line 14'], ['amtCreditCF', 'AMT credit carryforward', '8801']]],
    ['California (Form 540)', [['caAgi', 'CA adjusted gross income', '17'], ['caDeduction', 'CA deduction', '18'], ['caTaxable', 'CA taxable income', '19'], ['caTax', 'CA tax', '31'], ['caMhst', 'Mental Health Services Tax', '62'], ['caTotalTax', 'CA total tax', '64'], ['caWithheld', 'CA withholding', '71'], ['caEstPaid', 'CA estimated payments', '72']]],
  ];
  const retYears = () => Object.keys(state.taxReturns || {}).map(Number).sort((a, b) => b - a);
  const retLatest = () => { const ys = retYears(); return ys.length ? { year: ys[0], f: state.taxReturns[ys[0]].fields } : null; };
  // MAGI flavors from a return
  function retMagi(f) {
    const agi = +f.agi || 0, ex = +f.taxExemptInt || 0, ssNon = Math.max(0, (+f.ssGross || 0) - (+f.ssTaxable || 0));
    return { agi, aca: agi + ex + ssNon, irmaa: agi + ex, p469: agi - (+f.ssTaxable || 0) };
  }
  // what the Plan takes from filed returns: actual MAGI history + carryforwards from the latest return before the plan starts
  function returnsForPlan(startYear) {
    if (state.useReturns === false || !state.taxReturns) return {};
    const seed = {}; for (const y of retYears()) { const m = retMagi(state.taxReturns[y].fields); if (m.agi) seed[y] = { i: m.irmaa, p: m.p469 }; }
    const prior = retYears().find((y) => y < startYear); const f = prior ? state.taxReturns[prior].fields : {};
    return { magiSeed: seed, capLossCF: +f.capLossCarryOut || 0, returnYear: prior || null };
  }
  // run this app's engine on the return's own income lines
  function retReconcile(y, f) {
    const S = state.settings; const g = (k2) => +f[k2] || 0;
    const single = S.household.filing === 'single';
    const inc = { ordinary: g('wages') + g('taxableInt') + Math.max(0, g('ordDiv') - g('qualDiv')) + g('iraDist') + g('pensions') + g('otherIncome') - g('adjustments'), ordinaryInvestment: g('taxableInt') + Math.max(0, g('ordDiv') - g('qualDiv')) /* NIIT base: wages, IRA and pension income excluded */, qualified: g('qualDiv'), taxExempt: g('taxExemptInt'), otherIncome: 0, capInc: g('capGain'), ssTaxable: g('ssTaxable'), ordinaryInvestment: g('taxableInt') + Math.max(0, g('ordDiv') - g('qualDiv')) };
    const opts = { calYear: y, filing: single ? 'single' : undefined, ages: single ? [y - S.household.birthYearSelf] : [y - S.household.birthYearSelf, y - S.household.birthYearSpouse] };
    if (f.deduction != null) opts.deductionOverride = g('deduction') + g('qbi');
    if (f.caDeduction != null) opts.caDeductionOverride = g('caDeduction');
    const t = E.taxes(S, y, inc, opts);
    return { t, inc, caTaxable: Math.max(0, t.agi - g('ssTaxable') - (f.caDeduction != null ? g('caDeduction') : 0)) };
  }
  const bizDay = (d) => { const x = new Date(d + 'T12:00:00'); const w = x.getDay(); if (w === 6) x.setDate(x.getDate() + 2); if (w === 0) x.setDate(x.getDate() + 1); return x; };
  // estimated-tax safe harbor: federal 25% x4; California 30/40/0/30; withholding counts as paid evenly through the year
  function estPlan(T) {
    const S = state.settings; const prev = (state.taxReturns || {})[T - 1]?.fields || null; const an = window.__an;
    const ES = state.estTax = state.estTax || {}; const e = ES[T] = ES[T] || {};
    const has = (v) => v != null && v !== '';
    // the 90%-of-this-year rule only applies to an estimate you enter: the Quarterly Review figure covers portfolio income only (no wages/RSUs)
    const qr = an && an.Y === T ? { fed: an.taxAfter.fed, ca: an.taxAfter.ca } : null;
    const curFed = has(e.fedEst) ? +e.fedEst : null, curCa = has(e.caEst) ? +e.caEst : null;
    const pFed = prev && has(prev.totalTax) ? +prev.totalTax : null, pCa = prev && has(prev.caTotalTax) ? +prev.caTotalTax : null, pAgi = prev ? +prev.agi || 0 : null;
    const hi = pAgi != null && pAgi > (S.household.filing === 'single' ? 150000 : 150000);
    const fedPct = hi ? 1.10 : 1.00;
    const agiT = has(e.agiEst) ? +e.agiEst : pAgi; const caOver1M = isCA() && agiT != null && agiT >= 1000000;
    const fedReq = [pFed != null ? pFed * fedPct : null, curFed != null ? curFed * 0.9 : null].filter((x) => x != null);
    const caReq = [!caOver1M && pCa != null ? pCa * (hi ? 1.10 : 1.00) : null, curCa != null ? curCa * 0.9 : null].filter((x) => x != null);
    const fedNeed = fedReq.length ? Math.min(...fedReq) : null, caNeed = caReq.length ? Math.min(...caReq) : null;
    const due = [`${T}-04-15`, `${T}-06-15`, `${T}-09-15`, `${T + 1}-01-15`].map(bizDay);
    const fs = [0.25, 0.25, 0.25, 0.25], cs = isCA() ? [0.30, 0.40, 0, 0.30] : [0.25, 0.25, 0.25, 0.25];
    const wF = +e.fedWithheld || 0, wC = +e.caWithheld || 0, pF = +e.fedPaid || 0, pC = +e.caPaid || 0;
    let cf = 0, cc = 0, paidF = pF, paidC = pC;
    const rows = due.map((d, i) => { cf += fs[i]; cc += cs[i];
      const fedCum = fedNeed != null ? Math.max(0, (fedNeed - wF) * cf) : null, caCum = caNeed != null ? Math.max(0, (caNeed - wC) * cc) : null;
      const fed = fedCum != null ? Math.max(0, fedCum - paidF) : null, ca = caCum != null ? Math.max(0, caCum - paidC) : null;
      paidF += fed || 0; paidC += ca || 0; return { d, fed, ca }; });
    return { T, prev, e, qr, agiT, curFed, curCa, pFed, pCa, pAgi, fedPct, hi, fedNeed, caNeed, caOver1M, rows, wF, wC, pF, pC };
  }
  function vReturns(snap, an) {
    const S = state.settings; state.taxReturns = state.taxReturns || {}; const ys = retYears();
    const y = ys.includes(state.retYear) ? state.retYear : ys[0]; const r = y ? state.taxReturns[y] : null; const f = r ? r.fields : {};
    const intro = `<div class="card"><h3>Tax returns</h3>
      <p>Drop your filed returns as PDFs (Form 1040 with schedules${isCA() ? ', and California 540' : ''}; TurboTax or preparer copies). They're read <b>here in your browser</b>. Only the summary lines below are kept: no SSNs, names or addresses. You can also type the numbers in.</p>
      <div id="trDrop" class="drop">Drop return PDFs here, or <label class="btn">choose files<input id="trIn" type="file" multiple accept=".pdf" hidden></label> <button class="btn" data-act="retAdd">Enter a year by hand</button></div>
      ${ys.length ? `<div class="seg" style="margin-top:8px">${ys.map((x) => `<button class="btn sm ${x === y ? 'primary' : ''}" data-act="retYear" data-y="${x}">${x}</button>`).join(' ')}</div>` : ''}
      <label class="fld chk" style="margin-top:8px"><input type="checkbox" data-scope="ui" data-path="useReturns" ${state.useReturns === false ? '' : 'checked'}><span>Use filed returns in the Plan (actual income for the Medicare 2-year lookback and rental-loss allowance; capital-loss carryforward)</span></label></div>`;
    const T = Math.max(an.Y, (ys[0] || an.Y - 1) + 1);
    if (!r) return intro + w2Card();
    const fmtIn = (k2) => `<input class="num" data-ret="${y}" data-f="${k2}" value="${f[k2] != null ? Math.round(f[k2] * 100) / 100 : ''}" placeholder="—" title="${esc((r.src || {})[k2] || 'not found in the PDF; type it if it applies')}">`;
    const grid = RET_FIELDS.filter(([g]) => isCA() || !/California/.test(g)).map(([g, list]) => `<h4>${g}</h4><div class="grid4 tight">${list.map(([k2, lab, ln]) => `<label class="fld"><span>${lab} <span class="mut">${/^\d/.test(ln) ? 'line ' + ln : ln}</span>${f[k2] != null && (r.src || {})[k2] && !(r.edited || {})[k2] ? ' <span class="pill ok" title="read from PDF">PDF</span>' : (r.edited || {})[k2] ? ' <span class="pill">edited</span>' : ''}</span>${fmtIn(k2)}</label>`).join('')}</div>`).join('');
    // sanity checks: income lines must add up to line 9; a return for this year or later can't be filed yet
    const g0 = (k2) => +f[k2] || 0; const parts = ['wages', 'taxableInt', 'ordDiv', 'iraDist', 'pensions', 'ssTaxable', 'capGain', 'otherIncome'];
    const sumParts = parts.reduce((a, k2) => a + g0(k2), 0); const impliedW = g0('totalIncome') - (sumParts - g0('wages'));
    const warns = [];
    if (f.totalIncome != null && Math.abs(sumParts - g0('totalIncome')) > 1) warns.push(`Lines 1z–8 add up to ${usd(sumParts)}, but total income (line 9) is ${usd(g0('totalIncome'))}. ${impliedW >= 0 ? `If the other lines are right, wages should be <b>${usd(impliedW)}</b>. <button class="btn sm" data-act="retFixW" data-y="${y}" data-v="${Math.round(impliedW * 100) / 100}">Set wages to ${usd(impliedW)}</button>` : 'Check the income lines.'}`);
    if (y >= new Date().getFullYear()) warns.push(`A ${y} return can't have been filed yet (it's ${new Date().getFullYear()}). The PDF probably included next year's estimated-tax vouchers. <button class="btn sm" data-act="retMove" data-y="${y}" data-to="${new Date().getFullYear() - 1}">Move to ${new Date().getFullYear() - 1}</button>`);
    const fieldsCard = `<div class="card"><h3>${y} return <span class="sub">${(r.files || []).map(esc).join(', ') || 'entered by hand'}</span></h3>${(r.fixes || []).length ? `<details class="guide"><summary><b>Auto-corrected ${r.fixes.length} misread line(s)</b> <span class="mut">check them against the PDF; type over any value to override</span></summary><ul class="steps">${r.fixes.map((x) => `<li>${esc(x)}</li>`).join('')}</ul></details>` : ''}${warns.map((w) => `<div class="banner">${w}</div>`).join('')}${grid}
      <p class="note">Hover a box to see the PDF line it came from. Edit anything that's wrong; edits are kept if you re-import. The capital-loss carryforward is computed from Schedule D lines 16 and 21 when they're present.</p>
      <p><button class="btn sm" data-act="retMove" data-y="${y}">Change tax year</button> <button class="btn danger sm" data-act="retDel" data-y="${y}">Remove ${y}</button></p></div>`;
    // 1. reconciliation
    let recon = '';
    if (f.agi != null || f.wages != null) {
      const { t, caTaxable } = retReconcile(y, f); const g = (k2) => +f[k2] || 0;
      const est = t.est ? ` <span class="pill amber">${y} tables estimated</span>` : '';
      const row = (lab, app, act, note = '') => { if (act == null || isNaN(act)) return `<tr><td>${lab}</td><td class="n">${usd(app)}</td><td class="n mut">—</td><td></td><td></td></tr>`; const d = app - act; const okp = Math.abs(d) <= Math.max(250, Math.abs(act) * 0.01);
        return `<tr><td>${lab}</td><td class="n">${usd(app)}</td><td class="n">${usd(act)}</td><td class="n ${okp ? '' : 'warnc'}">${Math.abs(d) < 1 ? '—' : (d > 0 ? '+' : '−') + usd(Math.abs(d))}</td><td>${okp ? '<span class="pill ok">match</span>' : `<span class="pill amber">gap</span> <span class="mut">${note}</span>`}</td></tr>`; };
      const fedIncTax = t.fedOrdinary + t.fedPref + t.amt + t.niit; const actFedInc = f.tax != null ? g('tax') + g('amt') + g('niit') : null;
      const why = [];
      if (f.agi != null && Math.abs(t.agi - g('agi')) > 250) why.push(`AGI differs by ${usd(t.agi - g('agi'))}. Some income isn't on the lines read (e.g. Schedule 1 items, K-1s, HSA), or a line was misread. Check the income boxes above.`);
      if (g('credits') > 0) why.push(`Your return has ${usd(g('credits'))} of credits (line 21: foreign tax, child, energy…). The app doesn't model credits, so its projections run higher by about that much a year.`);
      if (g('addlMedicare') > 0) why.push(`Additional Medicare tax (${usd(g('addlMedicare'))}) is a payroll tax. The Plan counts it with FICA, not in this table.`);
      if (isCA() && f.caTax != null && Math.abs((t.ca - t.caMhst) - g('caTax')) > Math.max(250, g('caTax') * 0.01)) why.push(`California tax differs. Check that CA AGI (${usd(g('caAgi'))}) matches federal AGI: Schedule CA adjustments (state-bond interest, HSA, etc.) change it. Exemption credits come after line 31.`);
      if (!why.length) why.push('The engine reproduces your filed return, so its projections start from a correct base.');
      recon = `<div class="card"><h3>1 · Does the app's tax engine match your ${y} return?${est}</h3>
        <table class="tbl narrow2"><thead><tr><th></th><th class="n">This app</th><th class="n">Your return</th><th class="n">Difference</th><th></th></tr></thead><tbody>
        ${row('Adjusted gross income', t.agi, f.agi != null ? g('agi') : null, 'income lines')}
        ${row('Taxable income', t.ordTaxable + t.prefTaxable, f.taxableIncome != null ? g('taxableIncome') : null, 'deduction or QBI')}
        ${row('Regular tax (line 16)', t.fedOrdinary + t.fedPref, f.tax != null ? g('tax') : null, 'under $100k the IRS tax table rounds to $50 brackets')}
        ${row('AMT', t.amt, f.amt != null ? g('amt') : null, 'ISOs or other AMT items')}
        ${row('Net investment income tax', t.niit, f.niit != null ? g('niit') : null, 'rental or K-1 investment income')}
        ${row('Federal income tax (line 16 + AMT + NIIT)', fedIncTax, actFedInc)}
        ${isCA() ? row('California taxable income', caTaxable, f.caTaxable != null ? g('caTaxable') : null, 'Schedule CA adjustments') + `
        ${row('California tax (line 31)', t.ca - t.caMhst, f.caTax != null ? g('caTax') : null)}
        ${row('Mental Health Services Tax', t.caMhst, f.caMhst != null ? g('caMhst') : null)}` : row(`${STN()} tax (app estimate)`, t.ca, null)}</tbody></table>
        <ul class="steps">${why.map((w) => `<li>${w}</li>`).join('')}</ul>
        <p class="note">Your return's deduction amounts are used here, so this tests rates, brackets, gain stacking and surtaxes. Effective rate on the return: federal ${f.totalTax && f.agi ? pct(g('totalTax') / g('agi') * 100, 1) : '—'}${f.caTotalTax && f.caAgi ? `, California ${pct(g('caTotalTax') / g('caAgi') * 100, 1)}` : ''}.</p></div>`;
    }
    // 2. carryforwards
    const props = (cur().realEstate || []).filter((p) => L.isRental(p.kind));
    const lat = retLatest(); const isLatest = lat && lat.year === y;
    const cf = `<div class="card"><h3>2 · Carryforwards from ${y} into ${y + 1}</h3>
      <table class="tbl"><thead><tr><th>Item</th><th class="n">From return</th><th>Where the app uses it</th><th></th></tr></thead><tbody>
      <tr><td>Capital-loss carryforward</td><td class="n">${f.capLossCarryOut != null ? usd(f.capLossCarryOut) : '—'}</td><td>Plan: starts the loss bank${isLatest ? ' automatically' : ' (the latest return before the plan starts is used)'}. Quarterly Review: offsets ${y + 1} gains (now ${usd(+cur().manual.lossCarryforward || 0)}).</td><td class="mut">${f.capLossCarryOut != null && y + 1 === an.Y ? (cur().manual.lossCarryforwardEdited ? 'overridden on Quarterly Review' : 'used automatically') : ''}</td></tr>
      <tr><td>Roth IRA contribution basis</td><td class="n">${f.rothBasis != null ? usd(f.rothBasis) : '—'}</td><td>Plan: Roth money you can spend before 59½ (now ${usd(+plan().rothBasis || 0)} in “${esc(plan().name)}”).</td><td>${f.rothBasis != null ? '<span class="mut">used automatically in every plan (override in Assumptions)</span>' : '<span class="mut">only on Form 8606 if you took Roth distributions. Otherwise add up your Roth IRA contributions and type it in the box above</span>'}</td></tr>
      <tr><td>Suspended rental losses</td><td class="n">${f.passiveUnallowed != null ? usd(f.passiveUnallowed) : '—'}</td><td>Rentals: released when there's passive income or the property is sold. Split them by property below.</td><td></td></tr>
      ${props.map((p) => `<tr><td class="mut" style="padding-left:18px">↳ ${esc(p.name)}</td><td></td><td><label class="mut">Suspended loss <input class="num" data-re="${p.id}" data-f="suspendedLoss" value="${p.suspendedLoss ?? ''}" placeholder="0"></label> <label class="mut">Depreciation taken to date <input class="num" data-re="${p.id}" data-f="priorDepreciation" value="${p.priorDepreciation ?? ''}" placeholder="estimated"></label></td><td class="mut">${f.rentDepreciation ? `Sched. E line 18 (all rentals) this year: ${usd(f.rentDepreciation)}` : ''}</td></tr>`).join('')}
      <tr><td>Nondeductible IRA basis</td><td class="n">${f.iraBasis != null ? usd(f.iraBasis) : '—'}</td><td class="mut">Lowers tax on future IRA withdrawals and conversions (pro-rata rule). Reference only; not modeled.</td><td></td></tr>
      <tr><td>AMT credit carryforward</td><td class="n">${f.amtCreditCF != null ? usd(f.amtCreditCF) : '—'}</td><td class="mut">Usable in years you don't owe AMT. Reference only; not modeled.</td><td></td></tr></tbody></table>
      <p class="note">Depreciation taken to date and suspended losses make rental sale taxes exact (depreciation is taxed back at up to 25% when you sell). Your preparer's depreciation report lists the total; the 1040 shows only this year's.</p></div>`;
    // 3. lookback
    const lbRows = ys.slice().sort().map((yy) => { const ff = state.taxReturns[yy].fields; const m = retMagi(ff); if (!m.agi) return '';
      const fpl = E.fplFor(S.ref, yy - 1, S.household.size); const pctF = m.aca / fpl.value * 100; const ir = E.irmaa(S, m.irmaa, S.household.filing === 'single');
      return `<tr><td>${yy}</td><td class="n">${usd(m.agi)}</td><td class="n">${usd(m.aca)}</td><td class="n ${pctF > 400 ? 'neg' : pctF > 350 ? 'warnc' : 'pos'}">${Math.round(pctF)}%</td><td class="n">${pctF > 400 ? `over by ${usd(m.aca - fpl.value * 4)}` : `${usd(fpl.value * 4 - m.aca)} under`}</td><td class="n">${usd(m.irmaa)}</td><td>${yy + 2}: ${ir.tier ? `<span class="pill amber">tier ${ir.tier}, +${usd(ir.annual)}/person if on Medicare</span>` : '<span class="pill ok">no surcharge</span>'}</td></tr>`; }).join('');
    const look = `<div class="card"><h3>3 · Your actual income for the lookback rules</h3>
      <table class="tbl"><thead><tr><th>Tax year</th><th class="n">AGI</th><th class="n">ACA MAGI</th><th class="n">% of poverty line</th><th class="n">vs 400% ACA cliff</th><th class="n">Medicare MAGI</th><th>Medicare surcharge in</th></tr></thead><tbody>${lbRows}</tbody></table>
      <p class="note">ACA MAGI = AGI + tax-exempt interest + untaxed Social Security; it sets that year's premium credit. Medicare's surcharge (IRMAA) uses AGI + tax-exempt interest from two years earlier. ${state.useReturns === false ? 'Not used by the Plan (turned off above).' : 'The Plan uses these actual figures for its first two years of Medicare surcharges and the rental-loss allowance.'}</p></div>`;
    return intro + w2Card() + fieldsCard + recon + cf + look;
  }
  function estCard(T, an) {
    const P4 = estPlan(T); const today = new Date();
    const ein = (k2, ph) => `<input class="num" data-est="${T}" data-f="${k2}" value="${P4.e[k2] ?? ''}" placeholder="${ph}">`;
    const next = P4.rows.find((x) => x.d >= today);
    return `<div class="card"><h3>4 · ${T} estimated tax payments <span class="sub">the safe harbor that avoids an underpayment penalty</span></h3>
      ${P4.prev ? '' : `<p class="banner">Add your ${T - 1} return to use the prior-year safe harbor. Until then only the 90%-of-this-year rule is shown.</p>`}
      <div class="grid4">
        <label class="fld"><span>${T} total federal tax estimate (optional)</span>${ein('fedEst', 'enter to use the 90% rule')}<span class="hint">include wages, RSUs, gains${P4.qr ? `. Quarterly Review's portfolio-only figure: ${usd(P4.qr.fed)}` : ''}</span></label>
        <label class="fld"><span>${T} ${STN()} tax estimate (optional)</span>${ein('caEst', 'enter to use the 90% rule')}<span class="hint">${P4.qr ? `portfolio-only: ${usd(P4.qr.ca)}` : ''}</span></label>
        <label class="fld"><span>${T} AGI estimate (optional)</span>${ein('agiEst', P4.pAgi != null ? `${T - 1}: ${Math.round(P4.pAgi)}` : 'enter')}<span class="hint">${isCA() ? 'California drops the prior-year safe harbor at $1M+' : 'sets the 110% rule above $150k'}</span></label>
        <label class="fld"><span>Federal withholding for ${T}</span>${ein('fedWithheld', '0')}<span class="hint">paychecks, RSUs, IRA withholding (counts as paid evenly)</span></label>
        <label class="fld"><span>${STN()} withholding for ${T}</span>${ein('caWithheld', '0')}</label>
        <label class="fld"><span>Federal estimates already paid</span>${ein('fedPaid', '0')}</label><label class="fld"><span>${STN()} estimates already paid</span>${ein('caPaid', '0')}</label></div>
      <table class="tbl narrow2"><thead><tr><th>Rule</th><th class="n">Federal</th><th class="n">${STN()}</th></tr></thead><tbody>
        <tr><td>${Math.round(P4.fedPct * 100)}% of ${T - 1} total tax${P4.hi ? ' (AGI over $150k)' : ''}</td><td class="n">${P4.pFed != null ? usd(P4.pFed * P4.fedPct) : '—'}</td><td class="n">${P4.caOver1M ? '<span class="mut">not allowed when AGI ≥ $1M</span>' : P4.pCa != null ? usd(P4.pCa * (P4.hi ? 1.1 : 1)) : '—'}</td></tr>
        <tr><td>90% of ${T} tax${P4.curFed == null && P4.curCa == null ? ' <span class="mut">(enter an estimate above)</span>' : ''}</td><td class="n">${P4.curFed != null ? usd(P4.curFed * 0.9) : '—'}</td><td class="n">${P4.curCa != null ? usd(P4.curCa * 0.9) : '—'}</td></tr>
        <tr><td><b>Required for ${T}</b> (the smaller)</td><td class="n"><b>${P4.fedNeed != null ? usd(P4.fedNeed) : '—'}</b></td><td class="n"><b>${P4.caNeed != null ? usd(P4.caNeed) : '—'}</b></td></tr>
        <tr><td>Less withholding and payments made</td><td class="n">−${usd(P4.wF + P4.pF)}</td><td class="n">−${usd(P4.wC + P4.pC)}</td></tr></tbody></table>
      <h4>Payment schedule</h4><table class="tbl narrow2"><thead><tr><th>Due</th><th class="n">Federal (25% each)</th><th class="n">${STN()} (${isCA() ? '30 / 40 / 0 / 30%' : '25% each; check your state\'s rules'})</th><th></th></tr></thead><tbody>
      ${P4.rows.map((rw) => `<tr class="${rw.d < today ? 'mut' : ''}"><td>${rw.d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</td><td class="n">${rw.fed != null ? usd(rw.fed) : '—'}</td><td class="n">${rw.ca != null ? usd(rw.ca) : '—'}</td><td>${rw.d < today ? 'past' : rw === next ? '<span class="pill amber">next</span>' : ''}</td></tr>`).join('')}</tbody></table>
      <p class="note">Pay federal at IRS Direct Pay or EFTPS (1040-ES) and ${isCA() ? 'California at FTB Web Pay (540-ES)' : `${STN()} on its revenue department's site`}. Paying the safe-harbor amount on time avoids the penalty even if you owe more in April. If an installment date has passed, paying the catch-up amount now limits the penalty. If most income comes late in the year (e.g. a December ${CS()} sale), the annualized-income method (Form 2210 Schedule AI) can lower earlier payments. ${P4.caOver1M ? '<b>California: with AGI of $1M or more, the prior-year safe harbor isn\'t available, so pay 90% of this year\'s tax.</b>' : ''}</p></div>`;
  }
  // ---------- REVIEW CADENCE: calendar-aware quarterly card, rebalancing, annual review, tax filing ----------
  const dstr = (d) => d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
  const daysTo = (d) => Math.ceil((d - new Date()) / 864e5);
  const ck = (scope, id, label, extra = '') => { const st = (state[scope] = state[scope] || {}); const on = !!st[id]; return `<li class="ckli ${on ? 'done' : ''}"><label><input type="checkbox" data-ck="${scope}" data-id="${esc(id)}" ${on ? 'checked' : ''}> <span>${label}</span></label>${extra ? `<div class="mut" style="margin:2px 0 0 24px">${extra}</div>` : ''}</li>`; };
  function calendarCard(an) {
    const now = new Date(); const Y = now.getFullYear(); const q = Math.floor(now.getMonth() / 3) + 1;
    const yearEnd = new Date(Y, 11, 31, 16); const dLeft = daysTo(yearEnd);
    const est = estPlan(Y); const nextEst = est.rows.find((r) => r.d >= new Date(now.toDateString()));
    const estTxt = nextEst ? (nextEst.fed == null && nextEst.ca == null ? `${dstr(nextEst.d)}: amounts appear once you add last year's return or a ${Y} tax estimate` : `${dstr(nextEst.d)}: federal ${nextEst.fed != null ? usd(nextEst.fed) : '—'}, California ${nextEst.ca != null ? usd(nextEst.ca) : '—'}`) : '';
    const room = an.th.ceiling - an.magiAfter.value;
    const items = [];
    if (an.working && q === 4) {
      items.push(['Year-end tax window is open', `${dLeft} days left to cut ${Y} taxes: max pre-tax 401(k)/HSA, harvest losses, give appreciated shares, and diversify only where it's (nearly) tax-free. <a href="#" data-tab="yearend">Open the year-end plan →</a>`, 'amber']);
      items.push(['No income target while working', `Your ${pct((an.taxAfter.fedMarginal + an.taxAfter.caMarginal) * 100, 0)} marginal rate makes deferring gains worth it. The ACA cliff and income room apply once you retire${an.retireDate ? ` (${an.retireDate})` : ''}.`, 'ok']);
      if (an.retireDate && +an.retireDate.slice(0, 4) === Y + 1) items.push(['Retirement transition', `${Y + 1} is your first retired year: schedule ${CS()} sales and any Roth conversion for January or later, and build the ${k(an.target)} cash buffer from the last paychecks. Choose COBRA or ${MKTN()} (enroll by Dec 31 for Jan 1 coverage).`, 'amber']);
      items.push(['RSU withholding', 'Flat 22% withholding on vests is below your bracket. Check whether a Jan 15 estimated payment is needed.', '']);
    } else if (q === 4) {
      items.push(['Year-end tax window is open', `${dLeft} days left. Anything that changes ${Y} income (sales, harvests, Roth conversions, gifts) must trade by <b>Dec 31</b>. <a href="#" data-tab="yearend">Open the year-end plan →</a>`, 'amber']);
      items.push([`${Y} income room`, room >= 0 ? `${usd(room)} left under your ${an.th.ceilingLabel} (${usd(an.th.ceiling)}). Gains realized now use it; unused room is lost on Jan 1.` : `<b class="neg">${usd(-room)} over</b> your ${an.th.ceilingLabel}. Harvest losses before Dec 31 or move planned sales to January.`, room >= 0 ? 'ok' : 'red']);
      items.push([isCA() ? 'Covered California' : 'ACA marketplace', `Open enrollment runs Nov 1 – Jan 31. Report your expected ${Y + 1} income; it sets next year's premium credit.`, '']);
      items.push(['Wash sales', `If you harvest a loss, don't buy the same or a substantially identical fund in any account (IRAs and 401(k)s included) within 30 days. A December harvest blocks rebuying until January.`, '']);
    } else if (q === 1) {
      items.push(['Tax season', `1099s arrive by mid-February (corrected ones into March). <a href="#" data-tab="filing">File taxes →</a>`, 'amber']);
      items.push(['Annual reset', `After filing, import the return and refresh the Plan. <a href="#" data-tab="annual">Annual reset →</a>`, '']);
      items.push(['Prior-year contributions', `IRA and HSA contributions for ${Y - 1} are allowed until Apr 15.`, '']);
    } else if (q === 2) items.push(['Mid-year income check', `${usd(Math.max(0, room))} of ${Y} income room left. Spread planned gains over the rest of the year rather than all in December.`, '']);
    else items.push(['Preview the year-end plan', `Q4 starts Oct 1. Check the ${Y} sale plan and income room now so December trades aren't rushed. <a href="#" data-tab="yearend">Year-end plan →</a>`, '']);
    if (nextEst) items.unshift(['Next estimated tax payment', `${estTxt} (${daysTo(nextEst.d)} days). <a href="#" data-tab="returns">Details →</a>`, daysTo(nextEst.d) <= 21 ? 'amber' : '']);
    return `<div class="card"><h3>Q${q} ${Y} · ${now.toLocaleDateString(undefined, { month: 'long', day: 'numeric' })} <span class="sub">${dLeft} days to year-end</span></h3>
      <table class="tbl"><tbody>${items.map(([a, b, c]) => `<tr><td style="width:190px"><b>${a}</b>${c ? ` <span class="pill ${c}">${c === 'ok' ? 'on track' : c === 'red' ? 'act' : 'now'}</span>` : ''}</td><td>${b}</td></tr>`).join('')}</tbody></table>
      <p class="note">${an.working ? '<b>Quarterly</b> = invest the surplus on target, rebalance, harvest losses, check RSU withholding, save a snapshot. <b>Annually</b> = cut this year\'s taxes in the Oct–Dec window, then file and reset the Plan in Jan–Apr.' : '<b>Quarterly</b> = keep the cash buffer funded, rebalance, harvest losses after dips, pay estimated tax, save a snapshot. <b>Annually</b> = decide how much income to realize (' + CS() + ' sales, Roth conversions, MAGI target) in the Oct–Dec window, then file taxes and reset the Plan in Jan–Apr.'}</p></div>`;
  }
  // allocation drift vs target, with where to trade to avoid taxes
  function rebalanceCard(an) {
    const S = state.settings; const T = S.alloc; const C = an.s.byClass; const g = (k2) => C[k2] || 0;
    const stock = g('us_stock') + g('intl_stock') + g('goog') + g('other'), bond = g('bond') + g('muni'), alt = g('gold') + g('crypto'), priv = g('private');
    const inv = stock + bond + alt; if (inv < 1) return '';
    const cur3 = { stock: stock / inv * 100, bond: bond / inv * 100, alt: alt / inv * 100 };
    const drift = (k2) => cur3[k2] - (+T[k2] || 0);
    const off = ['stock', 'bond', 'alt'].filter((k2) => Math.abs(drift(k2)) > (+T.band || 5));
    const retire = an.s.accts.filter((a) => a.taxType === 'pretax' || a.taxType === 'roth' || a.taxType === 'hsa');
    const retTot = sum(retire, (a) => a._value);
    const move = (k2) => Math.abs(drift(k2)) / 100 * inv;
    const L2 = { stock: 'Stocks (incl. ' + CS() + ')', bond: 'Bonds', alt: 'Gold & crypto' };
    const rows = ['stock', 'bond', 'alt'].map((k2) => `<tr><td>${L2[k2]}</td><td class="n">${pct(cur3[k2], 1)}</td><td class="n">${field2(k2)}</td><td class="n ${Math.abs(drift(k2)) > (+T.band || 5) ? 'warnc' : ''}">${drift(k2) >= 0 ? '+' : ''}${drift(k2).toFixed(1)} pts</td><td class="n">${Math.abs(drift(k2)) > (+T.band || 5) ? `${drift(k2) > 0 ? 'sell' : 'buy'} ${k(move(k2))}` : '—'}</td></tr>`).join('');
    function field2(k2) { return `<input class="num" style="width:56px" data-scope="settings" data-path="alloc.${k2}" value="${T[k2] ?? ''}">%`; }
    const how = off.length ? `<ul class="steps"><li><b>Trade inside retirement accounts first.</b> No tax there: ${retire.slice(0, 4).map((a) => esc(a.name)).join(', ')}${retire.length > 4 ? '…' : ''} (${k(retTot)} total)${retTot < move(off[0]) ? '. Not enough room in them, so use the steps below too' : ''}.</li>
      <li>Next, point new cash, dividends and the buffer refill at the underweight side.</li>
      <li>In taxable accounts, sell lots with losses first. ${CS()} trims belong in the Annual Review's income plan, not here.</li></ul>` : `<p class="pos">Within ±${T.band}% of target. Nothing to rebalance this quarter.</p>`;
    return `<div class="card"><h3>Rebalance check <span class="sub">invested assets ${k(inv)}, excluding cash buffer${priv ? ` and ${k(priv)} private/venture` : ''}</span></h3>
      <table class="tbl narrow2"><thead><tr><th></th><th class="n">Now</th><th class="n">Target</th><th class="n">Drift</th><th class="n">To fix</th></tr></thead><tbody>${rows}</tbody></table>
      <p class="mut">Rebalance band: <input class="num" style="width:48px" data-scope="settings" data-path="alloc.band" value="${T.band}"> points. ${CS()} is ${pct(an.s.googPct, 0)} of liquid net worth (limit ${S.trim.googConcentrationMax}%).</p>${how}</div>`;
  }
  // ---------- ANNUAL REVIEW ----------
  function vAnnual(snap, an, part = 'annual') {
    const now = new Date(); const Y = now.getFullYear(); const inWindow = now.getMonth() >= 9; const S = state.settings;
    const key = (id) => `${Y}:${id}`;
    const steps = an.plan?.steps || []; const byY = (y) => steps.filter((s) => s.year === y);
    const gainsY = sum(byY(an.Y), (s) => s.gain), gainsN = sum(byY(an.Y + 1), (s) => s.gain);
    const room = an.th.ceiling - an.magiAfter.value; const lr = retLatest(); const filedPrev = lr && lr.year >= Y - 1;
    const R = planResults(an); const conv = R.det.rows[0]?.conv || 0;
    const tlh = an.tlh?.items || []; const pretaxTot = an.s.byTax.pretax || 0;
    const A = `<div class="card"><h3>A · Year-end income plan for ${Y} <span class="sub">Oct 1 – Dec 31 ${inWindow ? '<span class="pill amber">open now</span>' : `<span class="pill">opens Oct 1</span>`}</span></h3>
      <div class="kpis"><div class="kpi"><div class="kl">${Y} income target</div><div class="kv">${k(an.th.ceiling)}</div><div class="ks">${esc(an.th.ceilingLabel)} · <a href="#" data-tab="settings">change</a></div></div>
      <div class="kpi"><div class="kl">Estimated ${Y} MAGI</div><div class="kv ${room < 0 ? 'neg' : ''}">${k(an.magiAfter.value)}</div><div class="ks">incl. planned sales · ${room >= 0 ? `${k(room)} room left` : `${k(-room)} over`}</div></div>
      <div class="kpi"><div class="kl">Planned gains</div><div class="kv">${k(gainsY)}</div><div class="ks">${Y} · ${k(gainsN)} moved into ${Y + 1}</div></div>
      <div class="kpi"><div class="kl">Loss-harvest candidates</div><div class="kv">${tlh.length}</div><div class="ks">${tlh.length ? esc([...new Set(tlh.map((t) => t.symbol))].slice(0, 3).join(', ')) : 'none right now'}</div></div></div>
      <ol class="steps cklist">
        ${ck('annual', key('target'), `Confirm the ${Y} income target`, `The ACA cliff matters only in years you buy ${MKTN()} coverage. While working, the target is usually a tax bracket instead. Set it in Settings → ACA.`)}
        ${ck('annual', key('sales'), `Execute the ${Y} part of the sale plan by Dec 31`, `${byY(an.Y).length} lot(s), ${k(gainsY)} of gains, on the <a href="#" data-tab="review">Review → Quarterly</a> sale plan. Sell ${CS()} lots there to diversify within the room.`)}
        ${ck('annual', key('harvest'), 'Harvest losses before Dec 31', tlh.length ? `See the tax-loss harvesting card on <a href="#" data-tab="review">Review → Quarterly</a>. Mind wash sales across all accounts.` : 'No positions with meaningful losses right now.')}
        ${ck('annual', key('roth'), `Decide on a ${Y} Roth conversion`, pretaxTot ? `${k(pretaxTot)} is in pre-tax accounts. The Plan's current strategy converts ${k(conv)} in its first year; compare strategies under <a href="#" data-tab="plan">Plan → Tax strategies</a>. Conversions count toward MAGI.` : 'No pre-tax balances.')}
        ${ck('annual', key('give'), 'Charitable gifts', 'Give appreciated shares (no gain tax) or bunch several years into a donor-advised fund in a high-income year.')}
        ${ck('annual', key('max'), 'Max out workplace accounts', '401(k) and HSA through the last paycheck. A mega-backdoor Roth too, if your plan allows it.')}
        ${ck('annual', key('aca'), `${isCA() ? 'Covered California' : 'ACA coverage'} for ${Y + 1}`, `Open enrollment runs Nov 1 – Jan 31. Report expected ${Y + 1} income (with ${k(gainsN)} of planned gains).`)}
        ${ck('annual', key('jan15'), 'Q4 estimated tax payment by Jan 15', `<a href="#" data-tab="returns">Tax returns → estimated payments</a>`)}
      </ol></div>`;
    const B = `<div class="card"><h3>B · Annual reset for ${filedPrev ? Y : Y} <span class="sub">Jan – Apr, after tax documents arrive</span></h3>
      <ol class="steps cklist">
        ${ck('annual', key('file'), `File ${Y - 1} taxes (or extend by Apr 15)`, `<a href="#" data-tab="filing">File taxes tab</a>: documents checklist and numbers for your preparer.`)}
        ${ck('annual', key('import'), `Import the ${Y - 1} return and reconcile`, filedPrev ? `<span class="pill ok">${lr.year} return loaded</span>` : `<a href="#" data-tab="returns">Tax returns →</a> Carryforwards and actual income flow into the Plan.`)}
        ${ck('annual', key('est'), `Set ${Y} estimated payments`, 'The safe harbor uses last year\'s total tax.')}
        ${ck('annual', key('spend'), 'Update annual spending from actual', `Plan now assumes ${k(catTotal(plan()))}/yr. Compare with last year's credit card and bank totals.`)}
        ${ck('annual', key('ss'), 'Refresh Social Security estimates', 'From ssa.gov → my Social Security, for both of you.')}
        ${ck('annual', key('plan'), 'Re-run the Plan', `Monte Carlo, tax strategies, and the stock return assumption. <a href="#" data-tab="plan">Plan →</a>`)}
        ${ck('annual', key('alloc'), 'Reset target allocation and ' + CS() + ' limit', `Targets (Plan → Assumptions → Investments): stocks ${allocTarget().stock}%, bonds ${allocTarget().bond}%, alternatives ${allocTarget().alt}%; ${CS()} ≤ ${S.trim.googConcentrationMax}%.`)}
        ${ck('annual', key('docs'), 'Insurance, beneficiaries, estate documents', 'Umbrella liability coverage, beneficiaries on every IRA and 401(k), trust funding (retitle accounts into the trust), guardianship for minor children.')}
        ${ck('annual', key('snap'), 'Save an annual snapshot and back up', `Click Save snapshot, then run <b>Backup to Zip</b>.`)}
      </ol></div>`;
    const AW = an.working ? annualWorking(an, Y, key) : '';
    const who = `<div class="card"><h3>What happens when</h3><table class="tbl"><thead><tr><th>Cadence</th><th>Purpose</th><th>Actions</th></tr></thead><tbody>
      <tr><td><b>Quarterly</b><br><span class="mut">Jan · Apr · Jul · Oct, ~30 min</span></td><td>Keep spending money ready and the portfolio on target</td><td>Import statements · cash buffer: Zero-Sale, Refill or Defensive · rebalance inside retirement accounts · harvest losses after dips · pay estimated tax · save snapshot</td></tr>
      <tr><td><b>Year-end window</b><br><span class="mut">Oct 1 – Dec 31</span></td><td>Control how much income each tax year gets</td><td>Set the MAGI target · sell ${CS()} and other gains up to it · Roth conversion · harvest losses · charity · ${MKTN()} income</td></tr>
      <tr><td><b>Annual reset</b><br><span class="mut">Jan – Apr</span></td><td>Close the books and re-plan</td><td>File taxes · import the return · carryforwards · estimated payments · update spending, Social Security and returns · re-run the Plan · estate and insurance check</td></tr></tbody></table></div>`;
    return part === 'yearend' ? (an.working ? AW : A) : B;
  }
  // ---------- FILE TAXES ----------
  function vFiling(snap, an) {
    const now = new Date(); const TY = now.getMonth() >= 10 ? now.getFullYear() : now.getFullYear() - 1; // Nov–Dec: prepare for this year's return
    const k0 = (id) => `${TY}:${id}`; const S = state.settings;
    const apr15 = bizDay(`${TY + 1}-04-15`), oct15 = bizDay(`${TY + 1}-10-15`);
    const accts = an.s.accts.filter((a) => !a.synthetic && a.taxType !== 'liability' && a.taxType !== 'property');
    const insts = [...new Set(accts.filter((a) => a.taxType === 'taxable' && a.key !== 'manual:checking').map((a) => a.institution))];
    const docs = [];
    { const nW = W2S().filter((x) => x.year === TY).length; docs.push(['w2', `W-2s from every employer (${esc(S.household.selfName)}${SOLO() || plan().people.retireAgeSpouse ? '' : `, ${esc(S.household.spouseName)} if they worked in ${TY}`})${nW ? ` · <span class="pill ok">${nW} imported</span>` : ''}`, `Late January. RSU income is included in box 1. ${nW ? 'Review them under Taxes → Returns → W-2s.' : 'Import the PDFs with the Import button to check withholding, 401(k) room and excess Social Security tax.'}`]); }
    for (const i of insts) docs.push(['1099-' + i, `${esc(i)}: consolidated 1099 (DIV, INT, B)`, /Schwab|Morgan/i.test(i) ? '<b>Stock-plan (RSU/ESPP) shares: the 1099-B often shows $0 or missing cost basis.</b> Use the supplemental statement or the vest-date value, or you pay tax on that income twice.' : /Wealthfront/i.test(i) ? 'Many small loss-harvest lots; import the file into your tax software rather than typing them.' : 'Mid-February; corrected versions can arrive into March. Wait for them before filing.']);
    if (!insts.some((i) => /Morgan/i.test(i)) && accts.some((a) => (a.lots || []).length)) docs.push(['ms', 'Morgan Stanley at Work: 1099-B and the supplemental cost-basis statement for ' + CS() + '', 'Same RSU basis issue as above.']);
    if (accts.some((a) => a.taxType === 'pretax' || a.taxType === 'roth')) docs.push(['1099r', '1099-R for any IRA/401(k) withdrawal, conversion or rollover; Form 5498 for contributions', 'Rollovers show code G (not taxable) and need the right code entered.']);
    const rentals = (cur().realEstate || []).filter((p) => L.isRental(p.kind));
    for (const p of cur().realEstate || []) if (+p.mtgBalance) docs.push(['1098-' + p.id, `${esc(p.name)}: Form 1098 mortgage interest + property tax bill`, L.isRental(p.kind) ? 'Rental share goes on Schedule E, personal share on Schedule A.' : 'Schedule A (only matters if you itemize).']);
    for (const p of rentals) docs.push(['rent-' + p.id, `${esc(p.name)}: rent ledger, expenses, ${p.kind === 'str' ? '1099-K from Airbnb/VRBO, nights rented vs personal-use days' : 'tenant payments'}`, p.kind === 'str' ? 'Average stay ≤ 7 days with material participation can make losses non-passive; personal use over 14 days limits losses.' : 'Keep receipts for repairs vs improvements (improvements are depreciated).']);
    if ((cur().manual.ytdHarvestedLosses || 0) > 0 || insts.length) docs.push(['tlh', 'Realized gain/loss reports from each brokerage', `App's ${TY} figures: gains ${usd(+cur().manual.ytdRealizedGains || 0)}, harvested losses ${usd(+cur().manual.ytdHarvestedLosses || 0)}.`]);
    if (plan().healthcare.model && an.Y >= TY) docs.push(['1095a', `Form 1095-A if you had ${MKTN()} coverage`, 'Needed for Form 8962 to reconcile the premium credit with actual income.']);
    if (accts.some((a) => a.taxType === 'hsa')) docs.push(['hsa', 'HSA: 1099-SA and 5498-SA', isCA() ? 'California taxes HSA contributions and earnings; add them back on Schedule CA.' : 'Needed for Form 8889.']);
    if (accts.some((a) => a.taxType === 'edu')) docs.push(['529', '529: Form 1099-Q in any year you withdraw; tuition 1098-T', 'Withdrawals must match qualified expenses in the same year.']);
    docs.push(['charity', 'Charitable receipts (cash and stock)', 'Stock gifts: fair value on the gift date; no gain to report.']);
    docs.push(['prior', `${TY - 1} return (federal + ${STN()})`, 'For carryforwards, prior-year safe harbor and comparison.']);
    // numbers to hand over
    const prevRet = (state.taxReturns || {})[TY - 1]?.fields || {}; const est = (state.estTax || {})[TY] || {};
    const R = planResults(an); const r0 = R.det.rows[0];
    const sched = rentals.map((p) => { const d = r0?.rentals?.[p.id || p.name]; if (!d) return ''; const f = 1 / r0.cpi;
      return `<tr><td>${esc(p.name)}</td><td class="n">${usd(d.gross * f)}</td><td class="n">${usd(d.dedOpex * f)}</td><td class="n">${usd(d.intR * f)}</td><td class="n">${usd(d.dep * f)}</td><td class="n">${usd(d.net * f)}</td><td class="n">${usd(+p.priorDepreciation || 0)}</td><td class="n">${usd(+p.suspendedLoss || 0)}</td></tr>`; }).join('');
    const numbers = `<div class="card"><h3>Numbers to have ready <span class="sub">for TurboTax or your preparer</span></h3>
      <table class="tbl narrow2"><tbody>
      <tr><td>Capital-loss carryforward from ${TY - 1}</td><td class="n">${prevRet.capLossCarryOut != null ? usd(prevRet.capLossCarryOut) : `<span class="mut">import the ${TY - 1} return</span>`}</td></tr>
      <tr><td>Federal estimated payments made for ${TY}</td><td class="n">${est.fedPaid ? usd(est.fedPaid) : '<span class="mut">record on Tax returns → estimated payments</span>'}</td></tr>
      <tr><td>${STN()} estimated payments made for ${TY}</td><td class="n">${est.caPaid ? usd(est.caPaid) : '—'}</td></tr>
      <tr><td>Roth IRA contribution basis</td><td class="n">${usd(+plan().rothBasis || 0)}</td></tr>
      <tr><td>Nondeductible IRA basis (Form 8606)</td><td class="n">${prevRet.iraBasis != null ? usd(prevRet.iraBasis) : '—'}</td></tr>
      <tr><td>App's estimate of ${an.Y} federal / ${STN()} tax on portfolio income</td><td class="n">${an.Y === TY ? `${usd(an.taxAfter.fed)} / ${usd(an.taxAfter.ca)}` : '—'}</td></tr></tbody></table>
      ${rentals.length ? `<h4>Schedule E draft from your Rentals inputs <span class="sub">annual model figures; replace with your actual ledger</span></h4><div class="scroll"><table class="tbl"><thead><tr><th>Property</th><th class="n">Rent</th><th class="n">Expenses</th><th class="n">Mortgage interest</th><th class="n">Depreciation</th><th class="n">Net</th><th class="n">Depreciation to date</th><th class="n">Suspended loss</th></tr></thead><tbody>${sched}</tbody></table></div>` : ''}</div>`;
    const traps = `<div class="card"><h3>Common mistakes for a household like yours</h3><ul class="steps">
      <li><b>RSU double tax:</b> stock-plan brokers (Schwab, Morgan Stanley at Work, E*Trade, Fidelity Stock Plan) often report $0 basis for RSU shares. The basis is the vest-date value already taxed on your W-2.</li>
      <li><b>Wash sales across accounts:</b> Wealthfront's harvesting plus the same funds bought in Fidelity or an IRA within 30 days disallows the loss. Brokers only catch it within one account.</li>
      ${isCA() ? '<li><b>California differences:</b> HSA contributions and earnings are taxable in CA; out-of-state muni interest is taxable in CA; Social Security is not.</li>' : ST().type === 'none' ? '' : `<li><b>${STN()} differences:</b> out-of-state muni interest is usually taxable; check how ${STN()} treats Social Security and retirement income.</li>`}
      <li><b>Net investment income tax (Form 8960):</b> 3.8% on interest, dividends, gains and passive rent above $250k MAGI. Short-term rental income can be excluded if you materially participate.</li>
      <li><b>SALT cap phase-down:</b> above $505k MAGI (2026) the $40,400 cap shrinks toward $10k. Check it if you itemize.</li>
      <li><b>Estimated-tax penalty:</b> if income spiked late in the year, Form 2210 Schedule AI (annualized income) can reduce or remove the penalty.</li>
      ${isCA() && an.magiAfter.value > 1000000 ? '<li><b>California 1% Mental Health Services Tax</b> on taxable income over $1M.</li>' : ''}</ul></div>`;
    return `<div class="card"><h3>File ${TY} taxes <span class="sub">federal${ST().type === 'none' ? '' : ` and ${STN()}`}</span></h3>
      <div class="kpis"><div class="kpi"><div class="kl">Filing deadline</div><div class="kv">${apr15.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}</div><div class="ks">${daysTo(apr15)} days · federal 1040${isCA() ? ' and CA 540' : ST().type === 'none' ? '' : ` and ${STN()} return`}</div></div>
      <div class="kpi"><div class="kl">With extension</div><div class="kv">${oct15.toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</div><div class="ks">Form 4868${isCA() ? '; California extends automatically' : ''}. <b>Tax is still due Apr 15.</b></div></div>
      <div class="kpi"><div class="kl">Q4 estimate</div><div class="kv">${bizDay(`${TY + 1}-01-15`).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</div><div class="ks"><a href="#" data-tab="returns">amounts →</a></div></div></div></div>
      <div class="card"><h3>Documents checklist <span class="sub">built from your accounts and properties</span></h3><ol class="steps cklist">${docs.map(([id, t, n]) => ck('filing', k0(id), t, n)).join('')}</ol></div>
      ${numbers}${traps}
      <div class="card"><h3>After you file</h3><ol class="steps cklist">${ck('filing', k0('import'), `Import the filed ${TY} return on the <a href="#" data-tab="returns">Tax returns</a> tab`, 'Checks it against the app, and carries forward losses and actual income.')}${ck('filing', k0('archive'), 'Save PDFs of both returns in FIRE-data/statements', 'Keep returns at least 7 years (3 for audits, 6 for big understatements, longer for basis records).')}</ol></div>`;
  }
  // ---------- LIFE PHASE: goals before vs after retirement ----------
  function goalsCard(an) {
    const S = state.settings; const w = an.working; const rd = an.retireDate;
    const days = rd ? Math.ceil((new Date(rd + 'T00:00:00') - new Date()) / 864e5) : null;
    const when = rd ? new Date(rd + 'T00:00:00').toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : 'not set';
    const col = (on, title, sub, items, nots) => `<div class="goalcol ${on ? 'on' : ''}"><div class="gh">${on ? '<span class="pill ok">now</span> ' : '<span class="pill">later</span> '}<b>${title}</b><div class="mut">${sub}</div></div>
      <ol>${items.map((x) => `<li>${x}</li>`).join('')}</ol>${nots ? `<div class="mut" style="font-size:12px"><b>Not a goal in this phase:</b> ${nots}</div>` : ''}</div>`;
    const pre = col(w, 'Working years: grow, diversify, cut taxes', `until ${when}${w && days != null ? ` (${days} days)` : ''}`, [
      `<b>Diversify ${CS()} and any other single stocks without big tax bills.</b> Sell RSUs at vest; sell high-basis lots paired with harvested losses; donate low-basis shares; save large sales for lower-income retirement years. Your limit: ${S.trim.googConcentrationMax}% of liquid net worth (now ${pct(an.s.googPct, 0)}).`,
      `<b>Lower taxes while you're in the top brackets</b> (${+an.m.wageIncome ? `${pct(an.taxAfter.fedMarginal * 100, 0)} federal + ${pct(an.taxAfter.caMarginal * 100, 1)} ${STC()}` : 'enter this year\'s wages on the Quarterly Review to see your rates'}). Max pre-tax 401(k) and HSA, mega-backdoor and backdoor Roth, bunch charity into a donor-advised fund, harvest losses (direct indexing), keep bonds in retirement accounts. No Roth conversions now.`,
      `<b>Keep ${S.buffer.emergencyMonths} months of emergency cash</b> and invest the rest of each paycheck on target. Rebalance quarterly.`,
      `<b>Get ready to retire:</b> build the ${k(an.target)} cash buffer in the last year, and plan health coverage (COBRA vs ${MKTN()}).`],
      'income targets, ACA cliff, spending from the buffer.');
    const post = col(!w, 'Retired: spend safely, control income', rd ? `from ${when}` : '', [
      `<b>Fund spending from the cash buffer</b> (${k(an.target)} = ${S.buffer.targetYears} years) and refill it with the quarterly decision: Zero-Sale, Refill, Defensive or Emergency.`,
      `<b>Hit a yearly income (MAGI) target:</b> ${esc(an.th.ceilingLabel)} (${k(an.th.ceiling)}) while you're on ${MKTN()}; otherwise fill a low tax bracket.`,
      '<b>Use the low-income years</b> for Roth conversions and to sell appreciated ' + CS() + ' at lower rates, before Social Security and RMDs raise your income.',
      '<b>Keep the plan on track:</b> Monte Carlo success, guardrails on spending, Medicare surcharges from 63.'],
      'maximizing contributions, deferring every gain.');
    const trans = w && rd && days < 400 ? `<p class="banner">Transition: ${+rd.slice(0, 4)} is your first retired year. Income from the last paycheck year is high, so push planned ${CS()} sales and any Roth conversion into January ${+rd.slice(0, 4)} or later. The income targets on these pages switch on automatically on ${when}.</p>` : '';
    return `<div class="card"><h3>Your goals <span class="sub">phase: <b>${w ? 'working' : 'retired'}</b>${S.household.retireDate ? '' : rd ? ' (retirement date from the Plan)' : ''} · <a href="#" data-tab="settings">change</a></span></h3>
      <div class="goalgrid">${w ? pre + post : post + pre}</div>${trans}</div>`;
  }
  function annualWorking(an, Y, key) {
    const S = state.settings; const pretax = an.s.byTax.pretax || 0;
    return `<div class="card"><h3>A · Year-end tax plan for ${Y} <span class="sub">working years: lower this year's tax and diversify</span></h3>
      <div class="kpis"><div class="kpi"><div class="kl">${Y} marginal rate</div><div class="kv">${pct((an.taxAfter.fedMarginal + an.taxAfter.caMarginal) * 100, 0)}</div><div class="ks">federal + ${STN()} on wages${+an.m.wageIncome ? '' : ' (enter wages on Quarterly Review)'}</div></div>
      <div class="kpi"><div class="kl">Each $1,000 deducted saves</div><div class="kv">${usd((an.taxAfter.fedMarginal + an.taxAfter.caMarginal) * 1000)}</div><div class="ks">at your top rates</div></div>
      <div class="kpi"><div class="kl">${CS()}</div><div class="kv ${an.s.googPct > S.trim.googConcentrationMax ? 'warnc' : ''}">${pct(an.s.googPct, 0)}</div><div class="ks">limit ${S.trim.googConcentrationMax}% · gain budget ${k(+S.working.gainBudget || 0)}/yr</div></div></div>
      <ol class="steps cklist">
        ${ck('annual', key('w401k'), 'Max pre-tax 401(k) and HSA through the last paycheck', '2026: $24,500 401(k) employee limit (+$8,000 catch-up at 50+); HSA family limit. Pre-tax beats Roth at your bracket.')}
        ${ck('annual', key('wmega'), 'Mega-backdoor Roth (after-tax 401(k) → Roth) if your plan allows it', 'Fills the 401(k) total limit with Roth money that never gets taxed again.')}
        ${ck('annual', key('wbackdoor'), 'Backdoor Roth IRA for each of you', 'Contribute non-deductible, convert right away. Keep pre-tax IRA balances at $0 (roll them into the 401(k)) or the pro-rata rule taxes it.')}
        ${ck('annual', key('wrsu'), 'Sell RSUs at vest and check withholding', 'RSUs are withheld at a flat 22% federal (37% over $1M) while your bracket is higher: top up via W-4 or an estimated payment to avoid a penalty.')}
        ${ck('annual', key('wdiv'), 'Diversify ' + CS() + ' tax-efficiently', `Quarterly Review → Diversification plan sells high-basis lots against harvested losses. Bigger sales cost about ${pct(((an.taxAfter.fedMarginal > 0.32 ? 0.238 : 0.188) + an.taxAfter.caMarginal) * 100, 0)} now vs much less in early retirement.`)}
        ${ck('annual', key('wtlh'), 'Harvest losses before Dec 31', 'Offsets gains first, then $3,000 of wages. Direct indexing makes this systematic (Plan → Direct indexing).')}
        ${ck('annual', key('wgive'), 'Charity: give appreciated ' + CS() + ' or bunch into a donor-advised fund', 'A deduction is worth more in a working year than in retirement. Giving shares avoids the gain tax too.')}
        ${ck('annual', key('wnoroth'), 'Skip Roth conversions this year', `Converting at ${pct(an.taxAfter.fedMarginal * 100, 0)} + ${STC()} rarely pays. Retirement years will be cheaper. ${pretax ? `${k(pretax)} is waiting in pre-tax accounts.` : ''}`)}
        ${ck('annual', key('wready'), 'Retirement readiness', `Cash buffer target ${k(an.target)} by your last paycheck · health coverage plan · final-year income kept high, first retired year low.`)}
      </ol></div>`;
  }
  // ---------- PORTFOLIO MIX, DIVERSIFICATION & REBALANCING ----------
  const BUCKETS = [['us', 'US stocks', '#3b6fd8'], ['intl', 'International stocks', '#6aa7d8'], ['bond', 'Bonds & stable value', '#e2733a'], ['alt', 'Gold & crypto', '#d9a520'], ['single', 'Single stocks', '#c94c43']];
  const MODELS = [['Aggressive', 90, 10, 0], ['Growth', 80, 20, 0], ['Early retiree', 70, 30, 0], ['Balanced', 60, 40, 0]];
  // same-index groups (overlap) — fine to hold across accounts (wash-sale swaps), but they're one exposure
  const INDEX_GROUP = { 'S&P 500': ['FXAIX', 'VOO', 'SPY', 'IVV', 'VFIAX', 'SWPPX', 'SPLG', 'INSTL 500 INDEX'], 'Total US market': ['VTI', 'VTSAX', 'FSKAX', 'ITOT', 'SCHB', 'FZROX', 'SWTSX'], 'US extended / mid / small': ['FSMAX', 'VXF', 'VEXAX', 'IJH', 'IJR', 'SPMD', 'VB', 'VO', 'SWSSX'],
    'Developed international': ['VEA', 'IEFA', 'SCHF', 'FSPSX', 'SWISX', 'DEVELOPED MKTS IDX', 'FTIHX', 'VXUS', 'IXUS'], 'Emerging markets': ['VWO', 'IEMG', 'SCHE', 'EMXC', 'FPADX', 'VANGUARD® EM MKTS'], 'US total bond': ['BND', 'AGG', 'FXNAX', 'SCHZ', 'VBTLX', 'INST TOT BD', 'IUSB', 'FIBR'] };
  const groupOf = (sym) => { const u = String(sym || '').toUpperCase(); for (const [g, list] of Object.entries(INDEX_GROUP)) if (list.includes(u)) return g; return null; };
  const isFundName = (h) => /fund|index|idx|etf|trust|portfolio|target|ishares|vanguard|spdr|schwab|fidelity|stable|bd\b|mkts|retire/i.test(h.desc || '') || /^[A-Z]{4}X$/.test(h.symbol || '') || /\s/.test(h.symbol || '');
  // look-through split of one holding into buckets (target-date funds by their glide path)
  function lookThrough(h, cls) {
    const v = h.value; const c = cls || h.assetClass;
    if (c === 'goog') return { single: v };
    if (c === 'us_stock') return !isFundName(h) && /^[A-Z.]{1,5}$/.test(h.symbol || '') && !groupOf(h.symbol) ? { single: v } : { us: v };
    if (c === 'intl_stock') return { intl: v };
    if (c === 'bond' || c === 'muni' || c === 'cash' || c === 'bank') return { bond: v };
    if (c === 'gold' || c === 'crypto') return { alt: v };
    if (c === 'balanced') { const y = +((h.symbol + ' ' + h.desc).match(/20[2-7]\d/) || [0])[0]; const st = y ? Math.max(30, Math.min(90, 50 + 1.5 * (y - new Date().getFullYear()))) / 100 : 0.6; return { us: v * st * 0.6, intl: v * st * 0.4, bond: v * (1 - st) }; }
    if (c === 'private') return { private: v };
    return { us: v };
  }
  function portfolioData(an) {
    const R = (state.rebal = state.rebal || { acct: {}, cls: {} }); R.acct = R.acct || {}; R.cls = R.cls || {};
    const accts = an.s.accts.filter((a) => !/^(re|mtg):/.test(a.key) && !['liability', 'property', 'edu'].includes(a.taxType) && Math.abs(a._value) > 1);
    const modeOf = (a) => R.acct[a.key] || (a.holdings.length > 40 ? 'lump' : 'include');
    const tickers = {}; const byAcct = []; const tot = { us: 0, intl: 0, bond: 0, alt: 0, single: 0, private: 0 };
    for (const a of accts) {
      const mode = modeOf(a); if (mode === 'exclude') continue;
      const ret = a.taxType !== 'taxable'; const row = { a, mode, ret, b: { us: 0, intl: 0, bond: 0, alt: 0, single: 0, private: 0 }, syms: {}, pureAmt: {}, mixed: new Set() };
      for (const h of a.holdings) {
        if (!ret && (h.assetClass === 'cash' || h.assetClass === 'bank')) continue; // taxable cash = spending buffer, managed separately
        const lt = lookThrough(h, R.cls[h.symbol]);
        const pure = Object.keys(lt).length === 1;
        for (const [b, v] of Object.entries(lt)) { row.b[b] += v; tot[b] += v; if (pure) { (row.syms[b] = row.syms[b] || new Set()).add(h.symbol || h.desc); row.pureAmt[b] = (row.pureAmt[b] || 0) + v; } }
        if (!pure && h.value > 1) row.mixed.add(h.symbol || h.desc);
        const key = mode === 'lump' ? 'acct:' + a.key : (h.symbol || h.desc);
        const t = tickers[key] = tickers[key] || { key, sym: mode === 'lump' ? a.name : h.symbol || h.desc, desc: mode === 'lump' ? `${a.holdings.length} holdings, shown as one line` : h.desc, cls: R.cls[h.symbol] || h.assetClass, value: 0, where: new Set(), lt: {}, lump: mode === 'lump' };
        t.value += h.value; t.where.add(a.taxType); for (const [b, v] of Object.entries(lt)) t.lt[b] = (t.lt[b] || 0) + v;
      }
      byAcct.push(row);
    }
    const invested = tot.us + tot.intl + tot.bond + tot.alt + tot.single;
    return { accts, modeOf, tickers: Object.values(tickers).sort((x, y) => y.value - x.value), byAcct, tot, invested };
  }
  function portfolioCard(an) {
    const S = state.settings; const T = allocTarget();
    const D = portfolioData(an); if (D.invested < 1) return ''; const cs = !!T.countSingles; const inv = D.invested - (cs ? 0 : D.tot.single);
    const tgt = { us: (+T.stock || 0) * (1 - T.intlShare / 100), intl: (+T.stock || 0) * T.intlShare / 100, bond: +T.bond || 0, alt: +T.alt || 0 };
    const curPct = (b) => (b === 'us' ? D.tot.us + (cs ? D.tot.single : 0) : D.tot[b]) / inv * 100; // single stocks: counted as US stocks only if chosen
    const drift = (b) => curPct(b) - tgt[b];
    const band = +T.band || 5;
    // --- 1. mix bar
    const bar = `<div class="mixbar">${BUCKETS.map(([b, l, c]) => D.tot[b] > 0 ? `<div style="width:${D.tot[b] / inv * 100}%;background:${c}" title="${l}: ${k(D.tot[b])} (${pct(D.tot[b] / inv * 100, 1)})"></div>` : '').join('')}</div>
      <div class="legend">${BUCKETS.map(([b, l, c]) => D.tot[b] > 0 ? `<span class="lg"><i style="background:${c}"></i>${l} ${pct(D.tot[b] / inv * 100, 0)}</span>` : '').join('')}</div>`;
    const tRow = (b, label) => `<tr><td>${label}</td><td class="n">${pct(curPct(b), 1)}</td><td class="n">${pct(tgt[b], 1)}</td><td class="n ${Math.abs(drift(b)) > band ? 'warnc' : ''}">${drift(b) >= 0 ? '+' : ''}${drift(b).toFixed(1)}</td><td class="n">${Math.abs(drift(b)) > band ? `${drift(b) > 0 ? 'sell' : 'buy'} ${k(Math.abs(drift(b)) / 100 * inv)}` : '—'}</td></tr>`;
    const models = MODELS.map(([n, st, bd, al]) => `<button class="btn sm ${+T.stock === st && +T.bond === bd ? 'primary' : ''}" data-act="allocModel" data-s="${st}" data-b="${bd}" data-a="${al}">${n} ${st}/${bd}</button>`).join(' ');
    const targets = `<div class="grid4 tight" style="margin:6px 0">
      <label class="fld"><span>Stocks %</span><input class="num" data-scope="plan" data-path="allocation.stockNow" value="${T.stock}"></label>
      <label class="fld"><span>…of which international %</span><input class="num" data-scope="plan" data-path="allocation.intlShare" value="${T.intlShare}"></label>
      <label class="fld"><span>Gold & crypto %</span><input class="num" data-scope="plan" data-path="allocation.alt" value="${T.alt}"></label>
      <label class="fld"><span>Bonds %</span><b style="padding:6px 0;display:block">${T.bond}%</b><span class="hint">the rest</span></label>
      <label class="fld"><span>Rebalance band ± pts</span><input class="num" data-scope="settings" data-path="alloc.band" value="${T.band}"></label>
      <label class="fld chk"><input type="checkbox" data-scope="settings" data-path="alloc.countSingles" ${cs ? 'checked' : ''}><span>Count single stocks toward the stock target</span><span class="hint">off: rebalance the diversified ${k(inv)} around them; ${CS()} is reduced by the ${an.working ? 'diversification' : 'sale'} plan</span></label></div>
      <p class="note">This is the same target as Plan → Assumptions → Investments (“${esc(T.planName)}”)${T.mode === 'glide' ? ', where a glide path is set: the stock % shown is the starting point' : T.mode === 'current' ? '. The Plan currently models your actual mix; choose “Rebalance to target” there to model this target' : ''}.</p>`;
    // --- 2. diversification
    const singles = D.tickers.filter((t) => (t.lt.single || 0) > 0).map((t) => ({ sym: t.sym, v: t.lt.single }));
    const singleTot = sum(singles, (x) => x.v);
    const groups = {}; for (const t of D.tickers) { const g = !t.lump && groupOf(t.sym); if (g) (groups[g] = groups[g] || []).push(t); }
    const overl = Object.entries(groups).filter(([, l]) => l.length > 1);
    const stocks = D.tot.us + D.tot.intl + D.tot.single; const intlOfStocks = stocks ? D.tot.intl / stocks * 100 : 0;
    const hhiParts = [...singles.map((x) => x.v / inv), (inv - singleTot) / inv]; const effN = 1 / sum(hhiParts, (x) => x * x); // diversified funds ≈ one well-diversified holding
    const tdf = D.tickers.filter((t) => t.cls === 'balanced');
    const flags = [];
    if (singleTot / inv > 0.10) flags.push(`<b>${pct(singleTot / inv * 100, 0)} in single stocks</b> (${singles.map((x) => `${esc(x.sym)} ${pct(x.v / inv * 100, 0)}`).join(', ')}). A common guide is under 10% in any one company, and an employer's stock also ties to your career. Diversify using the plan above, RSU sales at vest, and gifts of shares.`);
    if (stocks && (intlOfStocks < 20 || intlOfStocks > 50)) flags.push(`International is ${pct(intlOfStocks, 0)} of your stocks. The world market is about 37% non-US; most guides use 20–40%.`);
    if (overl.length) flags.push(`Same index in several funds: ${overl.map(([g, l]) => `${g} (${l.map((t) => esc(t.sym)).join(', ')})`).join('; ')}. That's fine, and useful for wash-sale swaps, but it's one exposure, not several.`);
    if (tdf.length) flags.push(`Target-date funds (${tdf.map((t) => esc(t.sym)).join(', ')}) hold their own stock/bond mix and rebalance themselves; they're split here by their glide path. To steer the mix precisely, use separate index funds in that 401(k).`);
    const div = `<div class="kpis" style="margin-top:8px"><div class="kpi"><div class="kl">Single-stock exposure</div><div class="kv ${singleTot / inv > 0.1 ? 'warnc' : ''}">${pct(singleTot / inv * 100, 0)}</div><div class="ks">${k(singleTot)} of ${k(inv)} invested</div></div>
      <div class="kpi"><div class="kl">International share of stocks</div><div class="kv">${pct(intlOfStocks, 0)}</div><div class="ks">world market ≈ 37%</div></div>
      <div class="kpi"><div class="kl">Effective number of bets</div><div class="kv">${effN.toFixed(1)}</div><div class="ks">funds count as one diversified bet; each big single stock as its own</div></div>
      <div class="kpi"><div class="kl">Tickers</div><div class="kv">${D.tickers.length}</div><div class="ks">${D.byAcct.length} accounts included</div></div></div>
      ${flags.length ? `<ul class="steps">${flags.map((f) => `<li>${f}</li>`).join('')}</ul>` : ''}
      ${!cs && D.tot.single ? `<p class="note">Including single stocks, stocks are ${pct((D.tot.us + D.tot.intl + D.tot.single) / D.invested * 100, 0)} of everything invested vs your ${T.stock}% target. Selling ${CS()} into bonds or international funds fixes both the concentration and the overall mix.</p>` : ''}`;
    // --- 3. rebalance plan: retirement accounts first (no tax), with asset location
    const over = ['us', 'intl', 'bond', 'alt'].filter((b) => drift(b) > band).map((b) => ({ b, amt: drift(b) / 100 * inv }));
    const under = ['bond', 'us', 'alt', 'intl'].filter((b) => drift(b) < -band).map((b) => ({ b, amt: -drift(b) / 100 * inv })); // international last: it belongs in taxable (foreign tax credit)
    const lab = Object.fromEntries(BUCKETS.map(([b, l]) => [b, l])); lab.us = 'US stocks';
    const retRows = D.byAcct.filter((r) => r.ret);
    const trades = []; const need = Object.fromEntries(under.map((u) => [u.b, u.amt])); let left = Object.fromEntries(over.map((o) => [o.b, o.amt]));
    // step 1: new money / spare cash in taxable buys international first (keeps the foreign tax credit), then US stocks
    const spare = Math.max(0, an.cash - (an.working ? an.floor : an.target)); let cashLeft = spare; const taxBuys = [];
    for (const b of ['intl', 'us']) if (need[b] > 1 && cashLeft > 1) { const x = Math.min(need[b], cashLeft); taxBuys.push({ b, x }); need[b] -= x; cashLeft -= x; }
    // asset location: sell bonds from Roth first / buy bonds in pre-tax first; stocks the other way
    const order = (b, buy) => retRows.slice().sort((x, y) => { const s = (r) => (r.a.taxType === 'roth' || r.a.taxType === 'hsa' ? 1 : 0); return (b === 'bond') === buy ? s(x) - s(y) : s(y) - s(x); });
    for (const o of over) for (const r of order(o.b, false)) {
      let avail = Math.min((r.b[o.b] || 0) - ((r.sold || {})[o.b] || 0), left[o.b]);
      for (const u of under) { if (avail <= 1 || need[u.b] <= 1 || u.b === 'intl') continue; /* international is bought in taxable */ const x = Math.min(avail, need[u.b]); trades.push({ r, from: o.b, to: u.b, x }); avail -= x; need[u.b] -= x; left[o.b] -= x; r.sold = r.sold || {}; r.sold[o.b] = (r.sold[o.b] || 0) + x; }
    }
    const fundIn = (r, b) => [...(r.syms[b] || [])].filter((s) => s && !/^CASH$|SPAXX/i.test(s)).slice(0, 3).join(', ');
    const anyOf = { us: 'a US total-market or S&P 500 index fund', intl: 'an international index fund', bond: 'a total bond or stable-value fund', alt: 'a gold or bitcoin fund (if offered)' };
    const tradeRows = trades.map((t) => `<tr><td>${esc(t.r.a.name)} <span class="pill ${t.r.a.taxType === 'pretax' ? 'pretax' : 'roth'}">${t.r.a.taxType === 'pretax' ? 'pre-tax' : 'Roth'}</span></td><td>Sell ${k(t.x)} of ${lab[t.from]}${fundIn(t.r, t.from) ? ` <span class="mut">(${esc(fundIn(t.r, t.from))})</span>` : ''}${(t.r.pureAmt[t.from] || 0) < t.x - 1 && t.r.mixed.size ? `<div class="mut" style="font-size:11.5px">${(t.r.pureAmt[t.from] || 0) > 1 ? `only ${k(t.r.pureAmt[t.from])} is in pure ${lab[t.from]} funds; the rest is inside ` : 'held inside '}${esc([...t.r.mixed].join(', '))}. Sell part of that fund and buy the pure funds instead.</div>` : ''}</td><td>Buy ${lab[t.to]}: ${fundIn(t.r, t.to) ? esc(fundIn(t.r, t.to)) : anyOf[t.to]}</td></tr>`).join('');
    const restBuy = sum(Object.values(need), (x) => Math.max(0, x)); const restSell = sum(Object.values(left), (x) => Math.max(0, x));
    const singleOver = singleTot / inv * 100 > S.trim.googConcentrationMax;
    const plan = !over.length && !under.length ? `<p class="pos">Every bucket is within ±${band} points of target. Nothing to rebalance this quarter.</p>` : `
      <ol class="steps">${taxBuys.length ? `<li><b>Spare cash in taxable</b> (${k(spare)} above your ${an.working ? 'emergency fund' : 'cash buffer target'}): ${taxBuys.map((t) => `buy ${k(t.x)} of ${t.b === 'intl' ? 'an international index fund (taxable keeps the foreign tax credit)' : 'broad US stocks, e.g. a US direct index excluding ' + CS() + ''}`).join('; ')}.</li>` : need.intl > 1 ? `<li><b>International goes in taxable:</b> buy the ${k(need.intl)} shortfall there with ${an.working ? 'paychecks and RSU proceeds' : 'new money'} rather than inside a 401(k), so you keep the foreign tax credit.</li>` : ''}
      <li><b>Inside retirement accounts (no tax):</b> ${trades.length ? 'make these exchanges, moving bonds into pre-tax accounts first.' : 'nothing to move there, because the overweight assets are all in taxable accounts.'}</li></ol>
      ${trades.length ? `<table class="tbl"><thead><tr><th>Account</th><th>Sell</th><th>Buy</th></tr></thead><tbody>${tradeRows}</tbody></table>` : ''}
      <ol class="steps" start="${taxBuys.length || need.intl > 1 ? 3 : 2}">${restBuy > 1 ? `<li><b>Still to add:</b> ${Object.entries(need).filter(([, v]) => v > 1).map(([b, v]) => `${k(v)} of ${lab[b]}`).join(', ')}. Direct ${an.working ? 'paycheck savings and RSU proceeds' : 'dividends and buffer refills'} there first.</li>` : ''}
        ${restSell > 1 ? `<li><b>Overweight left in taxable accounts:</b> ${Object.entries(left).filter(([, v]) => v > 1).map(([b, v]) => `${k(v)} of ${lab[b]}`).join(', ')}. Only sell lots at a loss or near cost. Otherwise let new money catch up instead of paying tax to rebalance.</li>` : ''}
        <li><b>New US stock money in taxable:</b> a broad US direct index (Russell 1000/3000 or total market; S&P 500 if that's what your provider offers) with <b>${CS()}/GOOGL excluded</b>. You get US market exposure without adding to ${CS()}, and its harvested losses can offset ${CS()} sales. Model it under <a href="#" data-tab="plan" data-ptab-go="di">Plan → Direct indexing</a>.</li>
        ${singleOver && cs ? `<li><b>Single stocks</b> count as US stocks above, so selling ${CS()} and buying international funds or bonds fixes both at once. Use the ${an.working ? 'diversification plan' : 'sale plan'} at the top, within your tax budget.</li>` : ''}</ol>`;
    // --- 4. ticker table + account toggles
    const acctToggles = D.accts.map((a) => { const m = D.modeOf(a); return `<tr><td>${esc(a.name)}</td><td><span class="pill ${a.taxType === 'pretax' ? 'pretax' : a.taxType === 'roth' ? 'roth' : 'taxable'}">${TAX_LABEL[a.taxType] || a.taxType}</span></td><td class="n">${k(a._value)}</td><td class="n">${a.holdings.length}</td><td><select data-rebal-acct="${a.key}">${[['include', 'Show each ticker'], ['lump', 'One line (e.g. direct indexing)'], ['exclude', 'Leave out of mix']].map(([v, l]) => `<option value="${v}" ${m === v ? 'selected' : ''}>${l}</option>`).join('')}</select></td></tr>`; }).join('');
    const CL = { us_stock: 'US stock', intl_stock: 'Intl stock', bond: 'Bond', muni: 'Muni', cash: 'Cash/stable', bank: 'Bank', goog: CS(), gold: 'Gold', crypto: 'Crypto', balanced: 'Target-date/balanced', private: 'Private', other: 'Unclassified' };
    const tick = D.tickers.map((t) => { const sh = t.value / inv * 100; const g = !t.lump && groupOf(t.sym);
      return `<tr><td><b>${esc(t.sym)}</b>${g ? ` <span class="pill">${g}</span>` : ''}<div class="mut" style="font-size:11px">${esc((t.desc || '').slice(0, 60))}</div></td><td>${t.lump ? '<span class="mut">mixed</span>' : `<select data-rebal-cls="${esc(t.sym)}">${Object.entries(CL).map(([v, l]) => `<option value="${v}" ${t.cls === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`}</td><td class="n">${k(t.value)}</td><td class="n ${sh > 10 && (t.lt.single || 0) > 0 ? 'warnc' : ''}">${pct(sh, 1)}</td><td>${[...t.where].map((w) => `<span class="pill ${w === 'pretax' ? 'pretax' : w === 'roth' || w === 'hsa' ? 'roth' : 'taxable'}">${w === 'pretax' ? 'pre-tax' : w}</span>`).join(' ')}</td></tr>`; }).join('');
    return `<div class="card" id="portfolio"><h3>Portfolio mix & rebalancing <span class="sub">${k(inv)} invested · excludes the taxable cash buffer${D.tot.private ? `, ${k(D.tot.private)} private/venture` : ''}</span></h3>
      ${bar}
      <h4>Target mix</h4><div class="seg">${models}</div>${targets}
      <table class="tbl narrow2"><thead><tr><th></th><th class="n">Now</th><th class="n">Target</th><th class="n">Drift (pts)</th><th class="n">To fix</th></tr></thead><tbody>${tRow('us', cs ? 'US stocks (incl. single stocks)' : 'US stock funds')}${tRow('intl', 'International stocks')}${tRow('bond', 'Bonds & stable value')}${tRow('alt', 'Gold & crypto')}</tbody></table>
      <details class="guide"><summary><b>What should the balance look like?</b></summary><ul class="steps">
        <li><b>Stocks vs bonds:</b> the bond share is mostly about the years just before and after retirement, when a crash hurts most. Many early retirees hold 60–70% stocks around the retirement date ("bond tent") and drift back up to 80%+ later. Your 2-year cash buffer already covers near-term spending, so you can lean toward the stock-heavy end.</li>
        <li><b>International:</b> 20–40% of stocks. It diversifies away from US-only valuations.</li>
        <li><b>Single stocks:</b> keep any one company under 10% of investments, lower when it's also your employer.</li>
        <li><b>Rebalance</b> when a bucket drifts more than ±5 points, checked quarterly. Rebalancing more often adds tax and costs without much benefit.</li>
        <li><b>Asset location (which account holds what):</b>
          <table class="tbl narrow2" style="margin-top:6px"><thead><tr><th>Asset</th><th>Best home</th><th>Why</th></tr></thead><tbody>
          <tr><td>Bonds, stable value</td><td><span class="pill pretax">pre-tax 401(k)/IRA</span></td><td>Interest is taxed as ordinary income (about ${pct((an.taxAfter.fedMarginal + an.taxAfter.caMarginal) * 100, 0)} federal + state for you) if held in taxable. In pre-tax it's deferred to lower retirement rates, and slow growth keeps future RMDs smaller.</td></tr>
          <tr><td>International stocks</td><td><span class="pill taxable">taxable</span></td><td>Foreign countries withhold tax on dividends (about 0.2–0.3% of value a year). Only a taxable account gets it back as the federal foreign tax credit; inside a 401(k)/IRA/Roth it's lost. California gives no credit either way.</td></tr>
          <tr><td>Broad US stocks / direct index</td><td><span class="pill taxable">taxable</span></td><td>Low dividends, few distributions, harvestable losses, and a step-up in basis at death.</td></tr>
          <tr><td>Highest expected growth</td><td><span class="pill roth">Roth</span></td><td>Growth is never taxed.</td></tr>
          <tr><td>${ST().type === 'none' ? 'Municipal bonds' : `${STN()} munis`}</td><td><span class="pill taxable">taxable</span></td><td>Tax-free for federal${ST().type === 'none' ? '' : ` and ${STC()}`}; pointless inside a retirement account.</td></tr></tbody></table>
          Getting the overall mix right matters more than perfect location, so it's fine to hold some international in a 401(k) if that's the only place to trade.</li></ul></details>
      <h4>Diversification</h4>${div}
      <h4>How to rebalance</h4>
      <p class="note"><b>Yes, use your retirement accounts.</b> Trades inside a 401(k), IRA or Roth create no tax, so they're the first place to rebalance. Your whole household is one portfolio: you can hold all your bonds in one 401(k) and all your international stocks in taxable, as long as the total matches the target. Two limits: each 401(k) only offers its own fund menu, and money can't move between accounts, only between funds inside an account.</p>
      ${plan}
      <details ${state.rebalOpen ? 'open' : ''} id="rebalDetails"><summary><b>All holdings (${D.tickers.length})</b> · choose which accounts to include</summary>
        <table class="tbl"><thead><tr><th>Account</th><th>Type</th><th class="n">Value</th><th class="n">Holdings</th><th>In this analysis</th></tr></thead><tbody>${acctToggles}</tbody></table>
        <div class="scroll" style="max-height:420px"><table class="tbl"><thead><tr><th>Ticker</th><th>Class</th><th class="n">Value</th><th class="n">% of invested</th><th>Held in</th></tr></thead><tbody>${tick}</tbody></table></div>
        <p class="note">Change a ticker's class if it's misclassified; that changes the mix everywhere in this card. "One line" keeps an account's money in the mix but collapses its tickers; use it for direct indexing. "Leave out" removes it entirely.</p></details></div>`;
  }
  // ---------- SPENDING: bank & card exports → outflows by month and category ----------
  const SPC = P.SPEND_CATS;
  const CC_NODETAIL = 'Credit card payments', SAVED = 'Saved & invested (own accounts)';
  const SP_MODELED = ['Housing (mortgage, rent, HOA)', 'Property tax', 'Income tax']; // the Plan models these separately
  const SP_COLORS = ['#4caf50', '#e2733a', '#3b6fd8', '#8d6e63', '#26a69a', '#7e57c2', '#d67aa0', '#ffa726', '#5c6bc0', '#ab47bc', '#29b6f6', '#9ccc65', '#ec407a', '#ffca28', '#90a4ae', '#a0785a', '#795548', '#455a64', '#bdbdbd'];
  const SPC_ALL = [...SPC, CC_NODETAIL, SAVED];
  const spColor = (c) => (c === CC_NODETAIL ? '#37474f' : c === SAVED ? '#80cbc4' : SP_COLORS[SPC.indexOf(c) % SP_COLORS.length] || '#bdbdbd');
  const SP_TO_PLAN = { Groceries: 'Essentials (groceries, utilities, insurance, transport)', 'Utilities & phone': 'Essentials (groceries, utilities, insurance, transport)', Insurance: 'Essentials (groceries, utilities, insurance, transport)', Transportation: 'Essentials (groceries, utilities, insurance, transport)', 'Personal care': 'Essentials (groceries, utilities, insurance, transport)', 'Fees & interest': 'Essentials (groceries, utilities, insurance, transport)',
    [CC_NODETAIL]: 'Other discretionary', Medical: 'Out-of-pocket medical, dental, vision', 'Kids & education': 'Kids & education', Travel: 'Travel & vacations', Dining: 'Dining & entertainment', Entertainment: 'Dining & entertainment', Subscriptions: 'Dining & entertainment',
    'Gifts & charity': 'Gifts & charity', 'Home & garden': 'Home projects & big purchases', Shopping: 'Other discretionary', Other: 'Other discretionary' };
  const SPD = () => { state.spending = state.spending || { txns: [], imports: [], rules: {} }; const d = state.spending; d.txns = d.txns || []; d.imports = d.imports || []; d.rules = d.rules || {};
    if (!d.v2) { for (const t of d.txns) if (t.kind === 'transfer' && t.amount > 0 && (P.isCardPaymentOut(t.desc) || t.matched)) { t.kind = 'cardpay'; delete t.matched; } d.v2 = true; if (d.includeModeled == null) d.includeModeled = true; }
    d.acctTypes = d.acctTypes || {};
    if (!d.v4 && d.v3) { d.v4 = true; for (const a of Object.keys(d.acctTypes)) { if (d.acctTypes[a] === 'card') continue; const L = d.txns.filter((x) => x.acct === a && !x.manual && typeof x.amount === 'number'); if (P.outSignVote(L.map((x) => ({ desc: x.desc, amt: x.amount }))) === -1) { for (const x of L) { x.amount = -x.amount; delete x.userKind; } spReclass(d, a); d.fixedSigns = (d.fixedSigns || []).concat(a); } } spDedupe(d); }
    if (!d.v3) { d.v3 = true; d.v4 = true; for (const im of d.imports) if (!d.acctTypes[im.acct]) d.acctTypes[im.acct] = im.isCard ? 'card' : 'bank'; for (const a of Object.keys(d.acctTypes)) spReclass(d, a); spDedupe(d); }
    return d; };
  // re-derive what each row is from its account type (keeps your manual edits and merchant rules)
  function spReclass(d, acct) {
    const card = d.acctTypes[acct] === 'card';
    for (const t of d.txns) { if (t.acct !== acct || t.manual || t.kind === 'dup' || typeof t.amount !== 'number') continue; const c = P.classifyTxn(t.desc, t.amount > 0, card, '', t.bankCat || '');
      if (!t.userKind) t.kind = c.kind; if (!t.userCat) t.category = (t.kind === 'spend' || t.kind === 'refund') ? (t.category && t.kind === c.kind ? t.category : c.category) : null; spApplyRules(t, d); }
  }
  // the same transaction imported twice (overlapping or differently formatted exports of one account) → kept once
  function spDedupe(d) {
    const seen = new Map(); let n = 0;
    for (const t of d.txns.slice().sort((a, b) => a.date.localeCompare(b.date))) {
      if (t.manual || !t.date || typeof t.amount !== 'number') continue; if (t.kind === 'dup' && t.userKind) continue;
      // same account + same amount + within 2 days + similar merchant name (exports format names differently)
      const key = `${t.acct}|${t.amount.toFixed(2)}`; const prev = seen.get(key) || []; const w1 = (merchantKey(t.desc).split(' ')[0] || '').slice(0, 6);
      const twin = prev.find((p) => p.src !== t.src && !p.used && Math.abs(new Date(p.date) - new Date(t.date)) <= 2 * 864e5 && (merchantKey(p.t.desc).split(' ')[0] || '').slice(0, 6) === w1);
      if (twin) { twin.used = true; if (t.kind !== 'dup') { t.dupOf = twin.t.id; t.kindBeforeDup = t.kind; t.kind = 'dup'; n++; } }
      else prev.push({ t, src: t.src, date: t.date }); seen.set(key, prev);
    }
    return n;
  }
  const merchantKey = (desc) => P.payeeOf(String(desc || '')).toUpperCase().replace(/[0-9#*]+/g, ' ').replace(/\b(DES|ID|INDN|CO|PPD|WEB|POS|PURCHASE|DEBIT|CARD|SQ|TST)\b:?/g, ' ').replace(/[^A-Z&' ]/g, ' ').replace(/\s+/g, ' ').trim().split(' ').slice(0, 3).join(' ');
  function spApplyRules(t, d) { const r = ((d || state.spending || {}).rules || {})[merchantKey(t.desc)]; if (r && (t.kind === 'spend' || t.kind === 'refund')) t.category = r; }
  // card payments seen from the bank side: same amount as a card's "payment received" within a week → transfer, not spending
  // a bank outflow equal to a card's "payment received" (±7 days) is a card payment
  function spMatchTransfers() {
    const D = SPD(); const pays = D.txns.filter((t) => t.kind === 'transfer' && t.amount < 0);
    for (const t of D.txns) if (t.kind === 'spend' && !t.manual && t.amount > 0) {
      const m = pays.find((p) => p.acct !== t.acct && Math.abs(-p.amount - t.amount) < 0.01 && Math.abs(new Date(p.date) - new Date(t.date)) <= 7 * 864e5);
      if (m) { t.kind = 'cardpay'; t.category = null; }
    }
  }
  // card payments only count as spending when that card's own purchases weren't imported (otherwise they'd be counted twice)
  function spCardPayCovered(D) {
    const pays = D.txns.filter((t) => t.kind === 'transfer' && t.amount < 0); const covered = new Set();
    for (const t of D.txns) if (t.kind === 'cardpay' && pays.some((p) => p.acct !== t.acct && Math.abs(-p.amount - t.amount) < 0.01 && Math.abs(new Date(p.date) - new Date(t.date)) <= 7 * 864e5)) covered.add(t.id);
    return covered;
  }
  function importTxns(r, fname) {
    const D = SPD(); const stem = fname.replace(/\.[a-z]+$/i, '').replace(/[_-]+/g, ' ');
    const known = Object.keys(D.acctTypes || {}); const acct = (prompt(`Account name for ${fname} (${r.txns.length} rows; looks like a ${r.isCard ? 'credit card' : 'bank account'}).${known.length ? `\nUse the same name to add to an existing account: ${known.join(', ')}` : ''}`, stem) || stem).trim();
    D.acctTypes[acct] = D.acctTypes[acct] || (r.isCard ? 'card' : 'bank');
    const seen = {}; let added = 0, dup = 0;
    const existing = new Set(D.txns.map((t) => t.id));
    for (const t of r.txns) { const base = `${acct}|${t.date}|${t.amount}|${t.desc}`; seen[base] = (seen[base] || 0) + 1; const id = base + '|' + seen[base];
      if (existing.has(id)) { dup++; continue; } const x = { id, ...t, acct, src: fname }; spApplyRules(x); D.txns.push(x); added++; }
    D.imports.push({ file: fname, acct, isCard: r.isCard, rows: r.txns.length, added, dup, skipped: (r.skipped || []).length, skippedEx: (r.skipped || []).slice(0, 5), from: r.from, to: r.to, at: new Date().toISOString().slice(0, 10) });
    spReclass(D, acct); const fuzzy = spDedupe(D); spMatchTransfers(); state.tab = 'spending'; save();
    toast(`${fname} → ${acct} (${D.acctTypes[acct] === 'card' ? 'credit card' : 'bank'}): ${added} transactions added${dup ? `, ${dup} exact duplicates skipped` : ''}${fuzzy ? `, ${fuzzy} matched rows from other files marked duplicate` : ''}${(r.skipped || []).length ? `, ${(r.skipped || []).length} rows couldn't be read` : ''}. Money out: ${r.txns.filter((t) => t.amount > 0).length} rows.`);
  }
  const ym = (d) => d.slice(0, 7);
  const monthName = (m) => new Date(m + '-15').toLocaleDateString(undefined, { month: 'short', year: '2-digit' });
  function spAgg(forPlan) {
    const D = SPD(); const incl = forPlan ? false : D.includeModeled !== false; const all = !forPlan && D.view === 'all'; const covered = spCardPayCovered(D);
    // which accounts to count: combined (card purchases + other bank outflows), bank accounts only (card payments stand in
    // for card spending), or credit cards only
    const src = D.source || 'combined'; const isCardA = (t) => D.acctTypes[t.acct] === 'card';
    const sp = [];
    for (const t of D.txns) {
      if (t.kind === 'dup' || t.kind === 'income') continue;
      if (src === 'card' && !isCardA(t)) continue;
      if (src === 'bank' && (isCardA(t) || t.manual)) continue;
      if (t.kind === 'spend' || t.kind === 'refund') { if (incl || !SP_MODELED.includes(t.category)) sp.push(t); }
      else if (t.kind === 'cardpay' && (src === 'bank' || (D.countCardPay && !covered.has(t.id)))) sp.push({ ...t, category: CC_NODETAIL });
      else if (all && t.kind === 'transfer' && t.amount > 0 && src !== 'card') sp.push({ ...t, category: SAVED });
    }
    const months = {}; for (const t of sp) { const m = ym(t.date); const c = t.category || 'Other'; (months[m] = months[m] || {})[c] = (months[m][c] || 0) + t.amount; }
    const ms = Object.keys(months).sort(); return { sp, months, ms, incl, all, covered, src };
  }
  function spPie(A, ms) {
    const tot = {}; for (const m of ms) for (const [c, v] of Object.entries(A.months[m] || {})) tot[c] = (tot[c] || 0) + v;
    const rows = Object.entries(tot).filter(([, v]) => v > 0.5).sort((a, b) => b[1] - a[1]); const T = rows.reduce((a, [, v]) => a + v, 0); if (!T) return '<p class="note">No spending in this period.</p>';
    const R = 120, cx = 140, cy = 140; let ang = -Math.PI / 2, g = '';
    for (const [c, v] of rows) { const a2 = ang + v / T * 2 * Math.PI; const big = a2 - ang > Math.PI ? 1 : 0; const x1 = cx + R * Math.cos(ang), y1 = cy + R * Math.sin(ang), x2 = cx + R * Math.cos(a2), y2 = cy + R * Math.sin(a2);
      const d = rows.length === 1 ? `M ${cx - R} ${cy} A ${R} ${R} 0 1 1 ${cx + R} ${cy} A ${R} ${R} 0 1 1 ${cx - R} ${cy} Z` : `M ${cx} ${cy} L ${x1} ${y1} A ${R} ${R} 0 ${big} 1 ${x2} ${y2} Z`;
      g += `<path d="${d}" fill="${spColor(c)}" stroke="#fff" stroke-width="1.5" data-act="spCat" data-c="${esc(c)}" style="cursor:pointer"><title>${esc(c)}: ${usd(v)} (${(v / T * 100).toFixed(1)}%)</title></path>`;
      if (v / T > 0.06) { const mid = (ang + a2) / 2; g += `<text x="${cx + R * 0.65 * Math.cos(mid)}" y="${cy + R * 0.65 * Math.sin(mid) + 4}" text-anchor="middle" style="font-size:11px;fill:#fff;font-weight:600;pointer-events:none">${Math.round(v / T * 100)}%</text>`; }
      ang = a2; }
    g += `<circle cx="${cx}" cy="${cy}" r="${R * 0.42}" fill="#fff"/><text x="${cx}" y="${cy - 2}" text-anchor="middle" style="font-size:16px;font-weight:700">${k(T)}</text><text x="${cx}" y="${cy + 15}" text-anchor="middle" class="axis">${k(T / Math.max(1, ms.length))}/mo</text>`;
    const legend = rows.map(([c, v]) => `<tr><td><a href="#" data-act="spCat" data-c="${esc(c)}"><span class="lg"><i style="background:${spColor(c)}"></i></span>${esc(c)}</a></td><td class="n">${usd(v)}</td><td class="n">${(v / T * 100).toFixed(1)}%</td><td class="n mut">${k(v / Math.max(1, ms.length))}/mo</td></tr>`).join('');
    return `<div style="display:flex;gap:18px;flex-wrap:wrap;align-items:flex-start"><svg viewBox="0 0 280 280" style="width:280px;max-width:100%">${g}</svg>
      <div style="flex:1;min-width:280px"><table class="tbl"><thead><tr><th>Category</th><th class="n">Total</th><th class="n">Share</th><th class="n">Per month</th></tr></thead><tbody>${legend}</tbody></table></div></div>`;
  }
  function spChart(A, msIn) {
    const ms = msIn || A.ms.slice(-24); if (!ms.length) return '';
    const w = 760, h = 260, pad = { l: 56, r: 10, t: 10, b: 30 }; const tots = ms.map((m) => Object.values(A.months[m]).reduce((a, v) => a + Math.max(0, v), 0));
    const y1 = Math.max(1, ...tots) * 1.1; const bw = (w - pad.l - pad.r) / ms.length; const Y = (v) => h - pad.b - v / y1 * (h - pad.t - pad.b);
    let g = ''; for (let i = 0; i <= 4; i++) { const v = y1 * i / 4; g += `<line x1="${pad.l}" x2="${w - pad.r}" y1="${Y(v)}" y2="${Y(v)}" class="grid"/><text x="${pad.l - 6}" y="${Y(v) + 4}" class="axis" text-anchor="end">${k(v)}</text>`; }
    const cats = SPC_ALL.filter((c) => ms.some((m) => (A.months[m][c] || 0) > 0));
    ms.forEach((m, i) => { let acc = 0; const x = pad.l + i * bw + bw * 0.15;
      for (const c of cats) { const v = Math.max(0, A.months[m][c] || 0); if (!v) continue; g += `<rect x="${x}" y="${Y(acc + v)}" width="${bw * 0.7}" height="${Y(acc) - Y(acc + v)}" fill="${spColor(c)}"><title>${monthName(m)} · ${c}: ${usd(v)}</title></rect>`; acc += v; }
      g += `<rect data-act="spMonth" data-m="${m}" x="${pad.l + i * bw}" y="${pad.t}" width="${bw}" height="${h - pad.t - pad.b}" fill="#000" fill-opacity="0" style="cursor:pointer"><title>${monthName(m)}: ${usd(tots[i])} · click to filter</title></rect>`;
      if (ms.length <= 14 || i % Math.ceil(ms.length / 12) === 0) g += `<text x="${pad.l + i * bw + bw / 2}" y="${h - 10}" class="axis" text-anchor="middle">${monthName(m)}</text>`; });
    const avg = tots.reduce((a, b) => a + b, 0) / tots.length; g += `<line x1="${pad.l}" x2="${w - pad.r}" y1="${Y(avg)}" y2="${Y(avg)}" stroke="#16202e" stroke-dasharray="5 4"/><text x="${w - pad.r}" y="${Y(avg) - 4}" class="axis" text-anchor="end">avg ${k(avg)}/mo</text>`;
    return `<svg viewBox="0 0 ${w} ${h}" class="chart">${g}</svg>` + legendHTML(cats.map((c) => ({ name: c, color: spColor(c) })));
  }
  function spProjection(A) {
    const D = SPD(); const infl = (+plan().inflation || 2.5) / 100; const ms = A.ms; if (!ms.length) return null;
    // leave out the current, still-incomplete month; then take up to 12 months back
    const curM = new Date().toISOString().slice(0, 7); const done = ms.filter((m) => m < curM); const use = done.length ? done : ms;
    const last = use[use.length - 1]; const mi = (m) => +m.slice(0, 4) * 12 + +m.slice(5, 7) - 1;
    const win = use.filter((m) => mi(m) > mi(last) - 12); const n = Math.min(12, mi(last) - mi(win[0]) + 1);
    const byCat = {}, oneOff = {};
    for (const t of A.sp) { if (!win.includes(ym(t.date))) continue; const c = t.category || 'Other'; if (c === SAVED) continue; if (t.oneTime) oneOff[c] = (oneOff[c] || 0) + t.amount; else byCat[c] = (byCat[c] || 0) + t.amount; }
    const scale = 12 / Math.max(1, n); const proj = {}; for (const [c, v] of Object.entries(byCat)) proj[c] = Math.max(0, v * scale * (1 + infl));
    const total = Object.values(proj).reduce((a, b) => a + b, 0); const trailing = Object.values(byCat).reduce((a, b) => a + b, 0) + Object.values(oneOff).reduce((a, b) => a + b, 0);
    return { proj, total, n, win, scale, infl, trailing, oneOff: Object.values(oneOff).reduce((a, b) => a + b, 0), year: +last.slice(0, 4) + 1 };
  }
  // are all the cards you pay from the bank actually imported? compare payments with card purchases month by month
  function spCoverage(D) {
    const pays = D.txns.filter((t) => t.kind === 'cardpay'); if (!pays.length) return '';
    const cardSpend = D.txns.filter((t) => (t.kind === 'spend' || t.kind === 'refund') && D.acctTypes[t.acct] === 'card');
    const months = [...new Set(pays.map((t) => ym(t.date)))].sort();
    const paid = (m) => pays.filter((t) => ym(t.date) === m).reduce((a, t) => a + t.amount, 0);
    const bought = (m) => cardSpend.filter((t) => ym(t.date) === m).reduce((a, t) => a + t.amount, 0);
    const P0 = months.reduce((a, m) => a + paid(m), 0), B0 = months.reduce((a, m) => a + bought(m), 0);
    const issuers = {}; for (const t of pays) { const iss = (t.desc.match(/CHASE|AMEX|AMERICAN EXPRESS|CITI|DISCOVER|CAPITAL ONE|BARCLAY|APPLE|GSBANK|GOLDMAN|BANK OF AMERICA|BOFA|WELLS|US BANK|SYNCHRONY|FIDELITY/i) || ['other card'])[0].toUpperCase().replace('AMERICAN EXPRESS', 'AMEX').replace('GSBANK', 'APPLE').replace('GOLDMAN', 'APPLE'); issuers[iss] = (issuers[iss] || 0) + t.amount; }
    const cardAccts = Object.entries(D.acctTypes).filter(([, v]) => v === 'card').map(([a]) => a);
    const gap = P0 - B0; const short = gap > 0.1 * P0 && gap > 1000;
    return `<div class="${short ? 'banner' : 'note'}" style="margin-top:6px"><b>Card coverage check:</b> over the ${months.length} months with card payments, your bank paid ${usd(P0)} into cards (${Object.entries(issuers).map(([i, v]) => `${esc(i)} ${k(v)}`).join(', ')}), and the imported card files show ${usd(B0)} of purchases${cardAccts.length ? ` (${cardAccts.map(esc).join(', ')})` : ''}.
      ${short ? ` That's ${usd(gap)} less than you paid, so <b>some card activity is missing</b>: import the CSV for each card above, for the same months.` : ' They line up (payments lag purchases by about a month).'}</div>`;
  }
  // per-account list: type flag, totals, and a detail view of everything that left the account
  function spAccounts(D, A, importBox = '', imps = '') {
    const accts = [...new Set(D.txns.map((t) => t.acct))].sort();
    const rows = accts.map((a) => { const L = D.txns.filter((t) => t.acct === a); const out = L.filter((t) => t.amount > 0 && t.kind !== 'dup'); const dates = L.map((t) => t.date).sort();
      return `<tr class="${D.acctView === a ? 'sel' : ''}"><td><a href="#" data-act="spAcct" data-a="${esc(a)}"><b>${esc(a)}</b></a></td><td>${a === 'Manual' ? '<span class="mut">manual</span>' : `<select data-sp-acct-type="${esc(a)}"><option value="bank" ${D.acctTypes[a] !== 'card' ? 'selected' : ''}>Bank account</option><option value="card" ${D.acctTypes[a] === 'card' ? 'selected' : ''}>Credit card</option></select>`}</td><td>${dates[0] || ''} → ${dates[dates.length - 1] || ''}</td><td class="n">${L.length}</td><td class="n">${usd(-L.filter((t) => t.amount < 0 && t.kind !== 'dup').reduce((x, t) => x + t.amount, 0))}</td><td class="n">${usd(out.reduce((x, t) => x + t.amount, 0))}</td><td class="n">${usd(out.filter((t) => t.kind === 'spend').reduce((x, t) => x + t.amount, 0))}</td><td class="n">${L.filter((t) => t.kind === 'dup').length || '—'}</td><td style="white-space:nowrap"><a href="#" data-act="spRenameAcct" data-a="${esc(a)}">rename</a> · <a href="#" data-act="spDelAcct" data-a="${esc(a)}" class="neg">delete</a></td></tr>`; }).join('');
    let detail = '';
    const a = D.acctView && accts.includes(D.acctView) ? D.acctView : null;
    if (a) {
      const isCard = D.acctTypes[a] === 'card';
      const L = D.txns.filter((t) => t.acct === a && t.amount > 0 && t.kind !== 'dup').sort((x, y) => y.date.localeCompare(x.date));
      const meth = (t) => (isCard ? (t.kind === 'spend' ? 'Card purchase' : 'Other') : P.payMethod(t.desc, t.kind));
      const ms = [...new Set(L.map((t) => ym(t.date)))].sort(); const nm = Math.max(1, ms.length);
      const by = {}; for (const t of L) { const m = meth(t); (by[m] = by[m] || { n: 0, v: 0, list: [] }); by[m].n++; by[m].v += t.amount; by[m].list.push(t); }
      const payees = {}; for (const t of L.filter((x) => x.kind === 'spend')) { const kk = merchantKey(t.desc) || t.desc; (payees[kk] = payees[kk] || { n: 0, v: 0, cat: t.category }); payees[kk].n++; payees[kk].v += t.amount; }
      const top = Object.entries(payees).sort((x, y) => y[1].v - x[1].v).slice(0, 15);
      const fm = state.spAcctMethod || ''; const dir = state.spAcctDir || 'out';
      const ALL = D.txns.filter((t) => t.acct === a && t.kind !== 'dup').sort((x, y) => y.date.localeCompare(x.date)); const IN = ALL.filter((t) => t.amount < 0);
      const allMs = [...new Set(ALL.map((t) => ym(t.date)))].sort();
      const monthly = allMs.map((m) => { const o = ALL.filter((t) => ym(t.date) === m); const inn = -o.filter((t) => t.amount < 0).reduce((x, t) => x + t.amount, 0), out = o.filter((t) => t.amount > 0).reduce((x, t) => x + t.amount, 0);
        return `<tr><td>${monthName(m)}</td><td class="n">${o.filter((t) => t.amount < 0).length}</td><td class="n pos">${usd(inn)}</td><td class="n">${o.filter((t) => t.amount > 0).length}</td><td class="n">${usd(out)}</td><td class="n ${inn - out < 0 ? 'neg' : ''}">${usd(inn - out)}</td></tr>`; }).reverse().join('');
      const totIn = -IN.reduce((x, t) => x + t.amount, 0), totOut = L.reduce((x, t) => x + t.amount, 0);
      const base = dir === 'in' ? IN : dir === 'all' ? ALL : (fm ? (by[fm]?.list || []) : L);
      const list = base.slice(0, 1500);
      detail = `<div id="spAcct" style="margin-top:12px"><h4>${esc(a)} · money out <span class="sub">${ms[0] ? monthName(ms[0]) : ''} – ${ms.length ? monthName(ms[ms.length - 1]) : ''} · ${nm} months</span> <a href="#" data-act="spAcct" data-a="" class="mut">close</a></h4>
        <table class="tbl narrow2"><thead><tr><th>How it left</th><th class="n">Count</th><th class="n">Total</th><th class="n">Per month</th><th>Counted as spending?</th></tr></thead><tbody>
        ${Object.entries(by).sort((x, y) => y[1].v - x[1].v).map(([m, o]) => `<tr class="${fm === m ? 'sel' : ''}"><td><a href="#" data-act="spMethod" data-m="${esc(m)}">${esc(m)}</a></td><td class="n">${o.n}</td><td class="n">${usd(o.v)}</td><td class="n">${usd(o.v / nm)}</td><td>${/Credit-card payment/.test(m) ? '<span class="pill">no</span> <span class="mut">card purchases counted instead</span>' : /Transfer/.test(m) ? '<span class="pill">no</span> <span class="mut">saving</span>' : '<span class="pill ok">yes</span>'}</td></tr>`).join('')}
        <tr><td><b>Total out</b></td><td class="n">${L.length}</td><td class="n"><b>${usd(L.reduce((x, t) => x + t.amount, 0))}</b></td><td class="n">${usd(L.reduce((x, t) => x + t.amount, 0) / nm)}</td><td></td></tr></tbody></table>
        <h4>Debits and credits by month <span class="sub">${ALL.length} rows · in ${usd(totIn)} · out ${usd(totOut)} · net ${usd(totIn - totOut)}</span></h4>
        <div class="scroll" style="max-height:300px"><table class="tbl narrow2"><thead><tr><th>Month</th><th class="n"># in</th><th class="n">Money in</th><th class="n"># out</th><th class="n">Money out</th><th class="n">Net</th></tr></thead><tbody>${monthly}</tbody></table></div>
        <div class="two"><div><h4>Biggest payees</h4><table class="tbl"><thead><tr><th>Payee</th><th class="n">#</th><th class="n">Total</th><th>Category</th></tr></thead><tbody>${top.map(([p2, o]) => `<tr><td>${esc(p2)}</td><td class="n">${o.n}</td><td class="n">${usd(o.v)}</td><td class="mut">${esc(o.cat || '')}</td></tr>`).join('')}</tbody></table></div>
        <div><h4>${dir === 'in' ? 'Money in' : dir === 'all' ? 'Every row' : fm ? esc(fm) : 'All money out'} <span class="sub">${list.length}${base.length > list.length ? ' of ' + base.length : ''}</span>
          <span class="seg" style="margin-left:6px">${[['out', 'Out'], ['in', 'In'], ['all', 'All']].map(([v, l]) => `<button class="btn sm ${dir === v ? 'primary' : ''}" data-act="spDir" data-d="${v}">${l}</button>`).join(' ')}</span>${fm && dir === 'out' ? ` <a href="#" data-act="spMethod" data-m="" class="mut">all methods</a>` : ''}</h4>
          <div class="scroll" style="max-height:420px"><table class="tbl"><tbody>${list.map((t) => `<tr><td>${t.date}</td><td>${esc(t.desc)}</td><td class="n ${t.amount < 0 ? 'pos' : ''}">${t.amount < 0 ? '+' : '−'}${usd(Math.abs(t.amount), 2)}</td><td class="mut">${esc(t.kind === 'spend' ? t.category || '' : { cardpay: 'card payment', transfer: 'transfer', income: 'money in', refund: 'refund' }[t.kind] || t.kind)}</td></tr>`).join('')}</tbody></table></div></div></div></div>`;
    }
    return `<div class="card"><h3>Accounts <span class="sub">import activity · set each account as a bank account or credit card · click a name to see what left it</span></h3>
      ${importBox}
      <table class="tbl"><thead><tr><th>Account</th><th>Type</th><th>Dates</th><th class="n">Rows</th><th class="n">Money in</th><th class="n">Money out</th><th class="n">Counted as spending</th><th class="n">Duplicates</th><th></th></tr></thead><tbody>${rows}</tbody></table>
      <p class="note"><b>Credit card:</b> every charge is spending; only "payment received" lines are skipped. <b>Bank account:</b> payments into credit cards and transfers to your own accounts are skipped; checks, bill pay, ACH, Zelle, ATM and debit-card purchases count. The same transaction found in two files of one account (overlapping or different exports) is counted once.</p>${imps}${detail}</div>`;
  }
  function vSpending(snap, an) {
    const D = SPD(); const A = spAgg(); const PJ = spProjection(spAgg(true)); const F = (state.spFilter = state.spFilter || {});
    const yrs = [...new Set(A.ms.map((m) => m.slice(0, 4)))].sort(); const YV = yrs.includes(D.yearView) || D.yearView === 'all' ? D.yearView : 'last12';
    const viewMs = YV === 'all' ? A.ms : YV === 'last12' ? A.ms.slice(-12) : A.ms.filter((m) => m.startsWith(YV));
    const srcBar = `<div class="seg" style="margin:4px 0">${[['combined', 'Cards + bank (no double counting)'], ['bank', 'Bank accounts only'], ['card', 'Credit cards only']].map(([v, l]) => `<button class="btn sm ${(D.source || 'combined') === v ? 'primary' : ''}" data-act="spSource" data-s="${v}">${l}</button>`).join(' ')}
      <span class="mut" style="margin-left:6px">${{ combined: 'card purchases by category, plus checks, bills and transfers out of the bank; bank → card payments skipped', bank: 'everything that left your bank accounts; card payments count as one line (they pay for the card spending)', card: 'only purchases on your credit cards, by category' }[D.source || 'combined']}</span></div>`;
    const yearBar = `<div class="seg" style="margin:4px 0 8px">${[['last12', 'Last 12 months'], ...yrs.map((y) => [y, y]), ['all', 'All']].map(([v, l]) => `<button class="btn sm ${YV === v ? 'primary' : ''}" data-act="spYear" data-y="${v}">${l}</button>`).join(' ')}</div>`;
    const importBox = `<div style="display:flex;gap:10px;flex-wrap:wrap;align-items:flex-start;margin-bottom:8px">
      <div id="spDrop" class="drop" style="flex:1;min-width:260px;margin:0">Drop bank or credit-card CSVs here, or <label class="btn primary">Import files<input id="spIn" type="file" multiple accept=".csv,.txt" hidden></label></div>
      <details id="spManualBox" ${state.spManualOpen || !D.txns.length ? 'open' : ''} style="flex:1;min-width:260px"><summary class="btn">+ Add spending by hand</summary>${spManual()}</details></div>
      <p class="note">Download "Activity" or "Transactions" as CSV from each bank and card (Chase, Amex, Citi, Capital One, Apple Card, Bank of America, Wells Fargo, Fidelity, Schwab…). Files are read in this browser only. Card payments from your bank, the cards' "payment received" lines and transfers to your own accounts aren't double counted; card refunds reduce spending; re-importing overlapping dates skips duplicates.</p>`;
    if (!D.txns.length) return `<div class="card"><h3>Accounts <span class="sub">import bank and credit-card activity to see where money goes</span></h3>${importBox}</div>`;
    const now = new Date(); const yNow = now.getFullYear();
    const last12 = A.ms.slice(-12); const sum12 = last12.reduce((a, m) => a + Object.values(A.months[m]).reduce((x, v) => x + v, 0), 0);
    const ytd = A.ms.filter((m) => m.startsWith(String(yNow))).reduce((a, m) => a + Object.values(A.months[m]).reduce((x, v) => x + v, 0), 0);
    const xfers = D.txns.filter((t) => t.kind === 'transfer'); const xferAmt = xfers.reduce((a, t) => a + Math.abs(t.amount), 0);
    const modeledAmt = D.txns.filter((t) => (t.kind === 'spend' || t.kind === 'refund') && SP_MODELED.includes(t.category)).reduce((a, t) => a + t.amount, 0);
    const planCat = catTotal(plan());
    // what the Plan expects to leave the bank in its first year: living spending + homes + rental costs (rent income arrives separately)
    const planOut = (() => { try { const R0 = planResults(an).det.rows[0]; if (!R0) return { total: planCat, homes: 0, rentals: 0, health: 0 }; const f = 1 / R0.cpi;
      const homes = (R0.housingOut || 0) * f; const rentals = Object.values(R0.rentals || {}).reduce((a, d) => a + ((d.cashOpex || 0) + (d.interest || 0) + (d.principal || 0)) * f, 0);
      return { total: planCat + homes + rentals, homes, rentals, health: (R0.health || 0) * f }; } catch (e) { return { total: planCat, homes: 0, rentals: 0, health: 0 }; } })();
    const kpis = `<div class="kpis">
      <div class="kpi"><div class="kl">Last ${last12.length} months</div><div class="kv">${k(sum12)}</div><div class="ks">${k(sum12 / Math.max(1, last12.length))}/month · ${last12.length < 12 ? `annualized ${k(sum12 / Math.max(1, last12.length) * 12)}` : ''}</div></div>
      <div class="kpi"><div class="kl">${yNow} so far</div><div class="kv">${k(ytd)}</div><div class="ks">through ${A.ms.length ? monthName(A.ms[A.ms.length - 1]) : '—'}</div></div>
      <div class="kpi"><div class="kl">Projected ${PJ ? PJ.year : ''}</div><div class="kv">${PJ ? k(PJ.total) : '—'}</div><div class="ks">${PJ ? `from ${PJ.n} months × ${(1 + PJ.infl).toFixed(3)} inflation${PJ.oneOff ? `, excl. ${k(PJ.oneOff)} one-time` : ''}` : ''}</div></div>
      <div class="kpi"><div class="kl">Plan assumes</div><div class="kv">${k(planOut.total)}</div><div class="ks">“${esc(plan().name)}”, first year, today's $: living ${k(planCat)} + homes ${k(planOut.homes)} (mortgage, property tax, insurance, HOA, upkeep)${planOut.rentals ? ` + rentals ${k(planOut.rentals)} (mortgage, tax, insurance, operating costs)` : ''}${planOut.health ? `. Healthcare premiums ${k(planOut.health)} not included.` : ''}</div></div></div>`;
    const outs = (f) => D.txns.filter(f).reduce((a, t) => a + Math.abs(t.amount), 0); const cnt = (f) => D.txns.filter(f).length;
    const cpAll = (t) => t.kind === 'cardpay', cpCov = (t) => t.kind === 'cardpay' && A.covered.has(t.id), sav = (t) => t.kind === 'transfer' && t.amount > 0, cardIn = (t) => t.kind === 'transfer' && t.amount < 0;
    const dbl = `<table class="tbl narrow2" style="margin-top:8px"><thead><tr><th>Money out, by type</th><th class="n">Count</th><th class="n">Amount</th><th>In the totals?</th></tr></thead><tbody>
      <tr><td>Purchases, bills, checks, payments to people</td><td class="n">${cnt((t) => t.kind === 'spend')}</td><td class="n">${usd(outs((t) => t.kind === 'spend'))}</td><td><span class="pill ok">yes</span>${A.incl ? '' : ` <span class="mut">except mortgage, property tax and income tax (${usd(modeledAmt)})</span>`}</td></tr>
      <tr><td>Payments from bank accounts into credit cards</td><td class="n">${cnt(cpAll)}</td><td class="n">${usd(outs(cpAll))}</td><td>${D.countCardPay ? '<span class="pill ok">only unmatched ones</span>' : '<span class="pill">no</span> <span class="mut">the cards\' own purchases are counted instead</span>'}</td></tr>
      <tr><td>Credit-card purchases (from card files)</td><td class="n">${cnt((t) => t.kind === 'spend' && SPD().acctTypes[t.acct] === 'card')}</td><td class="n">${usd(outs((t) => t.kind === 'spend' && SPD().acctTypes[t.acct] === 'card'))}</td><td><span class="pill ok">yes</span> <span class="mut">included in the first row</span></td></tr>
      <tr><td class="mut">Duplicates (same account in two files)</td><td class="n">${cnt((t) => t.kind === 'dup')}</td><td class="n">${usd(outs((t) => t.kind === 'dup'))}</td><td class="mut">counted once</td></tr>
      <tr><td>Transfers to your own savings, brokerage, 529</td><td class="n">${cnt(sav)}</td><td class="n">${usd(outs(sav))}</td><td>${A.all ? '<span class="pill ok">yes</span> <span class="mut">“All money out” view</span>' : '<span class="pill">no</span> <span class="mut">it\'s saving, not spending</span>'}</td></tr>
      <tr><td class="mut">Card refunds</td><td class="n">${cnt((t) => t.kind === 'refund')}</td><td class="n">−${usd(outs((t) => t.kind === 'refund'))}</td><td class="mut">reduce spending</td></tr>
      <tr><td class="mut">Money in: paychecks, deposits; card “payment received” lines</td><td class="n">${cnt((t) => t.kind === 'income') + cnt(cardIn)}</td><td class="n">${usd(outs((t) => t.kind === 'income') + outs(cardIn))}</td><td class="mut">not spending</td></tr></tbody></table>
      ${spCoverage(D)}
      <p class="note"><label><input type="checkbox" data-sp-opt="viewAll" ${A.all ? 'checked' : ''}> Show <b>all money out</b>, including transfers to your own accounts</label> · <label><input type="checkbox" data-sp-opt="includeModeled" ${A.incl ? 'checked' : ''}> include mortgage, property tax and income tax</label> · <label><input type="checkbox" data-sp-opt="countCardPay" ${D.countCardPay ? 'checked' : ''}> count bank → card payments when that card's file isn't imported</label>. If something is in the wrong row, change its Type in the transaction list.</p>`;
    // monthly table: categories × last 12 months
    const cats = SPC_ALL.filter((c) => A.ms.some((m) => A.months[m][c]));
    const allMs = viewMs; const sumV = allMs.reduce((a, m) => a + Object.values(A.months[m]).reduce((x, v) => x + v, 0), 0);
    const mt = `<div class="scroll"><table class="tbl"><thead><tr><th>Category</th>${allMs.map((m) => `<th class="n"><a href="#" data-act="spMonth" data-m="${m}">${monthName(m)}</a></th>`).join('')}<th class="n">Total</th><th class="n">Avg/mo</th></tr></thead><tbody>
      ${cats.map((c) => { const vals = allMs.map((m) => A.months[m][c] || 0); const t = vals.reduce((a, b) => a + b, 0); return `<tr><td><span class="lg"><i style="background:${spColor(c)}"></i></span>${c}</td>${vals.map((v) => `<td class="n">${v ? k(v) : '<span class="mut">—</span>'}</td>`).join('')}<td class="n"><b>${k(t)}</b></td><td class="n">${k(t / Math.max(1, allMs.length))}</td></tr>`; }).join('')}
      <tr><td><b>Total</b></td>${allMs.map((m) => `<td class="n"><b>${k(Object.values(A.months[m]).reduce((a, v) => a + v, 0))}</b></td>`).join('')}<td class="n"><b>${k(sumV)}</b></td><td class="n"><b>${k(sumV / Math.max(1, allMs.length))}</b></td></tr></tbody></table></div>`;
    // annual table
    const years = [...new Set(A.ms.map((m) => m.slice(0, 4)))].sort();
    const at = `<table class="tbl narrow2"><thead><tr><th>Category</th>${years.map((y) => `<th class="n">${y}${A.ms.filter((m) => m.startsWith(y)).length < 12 ? `<div class="mut" style="font-size:10.5px">${A.ms.filter((m) => m.startsWith(y)).length} mo</div>` : ''}</th>`).join('')}${PJ ? `<th class="n">${PJ.year} projected</th>` : ''}</tr></thead><tbody>
      ${cats.map((c) => `<tr><td>${c}</td>${years.map((y) => { const v = A.ms.filter((m) => m.startsWith(y)).reduce((a, m) => a + (A.months[m][c] || 0), 0); return `<td class="n">${v ? k(v) : '—'}</td>`; }).join('')}${PJ ? `<td class="n">${PJ.proj[c] ? k(PJ.proj[c]) : '—'}</td>` : ''}</tr>`).join('')}
      <tr><td><b>Total</b></td>${years.map((y) => `<td class="n"><b>${k(A.ms.filter((m) => m.startsWith(y)).reduce((a, m) => a + Object.values(A.months[m]).reduce((x, v) => x + v, 0), 0))}</b></td>`).join('')}${PJ ? `<td class="n"><b>${k(PJ.total)}</b></td>` : ''}</tr></tbody></table>`;
    // projection vs plan
    let pj = '';
    const houseAct = PJ ? D.txns.filter((t) => (t.kind === 'spend' || t.kind === 'refund') && SP_MODELED.slice(0, 2).includes(t.category) && PJ.win.includes(ym(t.date))).reduce((a, t) => a + t.amount, 0) * PJ.scale * (1 + PJ.infl) : 0;
    if (PJ) { const mapped = {}; for (const [c, v] of Object.entries(PJ.proj)) { if (SP_MODELED.includes(c)) continue; const pc = SP_TO_PLAN[c] || 'Other discretionary'; mapped[pc] = (mapped[pc] || 0) + v; }
      const pcs = plan().spending.categories; const names = [...new Set([...pcs.map((c) => c.name), ...Object.keys(mapped)])];
      pj = `<div class="card"><h3>${PJ.year} spending projection <span class="sub">${PJ.n < 12 ? `${PJ.n} complete months of data, scaled to a year` : 'last 12 complete months'} + ${(PJ.infl * 100).toFixed(1)}% inflation, one-time items left out</span></h3>
        <table class="tbl narrow2"><thead><tr><th>Plan category</th><th class="n">From your spending</th><th class="n">Plan assumes now</th><th class="n">Difference</th></tr></thead><tbody>
        ${names.map((n) => { const a = mapped[n] || 0, b = +(pcs.find((c) => c.name === n)?.amount || 0); const d = a - b; return `<tr><td>${esc(n)}</td><td class="n">${k(a)}</td><td class="n">${k(b)}</td><td class="n ${Math.abs(d) > 0.15 * Math.max(a, b) && Math.abs(d) > 2000 ? 'warnc' : ''}">${Math.abs(d) < 500 ? '—' : (d > 0 ? '+' : '−') + k(Math.abs(d))}</td></tr>`; }).join('')}
        <tr><td><b>Total living spending</b></td><td class="n"><b>${k(Object.values(mapped).reduce((a, b) => a + b, 0))}</b></td><td class="n"><b>${k(planCat)}</b></td><td></td></tr>
        <tr><td>Mortgage, property tax, HOA <span class="mut">(Plan: homes + rentals)</span></td><td class="n">${k(houseAct)}</td><td class="n">${k(planOut.homes + planOut.rentals)}</td><td class="n mut">insurance and upkeep are in the living rows above for actual spending</td></tr>
        <tr><td><b>Everything paid out</b></td><td class="n"><b>${k(Object.values(mapped).reduce((a, b) => a + b, 0) + houseAct)}</b></td><td class="n"><b>${k(planOut.total)}</b></td><td></td></tr></tbody></table>
        <p><button class="btn primary" data-act="spToPlan">Use these amounts in “${esc(plan().name)}”</button> ${state.settings.spending.source === 'manual' ? '' : '<!--'}<button class="btn" data-act="spToSettings">Use ${k(Object.values(mapped).reduce((a, b) => a + b, 0))} as the cash-buffer spending</button>${state.settings.spending.source === 'manual' ? '' : '-->'}</p>
        <p class="note">Mark big one-offs (a roof, a car, a wedding) as one-time in the list below so they don't inflate the projection; put recurring ones like college in the Plan's extra expenses instead. Mortgage, property tax and income tax stay out because the Plan models them from your homes and tax engine.</p></div>`; }
    // transactions
    const fm = F.month || '', fc = F.cat || '', fk = F.kind || 'spending', fq = (F.q || '').toLowerCase();
    let list = D.txns.filter((t) => (!fm || ym(t.date) === fm) && (!F.year || t.date.startsWith(F.year)) && (!fc || (fc === CC_NODETAIL ? t.kind === 'cardpay' : fc === SAVED ? t.kind === 'transfer' && t.amount > 0 : t.category === fc)) && (fk === 'all' || (fk === 'spending' ? t.kind === 'spend' || t.kind === 'refund' || (t.kind === 'cardpay' && (A.src === 'bank' || (D.countCardPay && !A.covered.has(t.id)))) || (A.all && t.kind === 'transfer' && t.amount > 0) : t.kind === fk)) && (!fq || t.desc.toLowerCase().includes(fq) || (t.acct || '').toLowerCase().includes(fq)));
    list.sort((a, b) => b.date.localeCompare(a.date)); const shown = list.slice(0, 300);
    const catSel = (t) => `<select data-sp-cat="${esc(t.id)}">${SPC.map((c) => `<option ${t.category === c ? 'selected' : ''}>${c}</option>`).join('')}</select>`;
    const kindSel = (t) => `<select data-sp-kind="${esc(t.id)}">${[['spend', 'Spending'], ['refund', 'Refund'], ['cardpay', 'Credit-card payment'], ['transfer', 'Transfer to own account'], ['income', 'Money in'], ['dup', 'Duplicate']].map(([v, l]) => `<option value="${v}" ${t.kind === v ? 'selected' : ''}>${l}</option>`).join('')}</select>`;
    const rows = shown.map((t) => `<tr><td>${t.date}</td><td>${esc(t.desc)}<div class="mut" style="font-size:11px">${esc(t.acct || '')}${t.matched ? ' · matched to a card payment' : ''}</div></td><td class="n ${t.amount < 0 ? 'pos' : ''}">${usd(t.amount, 2)}</td><td>${t.kind === 'spend' || t.kind === 'refund' ? catSel(t) : '<span class="mut">—</span>'}</td><td>${kindSel(t)}</td><td><label class="mut"><input type="checkbox" data-sp-one="${esc(t.id)}" ${t.oneTime ? 'checked' : ''}> one-time</label></td><td>${t.kind === 'dup' ? `<a href="#" data-act="spUndup" data-id="${esc(t.id)}" title="duplicate of another file's row">not a duplicate</a>` : ''}${t.kind === 'spend' ? `<a href="#" data-act="spRule" data-id="${esc(t.id)}" title="Always use this category for ${esc(merchantKey(t.desc))}">rule</a>` : ''} <a href="#" data-act="spDel" data-id="${esc(t.id)}" title="delete">✕</a></td></tr>`).join('');
    const filt = `<div class="skbar" style="flex-wrap:wrap;gap:6px"><select data-sp-f="year"><option value="">All years</option>${yrs.slice().reverse().map((y) => `<option ${F.year === y ? 'selected' : ''}>${y}</option>`).join('')}</select> <select data-sp-f="month"><option value="">All months</option>${A.ms.slice().reverse().map((m) => `<option value="${m}" ${fm === m ? 'selected' : ''}>${monthName(m)}</option>`).join('')}</select>
      <select data-sp-f="cat"><option value="">All categories</option>${SPC_ALL.map((c) => `<option ${fc === c ? 'selected' : ''}>${c}</option>`).join('')}</select>
      <select data-sp-f="kind">${[['spending', 'Spending + refunds'], ['cardpay', 'Credit-card payments'], ['transfer', 'Transfers'], ['income', 'Money in'], ['dup', 'Duplicates'], ['all', 'Everything']].map(([v, l]) => `<option value="${v}" ${fk === v ? 'selected' : ''}>${l}</option>`).join('')}</select>
      <input data-sp-f="q" placeholder="search merchant or account" value="${esc(F.q || '')}"> <span class="mut">${list.length} shown${list.length > 300 ? ' (first 300)' : ''} · total ${usd(list.reduce((a, t) => a + t.amount, 0))}</span></div>`;
    const imps = `<details><summary><b>Imported files (${D.imports.length})</b></summary><table class="tbl"><thead><tr><th>File</th><th>Account</th><th>Type</th><th>Dates</th><th class="n">Added</th><th></th></tr></thead><tbody>
      ${D.imports.map((x, i) => `<tr><td>${esc(x.file)}</td><td>${esc(x.acct)}</td><td>${x.isCard ? 'credit card' : 'bank'}</td><td>${x.from || ''} → ${x.to || ''}</td><td class="n">${x.added}${x.dup ? ` <span class="mut">(${x.dup} dup)</span>` : ''}${x.skipped ? `<div class="warnc" style="font-size:11px" title="${esc((x.skippedEx || []).join('\n'))}">${x.skipped} rows not read (hover)</div>` : ''}</td><td><a href="#" data-act="spFlip" data-i="${i}" title="if purchases show up as income">flip signs</a> · <a href="#" data-act="spDelImp" data-i="${i}">remove</a></td></tr>`).join('')}</tbody></table></details>`;
    const CV = D.chartView === 'pie' ? 'pie' : 'bars'; const TV = D.tableView === 'year' ? 'year' : 'month';
    const viewBar = `<div class="seg" style="margin:4px 0 8px">${[['bars', 'Monthly bars'], ['pie', 'Totals pie']].map(([v, l]) => `<button class="btn sm ${CV === v ? 'primary' : ''}" data-act="spChartView" data-v="${v}">${l}</button>`).join(' ')}</div>`;
    const tableBar = `<div class="seg" style="margin:14px 0 6px">${[['month', `By month (${YV === 'last12' ? 'last 12' : YV === 'all' ? 'all' : YV})`], ['year', 'By year']].map(([v, l]) => `<button class="btn sm ${TV === v ? 'primary' : ''}" data-act="spTableView" data-v="${v}">${l}</button>`).join(' ')}</div>`;
    const periodLabel = YV === 'last12' ? 'last 12 months' : YV === 'all' ? 'all months' : YV;
    return kpis + `<div class="card"><h3>${A.all ? 'Money out' : 'Spending'} <span class="sub">${periodLabel} · ${CV === 'pie' ? 'click a slice to see its transactions' : 'click a month to see its transactions'}</span></h3>${srcBar}${yearBar}${viewBar}
        ${CV === 'pie' ? spPie(A, viewMs) : spChart(A, viewMs)}
        <details id="spTables" ${D.tablesOpen ? 'open' : ''} style="margin-top:10px"><summary><b>Tables by category</b> <span class="sub">by month or by year</span></summary>${tableBar}${TV === 'year' ? at : mt}</details>
        <details style="margin-top:10px"><summary><b>What's counted</b> <span class="sub">money out by type, double-counting check</span></summary>${dbl}</details></div>`
      + spAccounts(D, A, importBox, imps) + pj
      + `<div class="card" id="spTx"><h3>Transactions</h3>${filt}<div class="scroll" style="max-height:520px"><table class="tbl"><thead><tr><th>Date</th><th>Description</th><th class="n">Amount</th><th>Category</th><th>Type</th><th></th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
        <p class="note">Change a category or type here. “rule” remembers the category for that merchant on every past and future import.</p></div>`;
  }
  function spManual() {
    return `<div style="margin-top:8px"><p class="mut" style="margin:0 0 4px">Cash, checks or accounts you don't export.</p><div class="grid4 tight">
      <label class="fld"><span>Date</span><input id="spmD" type="date" value="${new Date().toISOString().slice(0, 10)}"></label>
      <label class="fld"><span>Description</span><input id="spmT" placeholder="e.g. Roof repair"></label>
      <label class="fld"><span>Amount</span><input id="spmA" class="num" placeholder="0"></label>
      <label class="fld"><span>Category</span><select id="spmC">${SPC.map((c) => `<option>${c}</option>`).join('')}</select></label>
      <label class="fld chk"><input id="spmO" type="checkbox"><span>One-time (leave out of the projection)</span></label>
      <label class="fld"><span>Repeat monthly for</span><input id="spmR" class="num" placeholder="1" title="months"><span class="hint">months, e.g. 12 for a monthly bill</span></label></div>
      <p><button class="btn primary" data-act="spAdd">Add</button></p></div>`;
  }
  function bindSpending() {
    const drop = $('#spDrop'), inp = $('#spIn'); if (!drop) return;
    ['dragover', 'dragenter'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, () => drop.classList.remove('over')));
    drop.addEventListener('drop', (e) => { e.preventDefault(); handleFiles(e.dataTransfer.files); });
    inp.addEventListener('change', () => handleFiles(inp.files));
  }
  // ---------- NAVIGATION: 6 jobs → sub-pages ----------
  // state.tab is always a page ("leaf"); groups decide the top tabs and the sub-tab bar.
  const GROUPS = [
    ['home', 'Home', [['home', 'Home']]],
    ['review', 'Review', [['review', 'Quarterly'], ['yearend', 'Year-end'], ['annual', 'Annual reset']]],
    ['money', 'Money', [['accounts', 'Net worth'], ['spending', 'Spending'], ['rentals', 'Rentals'], ['history', 'History']]],
    ['taxes', 'Taxes', [['taxes', 'This year'], ['returns', 'Returns'], ['filing', 'Filing']]],
    ['plan', 'Plan', [['plan', 'Plan']]],
    ['settings', 'Settings', [['import', 'Data & import'], ['settings', 'Rules & reference'], ['help', 'How to use']]],
  ];
  const groupOfLeaf = (leaf) => (GROUPS.find(([, , L]) => L.some(([id]) => id === leaf)) || GROUPS[0])[0];
  // Review opens on the page the calendar calls for
  function reviewDefault() { const m = new Date().getMonth(); return m >= 9 ? 'yearend' : m <= 3 ? 'annual' : 'review'; }
  function goGroup(g) {
    state.lastLeaf = state.lastLeaf || {};
    if (g === 'review') return state.lastLeaf.review && state.reviewSession === sessionId ? state.lastLeaf.review : reviewDefault();
    if (g === 'plan' && !state.planVisited) { state.planTab = 'setup'; state.planVisited = true; }
    return state.lastLeaf[g] || GROUPS.find(([id]) => id === g)[2][0][0];
  }
  const sessionId = Math.random().toString(36).slice(2);
  // little dots on top tabs for things that need attention
  function navBadges(an) {
    const b = {}; const today = new Date();
    try { const est = estPlan(today.getFullYear()); const nx = est.rows.find((r) => r.d >= new Date(today.toDateString())); if (nx && ((nx.fed || 0) + (nx.ca || 0)) > 0 && (nx.d - today) / 864e5 <= 21) b.taxes = `estimated tax due ${dstr(nx.d)}`; } catch (e) { }
    if (!b.taxes && today.getMonth() <= 3 && !(state.filing || {})[`${today.getFullYear() - 1}:import`]) b.taxes = `file ${today.getFullYear() - 1} taxes by Apr 15`;
    const D = state.spending; const lastImp = D && D.imports && D.imports.length ? D.imports.map((x) => x.at || '').sort().pop() : null;
    const stmtAge = (today - new Date(cur().asOf)) / 864e5;
    if (stmtAge > 100) b.money = 'statements are over 3 months old';
    else if (lastImp && (today - new Date(lastImp)) / 864e5 > 30) b.money = 'spending imports are over a month old';
    if (an && ['refill', 'defensive', 'emergency'].includes(an.mode)) b.review = an.verdict.title;
    return b;
  }
  function navHTML(an) {
    const g = groupOfLeaf(state.tab); const B = navBadges(an);
    $('#tabs').innerHTML = GROUPS.map(([id, l]) => `<button class="tab ${g === id ? 'on' : ''}" data-group="${id}" ${B[id] ? `title="${esc(B[id])}"` : ''}>${l}${B[id] ? ' <span class="tabdot"></span>' : ''}</button>`).join('');
    const L = GROUPS.find(([id]) => id === g)[2];
    return L.length > 1 ? `<div class="subnav">${L.map(([id, l]) => `<button class="stab ${state.tab === id ? 'on' : ''}" data-tab="${id}">${l}</button>`).join('')}</div>` : '';
  }
  function nextStep(label, tab, extra = '') { return `<div class="card nextstep"><a href="#" data-tab="${tab}" ${extra}><b>Next: ${label} →</b></a></div>`; }
  // ---------- HOME ----------
  function vHome(snap, an) {
    if (!snap.accounts.length && !(snap.realEstate || []).some((p) => +p.value)) return vReview(snap, an); // welcome page
    const S = state.settings; const B = navBadges(an); const today = new Date();
    const actions = [];
    const v = an.verdict; actions.push([v.title, esc(v.line.replace(/ (The plan below|Plan below)[^.]*\./, '')), 'review', v.color === 'green' ? 'ok' : v.color === 'red' ? 'red' : 'amber']);
    try { const T = allocTarget(); const D = portfolioData(an); const inv = D.invested - (T.countSingles ? 0 : D.tot.single); if (inv > 1) { const usP = (D.tot.us + (T.countSingles ? D.tot.single : 0)) / inv * 100, bdP = D.tot.bond / inv * 100; const off = Math.max(Math.abs(usP + D.tot.intl / inv * 100 - T.stock), Math.abs(bdP - T.bond)); if (off > T.band) actions.push(['Rebalance', `Stocks/bonds are ${off.toFixed(0)} points off your ${T.stock}/${T.bond} target.`, 'review', 'amber']); } } catch (e) { }
    if (B.taxes) actions.push(['Taxes', esc(B.taxes), /file/.test(B.taxes) ? 'filing' : 'taxes', 'amber']);
    if (B.money) actions.push(['Update your data', esc(B.money), /statements/.test(B.money) ? 'import' : 'spending', 'amber']);
    if (today.getMonth() >= 9) actions.push(['Year-end window', `${Math.ceil((new Date(today.getFullYear(), 11, 31) - today) / 864e5)} days to Dec 31.`, 'yearend', '']);
    if (!state.snapshots.length || (today - new Date(state.snapshots[state.snapshots.length - 1].asOf)) / 864e5 > 95) actions.push(['Save a snapshot', 'No snapshot this quarter yet; save one after updating balances.', 'review', '']);
    const kp = `<div class="kpis"><div class="kpi"><div class="kl">Net worth</div><div class="kv">${k(an.s.total)}</div><div class="ks">liquid ${k(an.s.liquid)} · as of ${snap.asOf}</div></div>
      <div class="kpi"><div class="kl">Cash</div><div class="kv">${k(an.cash)}</div><div class="ks">${an.working ? `emergency target ${k(an.floor)}` : `buffer target ${k(an.target)} · ${an.runwayMonths.toFixed(0)} months`}</div></div>
      <div class="kpi"><div class="kl">${an.Y} income tax (est.)</div><div class="kv">${k(an.taxAfter.total)}</div><div class="ks">MAGI ${k(an.magiAfter.value)}</div></div>
      <div class="kpi"><div class="kl">${CS()}</div><div class="kv ${an.s.googPct > S.trim.googConcentrationMax ? 'warnc' : ''}">${pct(an.s.googPct, 0)}</div><div class="ks">limit ${S.trim.googConcentrationMax}%</div></div></div>`;
    const act = `<div class="card"><h3>What needs attention</h3><table class="tbl"><tbody>${actions.map(([t, d, tab, c]) => `<tr><td style="width:180px"><a href="#" data-tab="${tab}"><b>${t}</b></a>${c ? ` <span class="pill ${c}">${c === 'ok' ? 'ok' : c === 'red' ? 'act' : 'now'}</span>` : ''}</td><td>${d}</td><td style="width:60px"><a href="#" data-tab="${tab}">open →</a></td></tr>`).join('')}</tbody></table></div>`;
    const who = `<div class="card"><h3>How the app is organized</h3><table class="tbl"><tbody>
      <tr><td><b>Review</b></td><td>Quarterly check-in (cash buffer, sale plan, rebalance, loss harvesting) · Year-end income and tax plan (Oct–Dec) · Annual reset (Jan–Apr)</td></tr>
      <tr><td><b>Money</b></td><td>Net worth, spending, rentals and history: the data you keep up to date</td></tr>
      <tr><td><b>Taxes</b></td><td>This year's estimate and estimated payments · imported returns · filing checklist</td></tr>
      <tr><td><b>Plan</b></td><td>Assumptions and the long-term model: Monte Carlo, strategies, comparisons</td></tr>
      <tr><td><b>Import</b> (top right)</td><td>Any file: statements → Net worth, bank/card CSVs → Spending, tax returns → Taxes, ProjectionLab → Plan</td></tr></tbody></table></div>`;
    return goalsCard(an) + calendarCard(an) + kp + act + who;
  }
  // header Import: one button for every kind of file
  function bindGlobalImport() {
    const inp = $('#globalIn'); if (!inp || inp.dataset.bound) return; inp.dataset.bound = '1';
    inp.addEventListener('change', async () => {
      const files = [...inp.files]; const before = pending.length;
      const pl = files.filter((f) => /projectionlab/i.test(f.name) || /\.json$/i.test(f.name)); const rest = files.filter((f) => !pl.includes(f));
      for (const f of pl) { try { const r = L.parsePLAny(await f.text()); if (r.kind === 'json') { state.plImport = { file: f.name, loadedAt: new Date().toISOString().slice(0, 10), ...r }; } else if (r.kind === 'csv-income') plan().plInc = { file: f.name, ...r }; else if (r.kind === 'csv') plan().pl = { file: f.name, ...r }; state.tab = 'plan'; state.planTab = 'compare'; state.cmpView = 'pl'; toast(`${f.name}: ProjectionLab data loaded.`); } catch (e) { rest.push(f); } }
      if (rest.length) await handleFiles(rest);
      if (pending.length > before) { state.tab = 'import'; toast('Statements read. Review them and click Apply to working copy.'); }
      save(); render(); inp.value = '';
    });
  }
  // ---------- HISTORY ----------
  function priceLog() {
    const mk = cur().manual.market || {}; const H = mk.hist || {}; const keys = Object.keys(H).filter((k) => H[k].length);
    if (!keys.length) return `<div class="card"><h3>Daily price log</h3><p class="note">Empty so far. Each time prices are fetched on Quarterly Review, the day's price for every market is saved here and kept in your auto-save file. Open the app on market days to build the record.</p></div>`;
    const label = (k) => { const [b, px] = k.split('@'); const m = MKT.find((x) => x.k === b); return (m ? m.name.replace(/ \(.*\)/, '') : b) + (px ? ` (${px})` : ''); };
    const days = [...new Set(keys.flatMap((k) => H[k].map((p) => new Date(p[0]).toLocaleDateString('en-CA'))))].sort().reverse();
    const val = (k, d) => { const p = H[k].find((x) => new Date(x[0]).toLocaleDateString('en-CA') === d); return p ? p[1] : null; };
    const csv = ['date,' + keys.map(label).join(',')].concat(days.slice().reverse().map((d) => d + ',' + keys.map((k) => val(k, d) ?? '').join(','))).join('\n');
    const href = 'data:text/csv;charset=utf-8,' + encodeURIComponent(csv);
    return `<div class="card"><h3>Daily price log <span class="sub">${days.length} day(s) saved locally · since ${days[days.length - 1]}</span> <a class="btn sm" style="margin-left:auto" href="${href}" download="market-prices.csv">Download CSV</a></h3>
      <div class="scroll" style="max-height:300px"><table class="tbl"><thead><tr><th>Date</th>${keys.map((k) => `<th class="n">${esc(label(k))}</th>`).join('')}</tr></thead><tbody>${days.slice(0, 120).map((d) => `<tr><td>${d}</td>${keys.map((k) => { const v = val(k, d); return `<td class="n">${v == null ? '—' : v.toLocaleString(undefined, { maximumFractionDigits: 2 })}</td>`; }).join('')}</tr>`).join('')}</tbody></table></div>
      <p class="note">One price per market per day (the latest fetched that day), kept for 2 years in your data and auto-save file. Index rows marked (SPY), (DIA), (QQQ) are ETF prices from Finnhub; they're logged separately from index levels so charts never mix the two.</p></div>`;
  }
  function marketHistory(snaps) {
    const has = snaps.filter((s) => s.summary.market && Object.keys(s.summary.market).length);
    if (!has.length) return `<div class="card"><h3>Markets at each snapshot</h3><p class="note">Market prices are saved with each new snapshot once they've been fetched on Quarterly Review.</p></div>`;
    const cols = MKT.filter((m) => has.some((s) => s.summary.market[m.k]));
    const base = {}; cols.forEach((m) => (base[m.k] = (has.find((s) => s.summary.market[m.k]) || {}).summary.market[m.k]));
    const pal = { spx: '#3b6fd8', dji: '#16202e', ndx: '#8d7ad6', xau: '#d4af37', xag: '#9aa3ad', btc: '#f7931a', eth: '#627eea' };
    const ch = has.length > 1 ? lineChart(cols.map((m) => ({ name: m.name.replace(/ \(.*\)/, ''), color: pal[m.k], pts: has.map((s, i) => [i, s.summary.market[m.k] ? (s.summary.market[m.k] / base[m.k] - 1) * 100 : null]).filter((p) => p[1] != null) })), { xLabels: has.map((s) => s.asOf.slice(0, 7)), yFmt: (v) => v.toFixed(0) + '%', h: 220 }) : '';
    return `<div class="card"><h3>Markets at each snapshot <span class="sub">${has.length > 1 ? '% change since the first snapshot' : ''}</span></h3>${ch}
      <table class="tbl"><thead><tr><th>Snapshot</th>${cols.map((m) => `<th class="n">${m.name.replace(/ \(.*\)/, '')}</th>`).join('')}<th class="n">S&P below high</th></tr></thead><tbody>${has.slice().reverse().map((s) => `<tr><td>${s.asOf}</td>${cols.map((m) => `<td class="n">${s.summary.market[m.k] != null ? s.summary.market[m.k].toLocaleString(undefined, { maximumFractionDigits: m.dec }) + (s.summary.market[m.k + 'Proxy'] ? ` <span class="note">(${s.summary.market[m.k + 'Proxy']})</span>` : '') : '—'}</td>`).join('')}<td class="n">${s.summary.market.spDrawdownPct != null ? s.summary.market.spDrawdownPct + '%' : '—'}</td></tr>`).join('')}</tbody></table></div>`;
  }
  function vHistory(snap, an) {
    const snaps = state.snapshots.slice().sort((a, b) => a.asOf.localeCompare(b.asOf));
    const saveCard = `<div class="card"><h3>Snapshots <span class="sub">Each one freezes the account balances, manual inputs and summary metrics on that date</span></h3>
      <p>The working copy updates automatically as you import or edit. Click <b>Save snapshot</b> (top right) at each quarterly review to add a point to this history.</p>
      <button class="btn primary" data-act="saveSnap">Save snapshot now</button> <button class="btn" data-act="resummarize">Recalculate summaries with current settings</button></div>`;
    if (!snaps.length) return priceLog() + saveCard;
    const labels = snaps.map((s) => s.asOf.slice(0, 7));
    const idx = (i) => i;
    const S = (s) => s.summary;
    const last = snaps[snaps.length - 1], prev = snaps[snaps.length - 2];
    const delta = (f) => prev ? f(S(last)) - f(S(prev)) : null;
    const dchip = (d) => d == null ? '' : `<span class="${d >= 0 ? 'pos' : 'neg'}">${d >= 0 ? '▲' : '▼'} ${k(Math.abs(d))}</span> vs ${prev.asOf}`;
    const kpis = `<div class="kpis">
      <div class="kpi"><div class="kl">Net worth (${last.asOf})</div><div class="kv">${k(S(last).netWorth)}</div><div class="ks">${dchip(delta((x) => x.netWorth))}</div></div>
      <div class="kpi"><div class="kl">Liquid</div><div class="kv">${k(S(last).liquid ?? S(last).netWorth)}</div><div class="ks">${dchip(delta((x) => x.liquid ?? x.netWorth))}</div></div>
      <div class="kpi"><div class="kl">Cash buffer</div><div class="kv">${k(S(last).cash)}</div><div class="ks">${dchip(delta((x) => x.cash))}</div></div>
      <div class="kpi"><div class="kl">${CS()} share</div><div class="kv">${pct(S(last).googPct, 0)}</div><div class="ks">${prev ? `${pct(S(prev).googPct, 0)} at ${prev.asOf}` : ''}</div></div></div>`;
    const multi = snaps.length > 1;
    const nwChart = multi ? lineChart([
      { name: 'Net worth', color: '#16202e', pts: snaps.map((s, i) => [idx(i), S(s).netWorth]) },
      { name: 'Liquid', color: '#3b6fd8', pts: snaps.map((s, i) => [idx(i), S(s).liquid ?? S(s).netWorth]) },
      { name: 'Taxable', color: '#6aa5f0', dash: true, pts: snaps.map((s, i) => [idx(i), S(s).byTax.taxable || 0]) },
      { name: 'Pre-tax', color: '#e2733a', dash: true, pts: snaps.map((s, i) => [idx(i), S(s).byTax.pretax || 0]) },
      { name: 'Roth', color: '#3aa17e', dash: true, pts: snaps.map((s, i) => [idx(i), S(s).byTax.roth || 0]) }], { xLabels: labels }) : '<p class="note">Charts appear once you have two or more snapshots.</p>';
    const bufChart = multi ? lineChart([{ name: 'Cash buffer', color: '#c9b458', pts: snaps.map((s, i) => [i, S(s).cash]) }, { name: '' + CS() + ' value', color: '#e2733a', pts: snaps.map((s, i) => [i, S(s).goog]) }, { name: 'Est. MAGI', color: '#8d7ad6', dash: true, pts: snaps.map((s, i) => [i, S(s).magiEst || 0]) }], { xLabels: labels, h: 220 }) : '';
    const rows = snaps.slice().reverse().map((s) => `<tr><td><b>${s.asOf}</b><div class="note">${esc(s.note || '')}</div></td><td class="n">${usd(S(s).netWorth)}</td><td class="n">${usd(S(s).liquid ?? S(s).netWorth)}</td><td class="n">${usd(S(s).cash)}</td><td class="n">${pct(S(s).googPct, 0)}</td><td class="n">${usd(S(s).magiEst)}</td><td>${esc(S(s).verdict || '')}</td>
      <td class="nowrap"><button class="btn sm" data-act="restoreSnap" data-id="${s.id}" title="Load into working copy">Load</button> <button class="btn sm" data-act="noteSnap" data-id="${s.id}">Note</button> <button class="btn sm" data-act="delSnap" data-id="${s.id}">✕</button></td></tr>`).join('');
    // account matrix (last 8 snapshots)
    const cols = snaps.slice(-8);
    const names = {}; cols.forEach((s) => (S(s).accounts || []).forEach((a) => (names[a.key] = names[a.key] || { name: a.name, taxType: a.taxType })));
    const mrows = Object.entries(names).map(([key, n]) => {
      const vals = cols.map((s) => (S(s).accounts || []).find((a) => a.key === key)?.value);
      const d = vals.length > 1 && vals[vals.length - 1] != null && vals[vals.length - 2] != null ? vals[vals.length - 1] - vals[vals.length - 2] : null;
      return `<tr><td>${esc(n.name)}</td><td><span class="pill ${n.taxType}">${TAX_LABEL[n.taxType] || n.taxType}</span></td>${vals.map((v) => `<td class="n">${v == null ? '—' : k(v)}</td>`).join('')}<td class="n ${d == null ? '' : d >= 0 ? 'pos' : 'neg'}">${d == null ? '' : (d >= 0 ? '+' : '−') + k(Math.abs(d))}</td></tr>`;
    }).join('');
    return `${kpis}<div class="card"><h3>Net worth over time</h3>${nwChart}</div>${multi ? `<div class="card"><h3>Buffer, ${CS()} and MAGI over time</h3>${bufChart}</div>` : ''}
      <div class="card"><h3>Saved snapshots</h3><div class="scroll"><table class="tbl"><thead><tr><th>Date / note</th><th class="n">Net worth</th><th class="n">Liquid</th><th class="n">Cash buffer</th><th class="n">${CS()}</th><th class="n">Est. MAGI</th><th>Verdict</th><th></th></tr></thead><tbody>${rows}</tbody></table></div></div>
      ${priceLog()}
      ${marketHistory(snaps)}
      <div class="card"><h3>Account values by snapshot</h3><div class="scroll"><table class="tbl"><thead><tr><th>Account</th><th>Type</th>${cols.map((s) => `<th class="n">${s.asOf}</th>`).join('')}<th class="n">Δ last</th></tr></thead><tbody>${mrows}</tbody></table></div></div>${saveCard}`;
  }

  // ---------- IMPORT ----------
  let pending = [];
  function vImport(snap) {
    const list = pending.map((p) => `<tr><td>${esc(p.file)}</td><td>${p.kind === 'unknown' ? '<span class="pill red">not recognized</span>' : esc(p.kind)}</td><td>${p.asOf || '—'}</td><td>${(p.accounts || []).map((a) => esc(a.name) + ' · ' + usd(a.holdings.reduce((s, h) => s + h.value, 0))).join('<br>') || esc(p.error || '')}</td></tr>`).join('');
    return `${dsCard()}<div class="card"><h3>Quarterly import</h3>
      <div id="drop" class="drop">Drop statements here, or <label class="btn">choose files<input id="fileIn" type="file" multiple accept=".csv,.pdf" hidden></label><div class="note">Files are read in this browser only. Nothing is uploaded. ProjectionLab CSVs go in Plan → ProjectionLab.</div></div>
      ${pending.length ? `<table class="tbl"><thead><tr><th>File</th><th>Detected</th><th>As of</th><th>Accounts found</th></tr></thead><tbody>${list}</tbody></table>
      <p>Applying updates the <b>working copy</b>. Accounts in these files replace the same accounts. Manual accounts, and accounts you didn't re-import, stay as they are. Cost basis you typed for an account is reapplied when the new statement lacks it. Then click <b>Save snapshot</b> to record the quarter in History.</p>
      <button class="btn primary" data-act="commitImport">Apply to working copy</button> <button class="btn" data-act="clearImport">Clear</button>` : ''}</div>
      <div class="card"><h3>What to download each quarter</h3><table class="tbl"><thead><tr><th>Source</th><th>What to export</th><th>Status</th></tr></thead><tbody>
      <tr><td>Fidelity brokerage</td><td>Positions → Download CSV (cost basis included)</td><td><span class="pill ok">supported</span></td></tr>
      <tr><td>Schwab (incl. stock-plan accounts)</td><td>Accounts → Positions → Export (CSV), one account or all accounts</td><td><span class="pill ok">supported, with cost basis</span></td></tr>
      <tr><td>Fidelity (Roth / Trad IRA)</td><td>Monthly or quarterly statement PDF</td><td><span class="pill ok">supported</span></td></tr>
      <tr><td>Morgan Stanley at Work (stock plan)</td><td>Savings Plan Fund Details page → Print to PDF (lot table)</td><td><span class="pill ok">supported, lot level</span></td></tr>
      <tr><td>Wealthfront</td><td>Statement or account snapshot PDF (no basis). Type basis once under Net Worth; it's remembered.</td><td><span class="pill ok">supported</span></td></tr>
      <tr><td>Vanguard 401(k)</td><td>Quarterly statement PDF</td><td><span class="pill ok">supported, pre-tax/Roth split</span></td></tr>
      <tr><td>Vestwell 401(k)</td><td>Quarterly participant statement PDF</td><td><span class="pill ok">supported, vested balance</span></td></tr>
      <tr><td>W-2s (each employer)</td><td>Payroll site → Tax documents → W-2 PDF (late January)</td><td><span class="pill ok">supported</span></td></tr>
      <tr><td>Other brokers and banks, homes, mortgages</td><td>Net Worth → Add account, then edit the values each quarter</td><td><span class="pill">manual</span></td></tr></tbody></table></div>
      <div class="card"><h3>Data folder &amp; backups</h3>
      <p>Status: ${AUTO.dir ? `<b>${esc(AUTO.dir.name)}/</b> ${AUTO.active ? '<span class="pill ok">saving</span>' : '<span class="pill amber">paused: click Auto-save in the header to resume</span>'}` : AUTO.handle ? `single file <b>${esc(AUTO.name)}</b> (older setup). Switch to a folder below.` : '<span class="pill amber">not set up</span>'}</p>
      <ul class="steps"><li>Pick the <b>FIRE-data</b> folder inside your app folder (the one with FIRE-Command-Center.html). The app writes <code>autosave/FIRE-autosave.fire</code> after every change, plus one dated copy per day (last 30 kept). Each <b>Save snapshot</b> also writes <code>snapshots/FIRE-snapshot-&lt;date&gt;.fire</code>.</li>
      <li>Every file is encrypted with your password (AES-256). To move to a new computer, copy the app folder (the one with FIRE-Command-Center.html), open <b>FIRE-Command-Center.html</b>, then use <b>Load data file</b> on <code>FIRE-data/autosave/FIRE-autosave.fire</code>.</li>
      <li>To back up everything to Google Drive, double-click <b>Backup to Zip.command</b> in the app folder (the one with FIRE-Command-Center.html).</li></ul>
      <p><button class="btn primary" data-act="pickDataDir">${AUTO.dir ? 'Change data folder' : 'Choose data folder'}</button> ${AUTO.dir ? '<button class="btn" data-act="writeSnaps">Write all snapshot files now</button>' : ''}</p>
      <p class="note">Chrome or Edge required (Brave: enable brave://flags → File System Access API). Chrome may ask once per session to allow access again; choose “Allow on every visit” if offered.</p></div>
      ${aiCard()}
      <div class="card"><h3>Back up your data manually</h3><p>This browser keeps your snapshots and plans, but browser data can be cleared. If you don't use a data folder, export a data file after each review.</p>
      <button class="btn primary" data-act="autosave">Set up encrypted auto-save</button> <button class="btn" data-act="export">Export encrypted backup (.fire)</button> <button class="btn" data-act="importData">Load data file (.fire or .json)</button> <button class="btn" data-act="exportPlain">Export unencrypted JSON</button> <button class="btn" data-act="lockNow">Forget password</button> <button class="btn danger" data-act="resetAll">Reset this data set</button></div>
      <div class="card"><h3>Clear this browser <span class="sub">remove everything the app stored here</span></h3>
      <p>Removes <b>every data set</b> (${DS.list.length}), all snapshots, plans, settings, API keys and the remembered data folder from <b>this browser</b>. Use it on a shared or borrowed computer, before giving a computer away, or to start over.</p>
      <ul class="steps"><li><b>Not deleted:</b> encrypted files in your data folder (${AUTO.dir ? `<code>${esc(AUTO.dir.name)}/</code>` : 'none chosen'}), exported <code>.fire</code> files, and anything in Backups or Releases. Load them again any time with <b>Load data file</b>.</li>
        <li>${AUTO.dir && AUTO.active ? '<span class="pill ok">auto-save is on</span> your latest changes are already in the data folder.' : '<span class="pill amber">no current folder copy</span> export an encrypted backup first if you want to keep this data.'}</li></ul>
      <p><button class="btn danger" data-act="clearBrowser">Clear all app data from this browser…</button></p></div>`;
  }
  async function clearBrowserData() {
    const n = DS.list.length;
    const typed = prompt(`This removes all ${n} data set${n === 1 ? '' : 's'} and settings from this browser.${AUTO.dir ? `\nEncrypted files in ${AUTO.dir.name}/ are kept.` : '\nThere is no data-folder copy: export first if you want to keep it.'}\n\nType DELETE to confirm:`, '');
    if (String(typed || '').trim().toUpperCase() !== 'DELETE') { toast('Nothing was cleared.'); return; }
    wiping = true; AUTO.active = false; clearTimeout(AUTO.timer); sessionPw = null;
    try { for (const k2 of Object.keys(localStorage)) if (/^fireCC/.test(k2)) localStorage.removeItem(k2); } catch (e) { /* ignore */ }
    try { sessionStorage.clear(); } catch (e) { /* ignore */ }
    try { await new Promise((res) => { const rq = indexedDB.deleteDatabase('fireCC'); rq.onsuccess = rq.onerror = rq.onblocked = () => res(); setTimeout(res, 1500); }); } catch (e) { /* ignore */ }
    alert('Cleared. The app will reload empty. To remove the browser\'s own history or cache too, use your browser settings (see Settings → How to use).');
    location.reload();
  }
  function bindImport() {
    const drop = $('#drop'), inp = $('#fileIn');
    if (!drop) return;
    ['dragover', 'dragenter'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.add('over'); }));
    ['dragleave', 'drop'].forEach((ev) => drop.addEventListener(ev, (e) => { e.preventDefault(); drop.classList.remove('over'); }));
    drop.addEventListener('drop', (e) => handleFiles(e.dataTransfer.files));
    inp.addEventListener('change', () => handleFiles(inp.files));
  }
  async function handleFiles(files) {
    const pdfjsLib = window['pdfjs-dist/build/pdf'];
    for (const f of files) {
      const rec = { file: f.name };
      try {
        const buf = new Uint8Array(await f.arrayBuffer());
        let text, lines;
        if (/\.pdf$/i.test(f.name)) { lines = await P.pdfToLines(pdfjsLib, buf); text = lines.join('\n'); }
        else { text = new TextDecoder().decode(buf); lines = text.split(/\r?\n/); }
        rec.kind = P.detect(f.name, text);
        if (rec.kind === 'txn_csv') rec.txnData = P.parseTxnCSV(text, f.name); else Object.assign(rec, P.parseText(rec.kind, /\.pdf$/i.test(f.name) ? lines : text));
      } catch (err) { rec.kind = 'unknown'; rec.error = String(err.message || err); rec.accounts = []; }
      if (rec.kind === 'tax_return') { storeReturn(rec.taxReturn, f.name); continue; }
      if (rec.kind === 'w2') { if (rec.w2) storeW2(rec.w2, f.name); else toast(`${f.name}: looks like a W-2, but no amounts could be read. Add it by hand under Taxes → Returns.`); continue; }
      if (rec.kind === 'txn_csv' && rec.txnData) { importTxns(rec.txnData, f.name); continue; }
      pending.push(rec);
    }
    render();
  }
  function storeReturn(tr, fname) {
    state.taxReturns = state.taxReturns || {};
    const y = tr.year || (+prompt(`Which tax year is ${fname}?`, String(new Date().getFullYear() - 1)) || null); if (!y) return;
    const r = state.taxReturns[y] = state.taxReturns[y] || { fields: {}, src: {}, files: [], edited: {} };
    for (const k2 of Object.keys(r.fields)) if (!(r.edited || {})[k2] && !(k2 in tr.fields)) { delete r.fields[k2]; delete r.src[k2]; } // stale values from an earlier, worse read
    for (const [k2, v] of Object.entries(tr.fields)) if (!(r.edited || {})[k2]) { r.fields[k2] = v; r.src[k2] = tr.src[k2] || ''; }
    r.fixes = tr.fixes || []; r.sanV = 1;
    if (!r.files.includes(fname)) r.files.push(fname); state.retYear = y; state.tab = 'returns'; save();
    toast(`${fname}: ${Object.keys(tr.fields).length} lines read for ${y}. Review them on the Tax returns tab.`);
    nudgeLater('taxReturn', 6000);
  }
  function applyBasisOverrides(a) {
    for (const h of a.holdings) {
      if (h.cost != null) continue;
      const o = state.basisOverrides[a.key + '|' + h.symbol]; if (!o || o.cost == null) continue;
      if (o.qty && h.qty && Math.abs(o.qty - h.qty) > 1e-6) { h.cost = o.cost * h.qty / o.qty; h.costEstimated = true; } else h.cost = o.cost;
    }
    return a;
  }
  function commitImport() {
    const W = cur();
    const byKey = {}; W.accounts.forEach((a) => (byKey[a.key] = a));
    for (const p of pending) for (const a of p.accounts || []) { const prev = byKey[a.key]; const prevOwner = prev && !prev.ownerGuessed ? prev.owner : null; delete a.owner; byKey[a.key] = inferOwner(applyBasisOverrides(a), state.settings, prevOwner); if (prev && prev.ownerGuessed && a.ownerGuessed) a.owner = prev.owner; }
    W.accounts = Object.values(byKey);
    const asOf = pending.map((p) => p.asOf).filter(Boolean).sort().pop();
    if (asOf && asOf > W.asOf) {
      if (asOf.slice(0, 4) !== W.asOf.slice(0, 4)) { W.manual.ytdRealizedGains = 0; W.manual.ytdHarvestedLosses = 0; }
      W.asOf = asOf;
    }
    W.sources = pending.map((p) => ({ file: p.file, kind: p.kind, asOf: p.asOf }));
    pending = []; state.dirty = true; state.tab = 'review'; save(); render();
    toast('Working copy updated. Review it, then click Save snapshot to add it to History.');
  }
  // ---------- secure storage: encrypted export, auto-save to a file in your cloud folder ----------
  const b64 = { enc: (u8) => { let s = ''; u8.forEach((c) => (s += String.fromCharCode(c))); return btoa(s); }, dec: (t) => Uint8Array.from(atob(t), (c) => c.charCodeAt(0)) };
  const CRYPT = {
    ok: () => !!(window.crypto && crypto.subtle),
    async key(pw, salt, iter) { const km = await crypto.subtle.importKey('raw', new TextEncoder().encode(pw), 'PBKDF2', false, ['deriveKey']); return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, km, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']); },
    async encrypt(obj, pw) { const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12)), iter = 310000; const k2 = await CRYPT.key(pw, salt, iter);
      const ct = new Uint8Array(await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, k2, new TextEncoder().encode(JSON.stringify(obj))));
      return { format: 'fire-encrypted-v1', cipher: 'AES-256-GCM', kdf: 'PBKDF2-SHA256', iter, salt: b64.enc(salt), iv: b64.enc(iv), savedAt: new Date().toISOString(), data: b64.enc(ct) }; },
    async decrypt(env, pw) { const k2 = await CRYPT.key(pw, b64.dec(env.salt), env.iter); const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: b64.dec(env.iv) }, k2, b64.dec(env.data)); return JSON.parse(new TextDecoder().decode(pt)); },
  };
  let sessionPw = null;
  function askPassword(title, { confirm = false, note = '' } = {}) {
    return new Promise((resolve) => {
      const m = $('#pwModal'); m.innerHTML = `<div class="pwbox"><h3>${esc(title)}</h3>${note ? `<p class="note">${note}</p>` : ''}<input id="pw1" type="password" placeholder="Password" autocomplete="new-password">${confirm ? '<input id="pw2" type="password" placeholder="Confirm password" autocomplete="new-password">' : ''}<div class="pwerr" id="pwErr"></div><div><button class="btn primary" id="pwOk">OK</button> <button class="btn" id="pwCancel">Cancel</button></div></div>`;
      m.classList.add('on'); $('#pw1').focus();
      const done = (v) => { m.classList.remove('on'); m.innerHTML = ''; resolve(v); };
      const ok = () => { const a = $('#pw1').value; if (a.length < 8) { $('#pwErr').textContent = 'Use at least 8 characters.'; return; } if (confirm && a !== $('#pw2').value) { $('#pwErr').textContent = 'Passwords don’t match.'; return; } done(a); };
      $('#pwOk').onclick = ok; $('#pwCancel').onclick = () => done(null);
      m.onkeydown = (e) => { if (e.key === 'Enter') ok(); if (e.key === 'Escape') done(null); };
    });
  }
  async function sessionPassword(reason) {
    if (sessionPw) return sessionPw;
    const pw = await askPassword(reason, { confirm: true, note: 'This password encrypts your data file (AES-256). There is no way to recover it if forgotten. Write it down in your password manager.' });
    if (pw) sessionPw = pw; return pw;
  }
  function download(obj, name) { const blob = new Blob([JSON.stringify(obj)], { type: 'application/json' }); const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name; a.click(); }
  async function exportData(plain) {
    if (plain) { if (!confirm('Export WITHOUT encryption? Anyone who gets this file can read your balances, account numbers and tax lots.')) return; const copy = clone(state); if (copy.settings?.quotes) { copy.settings.quotes.fmpKey = ''; copy.settings.quotes.tdKey = ''; copy.settings.quotes.fhKey = ''; } download(copy, `fire-data-${cur().asOf}-UNENCRYPTED.json`); return; }
    if (!CRYPT.ok()) { alert('This browser can’t encrypt from a local file. Use Chrome, Edge or Safari.'); return; }
    const pw = await sessionPassword('Encrypt export'); if (!pw) return;
    download(await CRYPT.encrypt(state, pw), `fire-data-${cur().asOf}.fire`); toast('Encrypted backup downloaded. Move it into your encrypted cloud folder.');
  }
  let asNewDataset = false;
  async function loadDataFile(text) {
    let d = JSON.parse(text);
    if (d && d.format === 'fire-encrypted-v1') {
      for (let tries = 0; tries < 3; tries++) {
        const pw = await askPassword('Password for this data file'); if (!pw) return;
        try { d = await CRYPT.decrypt(d, pw); sessionPw = pw; break; } catch (e) { if (tries === 2) { alert('Wrong password.'); return; } }
      }
    }
    if (!d.snapshots && !d.working) throw new Error('not a FIRE data file');
    const empty = !(state.snapshots || []).length && !(cur().accounts || []).length;
    const asNew = asNewDataset || (!empty && confirm(`Load this file as a NEW data set?\n\nOK = add it as a separate data set (recommended)\nCancel = replace "${dsCur().name}" with it`));
    if (asNew) { const nm = (prompt('Name for this data set:', (d.settings?.household?.selfName && d.settings.household.selfName !== 'You' ? d.settings.household.selfName + "'s data" : 'Imported data')) || '').trim() || 'Imported data';
      const id = 'ds' + Date.now().toString(36); DS.list.push({ id, name: nm, slug: dsSlug(nm), created: new Date().toISOString() }); localStorage.setItem(dsKey(id), JSON.stringify(d)); dsSwitch(id); return; }
    localStorage.setItem(LS, JSON.stringify(d)); state = load(); save(); render(); toast('Data loaded.');
  }
  // IndexedDB keeps the auto-save file handle between sessions (handles can't go in localStorage)
  const idb = (mode, fn) => new Promise((res, rej) => { const rq = indexedDB.open('fireCC', 1); rq.onupgradeneeded = () => rq.result.createObjectStore('kv'); rq.onerror = () => rej(rq.error); rq.onsuccess = () => { const tx = rq.result.transaction('kv', mode); const st = tx.objectStore('kv'); const r = fn(st); tx.oncomplete = () => res(r && r.result); tx.onerror = () => rej(tx.error); }; });
  // ---------- Encrypted auto-save to a data folder (Chrome/Edge File System Access) ----------
  // FIRE-data/autosave/FIRE-autosave.fire (latest) + FIRE-autosave-YYYY-MM-DD.fire (one per day, last 30 kept)
  // FIRE-data/snapshots/FIRE-snapshot-<date>[-note].fire (written when you click Save snapshot; full state, restorable)
  const AUTO = { dir: null, handle: null, active: false, timer: null, last: null, name: '' };
  const autoStatus = () => { const el = $('#autoBtn'); if (!el) return; el.textContent = AUTO.active ? `Auto-save: ${AUTO.name}` : (AUTO.dir || AUTO.handle) ? 'Auto-save paused: click to resume' : 'Auto-save: off'; el.classList.toggle('on', AUTO.active); };
  const slug = (t) => String(t || '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40);
  async function subDir(dir, sub) { let d = dir; for (const p of String(sub || '').split('/').filter(Boolean)) d = await d.getDirectoryHandle(p, { create: true }); return d; }
  async function writeIn(dir, sub, name, text) { const d = await subDir(dir, sub); const fh = await d.getFileHandle(name, { create: true }); const w = await fh.createWritable(); await w.write(text); await w.close(); return d; }
  async function autoWrite() {
    if (!AUTO.active || !sessionPw || !(AUTO.dir || AUTO.handle)) return;
    try {
      const target = AUTO.dir || AUTO.handle;
      if ((await target.queryPermission({ mode: 'readwrite' })) !== 'granted') { AUTO.active = false; autoStatus(); return; }
      const txt = JSON.stringify(await CRYPT.encrypt(state, sessionPw));
      if (AUTO.dir) {
        const day = new Date().toLocaleDateString('en-CA');
        const d = await writeIn(AUTO.dir, dsFolder('autosave'), 'FIRE-autosave.fire', txt); await writeIn(d, '', `FIRE-autosave-${day}.fire`, txt);
        const dated = []; for await (const [n] of d.entries()) if (/^FIRE-autosave-\d{4}-\d{2}-\d{2}\.fire$/.test(n)) dated.push(n);
        dated.sort(); for (const n of dated.slice(0, Math.max(0, dated.length - 30))) await d.removeEntry(n).catch(() => {});
      } else { const w = await AUTO.handle.createWritable(); await w.write(txt); await w.close(); }
      AUTO.last = new Date(); $('#saveState').textContent = `Encrypted auto-save → ${AUTO.name} · ${AUTO.last.toLocaleTimeString()}`;
      aiAutoWrite();
    } catch (e) { AUTO.active = false; autoStatus(); toast('Auto-save stopped: ' + e.message); }
  }
  async function writeSnapshotFile(snap) {
    if (!AUTO.active || !AUTO.dir || !sessionPw) return false;
    try { const txt = JSON.stringify(await CRYPT.encrypt({ ...state, snapshotFile: { asOf: snap.asOf, note: snap.note, savedAt: snap.savedAt } }, sessionPw));
      await writeIn(AUTO.dir, dsFolder('snapshots'), `FIRE-snapshot-${snap.asOf}${snap.note ? '-' + slug(snap.note) : ''}.fire`, txt); return true; } catch (e) { toast('Snapshot file not written: ' + e.message); return false; }
  }
  function autoQueue() { if (!AUTO.active) return; clearTimeout(AUTO.timer); AUTO.timer = setTimeout(autoWrite, 1500); }
  async function autoResume() {
    const target = AUTO.dir || AUTO.handle;
    if ((await target.requestPermission({ mode: 'readwrite' })) !== 'granted') return false;
    const pw = sessionPw || await askPassword(`Password for your encrypted data in ${AUTO.name}`); if (!pw) return false;
    try { let fh = AUTO.handle; if (AUTO.dir) { const d = await subDir(AUTO.dir, dsFolder('autosave')); fh = await d.getFileHandle('FIRE-autosave.fire').catch(() => null); }
      if (fh) { const txt = await (await fh.getFile()).text(); if (txt.trim()) await CRYPT.decrypt(JSON.parse(txt), pw); } } catch (e) { alert('That password doesn’t open the existing auto-save file.'); return false; }
    sessionPw = pw; AUTO.active = true; autoStatus(); autoWrite(); return true;
  }
  async function autoToggle(forcePick) {
    if (!window.showDirectoryPicker) { alert('Saving to a folder needs Chrome or Edge (in Brave: brave://flags → "File System Access API" → Enabled). Otherwise use Export after each review.'); return; }
    if (!CRYPT.ok()) { alert('Encryption isn’t available in this browser.'); return; }
    if (!forcePick && (AUTO.dir || AUTO.handle) && !AUTO.active) { await autoResume(); return; }
    if (!forcePick && AUTO.active) { if (confirm(`Stop auto-saving to ${AUTO.name}?`)) { AUTO.active = false; autoStatus(); } return; }
    let dir; try { dir = await window.showDirectoryPicker({ id: 'fire-data', mode: 'readwrite', startIn: 'documents' }); } catch (e) { return; }
    const pw = sessionPw || await askPassword('Password for your data files', { confirm: true, note: 'Every file in the data folder is encrypted with this password. You need it to open your data on another computer. It isn’t stored anywhere.' }); if (!pw) return;
    sessionPw = pw; AUTO.dir = dir; AUTO.handle = null; AUTO.name = dir.name + '/'; AUTO.active = true;
    try { await idb('readwrite', (st) => { st.put(dir, 'datadir'); st.delete('autosave'); }); } catch (e) { /* folder not remembered after restart; still saves now */ } autoStatus(); await autoWrite();
    let n = 0; for (const sn of state.snapshots) if (await writeSnapshotFile(sn)) n++;
    toast(`Auto-saving to ${dir.name}/autosave${n ? `, and ${n} snapshot file(s) written to ${dir.name}/snapshots` : ''}. Everything is encrypted.`); render();
  }
  async function autoInit() { try { if (!window.indexedDB) return; const d = await idb('readonly', (st) => st.get('datadir')); if (d) { AUTO.dir = d; AUTO.name = d.name + '/'; } else { const h = await idb('readonly', (st) => st.get('autosave')); if (h) { AUTO.handle = h; AUTO.name = h.name; } } } catch (e) { } autoStatus(); }

  document.addEventListener('DOMContentLoaded', () => {
    $('#jsonIn').addEventListener('change', async (e) => {
      const f = e.target.files[0]; if (!f) return;
      try { await loadDataFile(await f.text()); } catch (err) { alert('Could not load: ' + err.message); } asNewDataset = false; e.target.value = '';
    });
    autoInit();
    $('#plIn').addEventListener('change', async (e) => {
      const f = e.target.files[0]; if (!f) return;
      try {
        const r = L.parsePLAny(await f.text());
        if (r.kind === 'csv-rates') { toast('That is the Rates report. It only repeats the growth, dividend and inflation settings, which the account data JSON already has. Not needed.'); e.target.value = ''; return; }
        if (r.kind === 'json') { state.plImport = { file: f.name, loadedAt: new Date().toISOString().slice(0, 10), ...r }; state.plPlanIdx = Math.max(0, r.plans.findIndex((p) => p.active)); }
        else if (r.kind === 'csv-income') plan().plInc = { file: f.name, ...r };
        else plan().pl = { file: f.name, ...r };
        save(); state.tab = 'plan'; state.planTab = 'compare'; state.cmpView = 'pl'; render();
        toast(r.kind === 'json' ? `ProjectionLab account data loaded (${r.accounts.length} accounts, ${r.plans.length} plans)${r.droppedSecret ? '. Its settings, including an API key, were not stored.' : '.'}` : r.kind === 'csv-income' ? `ProjectionLab income report loaded (${r.years.length} years, ${r.cols.length} income sources).` : `ProjectionLab summary report loaded (${r.years.length} years).`);
      } catch (err) { alert('Could not read ProjectionLab file: ' + err.message); }
      e.target.value = '';
    });
  });

  // ---------- AI REVIEW EXPORT ----------
  // Writes a plain-text copy of your data and the app's analysis (Markdown + JSON) so an AI assistant can read it and
  // double-check the numbers. NOT encrypted. Names and account numbers are masked by default; API keys are always removed.
  const AIR = () => (state.aiReview = { auto: false, redact: true, txns: false, ...(state.aiReview || {}) });
  function aiScrub(obj, redact) {
    const H = state.settings.household; const names = redact ? [H.selfName, H.spouseName].filter((n) => n && n.length > 1 && !/^(you|spouse)$/i.test(n)) : [];
    const nameRe = names.length ? new RegExp('\\b(' + names.map((n) => n.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|') + ')\\b', 'gi') : null;
    const fix = (s) => { if (!redact) return s; let t = s.replace(/\b[A-Za-z]*[Xx*•]*\d{5,}\b/g, (m) => '••' + m.slice(-4)); if (nameRe) t = t.replace(nameRe, (m) => (m.toLowerCase() === String(H.spouseName).toLowerCase() ? 'Spouse' : 'You')); return t; };
    const seen = new WeakSet();
    const walk = (v, depth) => {
      if (v == null || typeof v === 'number' || typeof v === 'boolean') return typeof v === 'number' && !isFinite(v) ? null : v;
      if (typeof v === 'string') return fix(v);
      if (typeof v === 'function' || depth > 9) return undefined;
      if (v instanceof Date) return v.toISOString();
      if (typeof v !== 'object' || seen.has(v)) return undefined; seen.add(v);
      if (Array.isArray(v)) return v.map((x) => walk(x, depth + 1));
      const o = {}; for (const [k, x] of Object.entries(v)) { if (/(fmp|fh|td|api|secret|private)Key$|^sheetUrl$|password|token/i.test(k) && typeof x === 'string') continue; const w = walk(x, depth + 1); if (w !== undefined) o[fix(k)] = w; } return o;
    };
    return walk(obj, 0);
  }
  function aiBuild({ full = true } = {}) {
    const R = AIR(); const S = state.settings; const an = window.__an; const snap = cur(); const P = plan(); const st = ST();
    let pr = null; try { pr = full ? planResults(an) : (planCache && planCache.det ? planCache : null); } catch (e) { pr = null; }
    if (!pr) { try { const init = L.initFromSnapshot(snap, S, an); Object.assign(init, returnsForPlan(init.year)); pr = { init, det: L.deterministic(P, init, S) }; } catch (e) { pr = null; } }
    // spending: monthly totals by category (transactions only if asked)
    let spending = null; try { const A = spAgg(false); spending = { source: A.src, months: A.months, planSpendingPerYear: S.spending.annual, planSpendingDetail: S.spending.fromPlan, transactions: R.txns ? A.sp.map((t) => ({ date: t.date, acct: t.acct, desc: t.desc, amount: t.amount, category: t.category, kind: t.kind })) : undefined }; } catch (e) { /* no spending data */ }
    const yrCols = ['year', 'age', 'sAge', 'filing', 'wages', 'ss', 'divs', 'rmd', 'conv', 'realized', 'harvested', 'magi', 'spend', 'health', 'housingOut', 'tax', 'fica', 'irmaa', 'ptc', 'penalty', 'fromTax', 'fromPre', 'fromRoth', 'taxable', 'pretax', 'roth', 'liquid', 'nw', 'short', 'cpiEnd'];
    const rows = pr && pr.det ? pr.det.rows.map((r) => { const o = {}; for (const c of yrCols) o[c] = r[c]; o.taxParts = r.taxParts; return o; }) : [];
    const data = {
      about: { app: 'FIRE Command Center (Pay Forward Labs)', generated: new Date().toISOString(), purpose: 'Plain-text copy of the household data and the app\'s own analysis, for an independent double-check.', redacted: R.redact, units: 'US dollars. Plan rows are nominal dollars; divide by cpiEnd for today\'s dollars. Rates in settings are decimals unless named ...Pct.' },
      household: { ...S.household, filing: S.household.filing, state: st.code, stateName: st.name, stateRules: st },
      settings: { buffer: S.buffer, alloc: S.alloc, trim: S.trim, aca: S.aca, working: S.working, spending: S.spending, market: S.market },
      taxReference: S.ref,
      accounts: snap.accounts.map((a) => ({ key: a.key, institution: a.institution, name: a.name, taxType: a.taxType, owner: a.owner, manual: !!a.manual, value: a._value, holdings: (a.holdings || []).map((h) => ({ symbol: h.symbol, desc: h.desc, qty: h.qty, price: h.price, value: h.value, cost: h.cost, costEstimated: h.costEstimated || undefined, assetClass: h.assetClass, lots: h.lots })) })),
      realEstate: snap.realEstate || [], manualInputs: snap.manual, asOf: snap.asOf,
      snapshotsHistory: state.snapshots.map((x) => { try { const s2 = E.summarize(x); return { asOf: x.asOf, note: x.note, total: s2.total, liquid: s2.liquid, property: s2.property, liabilities: s2.liabilities }; } catch (e) { return { asOf: x.asOf }; } }),
      thisYearAnalysis: an ? { year: an.Y, phase: an.phase, retireDate: an.retireDate, working: an.working, summary: an.s, portfolioIncome: an.inc, spendingPerYear: an.spend, buffer: { target: an.target, trigger: an.trigger, floor: an.floor, cash: an.cash, runwayMonths: an.runwayMonths, mode: an.mode, need: an.need }, magiNow: an.magiNow, magiAfter: an.magiAfter, acaThresholds: an.th, acaThresholdsNext: an.thNext, roomNow: an.roomNow, roomNext: an.roomNext, salePlan: an.plan, washSaleFlags: an.wash, taxLossHarvest: an.tlh, verdict: an.verdict, reasons: an.reasons, taxBeforeSales: an.taxNow, taxAfterSales: an.taxAfter, taxNextYear: an.taxNextAfter, carryforwardNext: an.carryNext } : null,
      taxReturns: Object.fromEntries(Object.entries(state.taxReturns || {}).map(([y, r]) => [y, { fields: r.fields, editedByUser: Object.keys(r.edited || {}) }])),
      estimatedTaxPayments: state.estTax || {},
      plan: { active: P.name, assumptions: P, otherPlans: state.plans.filter((p) => p !== P).map((p) => p.name) },
      planResults: pr ? { startingPoint: pr.init, success: pr.det ? pr.det.success : null, failedAtAge: pr.det ? pr.det.failed : null, lifetimeTax: pr.det ? pr.det.lifetimeTax : null, endLiquidTodayDollars: pr.det ? pr.det.endReal : null, legacyTodayDollars: pr.det ? pr.det.legacyReal : null, firstDeath: pr.det ? pr.det.firstDeath : null,
        monteCarlo: pr.mc ? { runs: pr.mc.runs, successRate: pr.mc.success, medianEndToday: pr.mc.medianEnd, p10EndToday: pr.mc.p10End, medianLifetimeTax: pr.mc.medianTax, bands: pr.mc.bands } : 'not run yet: open the Plan tab, then export again',
        historicalBacktest: pr.bt ? { runs: pr.bt.runs, successRate: pr.bt.success, byStartYear: pr.bt.byStart } : undefined, years: rows } : null,
      spending,
    };
    const J = aiScrub(data, R.redact);
    // ---- Markdown report ----
    const $k = (v) => (v == null || !isFinite(v) ? '—' : '$' + Math.round(v).toLocaleString());
    const pc = (v, d = 1) => (v == null || !isFinite(v) ? '—' : (v * 100).toFixed(d) + '%');
    const t = an && an.taxAfter;
    const md = [];
    md.push(`# FIRE Command Center: data for AI review`, '', `Generated ${new Date().toLocaleString()} · data as of ${snap.asOf || '—'} · ${R.redact ? 'names and account numbers masked' : 'NOT redacted'}`, '');
    md.push(`> Plain-text export of household finances and the app's own calculations. **Not encrypted.** The full detail is in \`FIRE-ai-review.json\` next to this file.`, '');
    md.push('## Instructions for the AI reviewer', '',
      'Please double-check this household\'s numbers independently. Don\'t just restate them. For each item, say whether it looks right, and show your math where it differs.', '',
      `1. **This year's tax** (${an ? an.Y : ''}): recompute federal and ${st.name} income tax from the income lines below, using current-year rules for ${S.household.filing === 'single' ? 'a single filer' : 'married filing jointly'}. Compare with the app's figures. Check the standard vs. itemized choice, the SALT cap, capital-gain stacking, NIIT and AMT.`,
      '2. **ACA and Medicare (IRMAA) income limits:** confirm the thresholds and whether planned sales stay under them.',
      '3. **Cash buffer and sale plan:** do the suggested sales cover the need at the lowest tax cost? Watch for wash sales, short-term gains and concentration.',
      '4. **Data quality:** look for missing cost basis, retirement accounts marked joint, stale prices, duplicate accounts, implausible values.',
      '5. **Plan assumptions:** are returns, inflation, spending, healthcare, Social Security and life expectancy reasonable? Flag anything aggressive.',
      '6. **Plan mechanics:** spot-check a few years in the year table. Do withdrawals plus income cover spending plus tax? Do RMDs start at the right age? Are Roth conversions and taxes consistent? Do balances roll forward?',
      '7. **Tax returns:** compare the imported return lines with the app\'s engine for those years, and check carryforwards.',
      '8. **Opportunities and risks** the app may have missed: Roth conversions, gain harvesting, asset location, insurance gaps, estate.',
      '', 'Note what you couldn\'t verify. This is a planning check, not tax or legal advice.', '');
    md.push('## Household and rules', '', `- Filing: **${S.household.filing === 'single' ? 'single' : 'married filing jointly'}**, state **${st.name}** (${st.type === 'ca' ? 'modeled in full' : st.type === 'none' ? 'no income tax' : st.q === 'approx' ? 'approximate' : 'published brackets'}), household size ${S.household.size}`,
      `- Birth years: ${S.household.birthYearSelf}${SOLO() ? '' : ` / ${S.household.birthYearSpouse}`} · phase: ${an ? an.phase : '—'}${an && an.retireDate ? `, retiring ${an.retireDate}` : ''}`,
      `- Concentrated stock: ${E._conc.symbols.length ? E._conc.symbols.join(', ') : 'none set'} · spending used by the app: ${$k(S.spending.annual)}/yr`, '');
    if (an) {
      const s = an.s; md.push('## Balances', '', `| | Amount |`, `|---|---:|`, `| Net worth | ${$k(s.total)} |`, `| Liquid investments | ${$k(s.liquid)} |`, `| Property | ${$k(s.property)} |`, `| Liabilities | ${$k(s.liabilities)} |`, `| Cash buffer | ${$k(s.bufferCash)} |`, `| Taxable unrealized gain | ${$k(s.taxableUnrealized)} |`, '');
      md.push('By tax type: ' + Object.entries(s.byTax || {}).map(([k2, v]) => `${k2} ${$k(v)}`).join(' · '), '');
      md.push('### Accounts', '', '| Account | Type | Owner | Value | Holdings | Missing basis |', '|---|---|---|---:|---:|---:|');
      for (const a of J.accounts) md.push(`| ${a.institution || ''} ${a.name || a.key} | ${a.taxType} | ${a.owner || ''} | ${$k(a.value)} | ${a.holdings.length} | ${a.taxType === 'taxable' ? a.holdings.filter((h) => h.cost == null && h.assetClass !== 'cash').length : '—'} |`);
      md.push('');
      md.push(`## This year (${an.Y}): the app's analysis`, '', `| | Before planned sales | After planned sales |`, `|---|---:|---:|`,
        `| MAGI | ${$k(an.magiNow && an.magiNow.value)} | ${$k(an.magiAfter && an.magiAfter.value)} |`,
        `| AGI | ${$k(an.taxNow && an.taxNow.agi)} | ${$k(t && t.agi)} |`,
        `| Federal tax | ${$k(an.taxNow && an.taxNow.fed)} | ${$k(t && t.fed)} |`,
        `| ${st.name} tax | ${$k(an.taxNow && an.taxNow.ca)} | ${$k(t && t.ca)} |`,
        `| Total income tax | ${$k(an.taxNow && an.taxNow.total)} | ${$k(t && t.total)} |`,
        `| Marginal (fed / state) | ${pc(an.taxNow && an.taxNow.fedMarginal, 0)} / ${pc(an.taxNow && an.taxNow.caMarginal)} | ${pc(t && t.fedMarginal, 0)} / ${pc(t && t.caMarginal)} |`, '');
      md.push(`Income inputs: wages ${$k(+an.m.wageIncome || 0)} · portfolio ordinary ${$k(an.inc.ordinary)} · qualified dividends ${$k(an.inc.qualified)} · tax-exempt ${$k(an.inc.taxExempt)} · other ${$k(+an.m.otherIncome || 0)} · realized gains YTD ${$k(+an.m.ytdRealizedGains || 0)} · harvested losses YTD ${$k(+an.m.ytdHarvestedLosses || 0)} · loss carryforward ${$k(+an.m.lossCarryforward || 0)}`, '');
      md.push(`ACA: 400% FPL cliff ${$k(an.th && an.th.cliff)} (FPL ${$k(an.th && an.th.fpl)}) · ceiling used: ${an.th ? String(an.th.ceilingLabel || '') + ' ' + $k(an.th.ceiling) : '—'} · room now ${$k(an.roomNow)}`, '');
      md.push(`Buffer: target ${$k(an.target)}, refill trigger ${$k(an.trigger)}, floor ${$k(an.floor)}, cash ${$k(an.cash)} (${an.runwayMonths ? an.runwayMonths.toFixed(1) : '—'} months) · mode **${an.mode}** · need ${$k(an.need)}`, '');
      if (an.plan && an.plan.steps && an.plan.steps.length) { md.push('Suggested sales:', '', '| Sell | Account | Year | Proceeds | Gain | Why |', '|---|---|---|---:|---:|---|'); for (const x of an.plan.steps.slice(0, 30)) md.push(`| ${x.symbol || ''} | ${aiScrub(String(x.account || ''), R.redact)} | ${x.year || ''} | ${$k(x.proceeds)} | ${$k(x.gain)} | ${aiScrub(String(x.why || ''), R.redact)} |`); md.push(''); }
      if (an.reasons && an.reasons.length) md.push('App\'s reasoning: ' + aiScrub(an.reasons.map(String).join(' · '), R.redact), '');
    }
    const ys = Object.keys(state.taxReturns || {}).sort();
    if (ys.length) { const keys = ['wages', 'taxableInt', 'taxExemptInt', 'ordDiv', 'qualDiv', 'capGain', 'agi', 'deduction', 'taxableIncome', 'totalTax', 'capLossCarryOut', 'caAgi', 'caTaxable', 'caTax'];
      md.push('## Imported tax returns (key lines)', '', '| Line | ' + ys.join(' | ') + ' |', '|---|' + ys.map(() => '---:').join('|') + '|');
      for (const k2 of keys) if (ys.some((y) => state.taxReturns[y].fields[k2] != null)) md.push(`| ${k2} | ` + ys.map((y) => $k(state.taxReturns[y].fields[k2])).join(' | ') + ' |'); md.push('', 'All lines are in the JSON under `taxReturns`.', ''); }
    if (pr && pr.det) {
      const d = pr.det; md.push(`## Lifetime plan: "${aiScrub(P.name, R.redact)}"`, '',
        `- Key assumptions: stocks ${P.returns.stock}%/yr, bonds ${P.returns.bond}%, cash ${P.returns.cash}%, inflation ${P.inflation}%, retire at ${P.people.retireAgeSelf ?? 'already retired'}${SOLO() ? '' : ` / ${P.people.retireAgeSpouse ?? 'already retired'}`}, life expectancy ${P.people.lifeSelf}${SOLO() ? '' : ` / ${P.people.lifeSpouse}`}, Social Security ${$k(P.ss.selfPIA)}${SOLO() ? '' : ` + ${$k(P.ss.spousePIA)}`} at ${P.ss.selfClaim}${SOLO() ? '' : `/${P.ss.spouseClaim}`}`,
        `- Fixed-return result: **${d.success ? 'money lasts' : 'runs short at age ' + d.failed}** · ending liquid (today's $) ${$k(d.endReal)} · legacy ${$k(d.legacyReal)} · lifetime tax ${$k(d.lifetimeTax)}`,
        pr.mc ? `- Monte Carlo (${pr.mc.runs} runs, U.S. history resampled): success **${pc(pr.mc.success, 0)}**, median ending ${$k(pr.mc.medianEnd)}, 10th percentile ${$k(pr.mc.p10End)}` : '- Monte Carlo: not run yet (open the Plan tab, then export again)',
        (() => { const L2 = lifeTimeline(P, S).filter((x) => x.where === 'below'); return L2.length ? `- Life events: ${L2.map((x) => `${x.y} ${x.label.replace(/<[^>]+>/g, '')} (${x.detail.replace(/<[^>]+>/g, '')})`).join('; ')}` : ''; })(),
        pr.bt ? `- Historical backtest: success ${pc(pr.bt.success, 0)} over ${pr.bt.runs} start years` : '', '');
      md.push('### Year by year (nominal dollars)', '', '| Year | Age | Wages | Soc Sec | RMD | Conv | Gains | MAGI | Spend+health | Tax | IRMAA | ACA credit | Liquid | Net worth | Short |', '|---|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|---:|');
      for (const r of d.rows) md.push(`| ${r.year} | ${r.age}${SOLO() || !r.aliveP ? '' : '/' + r.sAge} | ${$k(r.wages)} | ${$k(r.ss)} | ${$k(r.rmd)} | ${$k(r.conv)} | ${$k(r.realized + r.harvested)} | ${$k(r.magi)} | ${$k(r.spend + r.health)} | ${$k(r.tax)} | ${$k(r.irmaa)} | ${$k(r.ptc)} | ${$k(r.liquid)} | ${$k(r.nw)} | ${r.short > 1 ? $k(r.short) : ''} |`);
      md.push('');
    }
    if (spending && Object.keys(spending.months || {}).length) {
      const ms = Object.keys(spending.months).sort().slice(-24); const cats = [...new Set(ms.flatMap((m) => Object.keys(spending.months[m])))];
      const tot = (m) => Object.values(spending.months[m]).reduce((a, v) => a + v, 0);
      md.push('## Spending from imported transactions (last 24 months)', '', `Source: ${spending.source}. Plan spending used by the app: ${$k(S.spending.annual)}/yr.`, '', '| Month | Total | ' + cats.join(' | ') + ' |', '|---|---:|' + cats.map(() => '---:').join('|') + '|');
      for (const m of ms) md.push(`| ${m} | ${$k(tot(m))} | ` + cats.map((c) => $k(spending.months[m][c] || 0)).join(' | ') + ' |'); md.push('');
    }
    md.push('---', 'Full detail (every holding, lot, assumption, tax table and plan year) is in `FIRE-ai-review.json`.');
    return { md: md.join('\n'), json: JSON.stringify(J, null, 1) };
  }
  async function aiExport(where) {
    let out; try { out = aiBuild({ full: true }); } catch (e) { toast('AI review export failed: ' + e.message); return; }
    if (where === 'folder' && AUTO.dir) {
      try { if ((await AUTO.dir.queryPermission({ mode: 'readwrite' })) !== 'granted' && (await AUTO.dir.requestPermission({ mode: 'readwrite' })) !== 'granted') throw new Error('folder access not allowed');
        const d = await writeIn(AUTO.dir, dsFolder('ai-review'), 'FIRE-ai-review.md', out.md); await writeIn(d, '', 'FIRE-ai-review.json', out.json);
        AIR().last = new Date().toISOString(); save(); render(); toast(`Wrote ${AUTO.dir.name}/ai-review/FIRE-ai-review.md and .json`); return; } catch (e) { toast('Couldn’t write to the data folder (' + e.message + '). Downloading instead.'); }
    }
    for (const [txt, name, type] of [[out.md, 'FIRE-ai-review.md', 'text/markdown'], [out.json, 'FIRE-ai-review.json', 'application/json']]) {
      const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([txt], { type })); a.download = name; document.body.appendChild(a); a.click(); a.remove();
    }
    AIR().last = new Date().toISOString(); save(); toast('Downloaded FIRE-ai-review.md and .json. Keep them somewhere private.');
  }
  window.__aiBuild = aiBuild; // used by tests
  window.__storeW2 = (w2, f) => { storeW2(w2, f); render(); };
  let aiAutoAt = 0;
  async function aiAutoWrite() {
    const R = AIR(); if (!R.auto || !AUTO.active || !AUTO.dir || Date.now() - aiAutoAt < 60000) return; aiAutoAt = Date.now();
    try { const out = aiBuild({ full: false }); const d = await writeIn(AUTO.dir, dsFolder('ai-review'), 'FIRE-ai-review.md', out.md); await writeIn(d, '', 'FIRE-ai-review.json', out.json); R.last = new Date().toISOString(); } catch (e) { /* best effort */ }
  }
  function aiCard() {
    const R = AIR();
    return `<div class="card"><h3>AI review export <span class="sub">let an AI assistant read your data and double-check the analysis</span></h3>
      <p>Writes two plain-text files: <code>FIRE-ai-review.md</code> (a readable report with a checklist for the reviewer) and <code>FIRE-ai-review.json</code> (every account, holding, assumption, tax table, return line and plan year). Point an AI assistant at them and ask it to check the work.</p>
      <div class="grid4">
        <label class="fld chk"><input type="checkbox" data-air="redact" ${R.redact ? 'checked' : ''}><span>Mask names and account numbers</span></label>
        <label class="fld chk"><input type="checkbox" data-air="txns" ${R.txns ? 'checked' : ''}><span>Include individual transactions</span><span class="hint">otherwise monthly totals by category</span></label>
        <label class="fld chk"><input type="checkbox" data-air="auto" ${R.auto ? 'checked' : ''} ${AUTO.dir ? '' : 'disabled'}><span>Keep <code>FIRE-data/ai-review/</code> updated on each auto-save</span><span class="hint">${AUTO.dir ? 'at most once a minute; Monte Carlo figures refresh when you open the Plan' : 'choose a data folder first'}</span></label></div>
      <p>${AUTO.dir ? `<button class="btn primary" data-act="aiExportFolder">Write to ${esc(AUTO.dir.name)}/ai-review/</button> ` : ''}<button class="btn${AUTO.dir ? '' : ' primary'}" data-act="aiExportDl">Download the two files</button> ${R.last ? `<span class="mut">last written ${new Date(R.last).toLocaleString()}</span>` : ''}</p>
      <ul class="steps">
        <li><b>These files are not encrypted.</b> API keys are always removed, and names and account numbers are masked unless you turn that off. Balances, holdings and tax figures are included because that's what gets checked.</li>
        <li><b>With an AI assistant that can read your folder</b> (for example a desktop AI app with folder access), ask: <i>"Read FIRE-data/ai-review/FIRE-ai-review.md and the JSON next to it, and follow the reviewer instructions at the top."</i> Otherwise, attach the two files to a chat.</li>
        <li>Use a personal AI account for personal finances, and delete the files when you're done if you don't want a plain copy on disk. The backup and sharing scripts never include this folder.</li></ul></div>`;
  }

  // ---------- PLAN → LIFE EVENTS: one timeline of everything dated in the plan, plus new event types ----------
  function lifeTimeline(P, S) {
    const H = S.household; const bS = +H.birthYearSelf, bP = +H.birthYearSpouse; const Y0 = +String(cur().asOf || new Date().toISOString()).slice(0, 4);
    const items = []; const add = (y, label, detail, where, cls = '') => { if (y && isFinite(y)) items.push({ y: Math.round(y), label, detail, where, cls }); };
    const nm = (w) => esc(ownerName(w)); const people = SOLO() ? [['self', bS]] : [['self', bS], ['spouse', bP]];
    const ev = (e) => (e.age !== '' && e.age != null && +e.age ? bS + +e.age : e.year !== '' && e.year != null && +e.year ? +e.year : null);
    const go = (pt, t = 'Assumptions') => `<a href="#" data-tab="plan" data-ptab-go="${pt}">${t}</a>`;
    for (const [w, b] of people) {
      const ra = w === 'self' ? P.people.retireAgeSelf : P.people.retireAgeSpouse;
      add(ra ? b + +ra : null, `${nm(w)} retires`, `age ${ra}; paychecks stop, saving ends, the cash buffer takes over`, go('setup'), 'pill');
      const ca = w === 'self' ? P.ss.selfClaim : P.ss.spouseClaim, pia = w === 'self' ? P.ss.selfPIA : P.ss.spousePIA;
      if (+pia) add(b + +ca, `${nm(w)} claims Social Security`, `age ${ca}: ${k(L.ssAdj(+pia, +ca, +P.ss.fra || 67))}/yr in today's $`, go('setup'));
      add(b + 65, `${nm(w)} turns 65: Medicare`, 'ACA marketplace ends; Medicare premiums and income surcharges (IRMAA) begin', go('setup'));
      add(b + (b >= 1960 ? 75 : 73), `${nm(w)}: required withdrawals start`, `age ${b >= 1960 ? 75 : 73}, from pre-tax accounts`, '');
      const life = w === 'self' ? P.people.lifeSelf : P.people.lifeSpouse; add(b + +life, `${nm(w)}: plan ends (life expectancy)`, `age ${life}`, go('setup'), 'mut');
    }
    for (const j of P.work || []) if (j.endAge !== '' && j.endAge != null) add((j.who === 'spouse' ? bP : bS) + +j.endAge, `${nm(j.who)} leaves ${esc(j.name || 'job')}`, `${k(+j.salary)}/yr ends`, go('setup'));
    for (const x of P.expenses || []) { const y = x.startYear !== '' && x.startYear != null && +x.startYear ? +x.startYear : bS + +x.startAge; const y2 = x.endYear !== '' && x.endYear != null && +x.endYear ? +x.endYear : x.endAge !== '' && x.endAge != null ? bS + +x.endAge : y; add(y, esc(x.name || 'Expense'), `${k(+x.amount)}/yr${y2 > y ? ` through ${y2}` : ''}${x.from529 === true || x.from529 === 'true' ? ', paid from the 529 first' : ''}`, go('setup')); }
    for (const e of P.events || []) add(+e.year, esc(e.name || 'One-time event'), `${+e.amount >= 0 ? '+' : '−'}${k(Math.abs(+e.amount))}${e.taxable && e.taxable !== 'none' ? ` (taxed as ${e.taxable === 'ltcg' ? 'a capital gain' : 'income'})` : ''}`, 'below');
    for (const q of P.purchases || []) add(+q.year, `Buy ${esc(q.name || 'property')}`, `${k(+q.price)}, ${q.downPct ?? 20}% down`, go('setup'));
    for (const p of cur().realEstate || []) { const o = (P.reSale || {})[p.id] || {}; const sy = o.sellYear !== '' && o.sellYear != null ? +o.sellYear : +p.sellYear; if (sy) add(sy, `Sell ${esc(p.name)}`, `${k(+p.value)} today`, go('setup')); }
    for (const m of P.moves || []) { const y = ev(m); if (y) add(y, `Move${m.name ? ': ' + esc(m.name) : ''}${m.state ? ` (to ${esc((E.STATES[m.state] || {}).name || m.state)})` : ''}`, [m.state ? (E.STATES[m.state] && E.STATES[m.state].type === 'none' ? 'no state income tax' : 'new state tax rules') : 'same state', +m.spendPct ? `spending ${+m.spendPct > 0 ? '+' : ''}${m.spendPct}%` : '', (m.sellHome === true || m.sellHome === 'true') ? 'sell current home' : '', +m.newHomePrice ? `buy a ${k(+m.newHomePrice)} home` : ''].filter(Boolean).join(' · '), 'below', 'pill'); }
    for (const e of P.inheritances || []) { const y = ev(e); if (y && +e.amount) add(y, `Inheritance (${{ cash: 'cash', stocks: 'stocks', home: 'property', ira: 'inherited IRA', roth: 'inherited Roth' }[e.kind || 'cash']})`, `${k(+e.amount)}${/ira/.test(e.kind) ? ': taxable, drawn over 10 years' : e.kind === 'roth' ? ': tax-free, drawn over 10 years' : e.kind === 'stocks' ? ': basis steps up, no tax' : ': not taxable income'}`, 'below'); }
    for (const e of P.spendChanges || []) { const y = ev(e); if (y && +e.pct) add(y, `Spending ${+e.pct > 0 ? 'rises' : 'drops'} ${Math.abs(+e.pct)}%`, `${esc(e.name || '')}${e.endYear ? ` until ${e.endYear}` : ' from then on'}`, 'below'); }
    add(Y0, 'Today', 'working copy as of ' + esc(cur().asOf || ''), '', 'mut');
    return items.sort((a, b) => a.y - b.y || (a.label === 'Today' ? -1 : 0));
  }
  function pLife(P, S) {
    const H = S.household; const bS = +H.birthYearSelf, bP = +H.birthYearSpouse;
    const items = lifeTimeline(P, S); const rows = planCache && planCache.det ? planCache.det.rows : [];
    const stOpts = Object.entries(E.STATES).sort((a, b) => a[1].name.localeCompare(b[1].name)).map(([c, v]) => [c, v.name]);
    const tl = items.map((x) => `<tr class="${x.cls === 'mut' ? 'mut' : ''}"><td><b>${x.y}</b></td><td>${x.y - bS}${SOLO() ? '' : ` / ${x.y - bP}`}</td><td>${x.cls === 'pill' ? `<span class="pill">${x.label}</span>` : x.label}</td><td class="mut">${x.detail}</td><td>${x.where === 'below' ? '<span class="mut">below</span>' : x.where}</td></tr>`).join('');
    // effect of moves on state tax (from the fixed-return projection)
    let moveNote = '';
    if ((P.moves || []).length && rows.length) {
      const before = rows.filter((r) => r.state === (H.state || 'CA')), after = rows.filter((r) => r.state !== (H.state || 'CA'));
      const avg = (a) => (a.length ? sum(a, (r) => (r.taxParts?.ca || 0) / r.cpi) / a.length : 0);
      if (after.length) moveNote = `<p class="note">State income tax in the projection: about <b>${usd(Math.round(avg(before) / 100) * 100)}/yr</b> before the move vs <b>${usd(Math.round(avg(after) / 100) * 100)}/yr</b> after (today's $). To see the full effect, copy this plan (Plan → Compare), delete the move in the copy, and compare the two.</p>`;
    }
    return `<div class="card"><h3>Life events <span class="sub">everything dated in this plan, in order</span></h3>
      <div class="scroll"><table class="tbl"><thead><tr><th>Year</th><th>Age${SOLO() ? '' : 's'}</th><th>Event</th><th>Details</th><th>Edit in</th></tr></thead><tbody>${tl}</tbody></table></div>
      <p class="note">Retirement, Social Security, jobs, college and other expenses, and home purchases/sales are edited in ${'<a href="#" data-tab="plan" data-ptab-go="setup">Assumptions</a>'}; they're shown here so you can see the whole timeline. The events below are added here.</p></div>
    <div class="card"><h3>Moves <span class="sub">downsizing, a retirement community, another state</span></h3>
      ${listEditor('moves', [{ key: 'name', label: 'Name', type: 'text', ph: 'e.g. Retirement home' }, { key: 'age', label: 'Your age' }, { key: 'year', label: 'or year', ph: '—' }, { key: 'state', label: 'State for income tax', options: [['', 'Same state']].concat(stOpts) }, { key: 'spendPct', label: 'Cost of living %', ph: 'e.g. −10' }, { key: 'acaBenchmark', label: 'ACA benchmark $/yr', ph: 'unchanged' }, { key: 'sellHome', label: 'Sell home', type: 'check' }, { key: 'newHomePrice', label: 'New home price', ph: 'none' }, { key: 'newHomeDownPct', label: 'Down %', ph: '100' }, { key: 'newHomeTaxPct', label: 'Prop. tax %', ph: '1.0' }], P)}
      ${moveNote}
      <p class="note">Set moves, inheritances and spending changes by <b>your age</b>. Use "or year" only if you'd rather pin a calendar year; when both are filled, the age wins.</p>
      <ul class="steps"><li>Each move becomes a life event you can use as a <b>From</b>/<b>To</b> point for spending, income and expenses (e.g. travel until the move, a community fee from the move on).</li>
        <li>If you pick a state, from the move year on income tax uses that state's rules (Settings shows each state's rules). California-only items stop: disability insurance (SDI), the 2.5% early-withdrawal tax and the 30/40/0/30 estimate schedule.</li>
        <li><b>Your old state still taxes income sourced there:</b> the plan keeps charging it on rentals you still own in that state (non-resident tax). Stock that vests later for work done there, and deferred pay, can be taxed there too (not modeled). Retirement-plan withdrawals can't be taxed by a former state (federal law).</li>
        <li><b>Selling your home</b> uses the $500k (married) / $250k (single) home-sale exclusion. A new home has its own property tax (no Prop 13) and costs: insurance about 0.4% and upkeep about 1% of the price per year. Leave the price blank to keep or rent instead.</li>
        <li>Moving out of California? Its tax agency (FTB) audits residency changes. Keep evidence: new driver's license, voter registration, home, doctors, and days spent in each state.</li></ul></div>
    <div class="card"><h3>Inheritance</h3>
      ${listEditor('inheritances', [{ key: 'name', label: 'From', type: 'text' }, { key: 'age', label: 'Your age' }, { key: 'year', label: 'or year', ph: '—' }, { key: 'amount', label: "Amount (today's $)" }, { key: 'kind', label: 'Type', options: [['cash', 'Cash'], ['stocks', 'Stocks / brokerage'], ['home', 'Home / property'], ['ira', 'Inherited IRA / 401(k)'], ['roth', 'Inherited Roth']] }], P)}
      <ul class="steps"><li><b>Cash, stocks, property:</b> not taxable income. Inherited stocks and property get a new cost basis (market value at death), so selling soon after owes little tax. Cash and stocks join your taxable investments; property is added to net worth.</li>
        <li><b>Inherited IRA or 401(k):</b> under the 10-year rule it must be emptied within 10 years. The plan takes it evenly over 10 years as ordinary income. Spreading it into your lower-income years can save a lot. <b>Inherited Roth:</b> same 10 years, tax-free.</li>
        <li>Inheritances are uncertain. Consider leaving them out of your main plan and testing them in a copy.</li></ul></div>
    <div class="card"><h3>Spending changes</h3>
      ${listEditor('spendChanges', [{ key: 'name', label: 'Why', type: 'text' }, { key: 'age', label: 'From your age' }, { key: 'year', label: 'or year', ph: '—' }, { key: 'pct', label: 'Change %', ph: 'e.g. −15' }, { key: 'endYear', label: 'Until year', ph: 'always' }], P)}
      <p class="note">Scales all living-spending categories from that year (e.g. −20% when the kids leave, +10% for a travel decade). Housing, healthcare and taxes are modeled separately.</p></div>
    <div class="card"><h3>One-time events <span class="sub">windfalls, big purchases, gifts</span></h3>
      ${listEditor('events', [{ key: 'name', label: 'Name', type: 'text' }, { key: 'year', label: 'Year' }, { key: 'amount', label: 'Amount (+/−)' }, { key: 'taxable', label: 'Tax', options: [['none', 'None'], ['ordinary', 'Ordinary'], ['ltcg', 'Capital gain']] }, { key: 'basis', label: 'Basis (if gain)' }], P)}
      <p class="note">Positive = money in (bonus, sale of a business, gift received); negative = money out (car, wedding, gift to kids). Home purchases and sales go in Real estate.</p></div>`;
  }

  // ---------- W-2s ----------
  // Stored per data set in state.w2s. Used for: wages and withholding by year, checking the tax return, 401(k)/HSA room,
  // excess Social Security tax (two employers), additional Medicare tax, RSU under-withholding, and filling Plan → Work.
  const W2LIM = { // [401k deferral, catch-up 50+, Social Security wage base, HSA family limit]
    2023: [22500, 7500, 160200, 7750], 2024: [23000, 7500, 168600, 8300], 2025: [23500, 7500, 176100, 8550], 2026: [24500, 8000, 184500, 8750] };
  const w2Lim = (y) => W2LIM[y] || W2LIM[Math.max(...Object.keys(W2LIM).map(Number).filter((x) => x <= y)) || 2026] || W2LIM[2026];
  const W2S = () => (state.w2s = state.w2s || []);
  function w2Who(name) {
    const H = state.settings.household; const first = (n) => String(n || '').trim().split(/\s+/)[0].toLowerCase(); const nm = String(name || '').toLowerCase();
    if (SOLO()) return 'self';
    if (first(H.spouseName) && !/^spouse$/i.test(H.spouseName) && nm.includes(first(H.spouseName))) return 'spouse';
    return 'self';
  }
  function storeW2(w2, fname) {
    const y = w2.year || (+prompt(`Which tax year is ${fname}?`, String(new Date().getFullYear() - 1)) || null); if (!y) return;
    const L = W2S(); const b = w2.boxes;
    const dup = L.find((x) => x.year === y && Math.abs((x.boxes.box1 || 0) - (b.box1 || 0)) < 1 && Math.abs((x.boxes.box2 || 0) - (b.box2 || 0)) < 1);
    if (dup) { toast(`${fname}: already imported (${y}, ${dup.employer || 'W-2'}).`); return; }
    L.push({ id: 'w' + Date.now().toString(36) + Math.random().toString(36).slice(2, 5), year: y, who: w2Who(w2.employee), employer: w2.employer || '', state: w2.state || '', boxes: { ...b }, codes: { ...w2.codes }, box14: w2.box14 || [], file: fname, edited: {} });
    // final withholding for that year feeds the estimated-tax / filing view (only if you haven't typed it)
    const ES = (state.estTax = state.estTax || {}); const e = (ES[y] = ES[y] || {}); const yr = L.filter((x) => x.year === y);
    if (e.fedWithheld == null || e.fedWithheld === '' || e.fedWithheldFromW2) { e.fedWithheld = Math.round(sum(yr, (x) => x.boxes.box2 || 0)); e.fedWithheldFromW2 = true; }
    if (e.caWithheld == null || e.caWithheld === '' || e.caWithheldFromW2) { e.caWithheld = Math.round(sum(yr, (x) => x.boxes.box17 || 0)); e.caWithheldFromW2 = true; }
    state.retYear = y; state.tab = 'returns'; save();
    toast(`${fname}: W-2 for ${y}${w2.employer ? ` from ${w2.employer}` : ''} read. Check it under Taxes → Returns → W-2s.`);
  }
  function w2Insights(y) {
    const L = W2S().filter((x) => x.year === y); if (!L.length) return [];
    const [def, catchup, base, hsaFam] = w2Lim(y); const H = state.settings.household; const out = [];
    const g = (x, k2) => +x.boxes[k2] || 0, c = (x, k2) => +(x.codes || {})[k2] || 0;
    const people = SOLO() ? ['self'] : ['self', 'spouse'];
    for (const who of people) {
      const P = L.filter((x) => x.who === who); if (!P.length) continue; const nm = ownerName(who);
      const age = y - (who === 'self' ? H.birthYearSelf : H.birthYearSpouse); const lim = def + (age >= 50 ? catchup : 0);
      const k401 = sum(P, (x) => c(x, 'D') + c(x, 'AA') + c(x, 'E') + c(x, 'G'));
      if (k401 > lim + 1) out.push(['red', `${nm}: 401(k) deferrals ${usd(k401)} exceed the ${y} limit of ${usd(lim)}`, 'Ask the plan to refund the excess (plus earnings) by April 15, or it is taxed twice.']);
      else out.push([k401 >= lim - 1 ? 'ok' : 'amber', `${nm}: 401(k) ${usd(k401)} of ${usd(lim)}${age >= 50 ? ' (with catch-up)' : ''}`, k401 >= lim - 1 ? 'Maxed.' : `${usd(lim - k401)} of room was unused in ${y}${y >= new Date().getFullYear() ? '; raise your deferral before year-end' : ''}.`]);
      const ssTax = sum(P, (x) => g(x, 'box4')), maxSS = base * 0.062;
      if (P.length > 1 && ssTax > maxSS + 1) out.push(['ok', `${nm}: ${usd(ssTax - maxSS)} of excess Social Security tax`, `Two or more employers each withheld 6.2% up to the ${usd(base)} wage base. Claim the excess as a credit on Schedule 3, line 11 (it is refunded).`]);
      const hsa = sum(P, (x) => c(x, 'W')); if (hsa) out.push([hsa > hsaFam ? 'red' : 'ok', `${nm}: HSA through payroll ${usd(hsa)}`, `${y} family limit ${usd(hsaFam)} (self-only is about half). ${isCA() ? 'California taxes HSA contributions: add them back on Schedule CA.' : ''}`]);
      const rsu = sum(P, (x) => sum(x.box14 || [], (b) => (/RSU|GSU|NSO|STOCK/.test(b.label) ? b.amount : 0)));
      if (rsu) out.push(['amber', `${nm}: ${usd(rsu)} of stock compensation in box 1`, 'Stock vests are usually withheld at the flat 22% supplemental rate, well under a 32–37% bracket. Also make sure the shares\' cost basis isn\'t reported as $0 when you sell.']);
    }
    const wages = sum(L, (x) => g(x, 'box1')), fed = sum(L, (x) => g(x, 'box2')), medW = sum(L, (x) => g(x, 'box5')), medT = sum(L, (x) => g(x, 'box6'));
    out.unshift(['', `Wages ${usd(wages)} · federal withholding ${usd(fed)} (${wages ? pct(fed / wages * 100) : '—'} of wages)`, `${L.length} W-2${L.length > 1 ? 's' : ''}. Box 1 excludes pre-tax 401(k), HSA and health premiums; Medicare wages (box 5) ${usd(medW)} include them.`]);
    const thr = SOLO() ? 200000 : 250000; const addl = Math.max(0, medW - thr) * 0.009, addlWithheld = Math.max(0, medT - medW * 0.0145);
    if (medW > thr || addlWithheld > 1) out.push([Math.abs(addl - addlWithheld) < 50 ? 'ok' : 'amber', `Additional Medicare tax: ${usd(addl)} owed, ${usd(addlWithheld)} withheld`, addl > addlWithheld ? `About ${usd(addl - addlWithheld)} more is due with the return (Form 8959): employers only start withholding above $200k per job.` : addlWithheld > addl ? `About ${usd(addlWithheld - addl)} comes back on Form 8959 (withheld above $200k at one job, but the household is under ${usd(thr)}).` : 'Withheld correctly.']);
    const ret = (state.taxReturns || {})[y]?.fields;
    if (ret && ret.wages != null) out.push([Math.abs(ret.wages - wages) < 5 ? 'ok' : 'amber', `Return line 1: ${usd(ret.wages)} vs W-2 box 1 total ${usd(wages)}`, Math.abs(ret.wages - wages) < 5 ? 'Matches.' : 'They differ: a W-2 is missing here, or the return includes other wages (household employee, tips, dependent care). Check before filing.']);
    if (ret && ret.totalTax != null) out.push(['', `Total tax ${usd(ret.totalTax)} vs W-2 withholding ${usd(fed)}`, fed >= ret.totalTax ? 'Withholding covered the full tax.' : `Withholding covered ${pct(fed / ret.totalTax * 100, 0)}; the rest came from estimated payments or was owed.`]);
    return out;
  }
  function w2Card() {
    const L = W2S(); const years = [...new Set(L.map((x) => x.year))].sort((a, b) => b - a);
    const inp = (x, path, w = 92) => `<input class="num" style="width:${w}px" data-w2="${x.id}" data-f="${path}" value="${(() => { const v = path.split('.').reduce((o, p) => (o || {})[p], x); return v == null ? '' : Math.round(v * 100) / 100; })()}" placeholder="—">`;
    const body = years.map((y) => {
      const rows = L.filter((x) => x.year === y).map((x) => `<tr><td><select data-w2="${x.id}" data-f="who">${(SOLO() ? ['self'] : ['self', 'spouse']).map((o) => `<option value="${o}" ${x.who === o ? 'selected' : ''}>${esc(ownerName(o))}</option>`).join('')}</select></td>
        <td><input style="width:150px" data-w2="${x.id}" data-f="employer" value="${esc(x.employer)}" placeholder="Employer"></td><td class="n">${inp(x, 'boxes.box1')}</td><td class="n">${inp(x, 'boxes.box2')}</td><td class="n">${inp(x, 'boxes.box5')}</td><td class="n">${inp(x, 'boxes.box4', 80)}</td>
        <td class="n">${inp(x, 'codes.D', 80)}</td><td class="n">${inp(x, 'codes.AA', 80)}</td><td class="n">${inp(x, 'codes.W', 70)}</td><td class="n">${inp(x, 'boxes.box17', 80)}</td><td><button class="btn sm" data-act="w2Del" data-id="${x.id}" title="Remove this W-2">✕</button></td></tr>`).join('');
      const ins = w2Insights(y).map(([cls, t, n]) => `<li>${cls ? `<span class="pill ${cls}">${cls === 'ok' ? '✓' : cls === 'red' ? '!' : '•'}</span> ` : ''}<b>${t}</b><br><span class="mut">${n}</span></li>`).join('');
      return `<h4>${y}</h4><div class="scroll"><table class="tbl"><thead><tr><th>Whose</th><th>Employer</th><th class="n">1 Wages</th><th class="n">2 Fed withheld</th><th class="n">5 Medicare wages</th><th class="n">4 SS tax</th><th class="n">12 D 401(k)</th><th class="n">12 AA Roth</th><th class="n">12 W HSA</th><th class="n">17 State tax</th><th></th></tr></thead><tbody>${rows}</tbody></table></div>
        <ul class="steps">${ins}</ul>${y === years[0] ? `<p><button class="btn primary" data-act="w2Plan" data-y="${y}">Use ${y} W-2s for Plan → Work income</button> <span class="mut">sets each job's salary (box 5), pre-tax 401(k) (12 D) and Roth 401(k) (12 AA); you confirm first</span></p>` : ''}`;
    }).join('');
    return `<div class="card"><h3>W-2s <span class="sub">wage statements: drop the PDFs on the Import button, or add one by hand</span></h3>
      ${L.length ? body : '<p class="mut">No W-2s yet. Import them with the header <b>Import</b> button (several at once is fine).</p>'}
      <p><button class="btn" data-act="w2Add">Add a W-2 by hand</button></p>
      <p class="note">What W-2s do here: check wages and withholding against your return; show unused 401(k) and HSA room; find excess Social Security tax when someone had two employers (refundable); estimate additional Medicare tax; flag stock pay that was under-withheld; and fill Plan → Work income with real numbers. Final withholding also fills the estimated-tax and filing views for that year. Names, SSNs and addresses aren't kept.</p></div>`;
  }

  // ---------- DATA SET MANAGEMENT ----------
  function dsSwitch(id) { try { save(); } catch (e) { /* ignore */ } DS.active = id; dsSave(); location.reload(); }
  function dsNew() { const nm = (prompt('Name for the new data set (e.g. "Mom & Dad", "Test household"):', '') || '').trim(); if (!nm) return;
    const id = 'ds' + Date.now().toString(36); DS.list.push({ id, name: nm, slug: dsSlug(nm), created: new Date().toISOString() }); dsSwitch(id); }
  function dsRename(id) { const x = DS.list.find((y) => y.id === id); const nm = (prompt('Rename data set:', x.name) || '').trim(); if (!nm) return; x.name = nm; dsSave(); render(); }
  function dsUnload(id) {
    const x = DS.list.find((y) => y.id === id); const folder = AUTO.dir ? `${AUTO.dir.name}/${id === 'default' ? 'autosave' : `datasets/${x.slug}/autosave`}` : null;
    if (!confirm(`Unload "${x.name}" from this browser?\n\nIts working copy, snapshots and plans are removed from this browser.${folder ? `\nEncrypted files in ${folder} are NOT deleted; load them again any time with Load data file.` : '\nThere is no data-folder copy: export it first if you want to keep it.'}`)) return;
    try { localStorage.removeItem(dsKey(id)); } catch (e) { /* ignore */ }
    DS.list = DS.list.filter((y) => y.id !== id);
    if (!DS.list.length) DS.list = [{ id: 'default', name: 'My data', slug: '', created: new Date().toISOString() }];
    if (id === DS.active) { DS.active = DS.list[0].id; dsSave(); location.reload(); return; }
    dsSave(); render(); toast(`"${x.name}" unloaded from this browser.`);
  }
  function dsCard() {
    const size = (id) => { try { return Math.round((localStorage.getItem(dsKey(id)) || '').length / 1024); } catch (e) { return 0; } };
    return `<div class="card"><h3>Data sets <span class="sub">separate households or scenarios, each with its own accounts, plans, returns and spending</span></h3>
      <table class="tbl"><thead><tr><th>Name</th><th>Saves to</th><th class="n">Size</th><th>Last opened</th><th></th></tr></thead><tbody>
      ${DS.list.map((x) => `<tr${x.id === DS.active ? ' style="background:#eef4ff"' : ''}><td><b>${esc(x.name)}</b>${x.id === DS.active ? ' <span class="pill ok">open</span>' : ''}</td>
        <td class="mut"><code>FIRE-data/${x.id === 'default' ? '' : `datasets/${esc(x.slug)}/`}autosave/</code></td><td class="n">${size(x.id)} KB</td><td class="mut">${x.lastOpened ? new Date(x.lastOpened).toLocaleDateString() : '—'}</td>
        <td style="white-space:nowrap">${x.id === DS.active ? '' : `<button class="btn sm primary" data-act="dsSwitch" data-id="${x.id}">Switch</button> `}<button class="btn sm" data-act="dsRename" data-id="${x.id}">Rename</button> <button class="btn sm" data-act="dsUnload" data-id="${x.id}">Unload</button></td></tr>`).join('')}</tbody></table>
      <p><button class="btn primary" data-act="dsNew">New empty data set</button> <button class="btn" data-act="dsLoadNew">Load a .fire file as a new data set</button></p>
      <ul class="steps"><li>Each data set saves to its own folder inside your data folder and can have its <b>own password</b>. Switching reloads the app; auto-save resumes when you enter that data set's password.</li>
        <li><b>Unload</b> removes a data set from this browser only. Its encrypted files in the data folder stay, so you can load it again later.</li>
        <li>Statements you import go into the data set that's open. The header shows which one that is.</li></ul></div>`;
  }

  // ---------- DONATE ----------
  const DONATE_URL = 'https://buy.stripe.com/28E8wP9OEbmqcME2aZeZ200'; // Stripe payment link
  const donateCard = () => `<div class="card donate"><h3>Keep this tool free for everyone</h3>
      <p><b>Financial freedom shouldn't be locked behind a subscription.</b> Most planning tools charge $100–$300 a year and want your balances on their servers. This one is free, has no ads, needs no account, and never sees your data. Your numbers live on your computer, encrypted with a password only you know. <b>Own your own data.</b></p>
      <p>If it helped you plan a retirement, catch a tax trap or sleep better about the ACA cliff, a donation keeps it free and available to the next person who needs it.</p>
      <p><a class="btn donatebtn" href="${DONATE_URL}" target="_blank" rel="noopener noreferrer">Donate to keep it free</a> <span class="mut">Any amount helps. Secure checkout by Stripe opens in your browser; the app sends nothing about you.</span></p></div>`;

  // Donation reminder: shown only at moments the app has just proved useful, and rarely.
  // Rules: never in the first 3 days, at most once per 45 days, at most 3 times ever, never again after
  // "I've donated" or "Don't ask again". Each trigger fires once.
  const NUDGE = {
    snap2: ['You just saved your second snapshot', 'You now have a real history: net worth, mix and buffer, tracked over time on your own computer.'],
    taxReturn: ['Your return is in', 'The app just checked its tax engine against your real return and picked up your carryforwards, the kind of check a planner would charge for.'],
    checklist: ['Another review done', 'You\'ve worked through the review checklists: buffer, sales, income target, rebalancing.'],
    regular: ['Thanks for sticking with it', 'You\'ve been using FIRE Command Center for a couple of months now.'],
  };
  function donateNudge(trigger) {
    try {
      const D = (state.donate = state.donate || {}); const now = Date.now(), day = 864e5;
      D.firstSeen = D.firstSeen || now; D.fired = D.fired || {}; D.shown = D.shown || [];
      if (D.never || D.donated || D.fired[trigger] || !NUDGE[trigger]) return;
      if (now - D.firstSeen < 3 * day || D.shown.length >= 3 || (D.shown.length && now - D.shown[D.shown.length - 1] < 45 * day)) return;
      if (document.querySelector('#pwModal.on')) return;
      D.fired[trigger] = now; D.shown.push(now); save();
      const [title, why] = NUDGE[trigger];
      const m = $('#donateModal'); if (!m) return;
      m.innerHTML = `<div class="pwbox donatebox"><img class="dnicon" src="%%BRAND_ICON%%" alt=""><h3>${title}</h3><p>${why}</p>
        <p>FIRE Command Center is free for everyone: no subscription, no ads, no account, and your data never leaves your computer. <b>We really appreciate donations that help keep it that way</b>.</p>
        <p class="mut">Donate what you can, and only if you're getting real value from this app.<br>Thank you, from Pay Forward Labs.</p>
        <div class="row"><a class="btn donatebtn" id="dnGo" href="${DONATE_URL}" target="_blank" rel="noopener noreferrer">Donate</a><button class="btn" id="dnLater">Maybe later</button></div>
        <div class="row" style="margin-top:6px"><a href="#" id="dnDone" class="mut">I've donated, thank you</a> · <a href="#" id="dnNever" class="mut">Don't ask again</a></div></div>`;
      m.classList.add('on');
      const close = () => { m.classList.remove('on'); m.innerHTML = ''; save(); };
      $('#dnGo').onclick = () => { D.clicked = now; setTimeout(close, 50); };
      $('#dnLater').onclick = close;
      $('#dnDone').onclick = (e) => { e.preventDefault(); D.donated = now; close(); toast('Thank you! You won\'t see this again.'); };
      $('#dnNever').onclick = (e) => { e.preventDefault(); D.never = now; close(); toast('Got it. The Donate link stays on the Help tab if you change your mind.'); };
      m.onclick = (e) => { if (e.target === m) close(); }; m.onkeydown = (e) => { if (e.key === 'Escape') close(); };
    } catch (e) { /* never block the app over a reminder */ }
  }
  const nudgeLater = (trigger, ms = 1500) => setTimeout(() => donateNudge(trigger), ms);

  // ---------- HOW TO USE (help tab) ----------
  function vHelp() {
    const S = state.settings; const st = ST();
    const go = (tab, label, ptab) => `<a href="#" data-tab="${tab}"${ptab ? ` data-ptab-go="${ptab}"` : ''}>${label}</a>`;
    const fileRows = [
      ['Fidelity positions', 'CSV', 'Fidelity.com → Accounts → Positions → Download (all accounts)', 'Holdings, quantities, prices, cost basis'],
      ['Fidelity monthly / quarterly statement', 'PDF', 'Fidelity.com → Documents → Statements', 'Balances and holdings by account (use the CSV when you can; it has cost basis)'],
      ['Schwab positions', 'CSV', 'Schwab.com → Accounts → Positions → Export (one account or All-Accounts)', 'Holdings, quantities, prices, cost basis'],
      ['Wealthfront statement', 'PDF', 'Wealthfront → Documents → Statements', 'Holdings and balances'],
      ['Vanguard 401(k) statement', 'PDF', 'Vanguard (employer plan) → Statements', 'Balance by fund and source (pre-tax / Roth)'],
      ['Vestwell 401(k) statement', 'PDF', 'Your plan site → Statements', 'Balance by fund and source'],
      ['Morgan Stanley at Work stock plan', 'PDF', 'Stock-plan site → Portfolio → lot detail / statement', 'Share lots with purchase dates and cost (for tax-aware sale plans)'],
      ['Bank and credit-card transactions', 'CSV', 'Your bank or card site → Activity → Download (CSV). Tested with Chase, Bank of America, Capital One, Schwab checking, Amex and Fidelity cash management; most others with Date / Description / Amount (or Debit / Credit) columns work', 'Spending tab: money out by category and month. Card payments and transfers are detected so nothing is counted twice'],
      ['W-2 wage statements', 'PDF', 'Employer payroll site (ADP, Workday, Gusto…) → Tax documents, in late January', 'Wages, withholding, 401(k)/Roth/HSA (box 12), Social Security and Medicare wages, state tax. Checks 401(k) room, excess Social Security tax and the return; can fill Plan → Work income'],
      ['Federal tax return (Form 1040 + schedules)', 'PDF', 'TurboTax / preparer copy, or IRS transcript saved as PDF', 'Summary lines only: wages, AGI, taxable income, gains, tax, carryforwards, withholding'],
      ['California return (Form 540)', 'PDF', 'Usually in the same PDF as the 1040', 'CA AGI, deduction, taxable income, tax, withholding (other states’ returns aren’t read)'],
      ['ProjectionLab export', 'JSON or CSV', 'ProjectionLab → Settings → Export data', 'Comparison only (Plan → Compare → vs ProjectionLab); never overwrites your plan'],
      ['FIRE Command Center data file', '.fire (encrypted)', 'Made by this app: Export, auto-save, snapshots', 'Everything: accounts, history, plans, settings, spending, returns'],
    ];
    return `<div class="card"><div class="helphero"><img class="firewm" src="%%FIRE_WORDMARK%%" alt="FIRE Command Center: retirement & financial planning"><div class="madeby helpbrand"><span class="mut">Made by</span><img src="%%BRAND_WORDMARK%%" alt="Pay Forward Labs" style="height:44px"></div></div></div>
    <div class="card"><h3>How to use this tool <span class="sub">a private, offline retirement and tax planner</span></h3>
      <p>FIRE Command Center turns your statements into a current net worth, a cash-buffer and sale plan for each quarter, a tax picture for this year, and a lifetime plan with Monte Carlo risk. It runs entirely in this browser from one HTML file. There's no account, no server, and nothing you import is uploaded.</p>
      <p class="note">Set up for: <b>${esc(st.name)}</b> · <b>${SOLO() ? 'single' : 'married filing jointly'}</b> · household of ${S.household.size}. Change these in ${go('settings', 'Settings → Rules & reference')}.</p></div>
    ${donateCard()}

    <div class="card"><h3>First-time setup <span class="sub">about 30 minutes</span></h3><ol class="steps">
      <li><b>Pick your state and filing status</b> in ${go('settings', 'Settings → Rules & reference')}.</li>
      <li><b>Import your statements</b> with the <b>Import</b> button in the header (or drag files onto ${go('import', 'Data & import')}). Review what was read, then click <b>Apply to working copy</b>. Accounts you can't download can be added by hand on ${go('accounts', 'Net worth')}.</li>
      <li><b>Check owners and account types</b> on ${go('accounts', 'Net worth')}: pre-tax, Roth, taxable, HSA, 529, and whose account it is. Add cost basis where a statement didn't include it.</li>
      <li><b>Fill in Plan → Assumptions</b> (${go('plan', 'open', 'setup')}): birth years, retirement age, spending, jobs and where paychecks go, Social Security, healthcare, home and rentals, investment mix, and any concentrated stock ticker.</li>
      <li><b>Import last year's tax return</b> (PDF) on ${go('returns', 'Taxes → Returns')}. It checks the tax engine against your real return and fills carryforwards and prior-year safe harbor.</li>
      <li><b>Several households?</b> Use the data-set menu in the header to add a separate data set for each, and switch between them. Unload one to remove it from this browser; its encrypted files stay in the data folder.</li>
      <li><b>Turn on auto-save</b> on ${go('import', 'Data & import')}: choose a data folder and a password. From then on every change is saved, encrypted, to that folder.</li>
      <li><b>Click Save snapshot</b> in the header to record today's balances in History.</li></ol></div>

    <div class="card"><h3>The routine</h3>
      <table class="tbl"><thead><tr><th>When</th><th>Where</th><th>What to do</th></tr></thead><tbody>
      <tr><td><b>Each quarter</b></td><td>${go('review', 'Review → Quarterly')}</td><td>Import fresh statements, look at the cash buffer and suggested sales, rebalance if a bucket drifted more than ±5 points, then Save snapshot.</td></tr>
      <tr><td><b>Oct – Dec</b></td><td>${go('yearend', 'Review → Year-end')}</td><td>Set this year's income target, harvest losses or gains, Roth conversions, ${SOLO() ? '' : 'both '}retirement contributions, ACA enrollment for next year.</td></tr>
      <tr><td><b>January</b></td><td>${go('annual', 'Review → Annual reset')}</td><td>Update spending, returns and goals; re-run the Plan; check the strategy comparison.</td></tr>
      <tr><td><b>Feb – Apr</b></td><td>${go('filing', 'Taxes → Filing')}</td><td>Document checklist, traps to avoid, then import the filed return on ${go('returns', 'Returns')}.</td></tr>
      <tr><td><b>Any time</b></td><td>${go('spending', 'Money → Spending')}</td><td>Import bank and card CSVs to see where money actually goes and compare it with the Plan's spending.</td></tr>
      <tr><td><b>Estimated taxes</b></td><td>${go('taxes', 'Taxes → This year')}</td><td>Safe-harbor amounts and due dates for federal${st.type === 'none' ? '' : ` and ${esc(st.name)}`}.</td></tr></tbody></table>
      <p class="note">The <b>Home</b> tab shows what's due now. Red or amber dots on tabs mean something needs attention.</p></div>

    <div class="card"><h3>What each area does</h3><ul class="steps">
      <li><b>Home:</b> net worth, this phase's goals (working vs retired), and the next step.</li>
      <li><b>Review:</b> Quarterly (buffer, sales, rebalancing, prices), Year-end (income control), Annual reset.</li>
      <li><b>Money:</b> Net worth (accounts and holdings, all editable), Spending, Rentals, History (snapshots and the daily price log).</li>
      <li><b>Taxes:</b> This year (estimate, ACA and Medicare income limits, estimated payments), Returns (imported returns and W-2s, carryforwards, lookback), Filing.</li>
      <li><b>Plan:</b> Assumptions, Life events (a timeline of retirement, Social Security, Medicare, moves, inheritances and more), Overview, Cash flow, Analytics (click a year for details), Strategies (tax strategies and direct indexing), Risk (Monte Carlo and historical backtest), Compare (your plans side by side, or vs ProjectionLab).</li>
      <li><b>Settings:</b> Data & import (files, auto-save, backups), Rules & reference (state, buffer and sale rules, market data, tax tables).</li></ul>
      <p class="note">Anything filled in from an imported file (balances, cost basis, return lines, wages, carryforwards) can be edited, and your edits win over later imports.</p></div>

    <div class="card"><h3>Files you can import</h3>
      <div class="scroll"><table class="tbl"><thead><tr><th>Source</th><th>Type</th><th>How to get it</th><th>What's read</th></tr></thead><tbody>
      ${fileRows.map(([a, b, c, d]) => `<tr><td><b>${a}</b></td><td>${b}</td><td>${c}</td><td>${d}</td></tr>`).join('')}</tbody></table></div>
      <ul class="steps">
        <li><b>File type is detected automatically.</b> Drop several at once; each is routed to the right place (holdings, Spending, Returns or Compare).</li>
        <li><b>PDFs must contain text.</b> Scanned or photographed pages have no text to read. Download the original PDF from the institution instead.</li>
        <li><b>Re-importing is safe.</b> Holdings are replaced by account; transactions are de-duplicated (same account, amount, payee and date within 2 days); returns keep your edits.</li>
        <li><b>Other institutions:</b> if a file isn't recognized, add the account by hand on Net worth, or export positions to CSV and check the format matches Fidelity's or Schwab's.</li>
        <li><b>Tax returns:</b> SSNs, names and addresses are never stored; only the summary lines listed above.</li></ul></div>

    <div class="card"><h3>Where your data lives</h3>
      <table class="tbl"><thead><tr><th>Place</th><th>What</th><th>Encrypted?</th><th>Notes</th></tr></thead><tbody>
      <tr><td><b>This browser</b></td><td>Working copy of everything</td><td>No (browser storage)</td><td>Per browser and computer. Clearing site data or using a private window loses it, so keep auto-save or exports on.</td></tr>
      <tr><td><b>FIRE-data/autosave/</b></td><td><code>FIRE-autosave.fire</code> plus one dated copy per day (last 30 kept)</td><td>Yes: AES-256-GCM, key from your password (PBKDF2, 310,000 rounds)</td><td>Written about 1.5 s after each change. Needs Chrome or Edge (folder access). After a browser restart, click Auto-save and re-enter the password.</td></tr>
      <tr><td><b>FIRE-data/snapshots/</b></td><td>A full copy at each Save snapshot</td><td>Yes</td><td>Point-in-time restore points.</td></tr>
      <tr><td><b>Export (encrypted)</b></td><td>A <code>.fire</code> file you save anywhere</td><td>Yes</td><td>Works in any modern browser. Load it with <b>Load data file</b> on Data & import.</td></tr>
      <tr><td><b>FIRE-data/datasets/&lt;name&gt;/</b></td><td>Extra data sets (other households or scenarios), each with its own autosave/ and snapshots/</td><td>Yes (each can have its own password)</td><td>Switch, add or unload data sets from the header menu or Settings → Data & import.</td></tr>
      <tr><td><b>FIRE-data/ai-review/</b></td><td>Optional plain-text copy of your data and the analysis for an AI assistant to double-check (Settings → Data & import → AI review export)</td><td><b>No</b></td><td>Names and account numbers masked by default; API keys always removed. Never included in backups or shared packages.</td></tr>
      <tr><td><b>FIRE-data/statements/</b></td><td>Optional place for original PDFs/CSVs</td><td><b>No</b></td><td>The backup script asks before including them.</td></tr>
      <tr><td><b>Backup to Zip.command</b></td><td>Zips the whole folder into Backups/ and copies it to a personal Google Drive if installed</td><td>Data files yes; app and docs no</td><td>Mac only. Uses @gmail.com Drive accounts, or the one in <code>FIRE_DRIVE_ACCOUNT</code>.</td></tr></tbody></table>
      <ul class="steps">
        <li><b>Clearing this browser:</b> Settings → Data & import → <b>Clear this browser</b> removes everything the app stored here (all data sets) and keeps your encrypted files. To do it by hand in Chrome or Edge: open the app, press F12 (⌥⌘I on Mac) → <b>Application</b> → <b>Storage</b> → <b>Clear site data</b>. In Safari: Settings → Privacy → Manage Website Data → remove "file" or local entries. In Firefox: Settings → Privacy & Security → Cookies and Site Data → Manage Data. Clearing your whole browser history/cache also works but removes other sites' data too.</li>
        <li><b>The password can't be recovered.</b> Keep it in a password manager. Without it, the .fire files can't be opened.</li>
        <li><b>Move to a new computer:</b> copy the folder, open the HTML file, Load data file → <code>FIRE-data/autosave/FIRE-autosave.fire</code>, then choose the data folder again.</li>
        <li><b>What leaves your computer:</b> only market-price requests (index, gold, silver, bitcoin and fund symbols) to your own published Google Sheet, Cboe, Yahoo, gold-api.com, CoinGecko, Coinbase, or the price services whose keys you add. No balances, names or files are sent. Turn this off in Settings → Market data. The Donate link opens Stripe in your browser only when you click it.</li>
        <li><b>API keys</b> for price services are stored in your data and encrypted backups. Use free, read-only keys.</li>
        <li><b>Sharing the tool:</b> share only <code>FIRE-Command-Center.html</code> (and <code>fire-app-src</code> for the code). Your data is never inside the HTML file; it stays in your browser and FIRE-data.</li></ul></div>

    <div class="card"><h3>Limitations</h3>
      <p class="note">This is a planning tool, not tax, legal or investment advice. Check important decisions with a CPA or fee-only advisor.</p>
      <h4>Taxes</h4><ul class="steps">
        <li>Federal: 2026 law (including OBBBA) with tables projected forward by inflation; checked against IRS examples (see <code>Validation-Report.md</code>).</li>
        <li>Filing status: married filing jointly or single. Head of household and married filing separately aren't modeled (single is the closest).</li>
        <li>State: <b>${esc(st.name)}</b> is ${st.type === 'ca' ? 'modeled in full' : st.type === 'none' ? 'modeled (no income tax)' : st.q === 'approx' ? '<b>approximate</b> (top rate on all taxable income; enter your effective rate in Settings for a closer number)' : 'modeled from its published brackets'}. City and county income taxes, state credits and special state capital-gains rules aren't modeled, except Washington's capital-gains tax and Massachusetts' surtax.</li>
        <li>Not modeled: tax credits (child, dependent care, foreign tax, energy), charitable deductions, self-employment tax, the kiddie tax. AMT is included.</li>
        <li>The tax-return importer reads Form 1040 and California 540 only. Other states' returns can be entered by hand.</li></ul>
      <h4>Plan and projections</h4><ul class="steps">
        <li>Returns, inflation and spending are your assumptions. Monte Carlo resamples U.S. market history (1928–2025); the future can be worse.</li>
        <li>ACA: assumes enhanced subsidies expired after 2025 (400% of poverty line cliff); change it in Settings if Congress extends them.</li>
        <li>Social Security uses your benefit estimate and claiming age; survivor benefits before the deceased's claiming age aren't modeled.</li>
        <li>Direct-indexing loss harvests are your assumption, not simulated lot by lot.</li>
        <li>Long-term care defaults are California medians; set your own costs.</li>
        <li>Estates: federal exemption only; state estate and inheritance taxes aren't modeled.</li></ul>
      <h4>Files and browsers</h4><ul class="steps">
        <li>Statement formats change. If an import looks wrong, edit the values, or add the account by hand.</li>
        <li>Only the institutions listed above are recognized; others can be entered manually.</li>
        <li>Auto-save to a folder needs Chrome or Edge. Safari and Firefox work with Export / Load data file.</li>
        <li>Spending categories come from payee keywords; change a category and that payee keeps it on future imports.</li></ul></div>`;
  }

  // ---------- STATE TAX REFERENCE ----------
  function stateRefCard() {
    const st = ST(); const c = st.code; const ov = (state.settings.ref.stateOverrides || {})[c] || {};
    const Q = { exact: ['pos', 'exact'], good: ['', 'published 2025 schedule'], approx: ['warnc', 'approximate'] }[st.q] || ['', ''];
    const flags = [st.stdFed ? 'starts from federal taxable income' : st.std ? `state deduction ${usd(st.std)} (MFJ)` : st.type === 'none' || st.type === 'ca' ? '' : 'no standard deduction',
      st.ssTax ? 'taxes some Social Security' : st.type === 'none' ? '' : 'Social Security exempt', st.retEx ? 'exempts retirement-plan withdrawals' : '', st.cp ? 'community property (full step-up at first death)' : '',
      st.surtax ? `+${pct(st.surtax.rate * 100, 0)} surtax over ${usd(st.surtax.over)}` : '', st.cg ? `${pct(st.cg.rate * 100, 0)} capital-gains excise over ${usd(st.cg.over)}${st.cg.over2 ? ` (${pct(st.cg.rate2 * 100, 1)} over ${usd(st.cg.over2)})` : ''}` : '', st.note || ''].filter(Boolean);
    const rates = st.type === 'ca' ? 'California brackets (1%–12.3%) + 1% over $1M; capital gains taxed as ordinary income. Tables are under Reference tables below.'
      : st.type === 'none' ? 'No income tax on wages or investment income.'
      : st.type === 'brackets' ? 'Brackets (MFJ): ' + st.brackets.map(([l, r], i) => `${pct(r * 100, 2)}${l === Infinity ? ' above' : ' to ' + usd(l)}`).join(' · ')
      : `${pct(st.rate * 100, 2)} ${st.type === 'approx' ? 'applied to all taxable income (the top rate, so it errs high)' : 'flat'}`;
    const editable = st.type === 'flat' || st.type === 'approx';
    return `<div class="card"><h3>${esc(st.name)} income tax <span class="sub"><span class="${Q[0]}">${Q[1]}</span></span></h3>
      <p>${rates}</p>${flags.length ? `<p class="mut">${flags.map(esc).join(' · ')}</p>` : ''}
      ${editable ? `<div class="grid4"><label class="fld"><span>Rate % (override)</span><input class="num" data-st-ov="rate" value="${ov.rate != null ? +(ov.rate * 100).toFixed(3) : ''}" placeholder="${+(st.rate * 100).toFixed(3)}"></label>
        <label class="fld"><span>State deduction, MFJ (override)</span><input class="num" data-st-ov="std" value="${ov.std ?? ''}" placeholder="${st.stdFed ? 'uses federal' : st.std || 0}"></label></div>` : ''}
      <p class="note">${st.type === 'ca' ? 'California is modeled in full, including Prop 13, SDI, the 2.5% early-withdrawal tax and 30/40/0/30 estimated payments.' : `The Plan applies this to AGI each year (Social Security${st.retEx ? ' and retirement withdrawals' : ''} excluded where the state does). Local and city income taxes, credits and special capital-gains rules aren't modeled.${st.q === 'approx' ? ' Approximate: for a closer number, enter your effective rate from last year\'s state return (state tax ÷ federal AGI) above.' : ''}`} Moving states? Change it above; ACA, estate and estimated-payment guidance follow.</p></div>`;
  }

  // ---------- SETTINGS ----------
  function vSettings() {
    const S = state.settings;
    const fplRows = Object.entries(S.ref.fpl).map(([y, [b, a]]) => `<tr><td>${y}</td><td><input type="number" data-scope="settings" data-path="ref.fpl.${y}.0" value="${b}"></td><td><input type="number" data-scope="settings" data-path="ref.fpl.${y}.1" value="${a}"></td></tr>`).join('');
    const ps = phaseSettings();
    return `<div class="card"><h3>Life phase</h3><div class="grid4">
      ${field('Phase', 'settings', 'household.phase', { type: 'select', options: [['auto', 'Automatic (by retirement date)'], ['working', 'Working'], ['retired', 'Retired']] })}
      <label class="fld"><span>Retirement starts</span><b style="padding:6px 0;display:block">${ps.household.retireDate || 'already retired'}</b><span class="hint">from your retirement age in <a href="#" data-tab="plan" data-ptab-go="setup">Assumptions</a></span></label>
      ${field('Working: gains to realize per year to diversify', 'settings', 'working.gainBudget', { hint: '$0 = only tax-free sales (offset by losses)' })}
</div>
      <p class="note">Working years: diversify and cut taxes; no income targets or buffer refills. Retired: fund spending from the cash buffer and control income (MAGI) each year. The Quarterly Review, Annual Review and calendar switch automatically on the retirement date.</p></div>
    <div class="card"><h3>Household</h3><div class="grid4">
      ${field('State of residence', 'settings', 'household.state', { type: 'select', options: Object.entries(E.STATES).sort((x, y) => x[1].name.localeCompare(y[1].name)).map(([c, v]) => [c, v.name]) })}
      ${field('Filing status', 'settings', 'household.filing', { type: 'select', options: [['MFJ', 'Married filing jointly'], ['single', 'Single (no spouse)']] })}
      ${field('Household size (ACA)', 'settings', 'household.size', { hint: 'people on your tax return' })}</div>
      <p class="note">Names, birth years, retirement ages, spending, returns, allocation, ACA and dividend assumptions are all in <a href="#" data-tab="plan" data-ptab-go="setup">Plan → Assumptions</a>.</p></div>
      ${stateRefCard()}
      <div class="card"><h3>Buffer rules</h3><div class="grid4">
      ${field('Target (years of spending)', 'settings', 'buffer.targetYears')}${field('Refill trigger (years)', 'settings', 'buffer.refillTriggerYears')}
      ${field('Emergency cash (months of spending)', 'settings', 'buffer.emergencyMonths', { hint: 'working: the cash you keep; retired: the floor' })}${field('Dividends sweep into buffer', 'settings', 'buffer.dividendsSweepToCash', { type: 'check' })}
      ${field('"Near ATH" if within %', 'settings', 'market.nearATHPct')}${field('"Correction" if down ≥ %', 'settings', 'market.correctionPct')}
</div>
      <p class="note">Mode precedence: Emergency (below floor and not near the high) → Full Refill (below trigger and near the high) → Defensive (below trigger, market down) → Trim → Zero-Sale.</p></div>
      <div class="card"><h3>Sale plans</h3><div class="grid4">
      ${field('Plan priority', 'settings', 'plan.priority', { type: 'select', options: [['tax', 'Most cash per MAGI dollar'], ['diversify', 'Reduce ' + CS() + ' first']] })}
      ${field('Split sales across Jan 1 (Q4)', 'settings', 'plan.splitAcrossYearEnd', { type: 'check' })}</div></div>
      <div class="card"><h3>Market data</h3><div class="grid4">
      ${field('Fetch live prices on Quarterly Review', 'settings', 'quotes.enabled', { type: 'check' })}
      ${field('Google Sheet published CSV link (recommended)', 'settings', 'quotes.sheetUrl', { text: true, hint: 'see setup below; contains only market formulas' })}
      ${field('FinancialModelingPrep API key (optional, for S&P/Dow/Nasdaq)', 'settings', 'quotes.fmpKey', { text: true, hint: 'free at financialmodelingprep.com' })}
      ${field('Finnhub API key (optional, free)', 'settings', 'quotes.fhKey', { text: true, hint: 'finnhub.io; prices via SPY/DIA/QQQ' })}
      ${field('Index price source', 'settings', 'quotes.prefer', { type: 'select', options: [['auto', 'Automatic (sheet → Cboe → Yahoo → keys)'], ['finnhub', 'Finnhub first (skip the Google Sheet)']] })}
      ${field('Twelve Data API key (optional alternative)', 'settings', 'quotes.tdKey', { text: true, hint: 'free at twelvedata.com; keys stay in this browser and encrypted backups' })}</div>
      <p class="note">Gold, silver and bitcoin come from gold-api.com (free, no key). Gold, silver and bitcoin fall back to CoinGecko and Coinbase. Index levels try your Google Sheet, then Cboe's free delayed-quote feed (no key; also supplies the S&P all-time high from daily history since 1975), then Yahoo Finance (browsers usually block it), then FinancialModelingPrep, Finnhub or Twelve Data if you add a key, falling back to the matching ETF (SPY, DIA, QQQ). Only ticker symbols are sent. Use “Test price sources” on Quarterly Review to see what's failing.</p></div>
      <div class="card"><h3>Set up the free Google Sheet price feed <span class="sub">one time, about 3 minutes</span></h3>
      <p>Google has no public stock API, but Google Sheets' <code>GOOGLEFINANCE</code> function is free and reliable (quotes delayed up to ~20 minutes). The app reads a sheet you publish as CSV. The sheet holds only market formulas, none of your data.</p>
      <ol class="steps"><li>Use a <b>personal</b> Google account and create a new sheet at sheets.new.</li>
      <li>Click cell A1 and paste the first block below (fills A1:F10; leave column G onward empty).</li>
      <li><b>File → Share → Publish to web</b> → pick the sheet → <b>Comma-separated values (.csv)</b> → Publish, then copy the link.</li>
      <li>Paste the link into “Google Sheet published CSV link” above, then open Quarterly Review and click ↻ Refresh prices.</li></ol>
      <textarea class="codebox" readonly rows="8" onclick="this.select()">${esc(SHEET_TEMPLATE)}</textarea>
      <h4>For 1-month history: add the daily recorder script</h4>
      <p class="note">Google won't let historical GOOGLEFINANCE data leave a sheet. This script copies each day's prices into columns G onward as plain numbers, which the published CSV does include. In the sheet: <b>Extensions → Apps Script</b>, replace everything with the code below, Save, choose <b>installDailyTrigger</b> in the function menu and click <b>Run</b> (approve access once). It then runs every day around 2 pm. History builds one day at a time; until there are 5+ days, the app uses Cboe and CoinGecko for charts.</p>
      <textarea class="codebox" readonly rows="10" onclick="this.select()">${esc(SHEET_SCRIPT)}</textarea>
      <p class="note">Note: Google blocks historical GOOGLEFINANCE data from leaving the sheet, so columns E and G may show #N/A in the published copy even though they display in Sheets. That's expected; the app gets the all-time high and 1-month charts from Cboe and CoinGecko instead. Prices in column B are what matter. Gold, silver, bitcoin and ether use Google's currency feeds (XAUUSD, XAGUSD, BTCUSD, ETHUSD). Add a row for any fund you hold (lower-case ticker in column A, =GOOGLEFINANCE("TICKER","price") in B) to price it live; GLD and IBIT are examples. Google refreshes published sheets about every 5 minutes.</p></div>
      <div class="card"><h3>Poverty guidelines <span class="sub">add next year's row when HHS publishes it (January)</span></h3>
      <table class="tbl narrow"><thead><tr><th>Guideline year</th><th>1 person</th><th>+ each extra</th></tr></thead><tbody>${fplRows}</tbody></table></div>
`;
  }

  // ---------- boot ----------
  state = load();
  function countSession() { const D = (state.donate = state.donate || {}); D.firstSeen = D.firstSeen || Date.now(); D.sessions = (D.sessions || 0) + 1; if (D.sessions >= 6 && Date.now() - D.firstSeen > 60 * 864e5) nudgeLater('regular', 20000); }
  if (!document.readyState || document.readyState === 'loading') document.addEventListener('DOMContentLoaded', () => { countSession(); save(); render(); }); else { countSession(); save(); render(); }
})();
