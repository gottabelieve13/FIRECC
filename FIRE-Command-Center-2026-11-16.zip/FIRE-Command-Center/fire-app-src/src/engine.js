/* ============================================================
   ENGINE — pure functions: snapshot + settings → analysis.
   Estimates only; every threshold lives in settings so it can be
   updated each year without code changes.
   ============================================================ */
(function (root) {
  const E = {};
  // the user's concentrated position (employer stock etc.): tickers + display name, set by the app from Settings
  E._conc = { symbols: [], label: 'your single stock' };
  E.cs = () => E._conc.label;
  E.isConc = (sym) => E._conc.symbols.includes(String(sym || '').toUpperCase());

  // ---------- reference tables (editable via settings.ref) ----------
  E.DEFAULT_REF = {
    // HHS poverty guidelines (48 states). Coverage year Y uses guideline year Y-1.
    fpl: { 2024: [15060, 5380], 2025: [15650, 5500], 2026: [15960, 5680] },
    // Federal MFJ 2026 (IRS IR-2025-103 / Rev. Proc. 2025-32)
    fed: {
      2024: { std: 29200, brackets: [[23200, .10], [94300, .12], [201050, .22], [383900, .24], [487450, .32], [731200, .35], [Infinity, .37]], ltcg: [[94050, 0], [583750, .15], [Infinity, .20]] },
      2025: { std: 31500, brackets: [[23850, .10], [96950, .12], [206700, .22], [394600, .24], [501050, .32], [751600, .35], [Infinity, .37]], ltcg: [[96700, 0], [600050, .15], [Infinity, .20]] }, // OBBBA std deduction
      2026: {
        std: 32200,
        brackets: [[24800, 0.10], [100800, 0.12], [211400, 0.22], [403550, 0.24], [512450, 0.32], [768700, 0.35], [Infinity, 0.37]],
        ltcg: [[98900, 0], [613700, 0.15], [Infinity, 0.20]],
      },
    },
    niitThreshold: 250000,
    // FICA 2026: Social Security wage base $184,500 (SSA), Medicare 1.45% + 0.9% over $250k MFJ
    fica: { ssBase: 184500, ssRate: 0.062, medRate: 0.0145, addlThreshold: 250000, addlRate: 0.009 },
    // California MFJ — approximate; indexed yearly
    ca: { 2024: { std: 11080, brackets: [[21512, .01], [50998, .02], [80490, .04], [111732, .06], [141212, .08], [721318, .093], [865574, .103], [1442628, .113], [Infinity, .123]] }, 2025: { std: 11412, brackets: [[22158, .01], [52528, .02], [82904, .04], [115084, .06], [145448, .08], [742958, .093], [891542, .103], [1485906, .113], [Infinity, .123]] } }, // FTB 2025 Schedule Y (MFJ); single = half
    // ACA applicable-percentage curve (post-enhanced-subsidy schedule, 2026). [FPL%, pct]
    acaCurve: [[0, 0.021], [133, 0.0314], [150, 0.0419], [200, 0.066], [250, 0.0844], [300, 0.0996], [400, 0.0996]],
    irmaaMFJ: 218000,
    // 2026 IRMAA (CMS): MAGI tiers and monthly surcharges per person (Part B above the $202.90 standard; Part D add-on)
    irmaa: { mfj: [218000, 274000, 342000, 410000, 750000], single: [109000, 137000, 171000, 205000, 500000],
      partB: [81.20, 202.90, 324.60, 446.30, 487.00], partD: [14.50, 37.50, 60.40, 83.30, 91.00] },
    medicarePartB: 202.90, // 2026 standard monthly premium (Medicare.gov)
    caSdi: 0.013, // California SDI 2026 (EDD), all wages
    fedSingle: { 2024: { std: 14600, brackets: [[11600, .10], [47150, .12], [100525, .22], [191950, .24], [243725, .32], [609350, .35], [Infinity, .37]], ltcg: [[47025, 0], [518900, .15], [Infinity, .20]] }, 2025: { std: 15750, brackets: [[11925, .10], [48475, .12], [103350, .22], [197300, .24], [250525, .32], [626350, .35], [Infinity, .37]], ltcg: [[48350, 0], [533400, .15], [Infinity, .20]] }, 2026: { std: 16100, brackets: [[12400, .10], [50400, .12], [105700, .22], [201775, .24], [256225, .32], [640600, .35], [Infinity, .37]], ltcg: [[49450, 0], [545500, .15], [Infinity, .20]] } },
    // AMT 2026 (OBBBA): exemptions, phase-out starts, 28% breakpoint
    amt: { 2024: { exMFJ: 133300, exSingle: 85700, poMFJ: 1218700, poSingle: 609350, bp: 232600, poRate: 0.25 }, 2025: { exMFJ: 137000, exSingle: 88100, poMFJ: 1252700, poSingle: 626350, bp: 239100, poRate: 0.25 }, 2026: { exMFJ: 140200, exSingle: 90100, poMFJ: 1000000, poSingle: 500000, bp: 244500, poRate: 0.5 } },
    estateExemption: 15000000, // per person 2026 (OBBBA), indexed after

    indexRate: 0.025, // used to roll tables forward when a year is missing
  };

  E.DEFAULT_SETTINGS = {
    refVersion: 2,
    household: { filing: 'MFJ', size: 3, state: 'CA', birthYearSelf: new Date().getFullYear() - 40, birthYearSpouse: new Date().getFullYear() - 40, agesConfirmed: false, selfName: 'You', spouseName: 'Spouse', phase: 'auto', retireDate: '' },
    working: { gainBudget: 0 }, // while working: gains you're willing to realize per year to diversify (0 = only tax-free, offset by losses)
    spending: { annual: 80000, confirmed: false, source: 'plan', sourceV: 1 }, // starter: typical U.S. household aged 35–44 (see E.STARTER)
    buffer: { targetYears: 2, refillTriggerYears: 1, emergencyMonths: 6, dividendsSweepToCash: true },
    market: { nearATHPct: 3, correctionPct: 10 },
    aca: { enabled: true, cliffInEffect: true, ceiling: 'cliff', customCeiling: 100000, safetyMargin: 3000, benchmarkPremium: 0 },
    trim: { googConcentrationMax: 25, googYtdTrigger: 20 },
    quotes: { enabled: true, sheetUrl: '', fmpKey: '', fhKey: '', tdKey: '', prefer: 'auto' },
    plan: { priority: 'tax' /* 'tax' | 'diversify' */, splitAcrossYearEnd: true },
    alloc: { stock: 70, bond: 30, alt: 0, intlShare: 30, band: 5 }, // target mix of invested assets (excl. cash buffer, private)
    yields: {
      FXAIX: 1.2, FSMAX: 1.0, SWSSX: 1.3, SWISX: 2.8, FSPSX: 2.8, FXNAX: 3.7, IOND: 0, SPAXX: 3.4, TIMXX: 3.4,
      CMF: 3.0, IEMG: 2.8, LQD: 4.5, SCHD: 3.8, SCHF: 2.9, SCHP: 4.0, VDE: 3.2, VEA: 3.0, VIG: 1.7, VTI: 1.2, VWO: 3.0, XLE: 3.3,
    },
    classYields: { us_stock: 1.3, intl_stock: 2.9, bond: 3.8, muni: 3.0, cash: 3.4, bank: 1.5, gold: 0, crypto: 0, goog: 0.3, balanced: 2.0, other: 0 },
    ref: E.DEFAULT_REF,
  };

  // Starter household for a new data set: a typical U.S. married couple around age 40 with one child.
  // Sources: BLS Consumer Expenditure Survey 2025 (released Oct 29, 2026): all households averaged $110,847 income before
  // taxes and $81,905 of spending; households aged 35–44 typically run about 10–20% above those averages. Spending here
  // excludes Social Security/pension contributions (the plan computes payroll tax and 401(k) saving itself).
  // Shares follow the CE 2025 mix (housing 34%, transportation 16.5%, food 13%, healthcare 8%, entertainment 5% …).
  E.STARTER = {
    wages: [['self', 'Job', 65000], ['spouse', 'Job', 55000]], // ≈ $120k household; 6% to 401(k), 3% match
    spending: [['Housing (rent or mortgage, utilities, upkeep)', 31200, 'essential'], ['Transportation (car payments, gas, insurance, repairs)', 15000, 'essential'],
      ['Groceries', 7200, 'essential'], ['Health insurance via work (your share)', 4800, 'essential', 65], ['Out-of-pocket medical, dental, vision', 2400, 'essential'], ['Kids, childcare & education', 1700, 'essential'],
      ['Dining, entertainment & travel', 9900, 'discretionary'], ['Clothing, personal care & other', 5300, 'discretionary'], ['Gifts & charity', 2500, 'discretionary']],
    ss: { selfPIA: 28000, spousePIA: 25000 }, // rough benefit at 67 for these earnings, today's $; replace with ssa.gov estimates
    retireAge: 65,
    source: 'BLS Consumer Expenditure Survey 2025 (all households: $110,847 income, $81,905 spending), scaled to ages 35–44',
  };
  E.DEFAULT_MANUAL = {
    checking: 20000, checkingOwner: 'joint', // starter: a few months of spending; replace with your balance wageIncome: 0, ytdRealizedGains: 0, ytdHarvestedLosses: 0, lossCarryforward: 0, otherIncome: 0,
    spDrawdownPct: null, googYtdPct: null, rothBasisAvailable: 0, manualAccounts: [],
  };

  // ---------- small utils ----------
  const sum = (a, f = (x) => x) => a.reduce((s, x) => s + (f(x) || 0), 0);
  const yearOf = (d) => +String(d).slice(0, 4);
  const monthOf = (d) => +String(d).slice(5, 7);
  E.sum = sum;

  function rolledTable(tbl, year, idx) {
    const ys = Object.keys(tbl).map(Number).sort();
    // JSON (localStorage) turns Infinity into null; normalize top brackets back to Infinity
    const norm = (b) => b && b.map(([lim, r]) => [lim == null ? Infinity : lim, r]);
    if (tbl[year]) return { t: { ...tbl[year], brackets: norm(tbl[year].brackets), ltcg: norm(tbl[year].ltcg) }, est: false };
    const last = ys.filter((y) => y <= year).pop() ?? ys[0];
    const f = Math.pow(1 + idx, year - last);
    const src = tbl[last];
    const scale = (b) => b.map(([lim, r]) => [lim == null || lim === Infinity ? Infinity : Math.round(lim * f), r]);
    return { t: { std: Math.round(src.std * f), brackets: scale(src.brackets), ltcg: src.ltcg ? scale(src.ltcg) : undefined }, est: true };
  }
  E.fplFor = (ref, guidelineYear, size) => {
    let row = ref.fpl[guidelineYear], est = false;
    if (!row) {
      const last = Math.max(...Object.keys(ref.fpl).map(Number));
      const f = Math.pow(1 + ref.indexRate, guidelineYear - last); row = ref.fpl[last].map((v) => v * f); est = true;
    }
    return { value: Math.round(row[0] + row[1] * (size - 1)), est };
  };

  // ---------- snapshot helpers ----------
  E.allAccounts = (snap) => {
    const man = (snap.manual?.manualAccounts || []).map((m, i) => ({ // legacy v1 format
      key: 'manual:' + i, institution: 'Manual', name: m.name, taxType: m.taxType || 'taxable', asOf: snap.asOf, manual: true,
      holdings: [{ symbol: m.symbol || 'MANUAL', desc: m.name, value: +m.value || 0, cost: m.cost === '' || m.cost == null ? null : +m.cost, assetClass: m.assetClass || 'other' }],
    }));
    const chk = snap.manual?.checking ? [{ owner: snap.manual.checkingOwner || 'joint',
      key: 'manual:checking', institution: 'Bank', name: 'Checking / savings (manual)', taxType: 'taxable', asOf: snap.asOf, manual: true,
      holdings: [{ symbol: 'CHECKING', desc: 'Checking', value: +snap.manual.checking, cost: null, assetClass: 'bank' }],
    }] : [];
    // structured real estate (Net Worth → Real estate) appears as property + mortgage accounts
    const re = (snap.realEstate || []).flatMap((p) => {
      const out = [{ owner: p.owner || 'joint', key: 're:' + p.id, institution: 'Real estate', name: p.name || 'Property', taxType: 'property', asOf: snap.asOf, synthetic: true,
        holdings: [{ symbol: (p.kind || 'primary').toUpperCase(), desc: p.name, value: +p.value || 0, cost: +p.basis || null, assetClass: 'real_estate' }] }];
      if (+p.mtgBalance) out.push({ owner: p.owner || 'joint', key: 'mtg:' + p.id, institution: 'Mortgage', name: (p.name || 'Property') + ' mortgage', taxType: 'liability', asOf: snap.asOf, synthetic: true,
        holdings: [{ symbol: 'MTG', desc: 'Mortgage', value: +p.mtgBalance, cost: null, assetClass: 'other' }] });
      return out;
    });
    return [...snap.accounts, ...man, ...chk, ...re];
  };

  // ---------- portfolio summary ----------
  E.summarize = (snap) => {
    const accts = E.allAccounts(snap);
    const byTax = {}, byClass = {}, byInst = {}, byOwner = {};
    let total = 0;
    let liabilities = 0, property = 0;
    for (const a of accts) {
      let v = sum(a.holdings, (h) => h.value);
      if (a.taxType === 'liability') { v = -Math.abs(v); liabilities += -v; }
      if (a.taxType === 'property') property += v;
      a._value = v; total += v;
      byTax[a.taxType] = (byTax[a.taxType] || 0) + v;
      byInst[a.institution] = (byInst[a.institution] || 0) + v;
      const ow = a.owner || 'joint'; byOwner[ow] = (byOwner[ow] || 0) + v;
      if (a.taxType === 'liability' || a.taxType === 'property') continue;
      for (const h of a.holdings) {
        if (h.assetClass === 'balanced') { byClass.us_stock = (byClass.us_stock || 0) + h.value * 0.5; byClass.intl_stock = (byClass.intl_stock || 0) + h.value * 0.3; byClass.bond = (byClass.bond || 0) + h.value * 0.2; }
        else byClass[h.assetClass] = (byClass[h.assetClass] || 0) + h.value;
      }
    }
    const goog = byClass.goog || 0;
    const taxableAccts = accts.filter((a) => a.taxType === 'taxable');
    const bufferCash = sum(taxableAccts, (a) => sum(a.holdings.filter((h) => h.assetClass === 'cash' || h.assetClass === 'bank'), (h) => h.value)) - 0; // credit cards subtracted below
    const cardDebt = sum(accts.filter((a) => a.taxType === 'liability' && a.debtKind === 'card'), (a) => Math.abs(sum(a.holdings, (h) => h.value)));
    const taxableValue = sum(taxableAccts, (a) => a._value);
    const taxableCost = sum(taxableAccts, (a) => sum(a.holdings, (h) => (h.assetClass === 'cash' || h.assetClass === 'bank' ? h.value : h.cost ?? h.value)));
    const liquid = total - property + liabilities;
    return { accts, total, liquid, property, liabilities, cardDebt, byTax, byClass, byInst, byOwner, goog, googPct: liquid ? goog / liquid * 100 : 0, bufferCash: bufferCash - cardDebt, taxableValue, taxableUnrealized: taxableValue - taxableCost };
  };

  // ---------- frozen summary stored with each saved snapshot ----------
  E.snapshotSummary = (snap, settings) => {
    const an = E.analyze(snap, settings); const s = an.s;
    return {
      netWorth: s.total, liquid: s.liquid, property: s.property, liabilities: s.liabilities, cash: an.cash, goog: s.goog, googPct: s.googPct,
      byTax: s.byTax, byClass: s.byClass, byInst: s.byInst, byOwner: s.byOwner, taxableUnrealized: s.taxableUnrealized,
      income: an.inc.total, magiEst: an.magiNow.value, mode: an.mode, verdict: an.verdict.title, spend: an.spend,
      accounts: s.accts.map((a) => ({ key: a.key, name: a.name, taxType: a.taxType, owner: a.owner || 'joint', value: a._value })),
      market: (() => { const mk = snap.manual?.market || {}; const o = {}; for (const kk of ['spx', 'dji', 'ndx', 'xau', 'xag', 'btc', 'eth']) if (mk[kk]?.price) { o[kk] = mk[kk].price; if (mk[kk].proxy) o[kk + 'Proxy'] = mk[kk].proxy; } if (mk.spxATH) o.spxATH = mk.spxATH; if (snap.manual?.spDrawdownPct != null) o.spDrawdownPct = snap.manual.spDrawdownPct; if (mk.asOf) o.asOf = mk.asOf; return o; })(),
    };
  };

  // ---------- income & MAGI ----------
  E.portfolioIncome = (snap, settings) => {
    // full-year estimate of taxable-account income (what lands on the 1040)
    const rows = []; let ordinary = 0, qualified = 0, taxExempt = 0;
    for (const a of E.allAccounts(snap)) {
      if (a.taxType !== 'taxable') continue;
      for (const h of a.holdings) {
        let inc, src;
        if (h.assetClass === 'goog' && a.dividends && a.dividends.length) {
          const last = a.dividends.slice(-1)[0].amount; inc = last * 4; src = 'last dividend × 4';
        } else if (h.symbol === 'CHECKING') { inc = h.value * (settings.checkingYield ?? 0.5) / 100; src = 'checking ~0.5%'; }
        else {
          const y = settings.yields[h.symbol] ?? settings.classYields[h.assetClass] ?? 0;
          inc = h.value * y / 100; src = `${y}% est. yield`;
        }
        let kind = 'qualified';
        if (h.assetClass === 'bond' || h.assetClass === 'cash' || h.assetClass === 'bank') kind = 'ordinary';
        if (h.assetClass === 'muni') kind = 'taxExempt';
        if (h.assetClass === 'intl_stock') { ordinary += inc * 0.15; qualified += inc * 0.85; }
        else if (kind === 'ordinary') ordinary += inc; else if (kind === 'taxExempt') taxExempt += inc; else qualified += inc;
        if (inc > 0.5) rows.push({ account: a.name, symbol: h.symbol, value: h.value, income: inc, kind, src });
      }
    }
    return { rows, ordinary, qualified, taxExempt, total: ordinary + qualified + taxExempt };
  };

  E.magi = ({ ordinary, qualified, taxExempt, otherIncome = 0, gains = 0, losses = 0, carryforward = 0 }) => {
    const netCap = gains - losses - carryforward;
    const capInc = Math.max(netCap, -3000);
    return { netCap, capInc, value: ordinary + qualified + taxExempt + otherIncome + capInc, carryOut: Math.max(0, -(netCap) - 3000) };
  };

  E.acaThresholds = (settings, taxYear) => {
    const fp = E.fplFor(settings.ref, taxYear - 1, settings.household.size);
    const t = {
      fpl: fp.value, fplEst: fp.est,
      csr94: Math.round(fp.value * 1.5), csr87: Math.round(fp.value * 2.0), csr73: Math.round(fp.value * 2.5),
      cliff: Math.round(fp.value * 4.0),
    };
    const c = settings.aca;
    t.ceiling = c.ceiling === 'csr87' ? t.csr87 : c.ceiling === 'csr73' ? t.csr73 : c.ceiling === 'custom' ? +c.customCeiling : t.cliff;
    if (c.ceiling === 'cliff' && !c.cliffInEffect) t.ceilingNote = 'Cliff toggled off — using 400% FPL as a soft target';
    t.ceilingLabel = { cliff: '400% FPL cliff', csr87: 'CSR-87 (200% FPL)', csr73: 'CSR-73 (250% FPL)', custom: 'Custom ceiling' }[c.ceiling];
    return t;
  };

  E.ptc = (settings, taxYear, magi) => {
    const prem = +settings.aca.benchmarkPremium; if (!prem) return null;
    const th = E.acaThresholds(settings, taxYear); const pct = magi / th.fpl * 100;
    if (pct > 400 && settings.aca.cliffInEffect) return { credit: 0, pct, appPct: null };
    const cv = settings.ref.acaCurve; let ap = cv[cv.length - 1][1];
    for (let i = 0; i < cv.length - 1; i++) if (pct >= cv[i][0] && pct < cv[i + 1][0]) { const [x0, y0] = cv[i], [x1, y1] = cv[i + 1]; ap = y0 + (y1 - y0) * (pct - x0) / (x1 - x0); break; }
    return { credit: Math.max(0, prem - ap * magi), pct, appPct: ap };
  };

  // ---------- tax estimate ----------
  // Federal (MFJ or single) + California. Amounts in `inc` are in taxYear dollars (the planner deflates future
  // years by CPI; thresholds that the law does NOT index are deflated with opts.cpi so they bite harder over time).
  const progressive = (inc, brackets) => { let tax = 0, prev = 0; for (const [lim, r] of brackets) { if (inc <= prev) break; tax += (Math.min(inc, lim) - prev) * r; prev = lim; } return tax; };
  const marginal = (inc, brackets) => { for (const [lim, r] of brackets) if (inc < lim) return r; return brackets[brackets.length - 1][1]; };
  // OBBBA SALT cap: $40,000 (2025) +1%/yr through 2029, phased down 30% of MAGI over $500k (+1%/yr) to a $10k floor; $10k from 2030
  E.saltCap = (calYear, magiNominal) => {
    if (calYear < 2025 || calYear >= 2030) return 10000;
    const k = Math.pow(1.01, calYear - 2025); const cap = 40000 * k, thr = 500000 * k;
    return Math.max(10000, cap - 0.3 * Math.max(0, magiNominal - thr));
  };
  // ---------- State income tax (married filing jointly, base year; single = half the brackets) ----------
  // type: none | flat | brackets | approx (top rate applied flat: conservative). q: 'exact' (verified), 'good' (published
  // 2025 schedule), 'approx'. stdFed: starts from federal taxable income. ssTax: taxes some Social Security for high earners.
  // retEx: exempts retirement-plan distributions. cg: Washington's capital-gains excise. All editable in Settings.
  E.STATES = {
    AL: { name: 'Alabama', type: 'approx', rate: 0.05, std: 7500, q: 'approx' }, AK: { name: 'Alaska', type: 'none', q: 'exact' },
    AZ: { name: 'Arizona', type: 'flat', rate: 0.025, stdFed: true, cp: true, q: 'good' }, AR: { name: 'Arkansas', type: 'approx', rate: 0.039, std: 4700, q: 'approx' },
    CA: { name: 'California', type: 'ca', cp: true, q: 'exact' },
    CO: { name: 'Colorado', type: 'flat', rate: 0.044, stdFed: true, ssTax: true, q: 'good' },
    CT: { name: 'Connecticut', type: 'brackets', brackets: [[20000, 0.02], [100000, 0.045], [200000, 0.055], [400000, 0.06], [500000, 0.065], [1000000, 0.069], [Infinity, 0.0699]], std: 0, ssTax: true, q: 'good' },
    DE: { name: 'Delaware', type: 'approx', rate: 0.066, std: 6500, q: 'approx' },
    DC: { name: 'District of Columbia', type: 'brackets', brackets: [[10000, 0.04], [40000, 0.06], [60000, 0.065], [250000, 0.085], [500000, 0.0925], [1000000, 0.0975], [Infinity, 0.1075]], stdFed: true, q: 'good' },
    FL: { name: 'Florida', type: 'none', q: 'exact' },
    GA: { name: 'Georgia', type: 'flat', rate: 0.0519, std: 24000, q: 'good' },
    HI: { name: 'Hawaii', type: 'approx', rate: 0.11, std: 4400, q: 'approx' },
    ID: { name: 'Idaho', type: 'flat', rate: 0.053, stdFed: true, cp: true, q: 'good' },
    IL: { name: 'Illinois', type: 'flat', rate: 0.0495, std: 5700, retEx: true, q: 'good' },
    IN: { name: 'Indiana', type: 'flat', rate: 0.03, std: 2000, q: 'good', note: 'plus county income tax (about 1–3%), not modeled' },
    IA: { name: 'Iowa', type: 'flat', rate: 0.038, stdFed: true, retEx: true, q: 'good' },
    KS: { name: 'Kansas', type: 'approx', rate: 0.0558, std: 8240, q: 'approx' },
    KY: { name: 'Kentucky', type: 'flat', rate: 0.04, std: 6540, q: 'good' },
    LA: { name: 'Louisiana', type: 'flat', rate: 0.03, std: 25000, cp: true, q: 'good' },
    ME: { name: 'Maine', type: 'approx', rate: 0.0715, stdFed: true, q: 'approx' },
    MD: { name: 'Maryland', type: 'approx', rate: 0.0895, std: 6700, q: 'approx', note: 'state top rate plus a typical county rate' },
    MA: { name: 'Massachusetts', type: 'flat', rate: 0.05, std: 8800, surtax: { over: 1083150, rate: 0.04 }, q: 'good', note: 'short-term gains are taxed at 8.5% (not modeled)' },
    MI: { name: 'Michigan', type: 'flat', rate: 0.0425, std: 11600, q: 'good', note: 'plus city income tax in some cities, not modeled' },
    MN: { name: 'Minnesota', type: 'brackets', brackets: [[47620, 0.0535], [189180, 0.068], [330410, 0.0785], [Infinity, 0.0985]], stdFed: true, ssTax: true, q: 'good' },
    MS: { name: 'Mississippi', type: 'flat', rate: 0.044, std: 26600, retEx: true, q: 'good' },
    MO: { name: 'Missouri', type: 'approx', rate: 0.047, stdFed: true, q: 'approx' },
    MT: { name: 'Montana', type: 'approx', rate: 0.059, stdFed: true, ssTax: true, q: 'approx' },
    NE: { name: 'Nebraska', type: 'approx', rate: 0.052, std: 17200, q: 'approx' },
    NV: { name: 'Nevada', type: 'none', cp: true, q: 'exact' },
    NH: { name: 'New Hampshire', type: 'none', q: 'exact' },
    NJ: { name: 'New Jersey', type: 'brackets', brackets: [[20000, 0.014], [50000, 0.0175], [70000, 0.0245], [80000, 0.035], [150000, 0.05525], [500000, 0.0637], [1000000, 0.0897], [Infinity, 0.1075]], std: 2000, retEx: false, q: 'good' },
    NM: { name: 'New Mexico', type: 'approx', rate: 0.059, stdFed: true, cp: true, ssTax: true, q: 'approx' },
    NY: { name: 'New York', type: 'brackets', brackets: [[17150, 0.04], [23600, 0.045], [27900, 0.0525], [161550, 0.055], [323200, 0.06], [2155350, 0.0685], [5000000, 0.0965], [25000000, 0.103], [Infinity, 0.109]], std: 16050, q: 'good', note: 'New York City and Yonkers income tax not modeled' },
    NC: { name: 'North Carolina', type: 'flat', rate: 0.0425, std: 25500, q: 'good' },
    ND: { name: 'North Dakota', type: 'brackets', brackets: [[48475, 0], [244825, 0.0195], [Infinity, 0.025]], stdFed: true, q: 'good' },
    OH: { name: 'Ohio', type: 'brackets', brackets: [[26050, 0], [Infinity, 0.0275]], std: 0, q: 'good', note: 'plus municipal income tax, not modeled' },
    OK: { name: 'Oklahoma', type: 'approx', rate: 0.0475, std: 12700, q: 'approx' },
    OR: { name: 'Oregon', type: 'brackets', brackets: [[8600, 0.0475], [21500, 0.0675], [250000, 0.0875], [Infinity, 0.099]], std: 5600, q: 'good' },
    PA: { name: 'Pennsylvania', type: 'flat', rate: 0.0307, std: 0, retEx: true, q: 'good', note: 'plus local earned-income tax, not modeled' },
    RI: { name: 'Rhode Island', type: 'approx', rate: 0.0599, std: 21800, ssTax: true, q: 'approx' },
    SC: { name: 'South Carolina', type: 'approx', rate: 0.062, stdFed: true, q: 'approx' },
    SD: { name: 'South Dakota', type: 'none', q: 'exact' }, TN: { name: 'Tennessee', type: 'none', q: 'exact' },
    TX: { name: 'Texas', type: 'none', cp: true, q: 'exact' },
    UT: { name: 'Utah', type: 'flat', rate: 0.045, std: 0, ssTax: true, q: 'approx' },
    VT: { name: 'Vermont', type: 'brackets', brackets: [[79950, 0.0335], [193300, 0.066], [294600, 0.076], [Infinity, 0.0875]], stdFed: true, ssTax: true, q: 'good' },
    VA: { name: 'Virginia', type: 'approx', rate: 0.0575, std: 17000, q: 'approx' },
    WA: { name: 'Washington', type: 'none', cp: true, cg: { over: 278000, rate: 0.07, over2: 1000000, rate2: 0.099 }, q: 'good', note: 'capital-gains excise on long-term gains (not real estate or retirement accounts)' },
    WV: { name: 'West Virginia', type: 'approx', rate: 0.0482, std: 0, q: 'approx' },
    WI: { name: 'Wisconsin', type: 'approx', rate: 0.0765, std: 23620, cp: true, q: 'approx' },
    WY: { name: 'Wyoming', type: 'none', q: 'exact' },
  };
  E.stateOf = (settings) => { const c = (settings?.household?.state || 'CA').toUpperCase(); const base = E.STATES[c] || E.STATES.CA; const ov = (settings?.ref?.stateOverrides || {})[c] || {}; return { code: E.STATES[c] ? c : 'CA', ...base, ...ov }; };
  // non-California state income tax in base-year dollars. Returns { tax, taxable, marginal }
  E.stateTax = (st, { agi, ssT, single, fedStd, pref, retDist = 0 }) => {
    const half = (x) => (single ? x / 2 : x);
    if (st.type === 'none') {
      let tax = 0, mg = 0;
      if (st.cg && pref > st.cg.over) { tax = (pref - st.cg.over) * st.cg.rate + Math.max(0, pref - (st.cg.over2 || Infinity)) * ((st.cg.rate2 || st.cg.rate) - st.cg.rate); mg = pref > (st.cg.over2 || Infinity) ? st.cg.rate2 : st.cg.rate; } // WA thresholds are per return
      return { tax, taxable: 0, marginal: mg, mhst: 0 };
    }
    const std = st.stdFed ? fedStd : half(st.std || 0);
    const taxable = Math.max(0, agi - (st.ssTax ? 0 : ssT) - (st.retEx ? retDist : 0) - std);
    let tax, mg;
    if (st.type === 'brackets') { const br = st.brackets.map(([l, r]) => [l === Infinity || l == null ? Infinity : half(l), r]); tax = progressive(taxable, br); mg = marginal(taxable, br); }
    else { tax = taxable * st.rate; mg = st.rate; }
    if (st.surtax && taxable > half(st.surtax.over)) { tax += (taxable - half(st.surtax.over)) * st.surtax.rate; mg += st.surtax.rate; }
    return { tax, taxable, marginal: mg, mhst: 0 };
  };
  E.taxes = (settings, taxYear, inc, opts = {}) => {
    // inc: {ordinary, qualified, taxExempt, otherIncome, capInc, ssTaxable}
    const R = settings.ref; const single = (opts.filing || settings?.household?.filing) === 'single'; const cpi = opts.cpi || 1; const calYear = opts.calYear || taxYear;
    const { t: fed, est: fedEst } = rolledTable(single ? (R.fedSingle || E.DEFAULT_REF.fedSingle) : R.fed, taxYear, R.indexRate);
    const { t: caMFJ, est: caEst } = rolledTable(R.ca, taxYear, R.indexRate);
    const ca = single ? { std: caMFJ.std / 2, brackets: caMFJ.brackets.map(([l, r]) => [l === Infinity ? l : l / 2, r]) } : caMFJ;
    const ssT = inc.ssTaxable || 0; // taxable Social Security (federal only; California exempts SS)
    const ordinaryAll = inc.ordinary + inc.otherIncome + ssT + Math.min(inc.capInc, 0);
    const pref = inc.qualified + Math.max(inc.capInc, 0);
    const agi = ordinaryAll + pref;
    const magi = agi + inc.taxExempt;
    const it = opts.itemized || {}; const propTax = it.propertyTax || 0, mortInt = it.mortgageInterest || 0, charity = it.charity || 0;
    // --- California first (needed for the federal SALT deduction) ---
    const caItem = propTax + (it.mortgageInterestCA ?? mortInt) + charity; // CA: no SALT cap, no state-tax deduction
    const caDed = opts.caDeductionOverride != null ? +opts.caDeductionOverride : Math.max(ca.std, caItem);
    const ST = E.stateOf(settings); const isCA = ST.type === 'ca';
    let caIncome, caTax, caMhst, stMarg;
    if (isCA) {
      caIncome = Math.max(0, agi - ssT - caDed);
      caTax = progressive(caIncome, ca.brackets);
      caMhst = Math.max(0, caIncome - 1000000 / cpi) * 0.01; // Mental Health Services Tax, 1% over $1M (not indexed)
      caTax += caMhst; stMarg = marginal(caIncome, ca.brackets);
    } else { // other states (stored in the same fields so the rest of the app works unchanged)
      const fedStdNow = (rolledTable(single ? (R.fedSingle || E.DEFAULT_REF.fedSingle) : R.fed, taxYear, R.indexRate).t.std);
      const r = E.stateTax(ST, { agi, ssT, single, fedStd: fedStdNow, pref: Math.max(0, inc.capInc), retDist: (inc.retirementDist || 0) });
      caIncome = r.taxable; caTax = r.tax; caMhst = 0; stMarg = r.marginal;
    }
    // --- federal deductions ---
    const ages = opts.ages || []; const nSenior = ages.filter((a) => a >= 65).length;
    let senior = 0;
    if (calYear >= 2025 && calYear <= 2028 && nSenior) senior = Math.max(0, nSenior * 6000 / cpi - 0.06 * Math.max(0, agi - (single ? 75000 : 150000) / cpi)); // MAGI here = AGI (no muni add-back)
    const saltAllowed = Math.min(E.saltCap(calYear, agi * cpi) / cpi, caTax + propTax); // §164(b)(7) MAGI = AGI
    const itemized = saltAllowed + mortInt + charity;
    const useItem = itemized > fed.std;
    // OBBBA (2026+): itemized deductions are worth at most 35% — reduce by 2/37 of the lesser of itemized or income above the 37% bracket
    const top37 = fed.brackets[fed.brackets.length - 2][0];
    const itemCut = useItem && calYear >= 2026 ? (2 / 37) * Math.min(itemized, Math.max(0, agi - senior - top37)) : 0;
    const ded = opts.deductionOverride != null ? +opts.deductionOverride : (useItem ? itemized - itemCut : fed.std) + senior;
    const ordTaxable = Math.max(0, ordinaryAll - ded);
    const leftover = Math.max(0, ded - ordinaryAll);
    const prefTaxable = Math.max(0, pref - leftover);
    const ordTax = progressive(ordTaxable, fed.brackets);
    let prefTax = 0, prev = ordTaxable, remaining = prefTaxable;
    for (const [lim, r] of fed.ltcg) { if (remaining <= 0) break; const room = Math.max(0, lim - prev); const amt = Math.min(room, remaining); prefTax += amt * r; remaining -= amt; prev += amt; }
    // --- NIIT (thresholds not indexed) ---
    const nii = Math.max(0, Math.max(0, inc.ordinaryInvestment ?? inc.ordinary) + inc.qualified + Math.max(inc.capInc, -3000 / (opts.cpi || 1))); // Form 8960: the deductible $3k capital loss reduces NII
    const niit = Math.max(0, Math.min(nii, agi - (single ? 200000 : 250000) / cpi)) * 0.038;
    // --- AMT (OBBBA: exemption phase-out at 50%) ---
    const A = rolledAmt(R.amt || E.DEFAULT_REF.amt, taxYear, R.indexRate);
    const amti = ordTaxable + prefTaxable + (opts.deductionOverride != null ? (useItem ? saltAllowed : Math.min(ded, fed.std)) : (useItem ? saltAllowed : fed.std) + senior);
    const ex = Math.max(0, (single ? A.exSingle : A.exMFJ) - (A.poRate ?? 0.5) * Math.max(0, amti - (single ? A.poSingle : A.poMFJ)));
    const base = Math.max(0, amti - ex); const prefIn = Math.min(prefTaxable, base); const ordBase = base - prefIn;
    const tmt = (ordBase <= A.bp ? 0.26 * ordBase : 0.26 * A.bp + 0.28 * (ordBase - A.bp)) + prefTax;
    const amt = Math.max(0, tmt - (ordTax + prefTax));
    const fedTotal = ordTax + prefTax + niit + amt;
    return {
      agi, magi, fedOrdinary: ordTax, fedPref: prefTax, niit, amt, fed: fedTotal, ca: caTax, caMhst, total: fedTotal + caTax,
      ordTaxable, prefTaxable, fedMarginal: marginal(ordTaxable, fed.brackets), caMarginal: stMarg, state: ST.code, stateName: ST.name,
      ltcgZeroRoom: Math.max(0, fed.ltcg[0][0] - ordTaxable - prefTaxable), est: fedEst || (isCA && caEst), std: fed.std, deduction: ded, itemizedUsed: useItem, saltAllowed, senior,
      bracketTop: (rate) => (fed.brackets.find(([, r]) => r === rate) || fed.brackets[1])[0], ltcg0Top: fed.ltcg[0][0],
    };
  };
  function rolledAmt(tbl, year, idx) {
    const ys = Object.keys(tbl).map(Number).sort(); const last = ys.filter((y) => y <= year).pop() ?? ys[0]; const f = Math.pow(1 + idx, year - last); const s = tbl[last];
    return { exMFJ: s.exMFJ * f, exSingle: s.exSingle * f, poMFJ: s.poMFJ * f, poSingle: s.poSingle * f, bp: s.bp * f, poRate: s.poRate ?? 0.5 };
  }
  // IRMAA (Medicare Part B + D income surcharges) per person per year, from MAGI two years earlier
  E.irmaa = (settings, magi, single, cpi = 1) => {
    const T = settings.ref.irmaa || E.DEFAULT_REF.irmaa; const th = single ? T.single : T.mfj;
    let tier = 0; for (let i = 0; i < th.length; i++) if (magi > th[i] * cpi) tier = i + 1;
    return { tier, annual: tier ? (T.partB[tier - 1] + T.partD[tier - 1]) * 12 * cpi : 0 };
  };

  // ---------- candidates for sale (taxable only) ----------
  E.saleCandidates = (snap, asOf) => {
    const out = []; const excluded = [];
    for (const a of E.allAccounts(snap)) {
      if (a.taxType !== 'taxable') continue;
      if (a.lots && a.lots.length) {
        for (const l of a.lots) {
          const st = (new Date(asOf) - new Date(l.date)) / 864e5 < 366;
          out.push({ account: a.name, acctKey: a.key, symbol: l.symbol, lotId: l.id, date: l.date, term: st ? 'Short' : 'Long', price: l.price, shares: l.shares, value: l.value, cost: l.cost, gain: l.value - l.cost, gainRatio: (l.value - l.cost) / l.value, assetClass: 'goog', divisible: true, lotLevel: true });
        }
        continue;
      }
      for (const h of a.holdings) {
        if (h.assetClass === 'cash' || h.assetClass === 'bank') continue;
        if (h.assetClass === 'private') { excluded.push({ account: a.name, symbol: h.symbol, value: h.value, reason: 'Venture / private: not sellable on demand' }); continue; }
        if (h.cost == null) { excluded.push({ account: a.name, symbol: h.symbol, value: h.value, reason: 'No cost basis in export — add basis to include' }); continue; }
        out.push({ account: a.name, acctKey: a.key, symbol: h.symbol, lotId: null, price: h.price, shares: h.qty, value: h.value, cost: h.cost, gain: h.value - h.cost, gainRatio: (h.value - h.cost) / h.value, assetClass: h.assetClass, divisible: true, lotLevel: false, term: 'Long*' });
      }
    }
    return { out, excluded };
  };

  // ---------- liquidation plan ----------
  // need: $ to raise. budgets: [{year, gainRoom}] (gainRoom = additional net capital gain allowed under ceiling that year)
  E.buildPlan = (snap, settings, need, budgets, ctx) => {
    const { out: cands, excluded } = E.saleCandidates(snap, snap.asOf);
    const pool = cands.filter((c) => c.term !== 'Short').map((c) => ({ ...c, left: c.value }));
    const steps = []; let raised = 0;
    const take = (c, dollars, tranche, year, why) => {
      dollars = Math.min(dollars, c.left); if (dollars <= 1) return 0;
      const frac = dollars / c.value; const gain = c.gain * frac;
      const shares = c.shares ? c.shares * frac : null;
      steps.push({ tranche, year, account: c.account, symbol: c.symbol, lotId: c.lotId, date: c.date, shares, proceeds: dollars, gain, gainRatio: c.gainRatio, why, all: dollars >= c.left - 1 });
      c.left -= dollars; raised += dollars; return gain;
    };
    const googOver = ctx.googPct > settings.trim.googConcentrationMax;
    for (const b of budgets) {
      let room = b.gainRoom; // positive = more gains allowed
      let lossPool = b.lossPool || 0; // harvested losses not yet matched by gains
      if (raised >= need) break;
      // Tranche 1 — positions at a loss (adds room)
      if (b.first) for (const c of pool.filter((c) => c.gain < 0).sort((x, y) => x.gainRatio - y.gainRatio)) {
        if (raised >= need) break;
        const g = take(c, need - raised, '1 · Harvest losses', b.year, ctx.swap ? `Unrealized loss ${fmtPct(c.gainRatio)}. Sell and buy a replacement fund (see Tax-loss harvesting) to keep your allocation` : `Unrealized loss ${fmtPct(c.gainRatio)}; the sale lowers MAGI`);
        lossPool += -g; room += -g;
      }
      // Tranche 2 — loss-paired GOOG (highest-basis lots first), gains ≤ available losses
      const goog = pool.filter((c) => c.assetClass === 'goog' && c.left > 1).sort((x, y) => x.gainRatio - y.gainRatio);
      for (const c of goog) {
        if (raised >= need || lossPool <= 1) break;
        const maxDollars = c.gainRatio > 0 ? lossPool / c.gainRatio : c.left;
        const g = take(c, Math.min(need - raised, maxDollars), '2 · Loss-paired ' + E.cs() + '', b.year, 'Gain offset 1:1 by harvested losses (≈$0 net MAGI)');
        lossPool -= g; room -= g;
      }
      // Tranche 3 — lowest gain per dollar until ACA room is used
      const rank = (c) => c.gainRatio - (settings.plan.priority === 'diversify' && googOver && c.assetClass === 'goog' ? 0.35 : 0);
      const rest = pool.filter((c) => c.left > 1 && c.gain >= 0).sort((x, y) => rank(x) - rank(y));
      for (const c of rest) {
        if (raised >= need || room <= 1) break;
        const maxDollars = c.gainRatio > 0 ? room / c.gainRatio : c.left;
        const g = take(c, Math.min(need - raised, maxDollars), b.first ? '3 · Within ACA headroom' : '4 · After Jan 1 (next tax year)', b.year,
          c.assetClass === 'goog' ? 'High-basis ' + E.cs() + ' lot; also reduces concentration' : c.assetClass === 'gold' ? `Low gain/$ (${fmtPct(c.gainRatio)}). Gold/silver ETF gains are taxed as collectibles (up to 28% federal)` : `Low gain/$ (${fmtPct(c.gainRatio)})`);
        room -= g;
      }
      b.roomLeft = room; b.lossLeft = lossPool;
    }
    const shortfall = Math.max(0, need - raised);
    const byYear = {};
    for (const s of steps) { byYear[s.year] = byYear[s.year] || { proceeds: 0, gain: 0 }; byYear[s.year].proceeds += s.proceeds; byYear[s.year].gain += s.gain; }
    return { steps, raised, shortfall, byYear, excluded, budgets };
  };
  const fmtPct = (x) => (x * 100).toFixed(0) + '%';

  // ---------- wash-sale scan ----------
  const IDENT_GROUPS = [
    ['GOOG', 'GOOGL'], ['BRK.A', 'BRK.B'], ['FOX', 'FOXA'], ['NWS', 'NWSA'],
    ['FXAIX', 'IVV', 'VOO', 'SPY', 'SWPPX', 'Instl 500 Index'],
    ['VTI', 'FSKAX', 'ITOT', 'SCHB', 'FZROX'],
    ['FXNAX', 'BND', 'AGG', 'SCHZ', 'Inst Tot Bd'],
    ['VEA', 'SCHF', 'IEFA'], ['VWO', 'IEMG', 'SCHE'], ['SWISX', 'FSPSX'], ['FSMAX', 'VXF'],
  ];
  const groupOf = (s) => IDENT_GROUPS.find((g) => g.some((x) => s && (s === x || s.startsWith(x))));
  E.washScan = (snap, plan) => {
    const accts = E.allAccounts(snap); const flags = [];
    const holders = (sym, exceptKey) => {
      const g = groupOf(sym) || [sym]; const res = [];
      for (const a of accts) if (a.key !== exceptKey) for (const h of a.holdings) if (g.some((x) => h.symbol === x || (h.symbol || '').startsWith(x))) res.push({ account: a.name, taxType: a.taxType, symbol: h.symbol, same: h.symbol === sym });
      return res;
    };
    const lossSales = (plan?.steps || []).filter((s) => s.gain < 0);
    for (const s of lossSales) {
      const acct = accts.find((a) => a.name === s.account);
      for (const h of holders(s.symbol, acct?.key)) flags.push({
        severity: h.same ? 'high' : 'medium', ticker: s.symbol,
        text: `Plan sells ${s.symbol} at a loss, and ${h.account} holds ${h.symbol}${h.same ? '' : ' (tracks a similar index)'}. Don't buy it there (including automatic dividend reinvestment or 401(k) contributions) from 30 days before the sale to 30 days after.`,
      });
    }
    // Robo-TLH accounts vs other accounts holding same tickers
    for (const a of accts.filter((a) => /wealthfront|betterment|frec|public/i.test(a.institution) && a.taxType === 'taxable')) {
      const overlap = [];
      for (const h of a.holdings) { if (h.assetClass === 'cash' || h.assetClass === 'bank') continue; for (const o of holders(h.symbol, a.key)) if (o.same) overlap.push(`${h.symbol} (${o.account})`); }
      if (overlap.length) flags.push({ severity: 'medium', ticker: 'TLH', text: `${a.institution} harvests losses automatically. These tickers also sit in other accounts: ${[...new Set(overlap)].join(', ')}. Avoid buying them there by hand, and keep dividend reinvestment off in IRAs for the same tickers.` });
    }
    // GOOG/GOOGL across accounts
    const googHolders = accts.filter((a) => a.holdings.some((h) => E.isConc(h.symbol)));
    if (googHolders.length > 1) flags.push({ severity: 'low', ticker: E.cs(), text: `${E.cs()} held in ${googHolders.length} accounts. Gains don't trigger wash sales, but any ${E.cs()} loss lot is subject to purchases of either share class across all accounts, your spouse's included.` });
    if (!flags.length) flags.push({ severity: 'ok', ticker: '—', text: 'No conflicts found among held positions.' });
    flags.push({ severity: 'info', ticker: 'Scope', text: 'v1 checks holdings overlap only. Add trade history (Wealthfront TLH report, spouse IRA activity) to check exact 61-day windows.' });
    return flags;
  };

  // ---------- tax-loss harvesting opportunities (shown every quarter, whatever the buffer mode) ----------
  const REPLACE = {
    FXNAX: 'IUSB or FIBR (broader / different index). Avoid BND, AGG, SCHZ and FXNAX: they track the same Bloomberg US Aggregate index.',
    BND: 'IUSB or FIBR', AGG: 'IUSB or FIBR', SCHZ: 'IUSB or FIBR', IEI: 'VGIT or SCHR (similar duration, different index)', VGLT: 'SPTL or TLT', VCIT: 'IGIB or SPIB', LQD: 'VCIT or IGIB',
    FXAIX: 'VTI or SCHB (total market, different index)', FSMAX: 'VXF or SCHA', SWSSX: 'VB or IJR', SWISX: 'VEA or IEFA', FSPSX: 'IEFA or SCHF', VEA: 'IEFA or SCHF', VWO: 'IEMG', VTI: 'ITOT or SCHB',
  };
  E.tlhOpportunities = (snap, plan, s) => {
    const { out } = E.saleCandidates(snap, snap.asOf);
    const losses = out.filter((c) => c.gain < -500).map((c) => ({ ...c, loss: -c.gain }));
    if (!losses.length) return null;
    const total = losses.reduce((a, c) => a + c.loss, 0);
    // how much GOOG could be sold MAGI-neutral against these losses (highest-basis lots first)
    let rem = total, googProceeds = 0, googLots = 0;
    for (const l of out.filter((c) => c.assetClass === 'goog' && c.term !== 'Short').sort((a, b) => a.gainRatio - b.gainRatio)) { if (rem <= 1) break; const g = Math.min(rem, l.gain); googProceeds += g / l.gainRatio; rem -= g; googLots++; }
    const inPlan = new Set((plan?.steps || []).filter((x) => x.gain < 0).map((x) => x.symbol));
    const accts = E.allAccounts(snap);
    return { total, googProceeds, googLots, items: losses.map((c) => {
      const holders = accts.filter((a) => a.key !== c.acctKey && a.holdings.some((h) => h.symbol === c.symbol)).map((a) => a.name);
      return { ...c, inPlan: inPlan.has(c.symbol), replacement: REPLACE[c.symbol] || 'a similar fund that tracks a different index', alsoHeldIn: holders };
    }) };
  };

  // ---------- the quarterly verdict ----------
  // life phase: 'working' (paycheck funds spending; goals = diversify + cut taxes) or 'retired' (buffer + income targets)
  E.phase = (settings, asOf) => {
    const h = settings.household || {}; if (h.phase === 'working' || h.phase === 'retired') return { phase: h.phase, retireDate: h.retireDate || null };
    const rd = h.retireDate || null; return { phase: rd && rd > (asOf || new Date().toISOString().slice(0, 10)) ? 'working' : 'retired', retireDate: rd };
  };
  E.analyze = (snap, settings) => {
    const m = { ...E.DEFAULT_MANUAL, ...(snap.manual || {}) };
    const PH = E.phase(settings, new Date().toISOString().slice(0, 10)); const working = PH.phase === 'working';
    const s = E.summarize(snap);
    const asOf = snap.asOf; const Y = yearOf(asOf); const mon = monthOf(asOf);
    const inc = E.portfolioIncome(snap, settings);
    const spend = +settings.spending.annual;
    const target = spend * settings.buffer.targetYears;
    const trigger = spend * settings.buffer.refillTriggerYears;
    const floor = spend * settings.buffer.emergencyMonths / 12; // one emergency-cash rule for both phases
    const sweep = settings.buffer.dividendsSweepToCash ? inc.total : 0;
    const netBurn = Math.max(1, spend - sweep);
    const cash = s.bufferCash;
    const runwayMonths = cash / (netBurn / 12);

    // MAGI — current tax year baseline (before any new sales)
    const baseInc = { ordinary: inc.ordinary + (+m.wageIncome || 0), ordinaryInvestment: inc.ordinary /* wages aren't investment income (NIIT) */, qualified: inc.qualified, taxExempt: inc.taxExempt, otherIncome: +m.otherIncome || 0 };
    const magiNow = E.magi({ ...baseInc, gains: +m.ytdRealizedGains || 0, losses: +m.ytdHarvestedLosses || 0, carryforward: +m.lossCarryforward || 0 });
    const th = E.acaThresholds(settings, Y);
    const thNext = E.acaThresholds(settings, Y + 1);
    const margin = +settings.aca.safetyMargin || 0;
    // gain room: ceiling - (MAGI excluding cap gains) - margin, measured against net cap gains incl. losses
    const nonCap = baseInc.ordinary + baseInc.qualified + baseInc.taxExempt + baseInc.otherIncome;
    const netCapSoFar = (+m.ytdRealizedGains || 0) - (+m.ytdHarvestedLosses || 0) - (+m.lossCarryforward || 0);
    const roomNow = settings.aca.enabled ? th.ceiling - margin - nonCap - Math.max(netCapSoFar, 0) : 1e12;
    const lossPoolNow = Math.max(0, -netCapSoFar); // unmatched losses available to pair
    const carryNext = magiNow.carryOut;
    const roomNext = settings.aca.enabled ? thNext.ceiling - margin - nonCap : 1e12;

    // modes
    const dd = +m.spDrawdownPct || 0;
    const near = dd <= settings.market.nearATHPct; const correction = dd >= settings.market.correctionPct;
    const googYtd = m.googYtdPct;
    let mode, need = 0, reasons = [];
    reasons.push(`Cash buffer ${$k(cash)} vs. target ${$k(target)} (refill trigger ${$k(trigger)}, emergency floor ${$k(floor)}).`);
    reasons.push(`S&P 500 is ${m.spDrawdownPct == null ? '(not entered, assumed 0%)' : dd + '%'} below its all-time high (near ATH ≤ ${settings.market.nearATHPct}%, correction ≥ ${settings.market.correctionPct}%).`);
    const googOver = s.googPct > settings.trim.googConcentrationMax || (googYtd != null && googYtd >= settings.trim.googYtdTrigger);
    if (working) { reasons.length = 0; reasons.push(`Working until ${PH.retireDate || 'retirement'}: paychecks cover spending, so no buffer refill sales. Emergency cash ${$k(cash)} vs ${$k(floor)} (${settings.buffer.emergencyMonths} months).`); reasons.push(`${E.cs()} is ${s.googPct.toFixed(0)}% of liquid net worth (limit ${settings.trim.googConcentrationMax}%). Diversify within a gain budget of ${$k(+settings.working?.gainBudget || 0)} a year plus whatever harvested losses offset.`); }
    if (working) mode = googOver ? 'diversify' : 'growth';
    else if (cash < floor && correction) { mode = 'emergency'; need = floor * 2 - cash; }
    else if (cash < trigger && near) { mode = 'refill'; need = target - cash; }
    else if (cash < trigger && !near) { mode = 'defensive'; need = Math.max(0, trigger - cash); }
    else if (s.googPct > settings.trim.googConcentrationMax || (googYtd != null && googYtd >= settings.trim.googYtdTrigger)) { mode = roomNow > 5000 ? 'trim' : 'zero'; }
    else mode = 'zero';

    let plan = null;
    if (mode === 'diversify') {
      // working years: sell GOOG only where it's (nearly) tax-free — high-basis lots offset by harvested losses — plus an optional gain budget
      const googSnap = { ...snap, accounts: snap.accounts.map((a) => (a.lots && a.lots.length) ? a : (a.taxType === 'taxable' ? { ...a, holdings: a.holdings.filter((h) => h.cost != null && h.value < h.cost) } : null)).filter((a) => a && (a.lots?.length || a.holdings.length)) };
      const lossVal = sum(googSnap.accounts.filter((a) => !a.lots), (a) => sum(a.holdings, (h) => h.value));
      const lossAmt = sum(googSnap.accounts.filter((a) => !a.lots), (a) => sum(a.holdings, (h) => h.cost - h.value));
      const budget = Math.max(0, +settings.working?.gainBudget || 0); const excess = Math.max(0, s.goog - settings.trim.googConcentrationMax / 100 * s.liquid);
      need = lossVal + Math.min(excess, (budget + lossAmt + lossPoolNow) / 0.45);
      plan = need > 1 ? E.buildPlan(googSnap, settings, need, [{ year: Y, gainRoom: budget, lossPool: lossPoolNow, first: true }], { googPct: s.googPct, swap: true }) : null;
      need = plan ? plan.raised : 0;
    } else if (mode === 'refill' || mode === 'trim') {
      const budgets = [{ year: Y, gainRoom: Math.max(0, roomNow), lossPool: lossPoolNow, first: true }];
      if (mode === 'refill' && settings.plan.splitAcrossYearEnd && mon >= 9) budgets.push({ year: Y + 1, gainRoom: Math.max(0, roomNext + carryNext), lossPool: carryNext, first: false });
      if (mode === 'trim') {
        // GOOG lots only, sized to the remaining ACA gain room (capped at 10% of the position)
        // GOOG lots plus any positions sitting at a loss (harvested losses let more GOOG be sold at ~$0 net MAGI)
        const googSnap = { ...snap, accounts: snap.accounts.map((a) => (a.lots && a.lots.length) ? a : (a.taxType === 'taxable' ? { ...a, holdings: a.holdings.filter((h) => h.cost != null && h.value < h.cost) } : null)).filter((a) => a && (a.lots?.length || a.holdings.length)) };
        const lossVal = sum(googSnap.accounts.filter((a) => !a.lots), (a) => sum(a.holdings, (h) => h.value));
        const lossAmt = sum(googSnap.accounts.filter((a) => !a.lots), (a) => sum(a.holdings, (h) => h.cost - h.value));
        need = lossVal + Math.min(s.goog * 0.1, (Math.max(0, roomNow) + lossAmt) / 0.45);
        plan = E.buildPlan(googSnap, settings, need, budgets, { googPct: s.googPct, swap: true });
        need = plan.raised;
      } else plan = E.buildPlan(snap, settings, need, budgets, { googPct: s.googPct });
    } else if (mode === 'defensive' || mode === 'emergency') {
      // bonds / losses / near-basis only — no equity sales into a drawdown
      const snapBondsOnly = { ...snap, accounts: snap.accounts.map((a) => ({ ...a, lots: a.lots ? [] : a.lots, holdings: a.lots ? [] : a.holdings.filter((h) => ['bond', 'muni', 'cash'].includes(h.assetClass) || (h.cost != null && h.value - h.cost <= 0.05 * h.value)) })) };
      plan = E.buildPlan(snapBondsOnly, settings, need, [{ year: Y, gainRoom: Math.max(0, roomNow), lossPool: lossPoolNow, first: true }], { googPct: s.googPct });
    }

    const planGainsY = plan ? (plan.byYear[Y]?.gain || 0) : 0;
    const magiAfter = E.magi({ ...baseInc, gains: (+m.ytdRealizedGains || 0) + Math.max(0, planGainsY), losses: (+m.ytdHarvestedLosses || 0) + Math.max(0, -Math.min(0, planGainsY)), carryforward: +m.lossCarryforward || 0 });
    // more accurate: recompute from steps
    if (plan) {
      const g = plan.steps.filter((x) => x.year === Y);
      const gains = sum(g.filter((x) => x.gain > 0), (x) => x.gain), losses = -sum(g.filter((x) => x.gain < 0), (x) => x.gain);
      Object.assign(magiAfter, E.magi({ ...baseInc, gains: (+m.ytdRealizedGains || 0) + gains, losses: (+m.ytdHarvestedLosses || 0) + losses, carryforward: +m.lossCarryforward || 0 }));
    }
    const taxNow = E.taxes(settings, Y, { ...baseInc, capInc: magiNow.capInc });
    const taxAfter = E.taxes(settings, Y, { ...baseInc, capInc: magiAfter.capInc });
    let taxNextAfter = null;
    if (plan && plan.byYear[Y + 1]) {
      const g = plan.steps.filter((x) => x.year === Y + 1);
      const mm = E.magi({ ...baseInc, gains: sum(g.filter((x) => x.gain > 0), (x) => x.gain), losses: -sum(g.filter((x) => x.gain < 0), (x) => x.gain), carryforward: carryNext });
      taxNextAfter = { magi: mm, tax: E.taxes(settings, Y + 1, { ...baseInc, capInc: mm.capInc }) };
    }
    const wash = E.washScan(snap, plan);
    const tlh = E.tlhOpportunities(snap, plan, s);
    const verdict = E.verdictText(mode, { cash, target, need, plan, th, Y, runwayMonths, s, roomNow, m, spend, netBurn, dd, floor, trigger, PH, settings, taxAfter });
    return { phase: PH.phase, retireDate: PH.retireDate, working, s, m, inc, Y, mon, spend, target, trigger, floor, netBurn, cash, runwayMonths, magiNow, magiAfter, th, thNext, roomNow, roomNext, nonCap, mode, need, plan, wash, tlh, verdict, reasons, taxNow, taxAfter, taxNextAfter, carryNext };
  };

  const $k = (v) => (Math.abs(v) >= 1e6 ? '$' + (v / 1e6).toFixed(2) + 'M' : '$' + Math.round(v / 1000).toLocaleString() + 'k');
  E.$k = $k;

  E.verdictText = (mode, c) => {
    const quarterDraw = Math.round(c.netBurn / 4 / 1000) * 1000;
    const V = {
      zero: { color: 'green', icon: '●', title: 'Zero-Sale Mode', line: `Buffer is healthy (${$k(c.cash)}, ${c.runwayMonths.toFixed(0)} months of runway). Don't sell equities. Spend from cash: about ${$k(quarterDraw)} next quarter.` },
      refill: { color: 'blue', icon: '◆', title: 'Full Refill Mode', line: `Buffer is ${$k(c.cash)}, below the ${$k(c.trigger)} trigger, and markets are near their highs. Raise ${$k(c.need)} to get back to ${$k(c.target)}.` + (c.plan ? ` The plan below raises ${$k(c.plan.raised)}${c.plan.shortfall > 1 ? `, leaving ${$k(c.plan.shortfall)} uncovered within ACA limits` : ''}.` : '') },
      defensive: { color: 'amber', icon: '▲', title: 'Defensive Refill', line: `Buffer is ${$k(c.cash)}, below the trigger, but markets are ${c.dd}% off their highs. Top up to ${$k(c.trigger)} from bonds and loss positions only, and don't sell stocks into the drawdown.` },
      emergency: { color: 'red', icon: '■', title: 'Emergency Defense', line: `Buffer ${$k(c.cash)} is under the ${$k(c.floor)} floor during a correction. Sell bonds and losses first, then draw Roth contribution basis (no MAGI impact) before selling any stock.` },
      growth: { color: 'green', icon: '●', title: 'Working years: build and protect', line: `Paychecks cover spending. Keep ${$k(c.floor)} of emergency cash, max out pre-tax accounts, invest the surplus and rebalance. No sales needed: ${E.cs()} is within your ${c.settings?.trim.googConcentrationMax}% limit.` },
      diversify: { color: 'amber', icon: '◇', title: 'Working years: diversify tax-efficiently', line: `${E.cs()} is ${c.s.googPct.toFixed(0)}% of liquid net worth (limit ${c.settings?.trim.googConcentrationMax}%). At your bracket a long-term gain costs about ${Math.round(((c.taxAfter?.fedMarginal || 0.35) > 0.32 ? 0.238 : 0.188) * 100 + (c.taxAfter?.caMarginal || 0.093) * 100)}% in tax, so sell only what's (nearly) tax-free now: lots offset by harvested losses${c.settings?.working?.gainBudget ? ` plus your ${$k(c.settings.working.gainBudget)} gain budget` : ''}. Sell new RSUs at vest (no gain), and save bigger ${E.cs()} sales for your lower-income retirement years.` + (c.plan ? ` Plan below: ${$k(c.plan.raised)} of sales.` : '') },
      trim: { color: 'amber', icon: '◇', title: 'Opportunistic Trim Available', line: `Buffer is fine, but ${E.cs()} is ${c.s.googPct.toFixed(0)}% of net worth. You have about ${$k(Math.max(0, c.roomNow))} of gain room under the ACA ceiling, so trim high-basis ${E.cs()} lots${c.plan && c.plan.steps.some((x) => x.gain < 0) ? ', paired with a tax-loss swap that offsets their gains' : ''}.` },
    };
    return V[mode];
  };

  // ---------- projections ----------
  E.project = (snap, settings, an) => {
    const P = settings.projection || { realReturn: {}, endAge: 95 }; const h = settings.household; // legacy (unused)
    const s = an.s; const startYear = an.Y + 1;
    const rr = P.realReturn;
    const bucketReturn = (type) => {
      let tot = 0, wsum = 0;
      for (const a of s.accts.filter((a) => a.taxType === type || (type === 'roth' && a.taxType === 'hsa'))) for (const hh of a.holdings) { tot += hh.value; wsum += hh.value * (rr[hh.assetClass] ?? 3) / 100; }
      return tot ? wsum / tot : 0.03;
    };
    const base = { taxable: s.byTax.taxable || 0, pretax: s.byTax.pretax || 0, roth: (s.byTax.roth || 0) + (s.byTax.hsa || 0) };
    const r = { taxable: bucketReturn('taxable'), pretax: bucketReturn('pretax'), roth: bucketReturn('roth') };
    const taxableYield = an.inc.total / Math.max(1, base.taxable);
    // starting taxable chunks: lots/positions with basis, cash at basis, unknown-basis at the average ratio
    const { out: cands, excluded } = E.saleCandidates(snap, snap.asOf);
    const known = sum(cands, (c) => c.value), knownCost = sum(cands, (c) => c.cost);
    const avgCostFrac = known ? knownCost / known : 0.6;
    const chunks0 = cands.map((c) => ({ v: c.value, c: c.cost }));
    for (const x of excluded) chunks0.push({ v: x.value, c: x.value * avgCostFrac });
    const rest = base.taxable - sum(chunks0, (c) => c.v);
    if (rest > 1) chunks0.push({ v: rest, c: rest }); // cash & manual taxable at basis
    const rmdDiv = (age) => { const t = { 73: 26.5, 75: 24.6, 80: 20.2, 85: 16.0, 90: 12.2, 95: 8.9, 100: 6.4 }; const ks = Object.keys(t).map(Number); for (let i = 0; i < ks.length - 1; i++) if (age >= ks[i] && age < ks[i + 1]) { return t[ks[i]] + (t[ks[i + 1]] - t[ks[i]]) * (age - ks[i]) / (ks[i + 1] - ks[i]); } return 6.4; };
    const rmdAge = h.birthYearSelf >= 1960 ? 75 : 73;
    const scen = { low: P.lowAdj / 100, base: 0, high: P.highAdj / 100 };
    const results = {};
    for (const [name, adj] of Object.entries(scen)) {
      let b = { ...base }; const rows = []; let depleted = null;
      // taxable "chunks" (lots/positions) so sales pick highest-basis first, like Specific ID
      let chunks = chunks0.map((c) => ({ ...c }));
      for (let y = startYear; ; y++) {
        const age = y - h.birthYearSelf, sAge = y - h.birthYearSpouse;
        if (age > P.endAge) break;
        const ss = (age >= P.ssSelfAge ? +P.ssSelfAnnual : 0) + (sAge >= P.ssSpouseAge ? +P.ssSpouseAnnual : 0);
        let need = Math.max(0, an.spend - ss);
        const rmd = age >= rmdAge ? b.pretax / rmdDiv(age) : 0;
        let fromPretax = Math.min(b.pretax, rmd); need = Math.max(0, need - fromPretax);
        const tv = sum(chunks, (c) => c.v);
        const divs = tv * taxableYield; // spent first
        const fromDivs = Math.min(need, divs); need -= fromDivs;
        let fromTaxable = Math.min(need, tv); need -= fromTaxable;
        let extraPretax = 0, fromRoth = 0;
        if (need > 0) { extraPretax = Math.min(need, b.pretax - fromPretax); need -= extraPretax; fromPretax += extraPretax; }
        if (need > 0) { fromRoth = Math.min(need, b.roth); need -= fromRoth; }
        chunks.sort((x, z) => (x.v - x.c) / Math.max(1, x.v) - (z.v - z.c) / Math.max(1, z.v));
        let left = fromTaxable, realized = 0;
        for (const c of chunks) { if (left <= 0) break; const t = Math.min(left, c.v); const f = t / c.v; realized += (c.v - c.c) * f; c.v -= t; c.c -= c.c * f; left -= t; }
        chunks = chunks.filter((c) => c.v > 1);
        for (const c of chunks) c.v *= (1 + r.taxable + adj - taxableYield); // total return minus the dividends paid out above
        if (divs > fromDivs) chunks.push({ v: divs - fromDivs, c: divs - fromDivs });
        b.taxable = sum(chunks, (c) => c.v);
        const magi = divs + Math.max(realized, -3000) + fromPretax + 0.85 * ss;
        b.pretax = Math.max(0, b.pretax - fromPretax) * (1 + r.pretax + adj);
        b.roth = Math.max(0, b.roth - fromRoth) * (1 + r.roth + adj);
        const total = b.taxable + b.pretax + b.roth;
        if (need > 1 && depleted == null) depleted = age;
        rows.push({ year: y, age, sAge, taxable: b.taxable, pretax: b.pretax, roth: b.roth, total, ss, rmd, fromTaxable: fromTaxable + fromDivs, fromPretax, fromRoth, realized, magi, shortfall: need, early: age < 59.5 && (extraPretax > 0 || fromRoth > 0) });
      }
      results[name] = { rows, depleted, end: rows.length ? rows[rows.length - 1].total : 0 };
    }
    return { results, r, startYear, withdrawalRate: an.spend / s.total * 100, base };
  };

  root.FireEngine = E;
  if (typeof module !== 'undefined') module.exports = E;
})(typeof window !== 'undefined' ? window : globalThis);
