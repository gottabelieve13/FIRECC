#!/usr/bin/env python3
"""Build FIRE-Command-Center.html (one self-contained file) from the source files.

Usage:  python3 build.py [output.html] [--seed seed.json] [--pl projectionlab.csv]
By default the output contains NO financial data. --seed / --pl embed starting data (avoid for cloud copies).
"""
import json, sys, os
here = os.path.dirname(os.path.abspath(__file__))
src = os.path.join(here, 'src')
args = sys.argv[1:]
def opt(name):
    if name in args:
        i = args.index(name); v = args[i + 1]; del args[i:i + 2]; return v
seed_path, pl_path = opt('--seed'), opt('--pl')
out_path = args[0] if args else os.path.join(here, '..', 'FIRE-Command-Center.html')
rd = lambda *p: open(os.path.join(*p), encoding='utf-8').read()
safe = lambda s: s.replace('</script', '<\\/script')
shell = rd(src, 'shell.html')
out = shell.replace('<!--PDFJS-->', '<script>' + safe(rd(src, 'vendor', 'pdf.min.js')) + '</script>\n<script>' + safe(rd(src, 'vendor', 'pdf.worker.min.js')) + '</script>')
seed = json.load(open(seed_path)) if seed_path else {"id": "seed", "asOf": None, "accounts": [], "manual": {}, "sources": []}
out = out.replace('/*SEED*/', 'window.FIRE_SEED=' + safe(json.dumps(seed, separators=(',', ':'))) + ';')
for tag, f in [('PARSERS', 'parsers.js'), ('ENGINE', 'engine.js'), ('HIST', 'hist.js'), ('PLANNER', 'planner.js'), ('APP', 'app.js')]:
    out = out.replace('/*%s*/' % tag, safe(rd(src, f)))
# brand images (Pay Forward Labs): inlined as data URLs so the app stays one offline file
import base64
for ph, f in [('%%FIRE_ICON%%', 'fire-icon128.png'), ('%%FIRE_ICON32%%', 'fire-icon32.png'), ('%%FIRE_WORDMARK%%', 'fire-wordmark640.png'), ('%%BRAND_ICON%%', 'icon128.png'), ('%%BRAND_ICON32%%', 'icon32.png'), ('%%BRAND_WORDMARK%%', 'wordmark560.png')]:
    out = out.replace(ph, 'data:image/png;base64,' + base64.b64encode(open(os.path.join(src, 'brand', f), 'rb').read()).decode())
plseed = ''
if pl_path:
    plseed = 'window.FIRE_PL_SEED=' + safe(json.dumps({'file': os.path.basename(pl_path), 'text': open(pl_path, encoding='utf-8-sig').read()})) + ';'
out = out.replace('/*PLSEED*/', plseed)
open(out_path, 'w', encoding='utf-8').write(out)
print('wrote', out_path, len(out), 'bytes', '(with starting data)' if seed_path else '(no financial data)')
