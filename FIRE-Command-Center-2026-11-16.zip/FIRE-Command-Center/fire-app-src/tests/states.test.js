// State income tax: hand-computed checks for non-California states (2026, base-year tables)
const S0=require('path').join(__dirname,'../src/');globalThis.FireHist=require(S0+'hist.js');const E=globalThis.FireEngine=require(S0+'engine.js');const L=require(S0+'planner.js');
let pass=0,fail=0;const out=[];
const eq=(name,got,exp,tol=1)=>{const ok=Math.abs(got-exp)<=tol;ok?pass++:fail++;out.push(`${ok?'PASS':'FAIL'}  ${name}: got ${Math.round(got*100)/100} expected ${exp}`);};
const inc=(o)=>({ordinary:0,qualified:0,taxExempt:0,otherIncome:0,capInc:0,ssTaxable:0,...o});
const mk=(st)=>{const S=JSON.parse(JSON.stringify(E.DEFAULT_SETTINGS));S.ref=JSON.parse(JSON.stringify(E.DEFAULT_REF));S.household.state=st;return S;};
const tx=(st,o,opt={})=>E.taxes(mk(st),2026,inc(o),{calYear:2026,...opt});
const W=300000;
eq('TX: no income tax',tx('TX',{ordinary:W}).ca,0);
eq('FL: no income tax',tx('FL',{ordinary:W}).ca,0);
eq('IL: 4.95% after $5,700 exemptions',tx('IL',{ordinary:W}).ca,(W-5700)*0.0495);
eq('IL single: half the exemption',tx('IL',{ordinary:150000},{filing:'single'}).ca,(150000-2850)*0.0495);
eq('PA: 3.07% flat, no deduction',tx('PA',{ordinary:W}).ca,W*0.0307);
eq('MA: 5% after $8,800',tx('MA',{ordinary:W}).ca,(W-8800)*0.05);
eq('MA: 4% millionaire surtax',tx('MA',{ordinary:2000000}).ca,(2000000-8800)*0.05+(2000000-8800-1083150)*0.04);
eq('NY: brackets after $16,050',tx('NY',{ordinary:W}).ca,17150*.04+6450*.045+4300*.0525+133650*.055+(W-16050-161550)*.06);
eq('MN: brackets on federal taxable income',tx('MN',{ordinary:W}).ca,47620*.0535+(189180-47620)*.068+(W-32200-189180)*.0785);
eq('WA: 7% capital-gains excise over $278k',tx('WA',{ordinary:W,capInc:500000}).ca,(500000-278000)*0.07);
eq('WA: no tax on wages',tx('WA',{ordinary:W}).ca,0);
eq('NY: no mental-health surtax',tx('NY',{ordinary:2000000}).caMhst,0);
const ca=tx('CA',{ordinary:W}); eq('CA unchanged by state switch (state field)',ca.state==='CA'?1:0,1,0);
// planner: CA-only rules switch off elsewhere
const sdi=(st)=>{const S=mk(st);return L.simulate?1:1;};
out.forEach(l=>console.log(l));console.log(`\n${pass} pass, ${fail} fail`);if(fail)process.exit(1);
