// W-2 parsing: two common PDF text layouts, box 12 codes, no SSN kept
const P=require(require('path').join(__dirname,'../src/parsers.js'));let pass=0,fail=0;const ok=(n,c,d='')=>{c?pass++:fail++;console.log(`${c?'PASS':'FAIL'}  ${n}${d?'  ['+d+']':''}`);};
const A=['a Employee\'s social security number 123-45-6789 OMB No. 1545-0029','b Employer identification number (EIN) 12-3456789 1 Wages, tips, other compensation 2 Federal income tax withheld','12-3456789 185,432.10 31,250.55',
'c Employer\'s name, address, and ZIP code 3 Social security wages 4 Social security tax withheld','ACME CORPORATION 176,100.00 10,918.20','123 MAIN ST 5 Medicare wages and tips 6 Medicare tax withheld','209,000.00 3,030.50',
'e Employee\'s first name and initial Last name','JANE DOE','12a See instructions for box 12','D 23,500.00','12b','DD 18,204.00','12c W 4,300.00','14 Other RSU 41,000.00 CASDI 1,862.00',
'15 State Employer\'s state ID number 16 State wages, tips, etc. 17 State income tax','CA 123-4567-8 185,432.10 14,100.22','Form W-2 Wage and Tax Statement 2025 Department of the Treasury'];
ok('Detected as a W-2',P.detect('w2.pdf',A.join('\n'))==='w2');
const a=P.parseW2(A).w2;ok('Side-by-side boxes read in order',a.boxes.box1===185432.1&&a.boxes.box2===31250.55&&a.boxes.box3===176100&&a.boxes.box4===10918.2&&a.boxes.box5===209000&&a.boxes.box6===3030.5,JSON.stringify(a.boxes));
ok('Box 12 codes D, DD, W and box 14 RSU',a.codes.D===23500&&a.codes.DD===18204&&a.codes.W===4300&&a.box14[0].label==='RSU'&&a.box14[0].amount===41000);
ok('Year, employer, state; no SSN kept',a.year===2025&&a.employer==='ACME CORPORATION'&&a.state==='CA'&&!/123-45-6789/.test(JSON.stringify(a)),`${a.year} ${a.employer} ${a.state}`);
const B=['Form W-2 Wage and Tax Statement 2024','Copy B To Be Filed With Employee\'s FEDERAL Tax Return','1 Wages, tips, other compensation','98765.43','2 Federal income tax withheld','12000.00','5 Medicare wages and tips','105000.00','12a D 6234.57','c Employer\'s name, address and ZIP code','Globex Inc','1 Wages, tips, other compensation','11111.11'];
const b=P.parseW2(B).w2;ok('Value-below-label layout; first copy wins',b.year===2024&&b.boxes.box1===98765.43&&b.boxes.box2===12000&&b.boxes.box5===105000&&b.codes.D===6234.57&&b.employer==='Globex Inc',JSON.stringify(b.boxes));
ok('A 1040 is not mistaken for a W-2',P.detect('r.pdf','Form 1040 U.S. Individual Income Tax Return 2025 Filing Status ... attach Form(s) W-2 Wage and Tax Statement')!=='w2');
console.log(`\n${pass} passed, ${fail} failed`);if(fail)process.exit(1);
