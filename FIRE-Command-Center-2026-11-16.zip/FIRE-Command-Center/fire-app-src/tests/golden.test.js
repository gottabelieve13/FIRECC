const S0=require('path').join(__dirname,'../src/');globalThis.FireHist=require(S0+'hist.js');const E=globalThis.FireEngine=require(S0+'engine.js');const L=require(S0+'planner.js');
const S=JSON.parse(JSON.stringify(E.DEFAULT_SETTINGS));S.ref=JSON.parse(JSON.stringify(E.DEFAULT_REF));
let pass=0,fail=0;const out=[];
const eq=(name,got,exp,tol=1)=>{const ok=Math.abs(got-exp)<=tol;ok?pass++:fail++;out.push(`${ok?'PASS':'FAIL'}  ${name}: got ${Math.round(got*100)/100} expected ${exp}`);};
const prog=(x,br)=>{let t=0,p=0;for(const[l,r]of br){if(x<=p)break;t+=(Math.min(x,l)-p)*r;p=l;}return t;};
const inc=(o)=>({ordinary:0,qualified:0,taxExempt:0,otherIncome:0,capInc:0,ssTaxable:0,...o});
const FED=[[24800,.10],[100800,.12],[211400,.22],[403550,.24],[512450,.32],[768700,.35],[Infinity,.37]];
const CA25=[[22158,.01],[52528,.02],[82904,.04],[115084,.06],[145448,.08],[742958,.093],[891542,.103],[1485906,.113],[Infinity,.123]];
const CA26=CA25.map(([l,r])=>[l*1.025,r]); const CASTD26=11412*1.025;
// A: wages 200k MFJ 2026
let t=E.taxes(S,2026,inc({ordinary:200000}),{calYear:2026});
eq('A fed ordinary tax, $200k wages MFJ',t.fedOrdinary,26340);
eq('A CA tax (2025 table indexed 2.5%)',t.ca,prog(200000-CASTD26,CA26),2);
// B: $50k ordinary + $200k LTCG
t=E.taxes(S,2026,inc({ordinary:50000,capInc:200000}),{calYear:2026});
eq('B fed ordinary on $17.8k taxable',t.fedOrdinary,1780);eq('B LTCG 0%/15% stacking',t.fedPref,17835);eq('B NIIT at AGI 250k',t.niit,0);
// C: NIIT
t=E.taxes(S,2026,inc({ordinary:50000,capInc:300000,ordinaryInvestment:0}),{calYear:2026});
eq('C NIIT = 3.8% x min(NII 300k, AGI-250k=100k)',t.niit,3800);
// D: 20% LTCG bracket: ordinary 700k, LTCG 500k
t=E.taxes(S,2026,inc({ordinary:700000,capInc:500000,ordinaryInvestment:0}),{calYear:2026});
eq('D fed ordinary 667.8k taxable',t.fedOrdinary,prog(667800,FED));eq('D LTCG all at 20% (above 613.7k)',t.fedPref,100000);eq('D NIIT on 500k',t.niit,19000);
eq('D CA MHST 1% over $1M taxable',t.caMhst,(1200000-CASTD26-1000000)*0.01,2);
// E: SALT phase-down: MFJ AGI 600k in 2026, prop tax 30k
t=E.taxes(S,2026,inc({ordinary:600000}),{calYear:2026,itemized:{propertyTax:30000,mortgageInterest:0}});
eq('E SALT cap 2026 at AGI 600k = max(10k, 40.4k-0.3*(600k-505k))',t.saltAllowed,Math.max(10000,40400-0.3*95000));
// F: senior deduction 2026, both 66, AGI 100k: 12k
t=E.taxes(S,2026,inc({ordinary:100000}),{calYear:2026,ages:[66,66]});eq('F senior deduction 2 x 6k',t.senior,12000);
t=E.taxes(S,2026,inc({ordinary:250000}),{calYear:2026,ages:[66,66]});eq('F senior phaseout 12k-6%*(250k-150k)',t.senior,6000);
t=E.taxes(S,2029,inc({ordinary:100000}),{calYear:2029,ages:[66,66]});eq('F senior deduction ends after 2028',t.senior,0);
// G: muni interest must NOT reduce SALT cap / senior (MAGI for those = AGI)
t=E.taxes(S,2026,inc({ordinary:450000,taxExempt:200000}),{calYear:2026,itemized:{propertyTax:40000}});eq('G SALT cap ignores muni interest',t.saltAllowed,40400);
// H: single filer
t=E.taxes(S,2026,inc({ordinary:100000}),{calYear:2026,filing:'single'});eq('H single fed tax on 83.9k',t.fedOrdinary,prog(83900,[[12400,.1],[50400,.12],[105700,.22],[201775,.24],[256225,.32],[640600,.35],[Infinity,.37]]));
// I: AMT: big ISO-free case — high SALT itemizer w/ $1.5M income: compare tmt
t=E.taxes(S,2026,inc({ordinary:300000}),{calYear:2026,itemized:{propertyTax:60000}});eq('I no AMT for ordinary $300k itemizer',t.amt,0);
// J: IRMAA 2026
eq('J IRMAA tier2 MFJ magi 300k per person/yr',E.irmaa(S,300000,false).annual,(202.90+37.50)*12,0.01);
eq('J IRMAA none at 218k',E.irmaa(S,218000,false).annual,0);
// K: ACA PTC household 3 2026 coverage (2025 FPL 26,650): magi 80k, benchmark 30k
S.aca.benchmarkPremium=30000;S.household.size=3;
const p=E.ptc(S,2026,80000);eq('K PTC = 30k - 9.96% x 80k',p.credit,30000-0.0996*80000,5);
eq('K PTC cliff above 400% FPL',E.ptc(S,2026,26650*4+1).credit,0);
// L: SS claiming
eq('L SS at 62 (FRA 67) = 70%',L.ssAdj(100,62,67),70,0.01);eq('L SS at 70 = 124%',L.ssAdj(100,70,67),124,0.01);eq('L spousal at 62 = 32.5%',L.ssSpousal(100,62,67),32.5,0.01);eq('L spousal at FRA = 50%',L.ssSpousal(100,67,67),50,0.01);
// M: CA std/brackets 2025 check exact
const t25=E.taxes(S,2025,inc({ordinary:125000+11412}),{calYear:2025});eq('M FTB example: CA tax on $125k taxable (2025) = 4,768.10',t25.ca,4768.10,1);
// N: capital loss offsets ordinary up to 3k
t=E.taxes(S,2026,inc({ordinary:100000,capInc:-3000}),{calYear:2026});eq('N -3k capital loss reduces taxable to 64.8k',t.ordTaxable,64800);
console.log(out.join('\n'));console.log(`\n${pass} passed, ${fail} failed`);
{ // O: 2/37 itemized limit: AGI 1.5M, itemized 50k (SALT 40.4k->10k floor because phase-down... use mortgage)
 const t=E.taxes(S,2026,inc({ordinary:1500000}),{calYear:2026,itemized:{propertyTax:20000,mortgageInterest:40000}});
 const item=10000+40000; const exp=item-(2/37)*Math.min(item,1500000-768700);
 eq('O OBBBA 2/37 itemized limit at 37% bracket',t.deduction,exp,1);
 console.log(out[out.length-1]);}
