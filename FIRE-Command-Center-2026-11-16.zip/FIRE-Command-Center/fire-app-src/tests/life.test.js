// Life events: moving states, inheritances (cash and inherited IRA), spending changes, selling/buying a home with a move
const S0=require('path').join(__dirname,'../src/');globalThis.FireHist=require(S0+'hist.js');const E=globalThis.FireEngine=require(S0+'engine.js');const L=require(S0+'planner.js');
const S=JSON.parse(JSON.stringify(E.DEFAULT_SETTINGS));S.ref=JSON.parse(JSON.stringify(E.DEFAULT_REF));S.household.birthYearSelf=1970;S.household.birthYearSpouse=1970;S.household.state='CA';
let pass=0,fail=0;const ok=(n,c,d='')=>{c?pass++:fail++;console.log(`${c?'PASS':'FAIL'}  ${n}${d?'  ['+d+']':''}`);};
const W=(o)=>({stock:0,bond:0,cash:0,bank:0,gold:0,crypto:0,goog:0,...o});
const mkInit=(o={})=>({year:2027,taxable:4e6,pretax:1e6,roth:0,property:0,debt:0,cardDebt:0,chunks:[{v:4e6,c:3e6}],w:{taxable:W({stock:1}),pretax:W({stock:1}),roth:W({stock:1})},yieldTaxable:0.03,qualFrac:0.5,exemptFrac:0,props:o.props||[],pretaxS:1e6,pretaxP:0,rothS:0,rothP:0,edu:0});
const mkPlan=(mod)=>{const P=L.newPlan(S,'t');P.spending.categories=[{name:'Living',amount:150000,kind:'essential',startAge:'',endAge:''}];P.healthcare.model=false;P.inflation=0;P.returns={...P.returns,stock:0,bond:0,cash:0,bank:0,re:0};P.ss={selfPIA:0,selfClaim:67,spousePIA:0,spouseClaim:67,fra:67,haircutPct:0,haircutYear:2034};P.people.lifeSelf=90;P.people.lifeSpouse=90;mod&&mod(P);return P;};
const run=(P,I)=>L.deterministic(P,I||mkInit(),S);const R=(d,y)=>d.rows.find(r=>r.year===y);
const base=run(mkPlan());
const mv=run(mkPlan(P=>{P.moves=[{year:2030,state:'TX',spendPct:0}];}));
ok('Before the move: California tax charged',R(mv,2029).taxParts.ca>1000&&R(mv,2029).state==='CA',Math.round(R(mv,2029).taxParts.ca));
ok('After moving to Texas: no state income tax',R(mv,2030).taxParts.ca<1&&R(mv,2035).taxParts.ca<1&&R(mv,2030).state==='TX');
ok('Move by age works the same (age 60 = 2030)',run(mkPlan(P=>{P.moves=[{age:60,state:'TX'}];})).rows.find(r=>r.year===2030).state==='TX');
ok('Lifetime tax falls after a move to a no-tax state',mv.lifetimeTax<base.lifetimeTax-50000,`${Math.round(base.lifetimeTax)} → ${Math.round(mv.lifetimeTax)}`);
const sc=run(mkPlan(P=>{P.spendChanges=[{year:2032,pct:-20}];}));ok('Spending change −20% from 2032',Math.abs(R(sc,2032).spend-0.8*R(sc,2031).spend)<1,`${Math.round(R(sc,2031).spend)} → ${Math.round(R(sc,2032).spend)}`);
const mvc=run(mkPlan(P=>{P.moves=[{year:2030,state:'FL',spendPct:-10}];}));ok('Cost-of-living change on a move',Math.abs(R(mvc,2030).spend-0.9*R(mvc,2029).spend)<1);
const ih=run(mkPlan(P=>{P.inheritances=[{year:2029,amount:300000,kind:'cash'}];}));ok('Cash inheritance adds to savings, untaxed',R(ih,2029).liquid-R(base,2029).liquid>290000&&R(ih,2029).events>=300000&&R(ih,2029).tax<=R(base,2029).tax+1,`+${Math.round(R(ih,2029).liquid-R(base,2029).liquid)}`);
const ira=run(mkPlan(P=>{P.inheritances=[{year:2029,amount:200000,kind:'ira'}];}));
ok('Inherited IRA: taxable income spread over 10 years',[2029,2033,2038].every(y=>Math.abs(R(ira,y).ordInc-R(base,y).ordInc-20000)<1)&&Math.abs(R(ira,2039).ordInc-R(base,2039).ordInc)<1,`${Math.round(R(ira,2029).ordInc-R(base,2029).ordInc)}/yr, ordinary`);
const home={id:'h',name:'Home',kind:'primary',value:2000000,basis:800000,propertyTax:20000,insurance:3000,mtgBalance:0,costsInSpending:false};
const hs=run(mkPlan(P=>{P.moves=[{year:2030,state:'TX',sellHome:true,newHomePrice:900000,newHomeDownPct:100,newHomeTaxPct:1.8}];}),mkInit({props:[home]}));
ok('Move sells the home and buys one in the new state',R(hs,2029).property>1.9e6&&Math.abs(R(hs,2030).property-900000)<20000,`${Math.round(R(hs,2029).property)} → ${Math.round(R(hs,2030).property)}`);
ok('New-state home pays its own property tax (no Prop 13)',R(hs,2031).taxParts.propTax>15000&&R(hs,2031).taxParts.propTax<17000,Math.round(R(hs,2031).taxParts.propTax));
const rent={id:'k',name:'Rental',kind:'rental',value:1500000,basis:500000,purchaseYear:2004,propertyTax:12000,insurance:2000,rentMonthly:6000,mtgBalance:0};
const nr=run(mkPlan(P=>{P.moves=[{year:2030,state:'NV'}];}),mkInit({props:[rent]}));ok('Former state still taxes the rental you kept (non-resident)',R(nr,2031).taxParts.ca>500,Math.round(R(nr,2031).taxParts.ca));
// spending phases tied to events: travel 20k until retirement, 10k until the move, 5k after (back to back, no overlap)
const ph=run(mkPlan(P=>{P.people.retireAgeSelf=62;P.moves=[{id:'mvA',name:'Retirement home',year:2040,state:''}];P.spending.categories=[{name:'Living',amount:100000,kind:'essential'},
 {name:'Travel',amount:20000,kind:'discretionary',startAt:'now',endAt:'retire:self'},{name:'Travel',amount:10000,kind:'discretionary',startAt:'retire:self',endAt:'move:mvA'},{name:'Travel',amount:5000,kind:'discretionary',startAt:'move:mvA',endAt:'end'}];}));
const tv=(y)=>Math.round(R(ph,y).spendCats.Travel||0);
ok('Travel phases: now→retirement→move→end, back to back',tv(2031)===20000&&tv(2032)===10000&&tv(2039)===10000&&tv(2040)===5000&&tv(2055)===5000,`2031 ${tv(2031)}, 2032 ${tv(2032)}, 2039 ${tv(2039)}, 2040 ${tv(2040)}`);
ok('A move with no state keeps the same tax state',R(run(mkPlan(P=>{P.moves=[{id:'x',name:'Condo',year:2030,state:''}];})),2031).state==='CA');
const inc=run(mkPlan(P=>{P.people.retireAgeSelf=62;P.incomes=[{name:'Consulting',amount:50000,startAt:'retire:self',endAt:'ss:self',taxable:'ordinary',real:true}];P.ss.selfClaim=67;}));
ok('Income from retirement until Social Security',R(inc,2031).ordInc<1&&Math.round(R(inc,2032).ordInc)===50000&&Math.round(R(inc,2036).ordInc)===50000&&R(inc,2037).ordInc<1,`${Math.round(R(inc,2032).ordInc)} in 2032–36`);
console.log(`\n${pass} passed, ${fail} failed`);if(fail)process.exit(1);
