const path=require('path');const fs=require('fs');const P=require(path.join(__dirname,'../src/parsers.js'));
let pass=0,fail=0;const ok=(n,c,d='')=>{c?pass++:fail++;console.log(`${c?'PASS':'FAIL'}  ${n}${d?'  ['+d+']':''}`);};
const rd=(f)=>P.parseTxnCSV(fs.readFileSync(path.join(__dirname,'fixtures',f),'utf8'),f);
const a=rd('chase_card.csv'),b=rd('amex.csv'),c=rd('bofa_checking.csv');
ok('Chase card: purchases negative in file → spending',a.txns.filter(t=>t.kind==='spend').every(t=>t.amount>0));
ok('Chase card: payment received excluded',a.txns.find(t=>/AUTOMATIC PAYMENT/.test(t.desc)).kind==='transfer');
ok('Chase card: return reduces spending',a.txns.find(t=>t.kind==='refund').amount===-25);
ok('Amex: purchases positive in file → spending',b.txns.find(t=>/MARRIOTT/.test(t.desc)).amount===812.4);
ok('Amex: online payment excluded',b.txns.find(t=>/ONLINE PAYMENT/.test(t.desc)).kind==='transfer');
ok('Bank: card autopay tagged as card payment (excluded only when that card is imported)',c.txns.filter(t=>/CHASE CREDIT|AMERICAN EXPRESS/.test(t.desc)).every(t=>t.kind==='cardpay'));
const ty=P.parseTxnCSV('Posting Date,Description,Amount,Type\n01/05/2026,PG&E,280.00,DEBIT\n01/15/2026,PAYROLL,1000.00,CREDIT\n01/20/2026,CHECK 101,50.00,CHECK','x.csv');
ok('Unsigned amounts with a Debit/Credit type column',ty.txns[0].amount===280&&ty.txns[0].kind==='spend'&&ty.txns[1].kind==='income'&&ty.txns[2].kind==='spend');
ok('Dates like 05-Jan-2026 and 20260105',P.parseTxnCSV('Date,Description,Amount\n05-Jan-2026,A,-5\n20260106,B,-6','y.csv').txns.length===2);
ok('Bank: brokerage transfer excluded',c.txns.find(t=>/Fidelity Brokerage/.test(t.desc)).kind==='transfer');
ok('Bank: payroll is income, not spending',c.txns.find(t=>/PAYROLL/.test(t.desc)).kind==='income');
const living=[...a.txns,...b.txns,...c.txns].filter(t=>(t.kind==='spend'||t.kind==='refund')&&!/Housing|Property tax|Income tax/.test(t.category)).reduce((s,t)=>s+t.amount,0);
ok('Total living spending across 3 files',Math.abs(living-6138.30)<0.01,living.toFixed(2));
ok('Categories: groceries, travel, utilities, nanny→kids',a.txns[0].category==='Groceries'&&a.txns[2].category==='Travel'&&c.txns.find(t=>/NANNY/.test(t.desc)).category==='Kids & education');
console.log(`${pass} passed, ${fail} failed`);
{const C=P.classifyTxn;let p2=0,f2=0;const ok2=(n,c)=>{c?p2++:f2++;console.log(`${c?'PASS':'FAIL'}  ${n}`);};
ok2('Card account: COINBASE charge is spending (not a transfer)',C('COINBASE.COM',true,true).kind==='spend');
ok2('Bank account: payment into a credit card is skipped',C('CHASE CREDIT CRD AUTOPAY',true,false).kind==='cardpay');
ok2('Bank account: check is spending',C('CHECK 1042',true,false).kind==='spend');
ok2('Pay methods: check / ACH / Zelle / ATM / debit card',P.payMethod('CHECK 1042','spend')==='Check'&&P.payMethod('PGE DES:WEB ONLINE','spend')==='Direct payment (ACH / bill pay)'&&P.payMethod('ZELLE PAYMENT TO JO','spend')==='Zelle / Venmo / PayPal'&&P.payMethod('ATM WITHDRAWAL','spend')==='Cash / ATM'&&P.payMethod('POS PURCHASE SAFEWAY','spend')==='Debit-card purchase');
console.log(`${p2} passed, ${f2} failed (account rules)`);}
{let p3=0,f3=0;const ok3=(n,c,d='')=>{c?p3++:f3++;console.log(`${c?'PASS':'FAIL'}  ${n}${d?'  ['+d+']':''}`);};
const chk=(f,rows,out,inn)=>{const r=rd(f);const o=r.txns.filter(x=>x.amount>0).reduce((a,x)=>a+x.amount,0),i=-r.txns.filter(x=>x.amount<0).reduce((a,x)=>a+x.amount,0);ok3(`${f}: all ${rows} rows read, debits ${out}, credits ${inn}`,r.txns.length===rows&&r.skipped.length===0&&Math.abs(o-out)<0.01&&Math.abs(i-inn)<0.01,`${r.txns.length} rows, out ${o.toFixed(2)}, in ${i.toFixed(2)}`);};
chk('chase_checking.csv',6,8337.76,18500);chk('capone_bank.csv',3,1129.99,500);chk('schwab_checking.csv',3,10025,12.34);chk('fidelity_cma.csv',4,1794.12,9000);
console.log(`${p3} passed, ${f3} failed (bank formats)`);}
{const r=rd('capone360_sample.csv');const out=r.txns.filter(x=>x.amount>0).reduce((a,x)=>a+x.amount,0),inn=-r.txns.filter(x=>x.amount<0).reduce((a,x)=>a+x.amount,0);
 const g=(re)=>r.txns.find(x=>re.test(x.desc));let ok4=0,bad4=0;const t4=(n,c)=>{c?ok4++:bad4++;console.log(`${c?'PASS':'FAIL'}  ${n}`);};
 t4('Capital One 360: Debit = money out even with "AUTOPAY PAYMENT" wording (no sign flip)',g(/CITI/).amount===1200&&g(/CITI/).kind==='cardpay');
 t4('Capital One 360: negative Debit (ATM) is still money out',g(/ATM/).amount===100);
 t4('Capital One 360: negative Credit (deposit reversal) is money out',g(/Reversal/).amount===50);
 t4('Capital One 360: totals out 3730, in 5040',Math.abs(out-3730)<0.01&&Math.abs(inn-5040)<0.01);
 t4('Savings transfer excluded; PG&E is utilities',g(/Performance/).kind==='transfer'&&g(/PGANDE/).category==='Utilities & phone');
 console.log(`${ok4} passed, ${bad4} failed (Capital One 360)`);}
