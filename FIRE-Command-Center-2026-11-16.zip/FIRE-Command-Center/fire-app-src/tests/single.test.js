// Single (unmarried) households: single brackets everywhere, no spouse in the plan
const S0=require('path').join(__dirname,'../src/');globalThis.FireHist=require(S0+'hist.js');const E=globalThis.FireEngine=require(S0+'engine.js');const L=require(S0+'planner.js');
let pass=0,fail=0;const out=[];const ok=(name,cond,detail='')=>{cond?pass++:fail++;out.push(`${cond?'PASS':'FAIL'}  ${name}${detail?'  ['+detail+']':''}`);};
const mkS=(filing)=>{const S=JSON.parse(JSON.stringify(E.DEFAULT_SETTINGS));S.ref=JSON.parse(JSON.stringify(E.DEFAULT_REF));S.household.birthYearSelf=1978;S.household.birthYearSpouse=1980;S.household.filing=filing;S.household.size=filing==='single'?1:2;return S;};
const inc=(o)=>({ordinary:0,qualified:0,taxExempt:0,otherIncome:0,capInc:0,ssTaxable:0,...o});
// engine defaults to the household's filing status
{const t=E.taxes(mkS('single'),2026,inc({ordinary:100000}),{calYear:2026});const exp=12400*.1+(50400-12400)*.12+(100000-16100-50400)*.22;ok('Single 2026: $100k wages uses single brackets and $16,100 deduction',Math.abs(t.fedOrdinary-exp)<1,`${Math.round(t.fedOrdinary)} vs ${Math.round(exp)}`);}
{const t=E.taxes(mkS('single'),2026,inc({ordinary:300000,qualified:100000}),{calYear:2026});ok('Single NIIT threshold $200k (investment income $400k)',Math.abs(t.niit-200000*0.038)<1,Math.round(t.niit));}
{const t=E.taxes(mkS('MFJ'),2026,inc({ordinary:100000}),{calYear:2026});ok('MFJ unchanged when filing is MFJ',Math.abs(t.fedOrdinary-(24800*.1+(100000-32200-24800)*.12))<1);}
// planner
const W=(o)=>({stock:0,bond:0,cash:0,bank:0,gold:0,crypto:0,goog:0,...o});
const init={year:2027,taxable:3e6,pretax:5e5,roth:0,property:0,debt:0,cardDebt:0,chunks:[{v:3e6,c:3e6}],w:{taxable:W({stock:1}),pretax:W({stock:1}),roth:W({stock:1})},yieldTaxable:0,qualFrac:1,exemptFrac:0,props:[],pretaxS:3e5,pretaxP:2e5,rothS:0,rothP:0};
const mkPlan=(S)=>{const P=L.newPlan(S,'t');P.spending.categories=[{name:'Living',amount:100000,kind:'essential',startAge:'',endAge:''}];P.healthcare.model=false;P.inflation=0;P.returns={...P.returns,stock:0,bond:0,cash:0,bank:0,re:0};P.ss={selfPIA:30000,selfClaim:67,spousePIA:25000,spouseClaim:67,fra:67,haircutPct:0,haircutYear:2099};P.people.lifeSelf=90;P.people.lifeSpouse=95;P.work=[{who:'spouse',name:'x',salary:200000,growth:0,startAge:'',endAge:''}];return P;};
let I0;try{I0=L.initFromSnapshot?null:null;}catch(e){}
const Ss=mkS('single'),Sm=mkS('MFJ');
const ds=L.deterministic(mkPlan(Ss),JSON.parse(JSON.stringify(init)),Ss), dm=L.deterministic(mkPlan(Sm),JSON.parse(JSON.stringify(init)),Sm);
ok('Single plan: every year files single',ds.rows.every(r=>r.filing==='single'));
ok('Single plan: no first-death event',ds.firstDeath==null);
ok('Single plan: ends at your life expectancy (no spouse years)',ds.rows[ds.rows.length-1].age===90,'last age '+ds.rows[ds.rows.length-1].age);
const r70s=ds.rows.find(r=>r.age===70),r70m=dm.rows.find(r=>r.age===70);
ok('Single plan: Social Security is only your own benefit',Math.abs(r70s.ss-30000)<1,Math.round(r70s.ss));
ok('Married plan still counts both benefits',r70m.ss>50000,Math.round(r70m.ss));
ok('Single plan: spouse job ignored',ds.rows[0].wages<1,Math.round(ds.rows[0].wages));
ok('Single plan: spouse-owned IRA moves to you',ds.rows[0].pretaxP<1&&ds.rows[0].pretaxS>4e5,`${Math.round(ds.rows[0].pretaxS)}`);
ok('Single plan: spending stays 100% (no survivor cut)',ds.rows.slice(1).every(r=>Math.abs(r.spend-ds.rows[1].spend)<1));
out.forEach(l=>console.log(l));console.log(`\n${pass} pass, ${fail} fail`);if(fail)process.exit(1);
