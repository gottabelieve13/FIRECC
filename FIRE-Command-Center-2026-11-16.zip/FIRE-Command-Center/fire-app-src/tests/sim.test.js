const S0=require('path').join(__dirname,'../src/');globalThis.FireHist=require(S0+'hist.js');const E=globalThis.FireEngine=require(S0+'engine.js');const L=require(S0+'planner.js');
const S=JSON.parse(JSON.stringify(E.DEFAULT_SETTINGS));S.ref=JSON.parse(JSON.stringify(E.DEFAULT_REF));S.household.birthYearSelf=1978;S.household.birthYearSpouse=1980;
let pass=0,fail=0;const out=[];const ok=(name,cond,detail='')=>{cond?pass++:fail++;out.push(`${cond?'PASS':'FAIL'}  ${name}${detail?'  ['+detail+']':''}`);};
const W=(o)=>({stock:0,bond:0,cash:0,bank:0,gold:0,crypto:0,goog:0,...o});
const mkInit=(o={})=>{const tx=o.taxable??2e6, basis=o.basis??tx;return {year:2027,taxable:tx,pretax:o.pretax??1e6,roth:o.roth??0,property:0,debt:0,cardDebt:0,chunks:o.chunks||[{v:tx,c:basis}],w:{taxable:W({stock:1}),pretax:W({stock:1}),roth:W({stock:1})},yieldTaxable:o.yld??0,qualFrac:1,exemptFrac:0,props:o.props||[],pretaxS:o.pretaxS??(o.pretax??1e6),pretaxP:o.pretaxP??0,rothS:o.roth??0,rothP:0,edu:o.edu??0};};
const mkPlan=(mod)=>{const P=L.newPlan(S,'t');P.spending.categories=[{name:'Living',amount:100000,kind:'essential',startAge:'',endAge:''}];P.healthcare.model=false;P.inflation=0;P.returns={...P.returns,stock:0,bond:0,cash:0,bank:0,re:0};P.ss={selfPIA:0,selfClaim:67,spousePIA:0,spouseClaim:67,fra:67,haircutPct:0,haircutYear:2034};P.people.lifeSelf=95;P.people.lifeSpouse=95;mod&&mod(P);return P;};
const det=(P,I)=>L.deterministic(P,I,S);
// 1 conservation: zero returns, zero inflation, basis=value -> liquid falls by spend+tax each year exactly
{const d=det(mkPlan(),mkInit());let worst=0;for(let i=1;i<d.rows.length;i++){const a=d.rows[i-1],b=d.rows[i];if(b.short>1)break;const exp=a.liquid-(b.spend+b.health+b.tax+b.housingOut-b.ss-b.wages);worst=Math.max(worst,Math.abs(b.liquid-exp));}ok('Cash-flow conservation (0% returns): Δliquid = −(spend+tax+health)',worst<50,'tax solved to within $50; max error $'+worst.toFixed(2));}
// 2 RMD starts at 75 for born 1978, divisor 24.6
{const d=det(mkPlan(),mkInit({taxable:5e6}));const r74=d.rows.find(r=>r.age===74),r75=d.rows.find(r=>r.age===75);ok('No RMD at 74 (born 1960+ → 75)',r74.rmd<1);const prev=d.rows.find(r=>r.age===74).pretaxS;ok('RMD at 75 = prior balance / 24.6',Math.abs(r75.rmd-prev/24.6)<5,`${Math.round(r75.rmd)} vs ${Math.round(prev/24.6)}`);}
// 3 early withdrawal penalty 10%+2.5% CA when only pretax at 50
{const d=det(mkPlan(),mkInit({taxable:0,pretax:3e6,chunks:[]}));const r=d.rows[0];ok('Early pre-tax withdrawal penalty 12.5% (fed 10% + CA 2.5%)',Math.abs(r.taxParts.penalty-0.125*r.fromPre)<2,`penalty ${Math.round(r.taxParts.penalty)} on ${Math.round(r.fromPre)}`);}
// 4 Roth early access
{const d0=det(mkPlan(),mkInit({taxable:0,pretax:0,roth:3e6,chunks:[]}));ok('Roth earnings locked before 59½ with 0 basis → shortfall',d0.rows[0].short>1);
 const d1=det(mkPlan(P=>{P.rothBasis=1e6}),mkInit({taxable:0,pretax:0,roth:3e6,chunks:[]}));ok('Roth basis $1M spendable before 59½',d1.rows[0].short<1&&d1.rows[0].fromRoth>0);}
// 5 capital-loss carryforward
{const d=det(mkPlan(),mkInit({taxable:2e6,basis:3e6}));const r=d.rows[0];ok('Realized loss beyond $3k carries forward',r.diPool>40000,'pool '+Math.round(r.diPool));ok('Capital loss against income capped at $3,000 (nominal)',d.rows.every(x=>x.taxParts!=null));}
// 6 rental sale: depreciation recapture uses adjusted basis
{const prop={id:'r1',name:'R',kind:'rental',value:1500000,basis:1000000,purchaseYear:2013,buildingPct:60,mtgBalance:0,rentMonthly:5000,vacancyPct:0,propertyTax:0,insurance:0,hoa:0,maintAmt:0,mgmtPct:0,appreciation:0,sellYear:2027,sellCostPct:6};
 const d=det(mkPlan(P=>{P.reSale={}}),mkInit({props:[prop]}));const r=d.rows[0];const accDep=Math.min(27.5,14)*600000/27.5;const gain=1500000*0.94-(1000000-accDep);
 ok('Rental sale gain uses cost − depreciation',Math.abs(r.capGain-gain)<20000,`gain ${Math.round(r.capGain)} vs ~${Math.round(gain)}`);}
// 7 first death: survivor files single, step-up
{const d=det(mkPlan(P=>{P.people.lifeSelf=60}),mkInit({taxable:5e6,basis:1e6}));const r60=d.rows.find(x=>x.age===60),r61=d.rows.find(x=>x.age===61);ok('Survivor files single the year after first death',r60.filing==='MFJ'&&r61.filing==='single');}
// 8 SS survivor keeps larger benefit
{const d=det(mkPlan(P=>{P.ss.selfPIA=40000;P.ss.spousePIA=10000;P.ss.selfClaim=67;P.ss.spouseClaim=67;P.people.lifeSelf=80}),mkInit({taxable:5e6}));const a=d.rows.find(x=>x.age===79),b=d.rows.find(x=>x.age===82);ok('Survivor keeps larger SS benefit',Math.abs(b.ss-40000)<1&&a.ss>40000,`before ${Math.round(a.ss)} after ${Math.round(b.ss)}`);}
// 9 real/nominal invariance: 3% inflation vs 0% gives similar real ending (brackets indexed)
{const P0=mkPlan(P=>{P.returns.stock=4});const P3=mkPlan(P=>{P.returns.stock=4;P.inflation=3});const a=det(P0,mkInit({taxable:4e6,basis:2e6})),b=det(P3,mkInit({taxable:4e6,basis:2e6}));const rel=Math.abs(a.endReal-b.endReal)/a.endReal;ok('Inflation-neutral: real ending wealth within 3% at 0% vs 3% inflation',rel<0.03,`${(a.endReal/1e6).toFixed(2)}M vs ${(b.endReal/1e6).toFixed(2)}M`);}
// 10 ACA credit before 65 and none above cliff; IRMAA 2-yr lag
{const P=mkPlan(P=>{P.healthcare.model=true;P.healthcare.acaBenchmark=30000;P.spending.categories[0].amount=60000});S.aca.benchmarkPremium=30000;const d=det(P,mkInit({taxable:3e6}));const r=d.rows[0];ok('ACA premium credit received at low MAGI before 65',r.ptc>0,'ptc '+Math.round(r.ptc));const r66=d.rows.find(x=>x.age===67);ok('Medicare (not ACA) once both are 65+',r66.acaGross<1&&r66.medicare>0);}
// 11 MC determinism + percentile ordering
{const P=mkPlan(P=>{P.returns.stock=5;P.inflation=2.5});const I=mkInit({taxable:4e6,basis:2e6});const m1=L.monteCarlo(P,I,S,200),m2=L.monteCarlo(P,I,S,200);ok('Monte Carlo deterministic for fixed seed',m1.success===m2.success&&m1.medianEnd===m2.medianEnd);ok('Percentile bands ordered p10≤p25≤p50≤p75≤p90',m1.bands.every(b=>b.p10<=b.p25+1&&b.p25<=b.p50+1&&b.p50<=b.p75+1&&b.p75<=b.p90+1));const bt=L.backtest(P,I,S);ok('Backtest covers 98 start years',bt.runs===98||bt.byStart.length===98);}
// 12 history integrity
{const H=FireHist;ok('History 1928–2025 complete (98 rows)',H.length===98&&H[0].year===1928&&H[97].year===2025);ok('History S&P 2008 = −36.55%, 2022 = −18.04%',Math.abs(H[80].stock+0.3655)<1e-6&&Math.abs(H[94].stock+0.1804)<1e-6);ok('Long-run S&P real return ≈ 6.8%',Math.abs(L.HIST_REAL.stock-6.79)<0.1,L.HIST_REAL.stock.toFixed(2)+'%');}
// 13 direct indexing: loss pool used vs gains; $3,000 not indexed
{const P=mkPlan(P=>{P.inflation=3;P.di={...P.di,enabled:true,initial:500000,annual:0,years:0,harvestPct:10,decayPct:30}});const d=det(P,mkInit({taxable:3e6,basis:3e6}));ok('DI: ordinary offset never exceeds $3,000 nominal',d.rows.every(r=>r.diUseO<=3000.01),'max '+Math.max(...d.rows.map(r=>r.diUseO)).toFixed(0));}
// 14 529 out of liquid, in net worth
{const P=mkPlan();const d=det(P,mkInit({edu:100000}));const r=d.rows[0];ok('529 excluded from liquid, included in net worth',Math.abs(r.nw-(r.liquid+r.edu))<1);}

// 15 SS taxable portion (MFJ): SS 40k + 30k pre-tax withdrawals -> 11,100 taxable
{const P=mkPlan(P=>{P.ss.selfPIA=40000;P.ss.selfClaim=67;P.spending.categories[0].amount=70000;P.order='pretax-taxable-roth'});const d=det(P,mkInit({taxable:0,chunks:[],pretax:3e6}));const r=d.rows.find(x=>x.age===68);const ord=r.fromPre+r.rmd;const prov=ord+0.5*r.ss;const exp=prov<=32000?0:prov<=44000?Math.min(.5*r.ss,.5*(prov-32000)):Math.min(.85*r.ss,.85*(prov-44000)+Math.min(.5*r.ss,6000));ok('Taxable Social Security matches IRS worksheet',Math.abs(r.ssTax-exp)<5,`${Math.round(r.ssTax)} vs ${Math.round(exp)}`);}
// 16 Roth conversion: pre-tax down, Roth up by the same amount, tax paid from taxable
{const P=mkPlan(P=>{P.tax.convert='fixed';P.tax.convertFixed=100000;P.tax.convertStart='';P.tax.convertEnd=74});const d=det(P,mkInit({taxable:3e6,pretax:1e6,roth:0}));const r=d.rows[0];ok('Roth conversion moves pre-tax → Roth 1:1',Math.abs(r.roth-r.conv)<1&&Math.abs((1e6-r.pretax)-r.conv)<1,`conv ${Math.round(r.conv)} roth ${Math.round(r.roth)}`);}
// 17 Estate tax: 40% over 2 x $15M (portability), indexed
{const P=mkPlan(P=>{P.people.lifeSelf=50;P.people.lifeSpouse=48;P.spending.categories[0].amount=0});const d=det(P,mkInit({taxable:40e6,basis:40e6,pretax:0}));ok('Federal estate tax = 40% × (estate − $30M)',Math.abs(d.estateTaxReal-0.4*(d.rows[d.rows.length-1].taxable/d.rows[d.rows.length-1].cpiEnd-30e6))<5000,'estate tax '+Math.round(d.estateTaxReal));}
// 18 FICA + CA SDI: one earner $300k
{const P=mkPlan(P=>{P.work=[{who:'self',name:'Job',salary:300000,growth:0,pretax401k:0,match:0,rothContrib:0,startAge:'',endAge:50}]});const d=det(P,mkInit());const r=d.rows[0];const exp=184500*0.062+300000*0.0145+50000*0.009;ok('FICA: 6.2% to $184,500 + 1.45% + 0.9% over $250k',Math.abs(r.taxParts.fica-exp)<2,`${Math.round(r.taxParts.fica)} vs ${Math.round(exp)}`);ok('CA SDI 1.3% of all wages',Math.abs(r.taxParts.casdi-3900)<1);}
// 19 ACA cliff: MAGI just above 400% FPL loses all credit
{const S3=JSON.parse(JSON.stringify(S));S3.household.size=3;const thr=E.acaThresholds(S3,2026);ok('400% FPL cliff for household of 3 (2026 coverage) = $106,600',Math.abs(thr.fpl*4-106600)<1,'FPL '+thr.fpl);}
console.log(out.join('\n'));console.log(`\n${pass} passed, ${fail} failed`);
{const P=mkPlan(P=>{P.sim={...P.sim,matchMeans:true};P.returns.stock=4;});const path=L.adjustPath(P,FireHist.map(h=>({...h,goog:h.stock,crypto:h.stock,bank:h.cash})));
 const geo=Math.pow(path.reduce((p,h)=>p*(1+h.stock)/(1+h.infl),1),1/path.length)-1;ok('Monte Carlo "use my returns" shifts history to exactly the plan rate',Math.abs(geo-0.04)<1e-4,(geo*100).toFixed(3)+'%');console.log(out[out.length-1]);}
