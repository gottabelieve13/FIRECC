const S0=require('path').join(__dirname,'../src/');globalThis.FireHist=require(S0+'hist.js');const E=globalThis.FireEngine=require(S0+'engine.js');const L=require(S0+'planner.js');
const S=JSON.parse(JSON.stringify(E.DEFAULT_SETTINGS));S.ref=JSON.parse(JSON.stringify(E.DEFAULT_REF));S.household.birthYearSelf=1958;S.household.birthYearSpouse=1958;
let pass=0,fail=0;const ok=(n,c,d='')=>{c?pass++:fail++;console.log(`${c?'PASS':'FAIL'}  ${n}${d?'  ['+d+']':''}`);};
const W=(o)=>({stock:0,bond:0,cash:0,bank:0,gold:0,crypto:0,goog:0,...o});
const init=(o={})=>({year:2027,taxable:3e6,pretax:1e6,roth:0,property:0,debt:0,cardDebt:0,chunks:[{v:3e6,c:1e6}],w:{taxable:W({stock:1}),pretax:W({stock:1}),roth:W({stock:1})},yieldTaxable:0,qualFrac:1,exemptFrac:0,props:[],pretaxS:1e6,pretaxP:0,rothS:0,rothP:0,edu:0,...o});
const P=L.newPlan(S,'t');P.spending.categories=[{name:'L',amount:100000,kind:'essential',startAge:'',endAge:''}];P.healthcare.model=true;P.inflation=0;
const a=L.deterministic(P,init(),S), b=L.deterministic(P,init({magiSeed:{2025:{i:800000,p:800000}},capLossCF:50000}),S);
ok('2027 IRMAA uses actual 2025 MAGI from return (tier 5 at $800k)',b.rows[0].irmaa>a.rows[0].irmaa&&Math.abs(b.rows[0].irmaa-2*(487+91)*12)<5,`${Math.round(a.rows[0].irmaa)} → ${Math.round(b.rows[0].irmaa)}`);
ok('Capital-loss carryforward from return offsets 2027 gains',b.rows[0].diUseG+b.rows[0].diUseO>0&&b.rows[0].tax<a.rows[0].tax,`tax ${Math.round(a.rows[0].tax)} → ${Math.round(b.rows[0].tax)}`);
// 2024/2025 tables exact
const t25=E.taxes(S,2025,{ordinary:300000,qualified:0,taxExempt:0,otherIncome:0,capInc:0},{calYear:2025});const prog=(x,br)=>{let t=0,p=0;for(const[l,r]of br){if(x<=p)break;t+=(Math.min(x,l)-p)*r;p=l;}return t;};
ok('2025 federal table (OBBBA std $31,500) exact',Math.abs(t25.fedOrdinary-prog(300000-31500,[[23850,.1],[96950,.12],[206700,.22],[394600,.24],[501050,.32],[751600,.35],[Infinity,.37]]))<1,Math.round(t25.fedOrdinary)+'');ok('2025 not estimated',!t25.est);
const t24=E.taxes(S,2024,{ordinary:300000,qualified:0,taxExempt:0,otherIncome:0,capInc:0},{calYear:2024});ok('2024 federal table exact',Math.abs(t24.fedOrdinary-prog(300000-29200,[[23200,.1],[94300,.12],[201050,.22],[383900,.24],[487450,.32],[731200,.35],[Infinity,.37]]))<1);
ok('2024 CA table (std $11,080) exact',Math.abs(t24.ca-prog(300000-11080,[[21512,.01],[50998,.02],[80490,.04],[111732,.06],[141212,.08],[721318,.093],[865574,.103],[1442628,.113],[Infinity,.123]]))<1);
// AMT 2025 phaseout rate 25%: amti 1.5M ⇒ exemption 137000-0.25*(1.5M-1.2527M)
const big=E.taxes(S,2025,{ordinary:1500000,qualified:0,taxExempt:0,otherIncome:0,capInc:0},{calYear:2025,deductionOverride:0});ok('AMT uses 25% phase-out in 2025 (50% from 2026)',big.amt>=0);
console.log(`${pass} passed, ${fail} failed`);
