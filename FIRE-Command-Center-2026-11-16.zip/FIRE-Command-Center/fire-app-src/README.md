# FIRE Command Center: source

The app is a single offline HTML file built from these sources. There's no server.

The only network calls are optional market-price lookups, and they send ticker symbols only. Sources:

- your own published Google Sheet with GOOGLEFINANCE formulas
- Cboe delayed quotes, Yahoo Finance
- gold-api.com, CoinGecko, Coinbase
- FinancialModelingPrep, Finnhub or Twelve Data, with your keys

Turn them off in Settings → Market data. The Donate link opens Stripe only when clicked.

## Build

```
cd fire-app-src
python3 build.py                 # writes ../FIRE-Command-Center.html with NO financial data
```

`build.py` inlines the scripts, pdf.js and the logos (as data URLs) into one file.

`python3 build.py out.html --seed seed.json --pl projectionlab.csv` embeds starting data for testing. **Don't** do this for copies you share or sync: `Package App for Sharing.command` refuses to package a build with built-in data.

## Test

```
for f in tests/*.test.js; do node "$f"; done
```

There are 123 checks in 8 files. Fixtures in `tests/fixtures/` are made-up sample files, not real statements.

| File | Checks | Covers |
|---|---:|---|
| `golden.test.js` | 28 | 2026 federal + California tax against hand calculations |
| `states.test.js` | 13 | Other states: no-tax, flat, brackets, MA surtax, WA capital-gains excise |
| `single.test.js` | 11 | Single filers: brackets, thresholds, no-spouse plan |
| `sim.test.js` | 29 | Retirement rules and simulation invariants (RMDs, Social Security, ACA, IRMAA, conservation, Monte Carlo) |
| `returns.test.js` | 7 | Imported returns feeding carryforwards and lookbacks |
| `parse-return.test.js` | 4 | 1040/540 PDF text parsing, including line-number echoes and 2025's 11a/11b |
| `spending.test.js` | 25 | Bank/card CSV formats, signs, card payments, transfers, de-duplication |
| `w2.test.js` | 6 | W-2 PDF text layouts, box 12 codes, no SSN kept |

## Files

| File | What it does |
|---|---|
| `src/parsers.js` | Reads the following: Fidelity positions CSV and statement PDF; Schwab positions CSV; Morgan Stanley stock-plan lots; Wealthfront, Vanguard 401(k) and Vestwell statements; bank and credit-card CSVs; Form 1040 + California 540 PDFs; W-2 PDFs. Detects each file type automatically. |
| `src/engine.js` | Quarterly rules: cash-buffer modes, ACA MAGI, sale plans, wash-sale and tax-loss checks. Federal tax plus all 50 states and DC (`E.STATES`). Starter household (`E.STARTER`). |
| `src/planner.js` | Lifetime simulation: work income and saving, Social Security, healthcare/ACA/IRMAA, rentals, RMDs, Roth strategies, direct indexing, estate, Monte Carlo and historical backtest. Also ProjectionLab import. |
| `src/hist.js` | 1928–2025 stock, bond, T-bill, real estate and gold returns (Damodaran/NYU Stern) and CPI (Minneapolis Fed). |
| `src/app.js` | User interface, data sets, storage, encrypted export and auto-save, W-2s, AI review export, help, donation reminder. |
| `src/shell.html` | Page layout and styles. |
| `src/brand/` | FIRE Command Center and Pay Forward Labs logos. The `*-full.png` files are full resolution; the smaller ones are what gets built in. |
| `src/vendor/` | Mozilla pdf.js 3.11 (Apache-2.0) for reading PDFs offline. |

The `app_v1.js` and `sec_*.js` files are old drafts that the build doesn't use. They're left out of shared packages.

## Where data lives

- **This browser:** in localStorage, one key per data set (`fireCC.v1`, plus `fireCC.v1:<id>` for extra data sets; the list of data sets is in `fireCC.datasets`).
- **Encrypted auto-save** (Chrome/Edge): Settings → Data & import → Choose data folder, then pick `FIRE-data`. Each data set writes `autosave/` and `snapshots/` there (extra data sets under `datasets/<name>/`).
  - Encryption: AES-256-GCM, PBKDF2-SHA256, 310,000 iterations.
- **Export (encrypted)** downloads a `.fire` backup. **Load data file** restores it, either into the open data set or as a new one.
- **AI review export** writes plain-text `FIRE-ai-review.md` / `.json`. Names and account numbers are masked by default; API keys are always removed.
- There is no password recovery.
