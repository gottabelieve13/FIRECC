<p align="center"><img src="fire-app-src/src/brand/fire-wordmark640.png" alt="FIRE Command Center: retirement & financial planning" width="420"></p>

# FIRE Command Center

A private, offline retirement and tax planner, made by **Pay Forward Labs**.

It turns your statements into:

- a current net worth
- a cash-buffer and sale plan for each quarter
- a tax picture for this year
- a lifetime plan with Monte Carlo risk

It runs entirely in your browser from one HTML file. There's no account and no server, and nothing you import is uploaded.

---

## 1. Put it on your computer and run it

### What you need

- **A computer** (Mac or Windows) with a modern browser.
- **Google Chrome or Microsoft Edge** is recommended. They're the only browsers that can auto-save to a folder. Safari and Firefox still run the app; you save with **Export** instead (see [Where your data lives](#where-your-data-lives)).
- No installs, no Python, no internet connection. The internet is used only for optional market-price lookups.

### Install

1. **Get the folder.** Unzip the release (it unzips to a `FIRE-Command-Center` folder; yours may have another name) to a permanent place, such as `Documents`. Don't run it from inside a zip file or your Downloads preview.
2. **Keep the folder together.** It should look like this:

   ```
   FIRE-Command-Center/
   ├── FIRE-Command-Center.html   ← the app (double-click this)
   ├── README.md                  ← this file
   ├── FIRE-data/                 ← your encrypted data (created/filled by the app)
   │   ├── autosave/
   │   ├── snapshots/
   │   └── statements/            ← optional originals, NOT encrypted
   ├── Backup to Zip.command      ← one-click backup WITH your data (Mac)
   ├── Backups/                   ← zips made by the backup script (created on first run)
   ├── Package App for Sharing.command ← zip of the app WITHOUT your data (Mac)
   ├── Releases/                  ← zips made by the sharing script (created on first run)
   ├── Validation-Report.md       ← how the tax math was tested
   └── fire-app-src/              ← source code, tests, logos (only needed to rebuild)
   ```

### Run

1. **Double-click `FIRE-Command-Center.html`.** It opens in your default browser.
   - **If it opens in Safari (Mac):** right-click the file → **Open With** → **Google Chrome**.
   - **To always use Chrome:** right-click → **Get Info** → **Open with: Chrome** → **Change All**.
   - **Windows:** right-click → **Open with** → **Chrome** or **Edge**.
2. **Bookmark the page** (⌘D / Ctrl+D) so you can reopen it from the browser.
3. **Set up saving the first time** (takes 1 minute):
   1. Go to **Settings → Data & import → Data folder & backups**.
   2. Click **Choose data folder** and select the `FIRE-data` folder.
   3. Pick a password and store it in your password manager. **It can't be recovered.**

   After that, every change is saved, encrypted, about 1.5 seconds later.
4. **After a browser restart,** click **Auto-save** in the header and re-enter the password. Chrome may ask you to allow folder access again.

### Several households or scenarios (data sets)

The app can hold several independent data sets. Each one has its own accounts, plans, returns, spending and settings, for example "Us", "Mom & Dad" or "Test household".

- **Switch:** use the menu next to the title in the header. The app reloads with the chosen data set.
- **Add:**
  - **+ New data set…** (header menu) or **Settings → Data & import → Data sets → New empty data set**.
  - **Load a .fire file as a new data set** adds someone's encrypted export without touching yours.
- **Unload:** removes a data set from this browser. Its encrypted files in the data folder are **not** deleted, so you can load it again any time with **Load data file**.
- **Where it saves:**
  - The first data set uses `FIRE-data/autosave/` and `snapshots/` as before.
  - Others save to `FIRE-data/datasets/<name>/autosave/` and `snapshots/`.
  - Each data set can use its own password; after switching, click **Auto-save** and enter that data set's password.

### Move to another computer

1. Copy the whole folder (or unzip a backup) onto the new computer.
2. Open `FIRE-Command-Center.html` in Chrome or Edge.
3. Go to **Settings → Data & import → Load data file**. Choose `FIRE-data/autosave/FIRE-autosave.fire` and enter your password.
4. Click **Choose data folder** and select `FIRE-data` again to keep auto-saving.

### Update to a new version

Replace only `FIRE-Command-Center.html` (and `fire-app-src/` if you keep the code). Your data isn't inside the HTML file, so it stays put.

If you move or rename the HTML file, the browser may treat it as a new app. In that case, use **Load data file** as above to bring your data back.

### Back up

- **Mac:** double-click **`Backup to Zip.command`**. It zips the folder into `Backups/` and keeps the 10 newest. If Google Drive for desktop is installed, it also copies the zip to your personal (@gmail.com) Drive.
  - To use a different personal account, run it with `FIRE_DRIVE_ACCOUNT=you@example.com`.
  - Work accounts are never used.
  - It asks before including the unencrypted `statements/` folder.
  - **First run:** macOS may block it. Right-click → **Open** → **Open**. If it says it can't be executed after unzipping, run `chmod +x "Backup to Zip.command"` in Terminal once.
- **Windows:** right-click the folder → **Send to → Compressed (zipped) folder**, then upload the zip to your cloud drive.

### Share the app with someone (without your data)

Double-click **`Package App for Sharing.command`** (Mac). It creates `Releases/FIRE-Command-Center-YYYY-MM-DD.zip` containing:

- the app
- this README and `Validation-Report.md`
- both scripts
- the source code, with tests that use only made-up sample files
- an **empty** `FIRE-data/` folder

Your `.fire` files, statements and `Backups/` are never included. The script refuses to run if the app file has starting data built in. Like the backup script, macOS may ask you to right-click → **Open** the first time.

This is separate from **Backup to Zip**, which saves your data. Each excludes the other's zips.

### Rebuild from source (developers only)

```bash
cd fire-app-src
python3 build.py                          # writes ../FIRE-Command-Center.html (contains no financial data)
for f in tests/*.test.js; do node "$f"; done   # 123 automated checks in 8 test files
```

Source files are in `fire-app-src/src/` (`app.js`, `engine.js`, `planner.js`, `parsers.js`, `hist.js`, `shell.html`). Logos are in `fire-app-src/src/brand/`. See `fire-app-src/README.md` for details.

---

## 2. First-time setup (about 30 minutes)

1. **Pick your state and filing status** in **Settings → Rules & reference**. All 50 states plus DC are supported, filing either married jointly or single.
2. **Import your statements** with the **Import** button in the header, or drag files onto **Settings → Data & import**. Review what was read, then click **Apply to working copy**. Accounts you can't download can be added by hand on **Money → Net worth**.
3. **Check owners and account types** on **Net worth**: pre-tax, Roth, taxable, HSA or 529, and whose account it is. Add cost basis where a statement didn't include it.
4. **Fill in Plan → Assumptions.** A new data set starts with a typical U.S. married couple around age 40 (one child). These are only placeholders until you enter your own:
   - **Income:** $65k + $55k in wages, with 6% going to a 401(k) and a 3% employer match.
   - **Spending:** $80k a year, split like the average household in the BLS Consumer Expenditure Survey 2025 (housing, transportation, food, health and so on).
   - **Social Security:** $28k + $25k a year at 67, in today's dollars.
   - **Starting cash and retirement age:** $20k in checking, retiring at 65.

   Replace each one with your own:
   - birth years and retirement age
   - spending
   - jobs, and where paychecks go before retirement
   - Social Security and healthcare
   - home and rentals
   - investment mix, and any concentrated stock ticker
5. **Import last year's tax return** (PDF) on **Taxes → Returns**. It checks the tax engine against your real return and fills in carryforwards and the prior-year safe harbor.
6. **Turn on auto-save** (see [Run](#run) above).
7. **Click Save snapshot** in the header to record today's balances in History.

---

## 3. The routine

| When | Where | What to do |
|---|---|---|
| **Each quarter** | Review → Quarterly | Import fresh statements, check the cash buffer and suggested sales, rebalance if a bucket drifted more than ±5 points, then **Save snapshot**. |
| **Oct – Dec** | Review → Year-end | Set this year's income target. Harvest losses or gains, do Roth conversions and retirement contributions, and set up ACA coverage for next year. |
| **January** | Review → Annual reset | Update spending, returns and goals; re-run the Plan; check the strategy comparison. |
| **Feb – Apr** | Taxes → Filing | Work through the document checklist and traps to avoid, then import the filed return on **Returns**. |
| **Any time** | Money → Spending | Import bank and card CSVs to see where money actually goes, and compare with the Plan's spending. |
| **Estimated taxes** | Taxes → This year | Safe-harbor amounts and due dates for federal and state. |

The **Home** tab shows what's due now. Red or amber dots on tabs mean something needs attention.

---

## 4. What each area does

- **Home:** net worth, this phase's goals (working vs. retired), and the next step.
- **Review:**
  - **Quarterly:** buffer, sales, rebalancing, prices
  - **Year-end:** income control
  - **Annual reset**
- **Money:**
  - **Net worth:** accounts and holdings, all editable
  - **Spending**
  - **Rentals**
  - **History:** snapshots and the daily price log
- **Taxes:**
  - **This year:** estimate, ACA and Medicare income limits, estimated payments
  - **Returns:** imported returns and W-2s, carryforwards, lookback
  - **Filing**
- **Plan:**
  - **Assumptions**, **Overview**, **Cash flow**
  - **Analytics:** click a year for details
  - **Strategies:** tax strategies and direct indexing
  - **Risk:** Monte Carlo and historical backtest
  - **Compare:** your plans side by side, or against ProjectionLab
- **Settings:**
  - **Data & import:** files, auto-save, backups
  - **Rules & reference:** state, buffer and sale rules, market data, tax tables
  - **How to use:** this guide, in the app

Anything filled in from an imported file can be edited, and your edits win over later imports. That includes balances, cost basis, return lines, wages and carryforwards.

---

## 5. Files you can import

| Source | Type | How to get it | What's read |
|---|---|---|---|
| Fidelity positions | CSV | Fidelity.com → Accounts → Positions → Download (all accounts) | Holdings, quantities, prices, cost basis |
| Fidelity monthly / quarterly statement | PDF | Fidelity.com → Documents → Statements | Balances and holdings by account (the CSV is better because it has cost basis) |
| Schwab positions | CSV | Schwab.com → Accounts → Positions → Export (one account or All-Accounts) | Holdings, quantities, prices, cost basis |
| Wealthfront statement | PDF | Wealthfront → Documents → Statements | Holdings and balances |
| Vanguard 401(k) statement | PDF | Vanguard (employer plan) → Statements | Balance by fund and source (pre-tax / Roth) |
| Vestwell 401(k) statement | PDF | Your plan site → Statements | Balance by fund and source |
| Morgan Stanley at Work stock plan | PDF | Stock-plan site → Portfolio → lot detail / statement | Share lots with purchase dates and cost (for tax-aware sale plans) |
| Bank and credit-card transactions | CSV | Bank or card site → Activity → Download (CSV) | Spending: money out by category and month. Card payments and transfers are detected so nothing is counted twice. Tested with Chase, Bank of America, Capital One, Schwab checking, Amex and Fidelity cash management; most others with Date / Description / Amount (or Debit / Credit) columns work. |
| W-2 wage statements | PDF | Employer payroll site (ADP, Workday, Gusto…) → Tax documents, late January | Wages, withholding, box 12 (401(k) D, Roth AA, HSA W), Social Security and Medicare wages, state tax. Shows unused 401(k)/HSA room, excess Social Security tax from two employers (refundable), additional Medicare tax, stock-pay under-withholding and a check against the return. One click fills Plan → Work income. |
| Federal tax return (Form 1040 + schedules) | PDF | TurboTax / preparer copy, or IRS transcript saved as PDF | Summary lines only: wages, AGI, taxable income, gains, tax, carryforwards, withholding |
| California return (Form 540) | PDF | Usually in the same PDF as the 1040 | CA AGI, deduction, taxable income, tax, withholding (other states' returns aren't read) |
| ProjectionLab export | JSON or CSV | ProjectionLab → Settings → Export data | Comparison only (Plan → Compare → vs ProjectionLab); never overwrites your plan |
| FIRE Command Center data file | `.fire` (encrypted) | Made by this app: Export, auto-save, snapshots | Everything: accounts, history, plans, settings, spending, returns |

- **File type is detected automatically.** Select everything at once with the header **Import** button: holdings go to Net worth, transactions to Spending, returns and W-2s to Taxes → Returns, ProjectionLab files to Compare.
- **PDFs must contain text.** Scanned or photographed pages have no text to read, so download the original PDF from the institution.
- **Re-importing is safe:**
  - Holdings are replaced account by account.
  - Duplicate transactions are removed: same account, amount and payee, with dates within 2 days.
  - Imported returns keep your edits.
- **Other institutions:** if a file isn't recognized, add the account by hand on **Net worth**. You can also export positions to CSV and check that the format matches Fidelity's or Schwab's.
- **Tax returns and W-2s:** SSNs, names and addresses are never stored, only the amounts listed above. Lines the importer misreads (for example a line number read as an amount) are corrected automatically and listed for you to check.

---

## 6. Where your data lives

| Place | What | Encrypted? | Notes |
|---|---|---|---|
| **This browser** | Working copy of everything | No (browser storage) | Per browser and computer. Clearing site data or using a private window loses it, so keep auto-save or exports on. |
| **FIRE-data/autosave/** | `FIRE-autosave.fire` plus one dated copy per day (last 30 kept) | Yes: AES-256-GCM, key from your password (PBKDF2, 310,000 rounds) | Written about 1.5 s after each change. Needs Chrome or Edge. After a browser restart, click Auto-save and re-enter the password. |
| **FIRE-data/snapshots/** | A full copy at each Save snapshot | Yes | Point-in-time restore points. |
| **Export (encrypted)** | A `.fire` file you save anywhere | Yes | Works in any modern browser. Load it with **Load data file**. |
| **FIRE-data/datasets/&lt;name&gt;/** | Extra data sets, each with its own `autosave/` and `snapshots/` | Yes (each can have its own password) | Managed from the header menu or Settings → Data & import. |
| **FIRE-data/ai-review/** | Optional plain-text copy of your data and the app's analysis, for an AI assistant to double-check | **No** | Masks names and account numbers by default and always removes API keys. Never included in backups or shared packages. See [Have an AI double-check your numbers](#have-an-ai-double-check-your-numbers). |
| **FIRE-data/statements/** | Optional place for original PDFs/CSVs | **No** | The backup script asks before including them. |
| **Backup to Zip.command** | Zips the folder into `Backups/`, then copies it to a personal Google Drive if installed | Data files yes; app and docs no | Mac only. |

- **The password can't be recovered.** Keep it in a password manager. Without it, the `.fire` files can't be opened.
- **What leaves your computer:** only market-price requests for index, gold, silver, bitcoin and fund symbols.
  - They go to your own published Google Sheet, Cboe, Yahoo, gold-api.com, CoinGecko, Coinbase, or the price services whose keys you add.
  - No balances, names or files are sent.
  - To turn this off, go to **Settings → Market data**.
  - The Donate link opens Stripe in your browser only when you click it.
- **API keys** for price services are stored in your data and encrypted backups. Use free, read-only keys.
- **Sharing the tool:** share only `FIRE-Command-Center.html` (and `fire-app-src/` for the code). Your data is never inside the HTML file; it stays in your browser and `FIRE-data/`. Don't share `FIRE-data/` or `Backups/`. Use **Package App for Sharing** to make a clean zip.

### Have an AI double-check your numbers

1. Go to **Settings → Data & import → AI review export**.
2. Choose your options:
   - **Mask names and account numbers:** on by default.
   - **Include individual transactions:** off by default; you get monthly totals by category instead.
3. Click **Write to FIRE-data/ai-review/**, or download the two files:
   - `FIRE-ai-review.md`: a readable report with instructions for the reviewer at the top. It covers balances, this year's tax and ACA/Medicare limits, the sale plan, return lines, plan assumptions, the year-by-year plan, and spending.
   - `FIRE-ai-review.json`: every account, holding, lot, assumption, tax table and plan year.
4. Optional: tick **Keep FIRE-data/ai-review/ updated on each auto-save** so the files are always current (at most once a minute).
5. Ask your AI assistant to *"Read FIRE-data/ai-review/FIRE-ai-review.md and the JSON next to it, and follow the reviewer instructions at the top."* If it can't read your folder, attach the two files to a chat.

These files are **not encrypted**. Use a personal AI account for personal finances, and delete the files when you're done if you don't want a plain copy on disk.

---

## 7. Limitations

This is a planning tool, not tax, legal or investment advice. Check important decisions with a CPA or fee-only advisor.

### Taxes

- **Federal:** 2026 law (including the 2025 One Big Beautiful Bill Act), with tables projected forward by inflation. Checked against IRS examples; see `Validation-Report.md`.
- **Filing status:** married filing jointly or single. Head of household and married filing separately aren't modeled; single is the closest.
- **State accuracy:**
  - California is modeled in full: Prop 13, state disability insurance, the 2.5% early-withdrawal tax, the 1% surcharge over $1M, and 30/40/0/30 estimated payments.
  - No-income-tax states are exact.
  - About 25 states use their published 2025 brackets.
  - The rest are marked *approximate* in Settings: the top rate is applied to all taxable income. For a closer number, enter your effective rate (state tax ÷ federal AGI from last year's return).
  - Not modeled: city and county income taxes, state credits, and special state capital-gains rules. The exceptions are Washington's capital-gains tax and Massachusetts' surtax, which are included.
- **Not modeled:** tax credits (child, dependent care, foreign tax, energy), charitable deductions, self-employment tax, and the kiddie tax. The Alternative Minimum Tax (AMT) is included.
- **Tax-return import:** reads Form 1040 and California 540 only. Other states' returns can be entered by hand.

### Plan and projections

- Returns, inflation and spending are your assumptions. Monte Carlo resamples U.S. market history (1928–2025); the future can be worse.
- **ACA:** assumes the enhanced subsidies expired after 2025, so there's a cliff at 400% of the poverty line. Change this in Settings if Congress extends them.
- **Health insurance while working:** assumed to come through an employer (its cost belongs in spending); marketplace premiums start when everyone has stopped working.
- **Starter numbers:** a new data set starts with a typical U.S. couple around 40 (see First-time setup). They're placeholders, not advice.
- **Social Security** uses your benefit estimate and claiming age. Survivor benefits before the deceased's claiming age aren't modeled.
- **Direct indexing:** loss harvests are your assumption, not simulated lot by lot.
- **Long-term care:** defaults are California medians; set your own costs.
- **Estates:** only the federal exemption. State estate and inheritance taxes aren't modeled.

### Files and browsers

- Statement formats change. If an import looks wrong, edit the values or add the account by hand.
- Only the institutions listed above are recognized; others can be entered manually.
- Auto-save to a folder needs Chrome or Edge. Safari and Firefox work with Export and Load data file.
- Spending categories come from payee keywords. Change a category and that payee keeps it on future imports.

---

## Keep it free

Financial freedom shouldn't be locked behind a subscription. FIRE Command Center is free, has no ads, needs no account, and never sees your data. **Own your own data.**

If it's given you real value, a donation helps keep it free for everyone. Donate what you can, and only if it's useful to you:
**[Donate to keep it free](https://buy.stripe.com/28E8wP9OEbmqcME2aZeZ200)**

<p><img src="fire-app-src/src/brand/wordmark560.png" alt="Pay Forward Labs" width="200"></p>
