# FIRE Command Center: source

The app is a single HTML file built from these sources. No server. The only network calls are optional market-price lookups (your own published Google Sheet with GOOGLEFINANCE formulas, Cboe delayed quotes, gold-api.com, CoinGecko, Coinbase, Yahoo Finance, FinancialModelingPrep, Finnhub or Twelve Data), which send ticker symbols only. Turn them off in Settings → Market data.

## Build

```
cd fire-app-src
python3 build.py                 # writes ../FIRE-Command-Center.html with NO financial data
```

Options: `python3 build.py out.html --seed seed.json --pl projectionlab.csv` embeds starting data (don't do this for copies you sync to the cloud).

## Files

| File | What it does |
|---|---|
| `src/parsers.js` | Reads Fidelity CSV/PDF, Morgan Stanley stock-plan lots, Wealthfront, Vanguard and Vestwell statements |
| `src/engine.js` | Quarterly rules: buffer modes, ACA MAGI, liquidation plan, wash-sale and tax-loss checks, federal + CA tax |
| `src/hist.js` | 1928–2025 stock, bond, T-bill, real estate and gold returns (Damodaran/NYU Stern) and CPI (Minneapolis Fed) for Monte Carlo and backtests |
| `src/planner.js` | Lifetime simulation: Social Security, healthcare/ACA/IRMAA, rentals, RMDs, Roth strategies, estate |
| `src/app.js` | User interface, storage, encrypted export and auto-save |
| `src/shell.html` | Page layout and styles |
| `src/vendor/` | Mozilla pdf.js 3.11 (Apache-2.0) for reading PDFs offline |

## Where your data lives

- In the browser you open the HTML in (localStorage), per browser and per file location.
- **Encrypted auto-save** (Chrome/Edge): header → Auto-save → choose a file in your cloud folder. Every change is written there, encrypted with AES-256-GCM (PBKDF2-SHA256, 310k iterations) under your password.
- **Export (encrypted)** downloads a `.fire` backup; **Load data file** restores `.fire` or `.json`.
- There is no password recovery. Keep the password in your password manager.
