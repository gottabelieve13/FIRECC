/* ============================================================
   PARSERS — turn statements into normalized account objects.
   Works in browser and node. Each parser returns
   { kind, asOf, accounts:[Account], extras:{} }
   Account = { key, institution, name, taxType, asOf, holdings:[Holding], lots?:[Lot], note? }
   Holding = { symbol, desc, qty, price, value, cost, assetClass }
   ============================================================ */
(function (root) {
  const P = {};

  // ---------- helpers ----------
  const money = (s) => {
    if (s == null) return null;
    s = String(s).replace(/USD/g, '').replace(/\s+/g, '').replace(/[$,+]/g, '').replace(/^-\$/, '-');
    if (s === '' || s === '--' || s === '-' || /n\/?a/i.test(s)) return null;
    const neg = /^\(.*\)$/.test(s) || /^-/.test(s);
    const v = parseFloat(s.replace(/[()\-]/g, ''));
    return isNaN(v) ? null : (neg ? -v : v);
  };
  P.money = money;
  const isNum = (t) => /^-?\s?\$?-?[\d,]*\.?\d+$/.test(t.trim()) && /\d/.test(t);
  const MONTHS = { jan: 0, feb: 1, mar: 2, apr: 3, may: 4, jun: 5, jul: 6, aug: 7, sep: 8, oct: 9, nov: 10, dec: 11 };
  const iso = (y, m, d) => `${y}-${String(m + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
  P.dateFromText = (s) => {
    let m;
    if ((m = s.match(/(\d{1,2})-([A-Za-z]{3})-(\d{4})/))) return iso(+m[3], MONTHS[m[2].toLowerCase()], +m[1]);
    if ((m = s.match(/([A-Za-z]{3})[a-z]*\.?\s+(\d{1,2}),?\s+(\d{4})/))) return iso(+m[3], MONTHS[m[1].toLowerCase()], +m[2]);
    if ((m = s.match(/([A-Za-z]{3})-(\d{1,2})-(\d{4})/))) return iso(+m[3], MONTHS[m[1].toLowerCase()], +m[2]);
    if ((m = s.match(/(\d{1,2})\/(\d{1,2})\/(\d{4})/))) return iso(+m[3], +m[1] - 1, +m[2]);
    return null;
  };

  // Asset-class classifier (symbol first, then description keywords)
  const CLASS_BY_SYMBOL = {
    SPAXX: 'cash', FDRXX: 'cash', FZFXX: 'cash', TIMXX: 'cash', VMFXX: 'cash', SWVXX: 'cash',
    FXAIX: 'us_stock', FSKAX: 'us_stock', FSMAX: 'us_stock', SWSSX: 'us_stock', VTI: 'us_stock', IVV: 'us_stock',
    IJH: 'us_stock', IJR: 'us_stock', IUSG: 'us_stock', QUAL: 'us_stock', SPMD: 'us_stock', MGK: 'us_stock',
    VTV: 'us_stock', SCHD: 'us_stock', VIG: 'us_stock', VDE: 'us_stock', XLE: 'us_stock', VOO: 'us_stock',
    SWISX: 'intl_stock', FSPSX: 'intl_stock', VEA: 'intl_stock', VWO: 'intl_stock', IEMG: 'intl_stock', SCHF: 'intl_stock',
    EMXC: 'intl_stock', FPADX: 'intl_stock', VXUS: 'intl_stock',
    FXNAX: 'bond', BND: 'bond', IEI: 'bond', VGLT: 'bond', VCIT: 'bond', LQD: 'bond', SCHP: 'bond', AGG: 'bond',
    CMF: 'muni', MUB: 'muni', VTEB: 'muni',
    IOND: 'other',
    // crypto (spot ETFs / trusts) and gold & precious metals
    IBIT: 'crypto', FBTC: 'crypto', BITB: 'crypto', ARKB: 'crypto', GBTC: 'crypto', BTC: 'crypto', ETHA: 'crypto', FETH: 'crypto', ETHE: 'crypto', ETH: 'crypto', BITO: 'crypto',
    GLD: 'gold', IAU: 'gold', GLDM: 'gold', SGOL: 'gold', AAAU: 'gold', BAR: 'gold', PHYS: 'gold', SLV: 'gold', SIVR: 'gold', PSLV: 'gold', FGDL: 'gold',
  };
  P.classify = (symbol, desc) => {
    if (P.isConc && P.isConc(symbol)) return 'goog'; // your concentrated stock (Settings)
    const s = (symbol || '').toUpperCase().replace(/\*+/g, '');
    if (CLASS_BY_SYMBOL[s]) return CLASS_BY_SYMBOL[s];
    const d = (desc || '').toUpperCase();
    if (/BITCOIN|ETHEREUM|ETHER\b|CRYPTO|DIGITAL ASSET/.test(d)) return 'crypto';
    if (/GOLD|BULLION|PRECIOUS METAL|SILVER/.test(d)) return 'gold';
    if (/CHECKING|SAVINGS|CERTIFICATE OF DEPOSIT|\bCD\b|BANK/.test(d)) return 'bank';
    if (/MONEY MARKET|STABLE VALUE|CASH|SWEEP|CORE ACCOUNT/.test(d)) return 'cash';
    if (/TARGET RETIRE|TARGET DATE|LIFEPATH|FREEDOM 20/.test(d)) return 'balanced';
    if (/MUNI|MUN BD|TAX[- ]EXEMPT/.test(d)) return 'muni';
    if (/BOND|BD |BD\b|TREAS|TIPS|FIXED|INCOME|CORP/.test(d)) return 'bond';
    if (/INT'?L|INTERNATIONAL|DEVELOPED|EMERGING|EM MKTS|EMR|EX[- ]US|FTSE/.test(d)) return 'intl_stock';
    if (/INDEX|500|STOCK|EQUITY|ETF|GROWTH|VALUE|SMALL|MID|LARGE/.test(d)) return 'us_stock';
    return 'other';
  };
  const taxTypeFromName = (n) => {
    n = (n || '').toUpperCase();
    if (/ROTH/.test(n)) return 'roth';
    if (/HSA/.test(n)) return 'hsa';
    if (/529|SCHOLARSHARE|COLLEGE SAV/.test(n)) return 'edu';
    if (/IRA|401|403|ROLLOVER|SEP|PENSION/.test(n)) return 'pretax';
    return 'taxable';
  };
  const H = (symbol, desc, qty, price, value, cost) => ({
    symbol: (symbol || '').replace(/\*+/g, ''), desc: desc || '', qty: qty ?? null, price: price ?? null,
    value: value ?? 0, cost: cost ?? null, assetClass: P.classify(symbol, desc),
  });

  // ---------- PDF → lines (pdf.js text content, row reconstruction, handles landscape pages) ----------
  P.pdfToLines = async function (pdfjsLib, data) {
    const doc = await pdfjsLib.getDocument({ data, disableFontFace: true, isEvalSupported: false }).promise;
    const out = [];
    for (let p = 1; p <= doc.numPages; p++) {
      const page = await doc.getPage(p);
      const tc = await page.getTextContent();
      const rows = [];
      for (const it of tc.items) {
        if (!it.str || !it.str.trim()) continue;
        const t = it.transform; const rot = Math.abs(t[0]) < 0.01 && Math.abs(t[1]) > 0.01;
        const x = rot ? t[5] : t[4];
        const y = rot ? -t[4] : t[5];
        let r = rows.find((r) => Math.abs(r.y - y) < 2.5);
        if (!r) { r = { y, items: [] }; rows.push(r); }
        r.items.push({ x, s: it.str, w: it.width });
      }
      rows.sort((a, b) => b.y - a.y);
      for (const r of rows) {
        r.items.sort((a, b) => a.x - b.x);
        let line = '', lastEnd = null;
        for (const it of r.items) {
          if (lastEnd !== null) line += (it.x - lastEnd > 3) ? '  ' : (it.x - lastEnd > 0.5 ? ' ' : '');
          line += it.s; lastEnd = it.x + it.w;
        }
        out.push(line.replace(/\s+$/, ''));
      }
      out.push('--PAGE--');
    }
    return out;
  };

  // ---------- detection ----------
  P.detect = function (name, text) {
    const t = text.slice(0, 20000);
    if (/U\.S\. Individual Income Tax Return|Form\s*1040\b[\s\S]{0,400}Filing Status|California Resident Income Tax Return|Form\s*540\b[\s\S]{0,300}California/i.test(t) && !/Positions for|Account number,/.test(t)) return 'tax_return';
    if (/^﻿?Account number,Account name,Symbol/m.test(t)) return 'fidelity_csv';
    if (/Positions for (?:account|All-Accounts)/i.test(t) && /"Symbol","Description"/.test(t)) return 'schwab_csv';
    if (/Morgan Stanley at Work|Long Share Savings Plan|Summary of GOOGL? - NASDAQ/i.test(t)) return 'ms_lots';
    if (/Wealthfront Brokerage|Wealthfront:/i.test(t)) return 'wealthfront';
    if (/vestwell/i.test(t)) return 'vestwell';
    if (/vanguard\.com/i.test(t) && /401\(K\)|Source Activity/i.test(t)) return 'vanguard_401k';
    if (/INVESTMENT REPORT/.test(t) && /Fidelity/i.test(t)) return 'fidelity_stmt';
    if (P.isTxnCSV && P.isTxnCSV(t)) return 'txn_csv';
    return 'unknown';
  };

  // ---------- Fidelity positions CSV ----------
  function splitCSV(line) {
    const out = []; let cur = '', q = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (q) { if (c === '"' && line[i + 1] === '"') { cur += '"'; i++; } else if (c === '"') q = false; else cur += c; }
      else if (c === '"') q = true; else if (c === ',') { out.push(cur); cur = ''; } else cur += c;
    }
    out.push(cur); return out;
  }
  P.parseFidelityCSV = function (text) {
    const lines = text.replace(/^﻿/, '').split(/\r?\n/);
    const hdr = splitCSV(lines[0]).map((h) => h.trim());
    const ix = (n) => hdr.indexOf(n);
    const accts = {};
    let asOf = null;
    const dm = text.match(/Date downloaded\s+([A-Za-z]{3}-\d{1,2}-\d{4})/);
    if (dm) asOf = P.dateFromText(dm[1]);
    for (const ln of lines.slice(1)) {
      if (!ln.trim() || ln.startsWith('"')) continue;
      const f = splitCSV(ln);
      const acct = f[ix('Account number')], aname = f[ix('Account name')];
      if (!acct || !/\w/.test(acct)) continue;
      const sym = f[ix('Symbol')], desc = f[ix('Description')];
      const key = 'fidelity:' + acct;
      accts[key] = accts[key] || {
        key, institution: 'Fidelity', name: `Fidelity ${aname} (${acct.slice(-4)})`, taxType: taxTypeFromName(aname),
        asOf, holdings: [],
      };
      const h = H(sym, desc, money(f[ix('Quantity')]), money(f[ix('Last price')]), money(f[ix('Current value')]), money(f[ix('Cost basis total')]));
      if (/PENDING/i.test(sym)) continue;
      accts[key].holdings.push(h);
    }
    return { kind: 'fidelity_csv', asOf, accounts: Object.values(accts) };
  };

  // ---------- Schwab positions CSV (one or more "Positions for account …" sections) ----------
  P.parseSchwabCSV = function (text) {
    const lines = text.replace(/^﻿/, '').split(/\r?\n/);
    const accts = []; let cur = null, hdr = null, asOf = null;
    for (const ln of lines) {
      if (!ln.trim()) continue;
      const m = ln.match(/Positions for account\s+(.+?)\s+\.\.\.?(\w+)\s+as of.*?(\d{4})\/(\d{2})\/(\d{2})/i) || ln.match(/^"?([^".]+?)\s+\.\.\.?(\w+)"?\s*$/);
      if (m && !/^"?Symbol/.test(ln)) {
        if (m[3]) asOf = `${m[3]}-${m[4]}-${m[5]}`;
        const label = m[1].trim(), num = m[2];
        cur = { key: 'schwab:' + num, institution: 'Schwab', name: `Schwab ${label} (…${num})`, taxType: taxTypeFromName(label), asOf, holdings: [] };
        accts.push(cur); hdr = null; continue;
      }
      const f = splitCSV(ln).map((x) => x.trim());
      if (f[0] === 'Symbol') { hdr = f; continue; }
      if (!cur || !hdr) continue;
      const col = (re) => f[hdr.findIndex((h) => re.test(h))];
      const sym = f[0];
      if (/^(Positions|Account) Total/i.test(sym)) continue;
      if (/^Cash & Cash Investments/i.test(sym)) { const v = money(col(/^Mkt Val/)); if (v) cur.holdings.push({ symbol: 'CASH', desc: 'Cash & money market', qty: null, price: null, value: v, cost: v, assetClass: 'cash' }); continue; }
      const h = H(sym, col(/^Description/), money(col(/^Qty/)), money(col(/^Price$/)), money(col(/^Mkt Val/)), money(col(/^Cost Basis/)));
      const at = col(/^Asset Typ/) || '';
      if (/^Equity$/i.test(at) && !['goog', 'intl_stock', 'crypto', 'gold'].includes(h.assetClass)) h.assetClass = 'us_stock'; // single stocks ("CORP" in the name isn't a bond)
      else if (/Fixed Income|Bond/i.test(at) && h.assetClass === 'other') h.assetClass = 'bond';
      cur.holdings.push(h);
    }
    for (const a of accts) a.asOf = a.asOf || asOf;
    return { kind: 'schwab_csv', asOf, accounts: accts.filter((a) => a.holdings.length) };
  };

  // ---------- Tax returns: Form 1040 (+ Schedules 1, 2, D, E, Forms 8606/8801/8582/8960) and California 540 ----------
  // Reads only the summary lines the planner uses. SSNs, names and addresses are never kept.
  const TAXF = {
    fed: [['wages1a', '1a', /Total amount from Form\(s\) W-2, box 1/i], ['wages', '1z', /Add lines 1a through 1h/i], ['taxExemptInt', '2a', /Tax-exempt interest/i], ['taxableInt', '2b', /Taxable interest/i],
      ['qualDiv', '3a', /Qualified dividends/i], ['ordDiv', '3b', /Ordinary dividends/i], ['iraDist', '4b', /IRA distributions/i], ['pensions', '5b', /Pensions and annuities/i],
      ['ssGross', '6a', /Social security benefits/i], ['ssTaxable', '6b', null], ['capGain', '7', /Capital gain or \(loss\)/i], ['otherIncome', '8', /Additional income from Schedule 1/i],
      ['totalIncome', '9', /This is your total income/i], ['adjustments', '10', /Adjustments to income/i], ['agi', '11', /This is your adjusted gross income/i],
      ['deduction', '12', /Standard deduction or itemized deductions/i], ['qbi', '13', /Qualified business income deduction/i], ['taxableIncome', '15', /This is your taxable income/i],
      ['tax', '16', /^\s*16\b|\bTax \(see instructions\)/i], ['credits', '21', /Add lines 19 and 20/i], ['otherTaxes', '23', /Other taxes, including self-employment tax/i],
      ['totalTax', '24', /This is your total tax/i], ['withheld', '25d', /Add lines 25a through 25c/i], ['estPaid', '26', /estimated tax payments and amount applied/i],
      ['refund', '34', /amount you overpaid/i], ['owed', '37', /This is the amount you owe|Amount you owe/i]],
    sch2: [['amt', '1', /Alternative minimum tax/i], ['addlMedicare', '11', /Additional Medicare Tax/i], ['niit', '12', /Net investment income tax/i]],
    schD: [['stCarryIn', '6', /Short-term capital loss carryover/i], ['ltCarryIn', '14', /Long-term capital loss carryover/i], ['schDNet', '16', /Combine lines 7 and 15/i], ['schDLimited', '21', /smaller of|\(3,000\)/i]],
    schE: [['rentDepreciation', '18', /Depreciation expense or depletion/i], ['rentLossAllowed', '22', /Deductible rental real estate loss/i], ['rentNet', '26', /Total rental real estate and royalty income or \(loss\)/i]],
    f8606: [['iraBasis', '14', /total basis in traditional IRAs/i], ['rothBasis', '22', /basis in Roth IRA contributions/i]],
    f8801: [['amtCreditCF', '26', /Credit carryforward to/i]],
    f8582: [['passiveUnallowed', '', /unallowed loss|Unallowed losses/i]],
    f8960: [['niit8960', '17', /Net investment income tax for individuals/i]],
    ca: [['caAgi', '17', /California adjusted gross income/i], ['caDeduction', '18', /larger of your California itemized deductions|standard deduction/i], ['caTaxable', '19', /taxable income/i],
      ['caTax', '31', /^\s*31\b|\bTax\. Check the box/i], ['caMhst', '62', /Mental Health Services Tax/i], ['caTotalTax', '64', /total tax/i], ['caWithheld', '71', /California income tax withheld/i], ['caEstPaid', '72', /estimated tax and other payments/i]],
  };
  const AMT_RE = /\(?-?\$?(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d{2})?\)?\.?(?=\s|$)/g;
  P.parseTaxReturn = function (lines, loose = false) {
    const clean = (s) => String(s).replace(/\b\d{3}-\d{2}-\d{4}\b/g, '•••').replace(/\s+/g, ' ').trim().replace(/(\d{1,3}(?:,\d{3})+|\d{2,})\s*\.?\s+(\d{2})$/, '$1.$2');
    const out = { year: null, fields: {}, src: {}, forms: [] }; let ctx = loose ? 'fed' : 'pre'; let sawFed = false; // ignore cover pages, worksheets and summaries until the 1040 itself
    const esc = (c) => c.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    const codeAmt = (row, code) => { const re = new RegExp(`(?:^|\\s)${esc(code)}\\s+(\\(?-?\\$?(?:\\d{1,3}(?:,\\d{3})+|\\d+)(?:\\.\\d{2})?\\)?)\\.?(?=\\s|$)`, 'g'); let m, last = null; while ((m = re.exec(row))) last = m[1]; return last; };
    const take = (row, code, label) => {
      if (code) { const a = codeAmt(row, code); if (a != null) return P.money(a); }
      if (label && label.test(row)) { const ms = row.match(AMT_RE); if (ms && ms.length) { const v = P.money(ms[ms.length - 1].replace(/\.$/, '')); if (v != null && Math.abs(v) >= 1) return v; } }
      return null;
    };
    const qualifies = (row, code, label) => (label && label.test(row)) || (code && codeAmt(row, code) != null && (/[a-z]/.test(code) || new RegExp(`^${esc(code)}\\b`).test(row)));
    for (let i = 0; i < lines.length; i++) {
      const row = clean(lines[i]); if (!row) continue;
      if (/^SCHEDULE 2\b/.test(row) && /Additional Taxes/i.test(row + ' ' + (lines[i + 1] || ''))) ctx = 'sch2';
      else if (/^SCHEDULE D\b/.test(row) && /Capital Gains/i.test(row + ' ' + (lines[i + 1] || ''))) ctx = 'schD';
      else if (/^SCHEDULE E\b/.test(row)) ctx = 'schE';
      else if (/^SCHEDULE 1\b/.test(row) && /Additional Income/i.test(row + ' ' + (lines[i + 1] || ''))) ctx = 'sch1';
      else if (/^Form\s*8606\b/.test(row) && /Nondeductible IRAs/i.test(row + ' ' + (lines[i + 1] || ''))) ctx = 'f8606';
      else if (/^Form\s*8801\b/.test(row)) ctx = 'f8801';
      else if (/^Form\s*8582\b/.test(row)) ctx = 'f8582';
      else if (/^Form\s*8960\b/.test(row)) ctx = 'f8960';
      else if (/California Resident Income Tax Return|^(?:Form|FORM)\s*540\b(?!\s*(?:ES|V|2EZ|NR|X)\b)|^\s*540\s+20\d\d\s+Side\s+\d/i.test(row) && !/Schedule CA|540-?ES|voucher|estimated/i.test(row)) ctx = 'ca';
      else if (ctx === 'ca' && /^(Schedule\s+(CA|D|P|G|S|W)\b|FTB\s*\d{4}|Form\s*(?!540)\d{4}|California\s+(Capital|Adjustments|Alternative|Nonrefundable|Withholding))/i.test(row)) ctx = 'other';
      else if (/U\.S\. Individual Income Tax Return/i.test(row) && !/1040-?(ES|V|X)\b|estimated|voucher/i.test(row)) { ctx = 'fed'; sawFed = true; }
      else if (/^Form\s*1040\s*\(20\d\d\)\s*Page/i.test(row) && sawFed) ctx = 'fed';
      // any other form, schedule, worksheet or summary page: stop reading federal 1040 lines from it
      else if (/^(Form|FORM)\s*(\d{4}[A-Z-]*|W-2|1099|1098|1095)\b|^SCHEDULE\s+[A-Z0-9]+\b|^.{0,40}\b(Worksheet|Two-Year Comparison|Tax Summary|Tax History|Federal Information|Summary of)\b/i.test(row) && !/^Form\s*1040\s*\(20\d\d\)/i.test(row) && !/^(Form|FORM)\s*540\b/.test(row)) { if (['fed', 'pre'].includes(ctx) || ctx === 'other') ctx = 'other'; }
      if (!out.forms.includes(ctx)) out.forms.push(ctx);
      if (!out.year && (ctx === 'fed' || ctx === 'ca') && !/1040-?(ES|V)\b|estimated tax|voucher/i.test(row)) { const y = row.match(/(?:Form\s*1040|Income Tax Return|Form\s*540)[^0-9]{0,40}\b(20[2-3]\d)\b/i) || row.match(/\b(20[2-3]\d)\b.*(?:Income Tax Return)/i); if (y) out.year = +y[1]; }
      for (const [key, code, label] of TAXF[ctx] || []) {
        if (out.fields[key] != null || !qualifies(row, code, label)) continue;
        const v = take(row, code, label); if (v != null) { out.fields[key] = v; out.src[key] = row.slice(0, 120); }
      }
    }
    const f = out.fields;
    if (f.wages == null && f.wages1a != null) { f.wages = f.wages1a; out.src.wages = out.src.wages1a; } delete f.wages1a; delete out.src.wages1a;
    // no 1040 page header recognized: read federal lines anywhere (older behaviour)
    if (!sawFed && !loose && lines.some((l) => /Form\s*1040/i.test(l))) { const r2 = P.parseTaxReturn(lines, true); for (const [k2, v] of Object.entries(r2.taxReturn.fields)) if (f[k2] == null) { f[k2] = v; out.src[k2] = r2.taxReturn.src[k2]; } out.year = out.year || r2.taxReturn.year; }
    // Schedule D carryover out to next year: net loss beyond the amount deducted this year
    if (f.schDNet != null && f.schDNet < 0) f.capLossCarryOut = Math.max(0, -f.schDNet - Math.abs(f.schDLimited ?? 3000));
    return { kind: 'tax_return', asOf: out.year ? `${out.year}-12-31` : null, accounts: [], taxReturn: out };
  };

  // ---------- Fidelity monthly/quarterly statement PDF ----------
  P.parseFidelityStmt = function (lines) {
    let asOf = null;
    for (const l of lines) { const m = l.match(/([A-Z][a-z]+ \d{1,2}, \d{4})\s*-\s*([A-Z][a-z]+ \d{1,2}, \d{4})/); if (m) { asOf = P.dateFromText(m[2]); break; } }
    const accts = {}; let cur = null, inHold = false;
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i];
      let m = l.match(/Account #\s*([\d-]+)/);
      if (m) {
        const num = m[1]; const nxt = lines[i + 1] || '';
        const nm = (nxt.match(/(?:Account Summary|Holdings|Activity|Estimated Cash Flow.*?\))\s{2,}(.+)$/) || [])[1] || '';
        const key = 'fidelity:' + num;
        if (!accts[key]) accts[key] = { key, institution: 'Fidelity', name: `Fidelity ${nm.replace(/^[A-Z]+ [A-Z]+ - /i, '').trim() || num} (${num.slice(-4)})`, holder: (nm.match(/^([A-Z][A-Za-z]+ [A-Z][A-Za-z]+) - /) || [])[1] || null, taxType: taxTypeFromName(nm), asOf, holdings: [] };
        cur = accts[key];
        inHold = /^Holdings/.test(nxt);
        continue;
      }
      if (/^(Activity|Estimated Cash Flow|Account Summary|Additional Information)/.test(l)) inHold = false;
      if (/^Holdings/.test(l)) inHold = true;
      if (!cur || !inHold) continue;
      if (/^Total/.test(l)) continue;
      const toks = l.split(/\s{2,}/);
      if (toks.length < 4 || isNum(toks[0])) continue;
      const nums = toks.slice(1).filter(isNum);
      const qi = nums.findIndex((t) => /^\d[\d,]*\.\d{3}$/.test(t.trim()));
      if (qi < 0 || nums.length < qi + 3) continue;
      const qty = money(nums[qi]), price = money(nums[qi + 1]), value = money(nums[qi + 2]);
      const cost = nums.length >= qi + 6 ? money(nums[qi + 3]) : null;
      // ticker: same line or next few lines "(XXX)"
      let sym = null, desc = toks[0];
      for (let k = 0; k < 4 && !sym; k++) {
        const s = (lines[i + k] || '');
        if (k > 0 && /\s{2,}[\d,]+\.\d{3}\s{2,}/.test(s)) break;
        const mm = s.match(/\(([A-Z][A-Z0-9]{1,5})\)/);
        if (mm) sym = mm[1]; else if (k > 0 && !/^\s*[\d.]+%?\s*$/.test(s)) desc += ' ' + s.split(/\s{2,}/)[0];
      }
      cur.holdings.push(H(sym || desc.slice(0, 12), desc.replace(/\s+\(.*$/, '').trim(), qty, price, value, cost));
    }
    return { kind: 'fidelity_stmt', asOf, accounts: Object.values(accts).filter((a) => a.holdings.length) };
  };

  // ---------- Morgan Stanley at Work (GOOG/GOOGL lot detail) ----------
  P.parseMSLots = function (lines) {
    const text = lines.join('\n');
    const sym = ((text.match(/Summary of (GOOGL?)\s*-/) || [])[1]) || 'GOOG';
    const lots = []; let asOf = null, price = null; const divs = [];
    const re = /^(\d{1,2}-[A-Za-z]{3}-\d{4})\s+([\d,]+)\s+(Long|Short)\s+(\S+)\s*USD\s+(\S+)\s*USD\s+(\S+)\s*USD\s+([\d,.]+)\s+(\S+)\s*USD\s+(\S+)\s*USD/;
    for (const l of lines) {
      const s = l.trim();
      let m = s.match(re);
      if (m) {
        const date = P.dateFromText(m[1]);
        lots.push({ id: `${m[1]} #${m[2]}`, lot: m[2], date, term: m[3], shares: money(m[7]), cost: money(m[5]), costPerShare: money(m[6]), price: money(m[8]), value: money(m[9]), gain: money(m[4]) });
        price = money(m[8]);
        continue;
      }
      if ((m = s.match(/^(\d{1,2}-[A-Za-z]{3}-\d{4})\s+Closing\s+\S+ USD\s+([\d,.]+)\s+\$([\d,.]+) USD/))) { asOf = P.dateFromText(m[1]); price = money(m[3]); }
      if ((m = s.match(/^(\d{1,2}-[A-Za-z]{3}-\d{4})\s+Dividend\s+\w+\s+\$([\d,.]+) USD/))) divs.push({ date: P.dateFromText(m[1]), amount: money(m[2]) });
    }
    if (!asOf) { const m = text.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2}),/m); if (m) asOf = iso(2000 + +m[3], +m[1] - 1, +m[2]); }
    const shares = lots.reduce((a, l) => a + l.shares, 0);
    const value = lots.reduce((a, l) => a + l.value, 0), cost = lots.reduce((a, l) => a + l.cost, 0);
    const acct = {
      key: 'ms:' + sym, institution: 'Morgan Stanley at Work', name: `${sym} Long Share Account (Morgan Stanley)`, taxType: 'taxable', asOf,
      holdings: [{ symbol: sym, desc: sym + ' (stock plan)', qty: shares, price, value, cost, assetClass: 'goog' }],
      lots: lots.map((l) => ({ ...l, symbol: sym })),
      dividends: divs,
    };
    return { kind: 'ms_lots', asOf, accounts: [acct] };
  };

  // ---------- Wealthfront snapshot/statement ----------
  P.parseWealthfront = function (lines) {
    const text = lines.join('\n');
    let asOf = P.dateFromText((text.match(/Holdings as of ([A-Za-z]+ \d{1,2}, \d{4})/) || [])[1] || '') ||
      P.dateFromText((text.match(/Ending Balance[^\n]*/) || [''])[0]);
    if (!asOf) { const m = text.match(/([A-Za-z]+ \d{1,2}, \d{4})\s+Ending Balance/); if (m) asOf = P.dateFromText(m[1]); }
    const num = (text.match(/Wealthfront:\s*(\w+)/) || [])[1] || 'WF';
    const nm = (text.match(/\n((?:Trust |Joint |Individual |Roth |Traditional |SEP )?[\w ]*?(?:Wealthfront Portfolio|IRA|Investment Account))\s*\n/) || [])[1] || 'Wealthfront';
    const acct = { holder: /trust|joint/i.test(text.slice(0, 2000)) ? 'joint' : null, key: 'wealthfront:' + num, institution: 'Wealthfront', name: `${/wealthfront/i.test(nm) ? '' : 'Wealthfront '}${nm.trim()} (${num.slice(-4)})`, taxType: taxTypeFromName(nm), asOf, holdings: [] };
    const re = /^(.+?)\s{2,}([A-Z]{2,5})\s{2,}([\d,]*\.?\d+)\s{2,}\$([\d,]+\.\d+)\s{2,}\$([\d,]+\.\d{2})$/;
    for (const l of lines) {
      const m = l.trim().match(re);
      if (m && !/^Total/.test(m[1])) acct.holdings.push(H(m[2], m[1], money(m[3]), money(m[4]), money(m[5]), null));
    }
    const cm = text.match(/US Dollar\s+\$([\d,.]+)/);
    if (cm && money(cm[1]) > 0) acct.holdings.push(H('CASH', 'Cash', null, 1, money(cm[1]), null));
    return { kind: 'wealthfront', asOf, accounts: [acct] };
  };

  // ---------- Vanguard 401(k) quarterly ----------
  function splitByTax(base, total, rothAmt, holdings) {
    const out = [];
    const rothFrac = total > 0 ? rothAmt / total : 0;
    const mk = (suffix, taxType, frac) => ({
      ...base, key: base.key + ':' + taxType, name: `${base.name} — ${suffix}`, taxType,
      holdings: holdings.map((h) => ({ ...h, value: h.value * frac, qty: null, cost: null })),
    });
    if (rothFrac < 0.999) out.push(mk('Pre-tax', 'pretax', 1 - rothFrac));
    if (rothFrac > 0.001) out.push(mk('Roth', 'roth', rothFrac));
    return out;
  }
  P.parseVanguard401k = function (lines) {
    const text = lines.join('\n');
    const per = text.match(/ACCOUNT SUMMARY:\s*[\d/]+\s*-\s*([\d/]+)/);
    const asOf = per ? P.dateFromText(per[1]) : null;
    const plan = ((text.match(/\n([A-Z][A-Z .&]+ 401\(K\)[^\n–-]*)/) || [])[1] || 'Vanguard 401(k)').replace(/\s+/g, ' ').trim();
    const total = money((text.match(/Total Account Balance:\s*\$([\d,.]+)/) || [])[1]);
    const holdings = [];
    let mode = null, roth = 0, sourcesTotal = 0;
    for (let i = 0; i < lines.length; i++) {
      const l = lines[i].replace(/- \$/g, '-$');
      if (/Investment Activity/.test(l)) { mode = 'inv'; continue; }
      if (/Source Activity/.test(l)) { mode = 'src'; continue; }
      if (/^Total/.test(l.trim())) { if (mode) mode = mode === 'inv' ? null : mode; if (/Total Value/.test(l)) mode = null; continue; }
      const toks = l.split(/\s{2,}/);
      if (toks.length < 4 || isNum(toks[0])) continue;
      const nums = toks.slice(1).filter(isNum);
      if (mode === 'inv' && nums.length >= 5) {
        let name = toks[0];
        const nx = (lines[i + 1] || '').trim();
        if (nx && !/\$/.test(nx) && nx.split(/\s{2,}/).length === 1) name += ' ' + nx;
        holdings.push(H(null, name, null, null, money(nums[nums.length - 1]), null));
      } else if (mode === 'src' && nums.length >= 3) {
        const v = money(nums[nums.length - 1]); sourcesTotal += v;
        if (/roth/i.test(toks[0])) roth += v;
      }
    }
    holdings.forEach((h) => { h.symbol = h.desc.split(' ').slice(0, 3).join(' '); });
    const base = { key: 'vanguard401k:' + plan.slice(0, 20), institution: 'Vanguard', name: plan.replace(/SAVINGS PLAN/i, '').trim(), asOf, total, holder: (text.match(/^\s*([A-Z]+ (?:[A-Z] )?[A-Z]+)\s*$/m) || [])[1] || null };
    return { kind: 'vanguard_401k', asOf, accounts: splitByTax(base, sourcesTotal || total, roth, holdings), extras: { total, roth } };
  };

  // ---------- Vestwell 401(k) quarterly ----------
  P.parseVestwell = function (lines) {
    const text = lines.join('\n');
    const asOf = P.dateFromText((text.match(/As of ([A-Za-z]{3} \d{1,2}, \d{4})/) || [])[1] || '');
    const plan = ((text.match(/\n[A-Z][a-z]+ [A-Z][a-z]+\s{2,}(.+?401\(k\) Plan)/) || [])[1] || 'Vestwell 401(k)').trim();
    const holdings = []; let mode = null, roth = 0, total = 0, vested = 0, vestedRoth = 0;
    for (const raw of lines) {
      const l = raw.trim();
      if (/^FUNDING SOURCE/.test(l)) { mode = 'src'; continue; }
      if (/^Your Investments/.test(l)) { mode = 'inv'; continue; }
      if (/^For more information/.test(l)) { mode = null; continue; }
      const toks = l.split(/\s{2,}/);
      if (mode === 'src') {
        if (isNum(toks[0])) { total = money(toks[toks.length - 2]); vested = money(toks[toks.length - 1]); mode = null; continue; }
        const nums = toks.slice(1).filter(isNum);
        if (nums.length >= 5 && /roth/i.test(toks[0])) { roth += money(nums[nums.length - 2]); vestedRoth += money(nums[nums.length - 1]); }
      }
      if (mode === 'inv') {
        const m = l.match(/(?:^|\s{2,})([A-Z0-9]{3,9})\s{2,}(.+?)\s{2,}\$([\d,.]+)\s{2,}([\d.]+)%$/);
        if (m) holdings.push(H(/^\d/.test(m[1]) ? 'STABLE' : m[1], m[2], null, null, money(m[3]), null));
      }
    }
    // use vested balance (unvested match is forfeitable)
    const scale = total > 0 ? vested / total : 1;
    holdings.forEach((h) => (h.value *= scale));
    const base = { key: 'vestwell:' + plan.slice(0, 20), institution: 'Vestwell', name: plan, asOf, holder: (text.match(/\n([A-Z][a-z]+ [A-Z][a-z]+)\s{2,}\S.*401\(k\) Plan/) || [])[1] || null };
    return { kind: 'vestwell', asOf, accounts: splitByTax(base, vested, vestedRoth, holdings), extras: { total, vested, unvested: total - vested } };
  };

  // ---------- Bank / credit-card transaction exports (CSV) for the Spending tab ----------
  // Handles Chase, Amex, Capital One, Citi, Discover, Bank of America, Wells Fargo, Apple Card, Fidelity/Schwab cash
  // and most "Date, Description, Amount" or "Debit / Credit" layouts.
  P.SPEND_CATS = ['Groceries', 'Dining', 'Travel', 'Transportation', 'Utilities & phone', 'Insurance', 'Medical', 'Kids & education', 'Shopping', 'Entertainment', 'Subscriptions', 'Home & garden', 'Personal care', 'Gifts & charity', 'Fees & interest', 'Housing (mortgage, rent, HOA)', 'Property tax', 'Income tax', 'Other'];
  const CAT_RULES = [
    ['Groceries', /SAFEWAY|WHOLE ?FOODS|WHOLEFDS|TRADER JOE|COSTCO WHSE|COSTCO(?! GAS)|SPROUTS|INSTACART|RALEYS|LUCKY|NIJIYA|99 RANCH|H MART|MOLLIE STONE|BERKELEY BOWL|DRAEGER|ANDRONICO|GROCERY|MARKET\b|FOOD MAXX|SMART ?& ?FINAL|AMAZON FRESH/i],
    ['Dining', /RESTAURANT|DOORDASH|UBER ?EATS|GRUBHUB|CAVIAR|STARBUCKS|PEET|PHILZ|BLUE BOTTLE|CAFE|COFFEE|PIZZA|SUSHI|RAMEN|TAQUERIA|BURGER|CHIPOTLE|MCDONALD|SWEETGREEN|BAKERY|BAR & GRILL|KITCHEN|BISTRO|TST\*|SQ \*.*(CAFE|COFFEE|DELI)/i],
    ['Travel', /AIRLINE|UNITED\s?AIR|UNITED \d|DELTA AIR|ALASKA AIR|SOUTHWEST|JETBLUE|AMERICAN AIR|HAWAIIAN|HOTEL|MARRIOTT|HILTON|HYATT|IHG|FOUR SEASONS|AIRBNB|VRBO|EXPEDIA|BOOKING\.COM|HERTZ|AVIS|ENTERPRISE RENT|NATIONAL CAR|TSA PRE|CLEAR \*|GLOBAL ENTRY|AMTRAK/i],
    ['Transportation', /\bSHELL\b|CHEVRON|\b76\b|ARCO|EXXON|VALERO|COSTCO GAS|\bUBER\b(?! ?EATS)|LYFT|SUPERCHARG|TESLA|EV ?CHARG|CHARGEPOINT|PARKING|FASTRAK|BAY AREA FASTRAK|CALTRAIN|BART|CLIPPER|DMV|AUTO REPAIR|JIFFY|TIRE|CAR WASH/i],
    ['Utilities & phone', /PG&E|PGE\b|PGANDE|\bATT\b(?! ?&)|PACIFIC GAS|COMCAST|XFINITY|AT&T|ATT\*|VERIZON|T-MOBILE|TMOBILE|WATER|SEWER|RECOLOGY|WASTE|SONIC\.NET|INTERNET|CAL WATER|SFPUC|ELECTRIC/i],
    ['Insurance', /CALIFORNIA FAIR|FAIR PLAN|INS PREM|GEICO|STATE FARM|ALLSTATE|PROGRESSIVE|USAA|LIBERTY MUTUAL|FARMERS INS|INSURANCE|\bINS PREM|CHUBB|PURE INS|LEMONADE|NORTHWESTERN MUT|TRANSAMERICA/i],
    ['Medical', /PHARMACY|\bCVS\b|WALGREENS|RITE AID|KAISER|SUTTER|STANFORD HEALTH|UCSF|ONE MEDICAL|DENTAL|\bDDS\b|ORTHODONT|OPTOM|VISION|MEDICAL|CLINIC|HOSPITAL|LABCORP|QUEST DIAG|PHYSICAL THERAP|DERMATOLOG|PEDIATRIC/i],
    ['Kids & education', /SCHOOL|TUITION|DAYCARE|PRESCHOOL|\bCAMP\b|KUMON|MATHNASIUM|TUTOR|COLLEGE|UNIVERSITY|SCHOLASTIC|LESSON|ACADEMY|BABYSIT|NANNY|CHILDCARE|BRGHTWHL|BRIGHTWHEEL|CARE\.COM/i],
    ['Subscriptions', /NETFLIX|SPOTIFY|HULU|DISNEY\+|DISNEYPLUS|HBO|MAX\.COM|YOUTUBE PREM|APPLE\.COM\/BILL|ITUNES|AUDIBLE|KINDLE|NYTIMES|WSJ|PATREON|ICLOUD|GOOGLE \*(STORAGE|ONE)|PRIME VIDEO|AMAZON PRIME|PELOTON|CHATGPT|OPENAI|ANTHROPIC|DROPBOX|ADOBE|MICROSOFT/i],
    ['Entertainment', /TICKETMASTER|STUBHUB|LIVE NATION|\bAMC\b|CINEMA|THEATER|THEATRE|MUSEUM|STEAM GAMES|NINTENDO|PLAYSTATION|XBOX|BOWLING|GOLF|SKI|DISNEYLAND|SIX FLAGS|ZOO|CONCERT/i],
    ['Home & garden', /HOME DEPOT|LOWE'?S|ACE HARDWARE|ORCHARD SUPPLY|IKEA|WAYFAIR|CRATE|POTTERY BARN|WILLIAMS.SONOMA|RH\b|RESTORATION HARD|BED BATH|CONTAINER STORE|GARDEN|NURSERY|PLUMB|ELECTRICIAN|HANDYMAN|LANDSCAP|LAWN|GARDENER|POOL SERV|PEST|CLEANING|HOUSEKEEP|THUMBTACK|ANGI\b|TASKRABBIT|PG ?HOME/i],
    ['Personal care', /SALON|\bSPA\b|BARBER|HAIR|NAIL|MASSAGE|GYM|FITNESS|EQUINOX|24 HOUR|ORANGETHEORY|YOGA|PILATES|SEPHORA|ULTA|DRY ?CLEAN|LAUNDRY/i],
    ['Gifts & charity', /DONATION|CHARITY|GOFUNDME|RED CROSS|UNICEF|FOUNDATION|\bCHURCH\b|TEMPLE|FIDELITY CHARITABLE|SCHWAB CHARITABLE|DAF|NONPROFIT|1-800-FLOWERS|FTD|GIFT/i],
    ['Fees & interest', /\bFEE\b|INTEREST CHARGE|FINANCE CHARGE|LATE FEE|ANNUAL FEE|FOREIGN TRANSACTION|OVERDRAFT|ATM (FEE|WITHDRAWAL FEE)/i],
    ['Housing (mortgage, rent, HOA)', /MORTGAGE|\bMTG\b|HOME LOAN|MTG PMT|LOAN SERVIC|MR\.? ?COOPER|ROCKET MORT|ROCKET LOAN|LOANCARE|WELLS FARGO HOME|CHASE MORTGAGE|\bHOA\b|HOMEOWNERS ASSOC|\bRENT\b|PROPERTY MGMT|ESCROW/i],
    ['Property tax', /TAX COLLECTOR|PROPERTY TAX|COUNTY.{0,20}\bTAX\b|TREASURER.*TAX|SECURED TAX|COUNTY OF .*TAX|SMC TAX/i],
    ['Income tax', /IRS\b|USATAXPYMT|US TREASURY.*TAX|FRANCHISE TAX|FTB\b|CA FTB|EFTPS|STATE OF CALIF.*TAX|TAX PAYMENT/i],
    ['Shopping', /AMAZON|AMZN|TARGET|WALMART|BEST BUY|APPLE STORE|APPLE\.COM(?!\/BILL)|NORDSTROM|MACY|BLOOMINGDALE|NIKE|LULULEMON|UNIQLO|ZARA|GAP\b|OLD NAVY|REI\b|ETSY|EBAY|SHOPIFY|COSTCO\.COM|TJ ?MAXX|MARSHALLS|ROSS|DICK'?S/i],
  ];
  const BANK_CAT = [ // categories some issuers include in the export
    [/^(food & drink|restaurants?|dining)/i, 'Dining'], [/^(groceries|grocery|supermarkets)/i, 'Groceries'], [/^(travel|airlines?|lodging|hotels?|car rental)/i, 'Travel'],
    [/^(gas|automotive|gas\/automotive|transportation|parking|tolls)/i, 'Transportation'], [/^(bills & utilities|utilities|phone)/i, 'Utilities & phone'], [/^(health|health & wellness|medical|pharmacy)/i, 'Medical'],
    [/^(education)/i, 'Kids & education'], [/^(entertainment)/i, 'Entertainment'], [/^(shopping|merchandise|department stores)/i, 'Shopping'], [/^(home|home improvement)/i, 'Home & garden'],
    [/^(personal|personal care)/i, 'Personal care'], [/^(gifts & donations|charity|donations)/i, 'Gifts & charity'], [/^(fees & adjustments|fees|interest)/i, 'Fees & interest'], [/^(insurance)/i, 'Insurance']];
  P.payeeOf = (desc) => String(desc || '').replace(/^(PREAUTHORIZED WITHDRAWAL TO|ELECTRONIC PAYMENT TO|WITHDRAWAL (FROM|TO)|DEPOSIT FROM|PAPER PAYMENT TO|BILL PAYMENT TO|ZELLE MONEY (SENT TO|RECEIVED FROM)|INSTANT TRANSFER RECEIVED FROM|DEBIT CARD PURCHASE|POS PURCHASE|PURCHASE AUTHORIZED ON \S+)\s*/i, '');
  P.categorize = (desc, bankCat) => {
    desc = P.payeeOf(desc) || desc;
    for (const [c, re] of CAT_RULES) if (re.test(desc)) return c;
    if (bankCat) for (const [re, c] of BANK_CAT) if (re.test(bankCat.trim())) return c;
    return 'Other';
  };
  // money moving between your own accounts — never spending
  const CARD_PAYMENT_OUT = /(CREDIT ?CA?R?D|CRCARDPMT|CARD ?SERVICES|CARDMEMBER|AUTOPAY|E-?PAYMENT|EPAYMENT|ONLINE PAYMENT|PAYMENT TO|PMT\b|BILL ?PAY).*(CHASE|AMEX|AMERICAN EXPRESS|CITI|DISCOVER|CAPITAL ONE|BARCLAY|BANK OF AMERICA|BOFA|WELLS|APPLE ?CARD|GSBANK|GOLDMAN|US BANK|SYNCHRONY|FIDELITY|CARD)|(CHASE|AMEX|AMERICAN EXPRESS|CITI|DISCOVER|CAPITAL ONE|BARCLAY|APPLECARD|APPLE CARD|GSBANK).*(PAYMENT|AUTOPAY|PMT|EPAY)/i;
  const CARD_PAYMENT_IN = /PAYMENT ?(-|–)? ?THANK YOU|AUTOPAY PAYMENT|AUTOMATIC PAYMENT|ONLINE PAYMENT|MOBILE PAYMENT|PAYMENT RECEIVED|INTERNET PAYMENT|ACH PAYMENT|^PAYMENT$|DIRECTPAY|E-PAYMENT/i;
  const INTERNAL = /TRANSFER (TO|FROM)|PERFORMANCE SAVINGS|360 SAVINGS|TO .{0,40}SAVINGS ACCOUNT|HOLDINGS .{0,10}L\.?P\.?|(WITHDRAWAL|XFER|TRANSFER|DEPOSIT) (TO|FROM) (SAVINGS|CHECKING|MONEY MARKET)|ONLINE TRANSFER|XFER|INTERNAL TRANSFER|FUNDS TRANSFER|SAVINGS TRANSFER|MONEYLINE|FID BKG SVC|FIDELITY (BROKERAGE|INVESTMENTS)|SCHWAB BROKERAGE|VANGUARD (BUY|INVESTMENT)|WEALTHFRONT|BETTERMENT|ROBINHOOD|COINBASE|E\*?TRADE|MORGAN STANLEY|TREASURYDIRECT|529|SCHOLARSHARE|BROKERAGE|ACH (TO|FROM) .*(SAVINGS|CHECKING)|ZELLE.*(SELF|OWN)/i;
  const INCOME = /PAYROLL|DIRECT DEP|DIR DEP|SALARY|ADP|GUSTO|DIVIDEND|INTEREST (PAYMENT|PAID)|IRS TREAS 310|TAX REFUND|SSA TREAS|SOC SEC|AIRBNB PAYMENTS|VRBO PAYOUT|RENT (RECEIVED|DEPOSIT)|VENMO CASHOUT/i;
  function splitRow(line) { const out = []; let cur = '', q = false; for (let i = 0; i < line.length; i++) { const ch = line[i]; if (ch === '"') { if (q && line[i + 1] === '"') { cur += '"'; i++; } else q = !q; } else if (ch === ',' && !q) { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out.map((x) => x.trim()); }
  const toDate = (s) => {
    s = String(s || '').trim(); let m;
    if ((m = s.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/))) return `${m[1]}-${m[2].padStart(2, '0')}-${m[3].padStart(2, '0')}`;
    if ((m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{2,4})/))) { const y = m[3].length === 2 ? '20' + m[3] : m[3]; return `${y}-${m[1].padStart(2, '0')}-${m[2].padStart(2, '0')}`; }
    if ((m = s.match(/^(\d{4})(\d{2})(\d{2})$/))) return `${m[1]}-${m[2]}-${m[3]}`;
    if ((m = s.match(/^(\d{1,2})[ -]([A-Za-z]{3})[ -](\d{2,4})/))) { const mo = 'janfebmaraprmayjunjulaugsepoctnovdec'.indexOf(m[2].toLowerCase()) / 3 + 1; const y = m[3].length === 2 ? '20' + m[3] : m[3]; if (mo > 0) return `${y}-${String(mo).padStart(2, '0')}-${m[1].padStart(2, '0')}`; }
    if ((m = s.match(/^([A-Za-z]{3})[ -](\d{1,2}),?[ -](\d{4})/))) { const mo = 'janfebmaraprmayjunjulaugsepoctnovdec'.indexOf(m[1].toLowerCase()) / 3 + 1; if (mo > 0) return `${m[3]}-${String(mo).padStart(2, '0')}-${m[2].padStart(2, '0')}`; }
    return null;
  };
  // what a row is, given the account type. Credit cards: every charge is spending; only "payment received" lines are excluded.
  // Bank accounts: payments to credit cards and transfers to your own accounts are excluded; everything else going out is spending.
  P.classifyTxn = (desc, out, isCard, type = '', bankCat = '') => {
    let kind;
    if (isCard) kind = out ? 'spend' : (CARD_PAYMENT_IN.test(desc) || /payment/i.test(type) ? 'transfer' : 'refund');
    else if (out) kind = CARD_PAYMENT_OUT.test(desc) ? 'cardpay' : INTERNAL.test(desc) ? 'transfer' : 'spend';
    else kind = CARD_PAYMENT_IN.test(desc) || INTERNAL.test(desc) ? 'transfer' : 'income';
    return { kind, category: kind === 'spend' || kind === 'refund' ? P.categorize(desc, bankCat) : null };
  };
  // how money left a bank account
  P.payMethod = (desc, kind) => {
    const d = String(desc || '');
    if (kind === 'cardpay') return 'Credit-card payment'; if (kind === 'transfer') return 'Transfer to own account';
    if (/^CHECK\b|\bCHECK ?#|\bCHK\b|CHECK PAID|^CHECK \d|PAPER PAYMENT/i.test(d)) return 'Check';
    if (/\bATM\b|CASH WITHDRAWAL|WITHDRAWAL AT/i.test(d)) return 'Cash / ATM';
    if (/ZELLE|VENMO|PAYPAL|CASH APP|SQUARE CASH|APPLE CASH/i.test(d)) return 'Zelle / Venmo / PayPal';
    if (/WIRE/i.test(d)) return 'Wire';
    if (/\bPOS\b|DEBIT CARD|CHECKCARD|CHECK CARD|PURCHASE AUTHORIZED|DBT CRD|VISA DEBIT/i.test(d)) return 'Debit-card purchase';
    if (/ACH|AUTOPAY|AUTO PAY|DES:|PPD|\bWEB\b|BILL ?PAY|ONLINE PMT|PMT|PAYMENT|E-?PAY|DIRECT DEBIT|RECURRING/i.test(d)) return 'Direct payment (ACH / bill pay)';
    return 'Other';
  };
  // bank wording votes on which sign is money out (+1 / -1), 0 = can't tell
  const OUT_WORDS = /^(WITHDRAWAL|DEBIT|CHECK\s*#?\s*\d+(?! DEPOSIT)|CHECK (PAID|CASHED)|PURCHASE|POS\b|ATM|PAYMENT TO|ACH DEBIT|BILL ?PAY|ZELLE (PAYMENT )?TO|SENT|FEE)/i;
  const IN_WORDS = /^(DEPOSIT|CREDIT|ACH CREDIT|INTEREST|DIRECT DEP|PAYROLL|ZELLE (MONEY )?(RECEIVED|FROM)|INSTANT TRANSFER RECEIVED|TRANSFER FROM|REFUND|MOBILE DEPOSIT|CHECK DEPOSIT)|CHECK DEPOSIT|RECEIVED FROM/i;
  P.outSignVote = (rows) => { let v = 0; for (const r of rows) { const d = String(r.desc || '').trim(); if (IN_WORDS.test(d)) v -= Math.sign(r.amt); else if (OUT_WORDS.test(d)) v += Math.sign(r.amt); } return Math.abs(v) >= 3 ? Math.sign(v) : 0; };
  P.isCardPaymentOut = (desc) => CARD_PAYMENT_OUT.test(desc || '');
  P.isTxnCSV = (text) => { const head = text.replace(/^﻿/, '').split(/\r?\n/).slice(0, 8).join('\n'); return /date/i.test(head) && /(description|merchant|payee|details|name|memo|action)/i.test(head) && /(amount|debit|credit|withdrawal|deposit)/i.test(head) && !/Positions for|Account number,Account name,Symbol|Cost Basis Total/i.test(head); };
  P.parseTxnCSV = (text, fname = '') => {
    const lines = text.replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim());
    let hi = lines.findIndex((l) => /date/i.test(l) && /(amount|debit|credit|withdrawal|deposit)/i.test(l) && splitRow(l).length >= 3); let hdr;
    if (hi < 0) { // Wells Fargo style: no header — "date","amount","*","","description"
      if (lines.length && /^"?\d{1,2}\/\d{1,2}\/\d{4}"?,"?-?[\d.]+"?/.test(lines[0])) { hdr = ['Date', 'Amount', 'x', 'y', 'Description']; hi = -1; } else throw new Error('No Date / Amount columns found');
    } else hdr = splitRow(lines[hi]);
    const H = hdr.map((h) => h.toLowerCase());
    const col = (...res) => { for (const re of res) { const i = H.findIndex((h) => re.test(h)); if (i >= 0) return i; } return -1; };
    const iDate = col(/^transaction date$/, /^trans\.? date$/, /^date$/, /posting date|post date|posted date/, /date/);
    const iDesc = col(/^description$/, /^transaction description$/, /^merchant$/, /^payee$/, /^name$/, /^action$/, /description|merchant|payee|details$/, /memo/);
    const iAmt = col(/^amount/, /transaction amount/, /amount/); const iDeb = col(/^debit/, /withdrawal/), iCred = col(/^credit(?! card)/, /deposit/);
    const iCat = col(/^category$/, /category/); const iType = col(/^type$/, /transaction type/);
    const isCard = /card|amex|visa|mastercard|discover|sapphire|freedom|venture|apple/i.test(fname) || H.some((h) => /card no|card member|cardholder|purchased by/.test(h)) || (iType >= 0 && lines.slice(hi + 1, hi + 40).some((l) => /\b(Sale|Purchase|Payment)\b/i.test(splitRow(l)[iType] || '')));
    const raw = []; const skipped = []; let typeSigned = false;
    for (const l of lines.slice(hi + 1)) {
      let f = splitRow(l);
      // unquoted commas inside the description push the other columns right: fold them back if that makes the amount readable
      if (hi >= 0 && iDesc >= 0 && f.length > hdr.length) { const ai = iAmt >= 0 ? iAmt : iDeb; if (ai > iDesc && P.money(f[ai]) == null) for (let ex = 1; ex <= Math.min(4, f.length - hdr.length); ex++) if (P.money(f[ai + ex]) != null) { f = [...f.slice(0, iDesc), f.slice(iDesc, iDesc + ex + 1).join(','), ...f.slice(iDesc + ex + 1)]; break; } }
      const date = toDate(f[iDate]); if (!date) { if (f.some((x) => /\d/.test(x))) skipped.push(l.slice(0, 90)); continue; }
      let amt; if (iAmt >= 0 && f[iAmt] !== '' && f[iAmt] != null) amt = P.money(f[iAmt]); else { const d = P.money(f[iDeb]) || 0, c = P.money(f[iCred]) || 0; amt = d ? -Math.abs(d) : Math.abs(c); }
      // banks that export unsigned amounts with a Debit/Credit type column
      if (amt != null && iType >= 0 && iAmt >= 0) { const ty = String(f[iType] || ''); if (/^\s*(debit|withdrawal|check|fee|atm|pos)\b|debit$/i.test(ty) && !/credit/i.test(ty)) { amt = -Math.abs(amt); typeSigned = true; } else if (/^\s*(credit|deposit)\b|credit$/i.test(ty)) { typeSigned = true; /* a negative credit is a reversal: money out */ } }
      if (amt == null || amt === 0) { if (amt == null) skipped.push(l.slice(0, 90)); continue; }
      raw.push({ date, desc: (f[iDesc] || '').replace(/\s+/g, ' ').trim(), amt, bankCat: iCat >= 0 ? f[iCat] : '', type: iType >= 0 ? f[iType] : '' });
    }
    // which sign is money going out? purchases outnumber payments/deposits, and payment rows say so
    // which sign means money out? A Debit/Credit column or separate debit/credit columns settle it.
    // Cards: "payment received" lines are money in. Banks: wording like "Withdrawal…", "Check…", "Deposit…" votes.
    let outSign;
    if (typeSigned || (iDeb >= 0 && iAmt < 0)) outSign = -1;
    else if (isCard) { const payLike = raw.filter((r) => CARD_PAYMENT_IN.test(r.desc) || /payment/i.test(r.type)); if (payLike.length) outSign = -Math.sign(payLike.reduce((a, r) => a + Math.sign(r.amt), 0) || 1); else { const neg = raw.filter((r) => r.amt < 0).length; outSign = neg >= raw.length / 2 ? -1 : 1; } }
    else { const v = P.outSignVote(raw.map((r) => ({ desc: r.desc, amt: r.amt }))); outSign = v || (raw.filter((r) => r.amt < 0).length >= raw.length / 2 ? -1 : 1); }
    const txns = raw.map((r) => { const out = r.amt * outSign > 0; const amount = Math.abs(r.amt); const c = P.classifyTxn(r.desc, out, isCard, r.type, r.bankCat); return { date: r.date, desc: r.desc, amount: out ? amount : -amount, ...c, bankCat: r.bankCat || undefined }; });
    return { kind: 'txn_csv', isCard, outSign, txns, skipped, from: txns.length ? txns.map((t) => t.date).sort()[0] : null, to: txns.length ? txns.map((t) => t.date).sort().pop() : null };
  };

  // ---------- dispatcher ----------
  P.parseText = function (kind, textOrLines) {
    const lines = Array.isArray(textOrLines) ? textOrLines : textOrLines.split(/\r?\n/);
    switch (kind) {
      case 'fidelity_csv': return P.parseFidelityCSV(Array.isArray(textOrLines) ? textOrLines.join('\n') : textOrLines);
      case 'fidelity_stmt': return P.parseFidelityStmt(lines);
      case 'tax_return': return P.parseTaxReturn(lines);
      case 'txn_csv': return P.parseTxnCSV(Array.isArray(textOrLines) ? textOrLines.join('\n') : textOrLines);
      case 'schwab_csv': return P.parseSchwabCSV(Array.isArray(textOrLines) ? textOrLines.join('\n') : textOrLines);
      case 'ms_lots': return P.parseMSLots(lines);
      case 'wealthfront': return P.parseWealthfront(lines);
      case 'vanguard_401k': return P.parseVanguard401k(lines);
      case 'vestwell': return P.parseVestwell(lines);
      default: return { kind: 'unknown', accounts: [] };
    }
  };

  root.FireParsers = P;
  if (typeof module !== 'undefined') module.exports = P;
})(typeof window !== 'undefined' ? window : globalThis);
