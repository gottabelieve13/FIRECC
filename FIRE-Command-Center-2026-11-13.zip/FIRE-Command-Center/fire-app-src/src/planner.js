/* ============================================================
   PLANNER — ProjectionLab-style lifetime simulation.
   Yearly loop in nominal dollars; reports real (today's $) too.
   Features: spending schedule + guardrails, income streams, one-time events,
   Social Security, RMDs, Roth conversions (bracket / MAGI / fixed), federal+CA tax,
   NIIT, early-withdrawal penalty, ACA premium credit, IRMAA, property & debts,
   deterministic, Monte Carlo (block bootstrap of 1928-2025), historical backtest,
   max sustainable spending, scenario compare.
   ============================================================ */
(function (root) {
  const E = root.FireEngine, HIST = root.FireHist;
  const L = {};
  const sum = (a, f = (x) => x) => a.reduce((s, x) => s + (f(x) || 0), 0);

  L.newPlan = (settings, name = 'Base plan') => ({
    id: 'p' + Date.now() + Math.floor(Math.random() * 1000), name,
    endAge: settings.projection?.endAge ?? 95,
    inflation: 2.5,
    spending: { base: settings.spending.annual, source: 'flat', schedule: [], guardrails: { enabled: false, upper: 20, lower: 20, adjust: 10 } },
    expenses: [], // {name, amount, startAge, endAge, real:true}
    incomes: [], // {name, amount, startAge, endAge, real:true, taxable:'ordinary'|'none'}
    events: [], // {name, year, amount (+in / -out), taxable:'none'|'ordinary'|'ltcg', basis}
    ss: { selfAge: settings.projection?.ssSelfAge ?? 70, selfAmt: settings.projection?.ssSelfAnnual ?? 0, spouseAge: settings.projection?.ssSpouseAge ?? 67, spouseAmt: settings.projection?.ssSpouseAnnual ?? 0 },
    healthcare: { model: false, acaBenchmark: 30000, medicarePerPerson: 3000 },
    roth: { strategy: 'none', bracketTop: 0.12, magiTarget: 0, fixed: 50000, startAge: 0, endAge: 74 },
    order: 'taxable-pretax-roth',
    allocation: { mode: 'current', stockNow: 70, stockEnd: 50, glideEndAge: 75, alt: 0, intlShare: 30 },
    returns: { stock: 5.0, bond: 2.0, cash: 0.5, bank: -1.5, gold: 1.0, crypto: 5.0, cryptoVol: 60, re: 1.0, googExtraVol: 25 },
    sim: { runs: 1000, block: 5, seed: 7 },
    pl: null, // ProjectionLab comparison data
    people: { retireAgeSelf: null, retireAgeSpouse: null }, // null = already retired
    work: [], // {who:'self'|'spouse', name, salary, growth, pretax401k, match, rothContrib, startAge, endAge}
    reSale: {}, // per-plan overrides for current properties: {[id]: {sellYear, costsInSpending}}
    purchases: [], // future property purchases
  });
  const _newPlan = L.newPlan; L.newPlan = (settings, name) => L.normalizePlan(_newPlan(settings, name), settings);
  // monthly mortgage payment
  L.pmt = (bal, ratePct, years) => { const r = (+ratePct || 0) / 1200, n = Math.max(1, (+years || 30) * 12); return !bal ? 0 : r ? bal * r / (1 - Math.pow(1 + r, -n)) : bal / n; };

  // ---------- starting balances from the current snapshot ----------
  L.initFromSnapshot = (snap, settings, an) => {
    const accts = E.allAccounts(snap);
    const z = () => ({ stock: 0, bond: 0, cash: 0, bank: 0, gold: 0, crypto: 0, goog: 0 });
    const mix = { taxable: z(), pretax: z(), roth: z() };
    const add = (b, cls, v) => {
      if (cls === 'balanced') { mix[b].stock += v * 0.8; mix[b].bond += v * 0.2; return; }
      const k = ['goog', 'cash', 'bank', 'gold', 'crypto'].includes(cls) ? cls : /stock|other|real_estate|private/.test(cls) ? 'stock' : 'bond';
      mix[b][k] += v;
    };
    let property = 0, debt = 0, cardDebt = 0;
    let pretaxP = 0, rothP = 0, edu = 0;
    for (const a of accts) for (const h of a.holdings) {
      if (/^(re|mtg):/.test(a.key)) continue; // structured real estate handled separately
      if (a.owner === 'spouse' && a.taxType === 'pretax') pretaxP += h.value;
      if (a.owner === 'spouse' && (a.taxType === 'roth' || a.taxType === 'hsa')) rothP += h.value;
      if (a.taxType === 'property') { property += h.value; continue; }
      if (a.taxType === 'liability') { if (a.debtKind === 'card') cardDebt += Math.abs(h.value); else debt += Math.abs(h.value); continue; }
      if (a.taxType === 'edu') { edu += h.value; continue; } // 529: separate, tax-free for qualified education
      const b = a.taxType === 'taxable' ? 'taxable' : a.taxType === 'pretax' ? 'pretax' : 'roth';
      add(b, h.assetClass, h.value);
    }
    const tot = (b) => sum(Object.values(mix[b]));
    const w = {}; for (const b of Object.keys(mix)) { const t = tot(b) || 1; w[b] = Object.fromEntries(Object.entries(mix[b]).map(([k, v]) => [k, v / t])); }
    // taxable chunks grouped by gain ratio (≈ Specific-ID lots), at most ~16 chunks
    const { out, excluded } = E.saleCandidates(snap, snap.asOf);
    const known = sum(out, (c) => c.value), knownCost = sum(out, (c) => c.cost);
    const avgCost = known ? knownCost / known : 0.6;
    let raw = out.map((c) => ({ v: c.value, c: c.cost }));
    for (const x of excluded) raw.push({ v: x.value, c: x.cost ?? x.value * avgCost });
    const rest = tot('taxable') - sum(raw, (c) => c.v);
    if (rest > 1) raw.push({ v: rest, c: rest });
    raw.sort((a, b) => (a.v - a.c) / a.v - (b.v - b.c) / b.v);
    const chunks = []; const per = tot('taxable') / 16;
    let cur = null; for (const r of raw) { if (!cur || cur.v >= per) { cur = { v: 0, c: 0 }; chunks.push(cur); } cur.v += r.v; cur.c += r.c; }
    return {
      year: +snap.asOf.slice(0, 4) + 1, taxable: tot('taxable'), pretax: tot('pretax'), roth: tot('roth'), property, debt, cardDebt, chunks, w,
      yieldTaxable: an.inc.total / Math.max(1, tot('taxable')), qualFrac: an.inc.total ? an.inc.qualified / an.inc.total : 0.7,
      exemptFrac: an.inc.total ? an.inc.taxExempt / an.inc.total : 0,
      props: JSON.parse(JSON.stringify(snap.realEstate || [])),
      pretaxP, pretaxS: tot('pretax') - pretaxP, rothP, rothS: tot('roth') - rothP, edu,
    };
  };

  // ---------- return paths ----------
  function rng(seed) { let s = seed >>> 0 || 1; return () => { s ^= s << 13; s ^= s >>> 17; s ^= s << 5; return ((s >>> 0) / 4294967296); }; }
  function gauss(r) { let u = 0, v = 0; while (u === 0) u = r(); while (v === 0) v = r(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); }
  L.fixedPath = (plan, n) => {
    const i = plan.inflation / 100, R = plan.returns;
    const nom = (real) => (1 + real / 100) * (1 + i) - 1;
    return Array.from({ length: n }, () => ({ fixed: true, stock: nom(R.stock), bond: nom(R.bond), cash: nom(R.cash), bank: nom(R.bank ?? -1.5), gold: nom(R.gold ?? 1), crypto: nom(R.crypto ?? 5), re: nom(R.re), goog: nom(R.stock), infl: i }));
  };
  L.histPath = (start, n, wrap = true) => {
    const out = []; for (let k = 0; k < n; k++) { let idx = start + k; if (idx >= HIST.length) { if (!wrap) return null; idx %= HIST.length; } const h = HIST[idx]; out.push({ ...h, goog: h.stock, crypto: h.stock * 1.5, bank: h.cash * 0.5 }); } return out;
  };
  L.bootPath = (n, r, block, googVol, cryptoVol = 60) => {
    const out = []; while (out.length < n) { const s = Math.floor(r() * HIST.length); for (let k = 0; k < block && out.length < n; k++) { const h = HIST[(s + k) % HIST.length]; out.push({ ...h, goog: h.stock + gauss(r) * googVol / 100, crypto: h.stock * 1.5 + gauss(r) * cryptoVol / 100, bank: h.cash * 0.5 }); } }
    return out;
  };

  // ---------- plan defaults / migration ----------
  L.normalizePlan = (p, settings) => {
    p.people = { retireAgeSelf: null, retireAgeSpouse: null, lifeSelf: p.endAge ?? 95, lifeSpouse: 95, ...(p.people || {}) };
    p.endAge = +p.people.lifeSelf || 95;
    p.spending = { survivorPct: 75, ...p.spending };
    if (!Array.isArray(p.spending.categories) || !p.spending.categories.length) {
      const B = +p.spending.base || 0;
      p.spending.categories = [
        ['Essentials (groceries, utilities, insurance, transport)', 0.30, 'essential'], ['Out-of-pocket medical, dental, vision', 0.04, 'essential'],
        ['Kids & education', 0.12, 'essential'], ['Travel & vacations', 0.18, 'discretionary'], ['Dining & entertainment', 0.10, 'discretionary'],
        ['Gifts & charity', 0.06, 'discretionary'], ['Home projects & big purchases', 0.08, 'discretionary'], ['Other discretionary', 0.12, 'discretionary'],
      ].map(([name, f, kind]) => ({ name, amount: Math.round(B * f / 100) * 100, kind, startAge: '', endAge: '' }));
      p.spending.categoriesDefault = true;
    }
    const s = p.ss || {};
    if (s.selfPIA == null || (s.selfAmt != null && !+s.selfPIA && !+s.spousePIA && (+s.selfAmt || +s.spouseAmt))) p.ss = { selfPIA: +s.selfAmt || 0, selfClaim: +s.selfAge || 67, spousePIA: +s.spouseAmt || 0, spouseClaim: +s.spouseAge || 67, fra: 67, haircutPct: 0, haircutYear: 2034 };
    const h = p.healthcare || {};
    if (h.medigapPartD == null) p.healthcare = { model: true, acaBenchmark: h.acaBenchmark || 30000, growth: 1.5, medigapPartD: 3500 };
    if (!p.tax) { const r = p.roth || {}; p.tax = { convert: r.strategy === 'magi' ? 'aca' : (r.strategy || 'none'), convertBracket: +r.bracketTop || 0.22, convertFixed: +r.fixed || 50000, convertStart: '', convertEnd: +r.endAge || 74, protectACA: false, shield: false, shieldBracket: 0.22, harvest: false, harvestProtectACA: true }; }
    p.estate = { heirRate: 35, communityProperty: true, prop13: true, portability: true, ...(p.estate || {}) };
    p.healthcare = { ageRise: false, ageRisePct: 3, ageRiseFrom: 65, oopGrow: false, ltc: false, ltcSelfCost: 91520, ltcSelfYears: 2, ltcSelfStart: '', ltcSpouseCost: 91520, ltcSpouseYears: 3, ltcSpouseStart: '', ...(p.healthcare || {}) };
    if (p.rothBasis == null) p.rothBasis = 0;
    p.saving = { backdoorRoth: 0, megaBackdoor: 0, hsa: 0, ...(p.saving || {}) };
    p.allocation = { alt: 0, intlShare: 30, ...(p.allocation || {}) };
    p.di = { enabled: false, initial: 0, annual: 100000, years: 5, harvestPct: 10, decayPct: 30, feePct: 0.25, feeType: 'pct', feeFlat: 1500, feeYears: '', diversify: false, diversifyFromAge: 65, source: 'cash', ...(p.di || {}) };
    p.edu = { stockPct: 60, contrib: 0, contribEndYear: '', ...(p.edu || {}) };
    for (const x of p.expenses || []) if (x.from529 == null) x.from529 = /college|tuition|universit|school|529/i.test(x.name || '');
    return p;
  };
  L.horizon = (plan, init, settings) => {
    const h = settings.household; const a0 = init.year - h.birthYearSelf, b0 = init.year - h.birthYearSpouse;
    return Math.max(1, Math.max((+plan.people?.lifeSelf || plan.endAge || 95) - a0, (+plan.people?.lifeSpouse || 95) - b0) + 1);
  };
  // Social Security: own benefit adjusted for claiming age vs full retirement age
  L.ssAdj = (pia, claim, fra = 67) => { const m = Math.round((claim - fra) * 12); if (m < 0) { const e = -m; return pia * (1 - (Math.min(36, e) * 5 / 9 + Math.max(0, e - 36) * 5 / 12) / 100); } return pia * (1 + Math.min(m, (70 - fra) * 12) * (2 / 3) / 100); };
  L.ssSpousal = (otherPia, claim, fra = 67) => { const m = Math.round((fra - claim) * 12); const b = 0.5 * otherPia; return m <= 0 ? b : b * (1 - (Math.min(36, m) * 25 / 36 + Math.max(0, m - 36) * 5 / 12) / 100); };
  // ACA age-rating curve (federal default, 21 = 1.0)
  const AGE_CURVE = [[21, 1.0], [25, 1.004], [30, 1.135], [35, 1.222], [40, 1.278], [45, 1.444], [50, 1.786], [55, 2.23], [60, 2.714], [64, 3.0]];
  L.ageFactor = (a) => { a = Math.max(21, Math.min(64, a)); for (let i = 0; i < AGE_CURVE.length - 1; i++) { const [x0, y0] = AGE_CURVE[i], [x1, y1] = AGE_CURVE[i + 1]; if (a <= x1) return y0 + (y1 - y0) * (a - x0) / (x1 - x0); } return 3; };

  const isRental = (k) => k === 'rental' || k === 'str';
  // Repairs & maintenance: a fixed $/yr in today's dollars (inflated with CPI). Older data stored % of value → convert once.
  L.maintAmt = (pp) => (pp.maintAmt !== '' && pp.maintAmt != null ? +pp.maintAmt || 0 : (+pp.value || +pp.price || 0) * (+pp.maintPct || 0) / 100);
  L.isRental = isRental;
  // Rental-year P&L (Schedule E style). Amounts nominal. pp = live property state.
  L.rentalPL = (pp, { cpi, ptx, interest, principal, y }) => {
    const str = pp.kind === 'str';
    const rentalDays = str ? 365 * (+pp.occupancyPct || 0) / 100 : 365 * (1 - (+pp.vacancyPct || 0) / 100);
    const personalDays = +pp.personalDays || 0;
    const gross = str ? (+pp.nightlyRate || 0) * rentalDays * cpi : (+pp.rentMonthly || 0) * 12 * cpi * (1 - (+pp.vacancyPct || 0) / 100);
    const share = rentalDays + personalDays > 0 ? rentalDays / (rentalDays + personalDays) : 1; // §280A allocation
    const mgmt = gross * (+pp.mgmtPct || 0) / 100, platform = gross * (+pp.platformPct || 0) / 100;
    const cleaning = (+pp.cleaning || 0) * cpi, utilities = (+pp.utilities || 0) * cpi, supplies = (+pp.supplies || 0) * cpi;
    const insurance = (+pp.insurance || 0) * cpi, hoa = (+pp.hoa || 0) * cpi, repairs = L.maintAmt(pp) * cpi;
    const cashOpex = mgmt + platform + cleaning + utilities + supplies + insurance + hoa + repairs + ptx;
    const dedOpex = mgmt + platform + cleaning + share * (utilities + supplies + insurance + hoa + repairs + ptx);
    const yrs = y - (pp.depStart || y);
    const dep = yrs < 27.5 ? (pp.depBasis || 0) / 27.5 * share : 0;
    const intR = interest * share;
    const noi = gross - cashOpex;
    const net = gross - dedOpex - intR - dep; // Schedule E net (before passive-loss limits)
    const heavyPersonal = personalDays > Math.max(14, 0.1 * rentalDays);
    const nonPassive = str && (+pp.avgStay || 0) <= 7 && !!pp.materialParticipation; // STR "loophole"
    return { gross, mgmt, platform, cleaning, utilities, supplies, insurance, hoa, repairs, ptx, cashOpex, dedOpex, interest, intR, principal, dep, noi, net,
      cash: noi - interest - principal, share, rentalDays, personalDays, heavyPersonal, nonPassive, personalPtx: ptx * (1 - share), personalInt: interest * (1 - share) };
  };

  // ---------- one simulation ----------
  const RMD = { 73: 26.5, 74: 25.5, 75: 24.6, 76: 23.7, 77: 22.9, 78: 22.0, 79: 21.1, 80: 20.2, 81: 19.4, 82: 18.5, 83: 17.7, 84: 16.8, 85: 16.0, 86: 15.2, 87: 14.4, 88: 13.7, 89: 12.9, 90: 12.2, 91: 11.5, 92: 10.8, 93: 10.1, 94: 9.5, 95: 8.9, 96: 8.4, 97: 7.8, 98: 7.3, 99: 6.8, 100: 6.4, 101: 6.0, 102: 5.6, 103: 5.2, 104: 4.9, 105: 4.6, 106: 4.3, 107: 4.1, 108: 3.9, 109: 3.7, 110: 3.5, 111: 3.4, 112: 3.3, 113: 3.1, 114: 3.0, 115: 2.9, 116: 2.8, 117: 2.7, 118: 2.5, 119: 2.3, 120: 2.0 };
  L.simulate = (plan, init, settings, path, opts = {}) => {
    plan = L.normalizePlan(JSON.parse(JSON.stringify(plan)), settings);
    const hh = settings.household; const baseYear = init.year - 1; // tax tables are in baseYear dollars
    const nYears = L.horizon(plan, init, settings);
    const solo = hh.filing === 'single'; // single household: no spouse in any year
    const lifeS = +plan.people.lifeSelf || 95, lifeP = solo ? -Infinity : +plan.people.lifeSpouse || 95;
    const T = plan.tax, ES = plan.estate, HC = plan.healthcare, SS = plan.ss;
    let chunks = init.chunks.map((c) => ({ ...c }));
    let preS = init.pretaxS ?? init.pretax, preP = init.pretaxP ?? 0, pre = preS + preP, roth = init.roth, prop = init.property, debt = init.debt, edu = init.edu || 0;
    let cpi = 1; let spendMult = 1; let wr0 = null; let lastRealized = 0;
    const rows = []; let failed = null; const magiHist = {};
    for (const [yy, m] of Object.entries(init.magiSeed || {})) { magiHist['i' + yy] = m.i; magiHist['p' + yy] = m.p; } // actual MAGI from filed returns (IRMAA 2-yr lookback, §469)
    const tot = { tax: 0, irmaa: 0, propTax: 0, ptc: 0, rmd: 0, conv: 0, harvest: 0, gross: 0, amt: 0, mhst: 0, edu529: 0 };
    const rmdAgeS = hh.birthYearSelf >= 1960 ? 75 : 73, rmdAgeP = hh.birthYearSpouse >= 1960 ? 75 : 73;
    const spendScale = opts.spendScale ?? 1;
    const F = settings.ref.fica || E.DEFAULT_REF.fica; const STATE = E.stateOf(settings); const isCA = STATE.type === 'ca'; const sdiRate = isCA ? (settings.ref.caSdi ?? E.DEFAULT_REF.caSdi) : 0; // CA SDI; other states' payroll programs not modeled
    const partB = settings.ref.medicarePartB ?? E.DEFAULT_REF.medicarePartB;
    const zero = { ordinary: 0, qualified: 0, taxExempt: 0, otherIncome: 0, capInc: 0 };
    const tbl = { MFJ: E.taxes(settings, baseYear, zero, {}), single: E.taxes(settings, baseYear, zero, { filing: 'single' }) };
    const a0S = init.year - hh.birthYearSelf, a0P = init.year - hh.birthYearSpouse;
    const acaDenom = (solo ? [a0S] : [a0S, a0P]).filter((a) => a < 65).reduce((s, a) => s + L.ageFactor(a), 0) || L.ageFactor(Math.min(a0S, 64));
    // properties
    const props = [];
    for (const q of init.props || []) {
      const o = plan.reSale?.[q.id] || {};
      const basis = +q.basis || +q.value || 0, depBasis = isRental(q.kind) ? basis * (q.buildingPct === '' || q.buildingPct == null ? 60 : +q.buildingPct) / 100 : 0;
      const yrsOwned = Math.max(0, init.year - (+q.purchaseYear || init.year));
      props.push({ ...q, active: true, value: +q.value || 0, basis, depBasis, depStart: +q.purchaseYear || init.year, accDep: q.priorDepreciation !== '' && q.priorDepreciation != null ? +q.priorDepreciation : Math.min(27.5, yrsOwned) * depBasis / 27.5, suspended: +q.suspendedLoss || 0,
        bal: +q.mtgBalance || 0, rate: +q.mtgRate || 0, pay: +q.mtgPayment || L.pmt(+q.mtgBalance, q.mtgRate, q.mtgYearsLeft), extra: +q.mtgExtra || 0, ptNom: +q.propertyTax || 0,
        sellCostPct: o.sellCostPct != null && o.sellCostPct !== '' ? +o.sellCostPct : q.sellCostPct,
        sellYear: o.sellYear != null && o.sellYear !== '' ? +o.sellYear : (+q.sellYear || null), costsInSpending: o.costsInSpending === true || o.costsInSpending === 'true' ? true : o.costsInSpending === false || o.costsInSpending === 'false' ? false : !!q.costsInSpending });
    }
    for (const q of plan.purchases || []) props.push({ ...q, future: true, active: false, sellYear: +q.sellYear || null, costsInSpending: q.costsInSpending === true || q.costsInSpending === 'true' });
    let wasBoth = !solo; let firstDeath = null; const DI = plan.di || {}; let diPool = +init.capLossCF || 0; let rothFree = +plan.rothBasis || 0; const convHist = []; const wTax = { ...init.w.taxable }; // taxable mix; moving cash into direct indexing shifts it to stocks
    for (let t = 0; t < nYears; t++) {
      const y = init.year + t, age = y - hh.birthYearSelf, sAge = y - hh.birthYearSpouse;
      const aliveS = age <= lifeS, aliveP = sAge <= lifeP;
      if (!aliveS && !aliveP) break;
      const both = aliveS && aliveP; const filing = both ? 'MFJ' : 'single'; const single = !both;
      const p = path[t];
      const inflAdj = (amt, real) => (real === false ? amt : amt * cpi);
      // --- first death: step-up in basis (CA community property = full step-up on both halves) ---
      if (wasBoth && !both) {
        firstDeath = { year: y, who: aliveS ? 'spouse' : 'self' };
        const f = ES.communityProperty && STATE.cp ? 1 : 0.5; // full step-up only in community-property states
        for (const c of chunks) c.c += (c.v - c.c) * f;
        diPool *= 0.5; // the deceased spouse's share of capital-loss carryforwards expires
        for (const pp of props) if (pp.active) { pp.basis += (pp.value - pp.basis) * f; if (isRental(pp.kind)) { pp.depBasis = pp.value * (pp.buildingPct === '' || pp.buildingPct == null ? 60 : +pp.buildingPct) / 100; pp.depStart = y; pp.accDep *= (1 - f); } }
      }
      wasBoth = both;
      // --- direct indexing: move cash in, harvest losses (they fade as the basis falls), bank them ---
      let diContrib = 0, diFundGain = 0, diHarvest = 0, diUseG = 0, diUseO = 0, diFlow = 0, diFee = 0, lossExcess = 0;
      if (DI.enabled) {
        const lump = (t === 0 ? +DI.initial || 0 : 0) * cpi, yearly = t < (+DI.years || 0) ? (+DI.annual || 0) * cpi : 0;
        // "flow": the yearly amount is new money out of this year's cash flow (paycheck surplus, or portfolio withdrawals once retired)
        if (DI.source === 'flow' && yearly > 0) {
          const T0 = sum(chunks, (c) => c.v); diFlow = yearly; diContrib += yearly; chunks.push({ v: yearly, c: yearly, di: true, age: 0 });
          const sh = yearly / Math.max(1, T0 + yearly); for (const kk of Object.keys(wTax)) wTax[kk] *= 1 - sh; wTax.stock = (wTax.stock || 0) + sh;
        }
        let amt = lump + (DI.source === 'flow' ? 0 : yearly);
        if (amt > 0) {
          const src = chunks.filter((c) => !c.di).sort((a, b) => (a.v - a.c) / Math.max(1, a.v) - (b.v - b.c) / Math.max(1, b.v)); // cash / no-gain money first
          const T0 = sum(chunks, (c) => c.v);
          let moved = 0; for (const c of src) { if (amt <= 1) break; const x = Math.min(amt, c.v); const fr = x / Math.max(1e-9, c.v); diFundGain += (c.v - c.c) * fr; c.c -= c.c * fr; c.v -= x; amt -= x; moved += x; }
          chunks = chunks.filter((c) => c.v > 1); if (moved > 0) chunks.push({ v: moved, c: moved, di: true, age: 0 }); diContrib += moved;
          let mv = moved / Math.max(1, T0); for (const kk of ['bank', 'cash']) { const x = Math.min(mv, wTax[kk] || 0); wTax[kk] = (wTax[kk] || 0) - x; wTax.stock = (wTax.stock || 0) + x; mv -= x; }
        }
        // more losses in down years, fewer in strong years (fixed returns = the entered rate)
        const rs = (1 + p.stock) / (1 + p.infl) - 1, m0 = (+plan.returns.stock || 5) / 100;
        const mf = p.fixed ? 1 : Math.min(3, Math.max(0.2, (1 - 4 * rs) / Math.max(0.2, 1 - 4 * m0)));
        for (const c of chunks) if (c.di) { const l = Math.min(0.3 * c.c, (+DI.harvestPct || 0) / 100 * Math.pow(1 - (+DI.decayPct || 0) / 100, c.age) * c.v * mf); c.c -= l; diHarvest += l; c.age++; }
        diPool += diHarvest;
      }
      // spousal rollover: the survivor treats the deceased's IRA/401(k) as their own
      if (!aliveS && preS) { preP += preS; preS = 0; } if (!aliveP && preP) { preS += preP; preP = 0; }
      pre = preS + preP;
      const gF = Math.pow(1 + (+HC.growth || 0) / 100, t); // healthcare real growth
      // optional: per-person costs keep rising with age after 65 (Medigap attained-age pricing, more care in your 80s)
      const ageMult = (a) => (HC.ageRise && a > +HC.ageRiseFrom ? Math.pow(1 + (+HC.ageRisePct || 0) / 100, Math.min(35, a - +HC.ageRiseFrom)) : 1);
      const hhAgeMult = (() => { const xs = [aliveS ? ageMult(age) : null, aliveP ? ageMult(sAge) : null].filter((x) => x != null); return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 1; })();
      // optional: long-term care in the last years of each person's life (or from a chosen age)
      const ltcFor = (alive, a, life, cost, yrs, start) => { if (!HC.ltc || !alive || !(+yrs > 0)) return 0; const st = start !== '' && start != null ? +start : life - +yrs + 1; return a >= st && a < st + +yrs ? (+cost || 0) * cpi * gF : 0; };
      const ltc = ltcFor(aliveS, age, lifeS, HC.ltcSelfCost, HC.ltcSelfYears, HC.ltcSelfStart) + ltcFor(aliveP, sAge, lifeP, HC.ltcSpouseCost, HC.ltcSpouseYears, HC.ltcSpouseStart);
      // --- Social Security (claiming-age adjusted, spousal, survivor; optional trust-fund haircut) ---
      const fra = +SS.fra || 67;
      const ownS = L.ssAdj(+SS.selfPIA || 0, +SS.selfClaim || 67, fra), ownP = solo ? 0 : L.ssAdj(+SS.spousePIA || 0, +SS.spouseClaim || 67, fra);
      let bS = 0, bP = 0;
      if (aliveS && age >= +SS.selfClaim) { bS = ownS; if (aliveP && sAge >= +SS.spouseClaim) bS = Math.max(bS, L.ssSpousal(+SS.spousePIA || 0, +SS.selfClaim, fra)); if (!aliveP) bS = Math.max(bS, ownP); }
      if (aliveP && sAge >= +SS.spouseClaim) { bP = ownP; if (aliveS && age >= +SS.selfClaim) bP = Math.max(bP, L.ssSpousal(+SS.selfPIA || 0, +SS.spouseClaim, fra)); if (!aliveS) bP = Math.max(bP, ownS); }
      const hair = y >= +SS.haircutYear ? 1 - (+SS.haircutPct || 0) / 100 : 1;
      const ss = (bS + bP) * hair * cpi;
      // --- other income / events ---
      let ordInc = 0, freeInc = 0;
      for (const s of plan.incomes) if (age >= +s.startAge && age <= +s.endAge) { const v = inflAdj(+s.amount, s.real); if (s.taxable === 'none') freeInc += v; else ordInc += v; }
      let evIn = 0, evOut = t === 0 ? (init.cardDebt || 0) : 0, evOrd = 0, evGain = 0; // credit cards paid off from cash in year 1
      for (const e of plan.events) if (+e.year === y) {
        const v = inflAdj(+e.amount, e.real); if (v >= 0) { evIn += v; if (e.taxable === 'ordinary') evOrd += v; if (e.taxable === 'ltcg') evGain += v - inflAdj(+e.basis || 0, e.real); } else evOut += -v;
        if (e.propertyDelta) prop = Math.max(0, prop + inflAdj(+e.propertyDelta, e.real));
        if (e.debtDelta) debt = Math.max(0, debt + inflAdj(+e.debtDelta, e.real));
      }
      // --- real estate (Prop 13: assessed property tax grows ≤2%/yr) ---
      let sec1250 = 0, housingOut = 0, rentNet = 0, rentTaxable = 0, rentPreDep = 0, depY = 0, saleNet = 0, propTaxP = 0, mortIntFed = 0, mortIntCA = 0, releasedLoss = 0; const rentalDetail = {}; const passive = [];
      for (const pp of props) {
        if (pp.future && !pp.active && !pp.done && +pp.year === y) {
          const price = (+pp.price || 0) * cpi, down = price * (+pp.downPct || 0) / 100;
          Object.assign(pp, { active: true, value: price, basis: price, depBasis: isRental(pp.kind) ? price * (pp.buildingPct === '' || pp.buildingPct == null ? 60 : +pp.buildingPct) / 100 : 0, depStart: y, accDep: 0, suspended: 0, bal: price - down, rate: +pp.rate || 0, extra: 0, ptNom: (+pp.propertyTax || 0) * cpi, ptYear: y });
          pp.pay = L.pmt(pp.bal, pp.rate, pp.termYears); evOut += down;
        }
        if (!pp.active) continue;
        if (pp.sellYear && pp.sellYear === y) {
          const gross = pp.value * (1 - (pp.sellCostPct === '' || pp.sellCostPct == null ? 6 : +pp.sellCostPct) / 100); const net = gross - pp.bal;
          if (net >= 0) evIn += net; else evOut += -net;
          // adjusted basis = cost − depreciation taken (§1016); depreciation comes back as "unrecaptured §1250 gain", taxed up to 25%
          let gain = gross - (pp.basis - (isRental(pp.kind) ? pp.accDep || 0 : 0));
          if (pp.kind === 'primary') gain -= single ? 250000 : 500000; // §121 exclusion (not indexed)
          if (isRental(pp.kind)) { const rec = Math.min(pp.accDep || 0, Math.max(0, gain)); sec1250 += rec; releasedLoss += pp.suspended || 0; pp.suspended = 0; }
          if (gain > 0) evGain += gain; // includes the §1250 part (taxed as a gain + NIIT); the extra up-to-25% is added below
          saleNet += net; pp.active = false; pp.done = true; pp.value = 0; pp.bal = 0; continue;
        }
        const ptx = ES.prop13 && isCA ? pp.ptNom * Math.pow(1.02, y - (pp.ptYear || init.year)) : (+pp.propertyTax || 0) * cpi;
        const other = ((+pp.insurance || 0) + (+pp.hoa || 0) + L.maintAmt(pp)) * cpi;
        let interest = 0, mtgPay = 0, principal = 0; const bal0 = pp.bal;
        if (pp.bal > 0) { interest = pp.bal * pp.rate / 100; principal = Math.min(pp.bal, Math.max(0, pp.pay * 12 + pp.extra - interest)); mtgPay = interest + principal; pp.bal -= principal; }
        if (isRental(pp.kind)) {
          const r = L.rentalPL(pp, { cpi, ptx, interest, principal, y });
          pp.accDep += r.dep; depY += r.dep;
          rentNet += r.cash; rentPreDep += Math.max(0, r.gross - r.dedOpex - r.intR);
          propTaxP += r.personalPtx; mortIntFed += r.personalInt; mortIntCA += r.personalInt; // personal-use share is itemizable
          rentalDetail[pp.id || pp.name] = { name: pp.name, kind: pp.kind, ...r, value: pp.value, bal: pp.bal, accDep: pp.accDep };
          passive.push({ pp, r });
        } else {
          propTaxP += ptx; mortIntFed += interest * Math.min(1, 750000 / Math.max(1, bal0)); mortIntCA += interest * Math.min(1, 1000000 / Math.max(1, bal0));
          if (!pp.costsInSpending) housingOut += other + mtgPay; else propTaxP -= 0; // tax still deductible either way
        }
      }
      // passive-activity rules: losses offset passive income; up to $25k of LTR losses allowed (phased out $100k–$150k MAGI, MFJ); rest suspended until sale
      {
        const lastMagi = magiHist['p' + (y - 1)] ?? magiHist[y - 1] ?? 0;
        const allowance = Math.max(0, 25000 - 0.5 * Math.max(0, lastMagi - 100000)); // $25k active-participation allowance; single filers qualify too (not indexed)
        let passNet = 0, nonPass = 0;
        for (const { pp, r } of passive) {
          if (r.heavyPersonal && r.net < 0) { pp.suspended += -r.net; rentalDetail[pp.id || pp.name].allowed = 0; continue; } // vacation-home rule: no loss
          if (r.nonPassive) { nonPass += r.net; rentalDetail[pp.id || pp.name].allowed = r.net; continue; }
          passNet += r.net;
        }
        const pool = passive.filter((x) => !x.r.nonPassive && !(x.r.heavyPersonal && x.r.net < 0));
        const susp0 = sum(pool, (x) => x.pp.suspended || 0);
        let taxableP;
        if (passNet >= 0) { const use = Math.min(susp0, passNet); taxableP = passNet - use; pool.forEach((x) => (x.pp.suspended -= susp0 ? (x.pp.suspended || 0) * use / susp0 : 0)); }
        else { const ltrLoss = -sum(pool.filter((x) => x.pp.kind === 'rental' && x.r.net < 0), (x) => x.r.net); const allowed = Math.min(-passNet, allowance, ltrLoss); taxableP = -allowed;
          const extra = -passNet - allowed; const losers = pool.filter((x) => x.r.net < 0); const tl = -sum(losers, (x) => x.r.net); losers.forEach((x) => (x.pp.suspended += tl ? extra * (-x.r.net) / tl : 0)); }
        rentTaxable = taxableP + nonPass - releasedLoss;
        for (const { pp } of passive) if (rentalDetail[pp.id || pp.name]) rentalDetail[pp.id || pp.name].suspended = pp.suspended || 0;
      }
      
      const propTaxCash = sum(props.filter((x) => x.active && !isRental(x.kind) && !x.costsInSpending), (x) => (ES.prop13 && isCA ? x.ptNom * Math.pow(1.02, y - (x.ptYear || init.year)) : (+x.propertyTax || 0) * cpi));
      // --- work income ---
      let wages = 0, pre401 = 0, match = 0, rothC = 0, fica = 0, contribS = 0, contribP = 0;
      for (const j of plan.work || []) {
        const isSp = j.who === 'spouse'; const a = isSp ? sAge : age; if (isSp ? !aliveP : !aliveS) continue;
        const end = j.endAge !== '' && j.endAge != null ? +j.endAge : (isSp ? plan.people.retireAgeSpouse : plan.people.retireAgeSelf);
        if (end == null || end === '' || a >= +end) continue;
        if (j.startAge !== '' && j.startAge != null && a < +j.startAge) continue;
        const wg = (+j.salary || 0) * cpi * Math.pow(1 + (+j.growth || 0) / 100, t);
        const c401 = Math.min(wg, (+j.pretax401k || 0) * cpi), cm = (+j.match || 0) * cpi;
        wages += wg; pre401 += c401; match += cm; rothC += (+j.rothContrib || 0) * cpi; if (isSp) contribP += c401 + cm; else contribS += c401 + cm;
        fica += Math.min(wg, F.ssBase * cpi) * F.ssRate + wg * F.medRate;
      }
      fica += Math.max(0, wages - (single ? 200000 : F.addlThreshold)) * F.addlRate;
      const casdi = wages * sdiRate;
      // --- spending ---
      let baseSpend = plan.spending.base;
      if (plan.spending.source === 'schedule' && plan.spending.schedule.length) { const row = plan.spending.schedule.find((r) => +r.year === y) || plan.spending.schedule[plan.spending.schedule.length - 1]; baseSpend = +row.amount; }
      const surv = both || solo ? 1 : (+plan.spending.survivorPct || 100) / 100;
      const spendCats = {}; let essential = 0, discretionary = 0;
      const cats = plan.spending.source === 'schedule' && plan.spending.schedule.length ? [{ name: 'Living spending', amount: baseSpend, kind: 'essential' }] : plan.spending.categories;
      for (const c of cats) {
        if (c.startAge !== '' && c.startAge != null && age < +c.startAge) continue; if (c.endAge !== '' && c.endAge != null && age > +c.endAge) continue;
        const v = (+c.amount || 0) * cpi * spendScale * surv * (HC.oopGrow && /medical|dental|vision|health|pharm|prescription/i.test(c.name || '') ? gF * hhAgeMult : 1); spendCats[c.name] = (spendCats[c.name] || 0) + v; if (c.kind === 'discretionary') discretionary += v; else essential += v;
      }
      let eduNeed = 0;
      for (const x of plan.expenses) if (x.startYear !== '' && x.startYear != null ? (y >= +x.startYear && y <= (x.endYear !== '' && x.endYear != null ? +x.endYear : +x.startYear)) : (age >= +x.startAge && age <= +x.endAge)) { const v = inflAdj(+x.amount, x.real === 'false' ? false : x.real); spendCats[x.name] = (spendCats[x.name] || 0) + v; essential += v; if (x.from529 === true || x.from529 === 'true') eduNeed += v; }
      // 529: qualified withdrawals pay education expenses first (tax-free); optional yearly contributions come out of cash flow
      const eduContrib = (+plan.edu.contrib || 0) && (!plan.edu.contribEndYear || y <= +plan.edu.contribEndYear) ? (+plan.edu.contrib) * cpi : 0;
      const eduPaid = Math.min(edu, eduNeed); edu = edu - eduPaid + eduContrib;
      const liquid0 = sum(chunks, (c) => c.v) + pre + roth;
      if (plan.spending.guardrails.enabled) { // guardrails flex discretionary spending only
        const g = plan.spending.guardrails; const wr = (essential + discretionary * spendMult) / Math.max(1, liquid0);
        if (wr0 == null) wr0 = wr; else if (wr > wr0 * (1 + g.upper / 100)) spendMult *= 1 - g.adjust / 100; else if (wr < wr0 * (1 - g.lower / 100)) spendMult *= 1 + g.adjust / 100;
        for (const c of cats) if (c.kind === 'discretionary' && spendCats[c.name]) spendCats[c.name] *= spendMult;
      }
      const spend = essential + discretionary * (plan.spending.guardrails.enabled ? spendMult : 1);
      // --- portfolio income & RMD ---
      const tv = sum(chunks, (c) => c.v);
      const divs = tv * init.yieldTaxable;
      const qd = divs * init.qualFrac, ex = divs * init.exemptFrac, od = divs - qd - ex;
      const ownerAge = aliveS ? age : sAge;
      const rmdOf = (bal, a, rAge, alive) => (alive && a >= rAge && bal > 0 ? bal / (RMD[Math.min(120, a)] || 2.0) : 0);
      const rmdS = rmdOf(preS, age, rmdAgeS, aliveS), rmdP = rmdOf(preP, sAge, rmdAgeP, aliveP); const rmd = rmdS + rmdP;
      // --- Roth conversion target ---
      const TB = tbl[filing]; const std = TB.std;
      const under65 = (aliveS && age < 65) || (aliveP && sAge < 65);
      const hhSize = Math.max(1, (+hh.size || 2) - (both || solo ? 0 : 1));
      const S2 = { ...settings, household: { ...hh, size: hhSize } };
      const acaCliffN = E.acaThresholds(S2, baseYear).cliff * cpi - (+settings.aca.safetyMargin || 0) * cpi;
      const irmaaT1N = ((settings.ref.irmaa || E.DEFAULT_REF.irmaa)[single ? 'single' : 'mfj'][0]) * cpi - 1000 * cpi;
      const ordBase = od + ordInc + evOrd + rmd + wages - pre401 + rentTaxable + 0.85 * ss;
      const magiBase = od + ordInc + evOrd + rmd + wages - pre401 + rentTaxable + ss + qd + ex + Math.max(0, lastRealized + evGain);
      let conv = 0;
      const cs = T.convertStart === '' || T.convertStart == null ? 0 : +T.convertStart;
      if (T.convert !== 'none' && ownerAge >= cs && ownerAge <= +T.convertEnd && pre - rmd > 0) {
        const fill = (rate) => Math.max(0, (TB.bracketTop(+rate) + std) * cpi - ordBase);
        if (T.convert === 'fixed') conv = +T.convertFixed * cpi;
        else if (T.convert === 'bracket') conv = fill(T.convertBracket);
        else if (T.convert === 'aca') conv = under65 && HC.model ? Math.max(0, acaCliffN - magiBase) : fill(T.convertBracket);
        else if (T.convert === 'irmaa') conv = Math.min(fill(T.convertBracket), Math.max(0, irmaaT1N - magiBase));
        if (T.protectACA && under65 && HC.model) conv = Math.min(conv, Math.max(0, acaCliffN - magiBase));
        conv = Math.max(0, Math.min(conv, pre - rmd));
      }
      const convS = pre - rmd > 0 ? conv * Math.max(0, preS - rmdS) / (pre - rmd) : 0, convP = conv - convS;
      // --- withdrawals / taxes fixed point ---
      let sec1250Tax = 0, magiI = 0, magiP = 0, lastTx = null, tax = 0, take = null, realized = 0, harvested = 0, fromPre = 0, fpS = 0, fpP = 0, fromRoth = 0, fromTax = 0, short = 0, penalty = 0, magi = magiBase + conv, ptc = 0, irmaa = 0, health = 0, ssTax = 0, acaGross = 0, medicare = 0;
      for (let it = 0; it < 5; it++) {
        health = ltc; ptc = 0; irmaa = 0; acaGross = 0; medicare = 0;
        if (HC.model) {
          const acaAges = [aliveS && age < 65 ? age : null, aliveP && sAge < 65 ? sAge : null].filter((a) => a != null);
          if (acaAges.length) {
            const prem = (+HC.acaBenchmark || 0) * cpi * gF * acaAges.reduce((s, a) => s + L.ageFactor(a), 0) / acaDenom;
            const pc = E.ptc({ ...S2, aca: { ...settings.aca, benchmarkPremium: prem / cpi } }, baseYear, magi / cpi);
            ptc = pc ? Math.min(prem, pc.credit * cpi) : 0; health += prem - ptc; acaGross = prem;
          }
          const n65 = (aliveS && age >= 65 ? 1 : 0) + (aliveP && sAge >= 65 ? 1 : 0);
          if (n65) {
            medicare = ((aliveS && age >= 65 ? ageMult(age) : 0) + (aliveP && sAge >= 65 ? ageMult(sAge) : 0)) * (partB * 12 + (+HC.medigapPartD || 0)) * cpi * gF; health += medicare;
            const lb = magiHist['i' + (y - 2)] ?? magiHist[y - 2]; if (lb != null) { irmaa = n65 * E.irmaa(settings, lb, single, cpi).annual; } // MAGI from 2 years earlier vs this year's thresholds
            health += irmaa;
          }
        }
        let need = spend + health + housingOut + propTaxCash + rothC + evOut + eduContrib + diFlow + tax - ss - ordInc - freeInc - evIn - divs - rmd - rentNet - (wages - pre401) - eduPaid;
        fromTax = 0; fromPre = 0; fpS = 0; fpP = 0; fromRoth = 0; realized = 0; short = 0; penalty = 0; harvested = 0;
        const sorted = chunks.map((c) => ({ ...c })).sort((a, b) => (a.v - a.c) / Math.max(1, a.v) - (b.v - b.c) / Math.max(1, b.v));
        let reinvest = 0; if (need < 0) { reinvest = -need; need = 0; }
        const ordSoFar = () => ordBase + conv + fromPre;
        const takePre = (cap) => { // penalty-free owner (59½+) first, then the younger owner with the 10% penalty
          let want = Math.min(need, cap);
          const owners = [['S', age, aliveS], ['P', sAge, aliveP]].filter((o) => o[2]).sort((a, b) => (b[1] >= 59.5) - (a[1] >= 59.5));
          for (const [o, a] of owners) { if (want <= 0) break; const bal = o === 'S' ? preS - rmdS - convS - fpS : preP - rmdP - convP - fpP; const x = Math.min(want, Math.max(0, bal)); if (o === 'S') fpS += x; else fpP += x; fromPre += x; need -= x; want -= x; if (a < 59.5) penalty += x * (isCA ? 0.125 : 0.10); /* 10% federal (+2.5% California, R&TC §17085) */ }
        };
        const takeTax = () => { for (const c of sorted) { if (need <= 0) break; const x = Math.min(need, c.v); const f = x / Math.max(1e-9, c.v); realized += (c.v - c.c) * f; c.c -= c.c * f; c.v -= x; need -= x; fromTax += x; } };
        // before 59½ only Roth contributions and conversions at least 5 years old come out tax- and penalty-free (§408A(d)); earnings and newer conversions stay put
        const rothEarly = Math.max(aliveS ? age : 0, aliveP ? sAge : 0) < 59.5;
        const takeRoth = () => { const avail = rothEarly ? Math.min(roth, rothFree) - fromRoth : roth + conv - fromRoth; const x = Math.min(need, Math.max(0, avail)); fromRoth += x; need -= x; };
        const shieldCap = () => T.shield ? Math.max(0, (TB.bracketTop(+T.shieldBracket) + std) * cpi - ordSoFar()) : Infinity;
        for (const src of plan.order.split('-')) {
          if (need <= 0) break;
          if (src === 'taxable') takeTax(); if (src === 'pretax') takePre(shieldCap()); if (src === 'roth') takeRoth();
        }
        if (need > 0 && T.shield) takePre(Infinity); // shield is a preference, not a hard stop
        short = need;
        // gain harvesting: realize LTCG up to the top of the 0% bracket (CA still taxes it as ordinary income)
        if (T.harvest) {
          const ordTaxableN = Math.max(0, ordSoFar() - 0.85 * ss + Math.min(0.85 * ss, ssTax) - std * cpi);
          let room = TB.ltcg0Top * cpi - ordTaxableN - qd - Math.max(0, realized + evGain);
          if (T.harvestProtectACA && under65 && HC.model) room = Math.min(room, acaCliffN - (ordSoFar() - 0.85 * ss + ss + qd + ex + Math.max(0, realized + evGain)));
          for (const c of sorted.slice().reverse()) { if (room <= 1) break; const g = Math.min(room, Math.max(0, c.v - c.c)); c.c += g; harvested += g; room -= g; }
        }
        take = { sorted, reinvest };
        const ord = od + ordInc + evOrd + rmd + fromPre + conv + wages - pre401 + rentTaxable; // excludes SS
        const gRaw = realized + harvested + evGain + diFundGain;
        diUseG = Math.min(diPool, Math.max(0, gRaw)); const g2 = gRaw - diUseG; // banked losses offset gains first,
        diUseO = Math.min(diPool - diUseG, Math.max(0, 3000 + Math.min(0, g2))); // then up to $3,000 of ordinary income (fixed, not indexed)
        const capInc = Math.max(g2 - diUseO, -3000);
        lossExcess = Math.max(0, -(g2 - diUseO) - 3000); // net losses beyond $3,000 carry forward (§1212)
        const [t1, t2] = single ? [25000, 34000] : [32000, 44000]; // not indexed
        const prov = ord + qd + ex + capInc + 0.5 * ss;
        ssTax = ss <= 0 || prov <= t1 ? 0 : prov <= t2 ? Math.min(0.5 * ss, 0.5 * (prov - t1)) : Math.min(0.85 * ss, 0.85 * (prov - t2) + Math.min(0.5 * ss, (t2 - t1) / 2));
        const inc = { ordinary: ord / cpi, retirementDist: (rmd + fromPre + conv) / cpi, ordinaryInvestment: (od + rentTaxable) / cpi, qualified: qd / cpi, taxExempt: ex / cpi, otherIncome: 0, capInc: capInc / cpi, ssTaxable: ssTax / cpi };
        const tx = E.taxes(settings, baseYear, inc, { filing, cpi, calYear: y, ages: [aliveS ? age : null, aliveP ? sAge : null].filter((a) => a != null), itemized: { propertyTax: propTaxP / cpi, mortgageInterest: mortIntFed / cpi, mortgageInterestCA: mortIntCA / cpi } });
        lastTx = tx;
        sec1250Tax = sec1250 > 0 && tx.fedMarginal > 0.15 ? sec1250 * (Math.min(0.25, tx.fedMarginal) - (tx.ordTaxable + tx.prefTaxable > 613700 ? 0.20 : 0.15)) : 0; // ordinary rate capped at 25%, minus the LTCG rate already charged
        sec1250Tax = Math.max(0, sec1250Tax);
        const newTax = tx.total * cpi + sec1250Tax + penalty + fica + casdi;
        magi = ord + qd + ex + capInc + ss; // ACA MAGI: includes all Social Security and muni interest
        magiI = ord + qd + ex + capInc + ssTax; // IRMAA MAGI: AGI + muni interest
        magiP = ord + qd + capInc; // §469 MAGI: AGI without Social Security
        if (Math.abs(newTax - tax) < 50 && it > 0) { tax = newTax; break; }
        tax = newTax;
      }
      magiHist[y] = magi; magiHist['c' + y] = cpi; lastRealized = realized; diPool = Math.max(0, diPool - diUseG - diUseO) + lossExcess; magiHist['i' + y] = magiI; magiHist['p' + y] = magiP;
      // optional: spend leftover banked losses to diversify low-basis holdings (sell & rebuy; the gain is fully offset, so no tax)
      let diDiversified = 0;
      if (DI.enabled && DI.diversify && diPool > 1 && age >= (+DI.diversifyFromAge || 0)) {
        for (const c of take.sorted.filter((c) => !c.di && c.v > c.c).sort((a, b) => (a.c / a.v) - (b.c / b.v))) { if (diPool <= 1) break; const g = Math.min(diPool, c.v - c.c); c.c += g; diPool -= g; diDiversified += g; }
      }
      const taxParts = { fedOrd: (lastTx.fedOrdinary) * cpi, fedPref: lastTx.fedPref * cpi + sec1250Tax, niit: lastTx.niit * cpi, amt: lastTx.amt * cpi, ca: (lastTx.ca - lastTx.caMhst) * cpi, caMhst: lastTx.caMhst * cpi, fica, casdi, penalty, irmaa, propTax: propTaxP };
      chunks = take.sorted.filter((c) => c.v > 1);
      let saveRoth = 0;
      if (wages > 0 && take.reinvest > 0) { const SV = plan.saving || {}; saveRoth = Math.min(take.reinvest, ((+SV.backdoorRoth || 0) + (+SV.megaBackdoor || 0) + (+SV.hsa || 0)) * cpi); take.reinvest -= saveRoth; }
      if (take.reinvest > 0) chunks.push({ v: take.reinvest, c: take.reinvest });
      preS = Math.max(0, preS - rmdS - fpS - convS) + contribS; preP = Math.max(0, preP - rmdP - fpP - convP) + contribP; pre = preS + preP;
      roth = Math.max(0, roth + conv - fromRoth) + rothC + saveRoth;
      if (Math.max(aliveS ? age : 0, aliveP ? sAge : 0) < 59.5) rothFree = Math.max(0, rothFree - fromRoth); rothFree += rothC; convHist.push([y, conv]);
      for (const h of convHist) if (h[0] === y - 4 && h[1] > 0) rothFree += h[1]; // conversion from 5 tax years ago becomes accessible next year
      const f = 1 / cpi;
      tot.tax += tax * f; tot.irmaa += irmaa * f; tot.propTax += propTaxP * f; tot.ptc += ptc * f; tot.rmd += rmd * f; tot.conv += conv * f; tot.harvest += harvested * f; tot.amt += lastTx.amt; tot.mhst += lastTx.caMhst; tot.edu529 += eduPaid * f; tot.diHarvest = (tot.diHarvest || 0) + diHarvest * f; tot.diUsed = (tot.diUsed || 0) + (diUseG + diUseO) * f; tot.diUseO = (tot.diUseO || 0) + diUseO * f; tot.diContrib = (tot.diContrib || 0) + diContrib * f; tot.diDiversified = (tot.diDiversified || 0) + diDiversified * f; tot.diFlow = (tot.diFlow || 0) + diFlow * f;
      tot.gross += (wages + ss + divs + ordInc + evOrd + rmd + fromPre + conv + Math.max(0, rentTaxable) + Math.max(0, realized + evGain)) * f;
      if (short > 1 && failed == null) failed = age;
      // --- growth ---
      const wFor = (b) => {
        if (plan.allocation.mode !== 'glide' && plan.allocation.mode !== 'target') return b === 'taxable' ? wTax : init.w[b];
        const a = plan.allocation; const fr = a.mode === 'target' ? 0 : Math.min(1, Math.max(0, (age - a0S) / Math.max(1, a.glideEndAge - a0S)));
        // glide the stock/bond/cash share; concentrated stock, gold, crypto and bank cash keep their current weights
        const w0 = init.w[b]; const fixedW = (w0.goog || 0) + (w0.gold || 0) + (w0.crypto || 0) + (w0.bank || 0); const rest = 1 - fixedW;
        const st = (a.stockNow + (a.stockEnd - a.stockNow) * fr) / 100; return { stock: st * rest, bond: (1 - st) * 0.85 * rest, cash: (1 - st) * 0.15 * rest, goog: w0.goog || 0, gold: w0.gold || 0, crypto: w0.crypto || 0, bank: w0.bank || 0 };
      };
      const ret = (w) => (w.stock || 0) * p.stock + (w.bond || 0) * p.bond + (w.cash || 0) * p.cash + (w.goog || 0) * p.goog + (w.gold || 0) * (p.gold ?? p.stock) + (w.crypto || 0) * (p.crypto ?? p.stock) + (w.bank || 0) * (p.bank ?? p.cash);
      const wt = wFor('taxable');
      const rt = ret(wt);
      const feeOn = DI.feeYears === '' || DI.feeYears == null || t < +DI.feeYears;
      { const dv = sum(chunks.filter((c) => c.di), (c) => c.v);
        if (DI.enabled && feeOn && dv > 0) { diFee = DI.feeType === 'flat' ? Math.min(dv, (+DI.feeFlat || 0) * cpi) : dv * (+DI.feePct || 0) / 100 * (1 + rt);
          if (DI.feeType === 'flat') for (const c of chunks) if (c.di) c.v -= diFee * c.v / dv; tot.diFee = (tot.diFee || 0) + diFee / cpi; } }
      for (const c of chunks) c.v *= Math.max(0.01, 1 + rt - (c.di && DI.feeType !== 'flat' && feeOn ? (+DI.feePct || 0) / 100 : 0) - init.yieldTaxable); // whole taxable account rebalanced to one mix
      { const gp = 1 + ret(wFor('pretax')); preS *= gp; preP *= gp; pre = preS + preP; } roth *= 1 + ret(wFor('roth'));
      { const sp = Math.min(100, Math.max(0, +plan.edu.stockPct || 0)) / 100; edu *= Math.max(0, 1 + sp * p.stock + (1 - sp) * p.bond); }
      prop *= 1 + p.re;
      for (const pp of props) if (pp.active) pp.value *= 1 + (p.fixed && pp.appreciation != null && pp.appreciation !== '' ? (1 + +pp.appreciation / 100) * (1 + p.infl) - 1 : p.re);
      const propV = prop + sum(props.filter((x) => x.active), (x) => x.value), debtV = debt + sum(props.filter((x) => x.active), (x) => x.bal);
      const cpiStart = cpi; cpi *= 1 + p.infl;
      const taxable = sum(chunks, (c) => c.v); const liquid = taxable + pre + roth; // 529 shown separately: it can only pay for education
      rows.push({ year: y, age, sAge, aliveS, aliveP, filing, cpi: cpiStart, cpiEnd: cpi, saveRoth, ltc, diContrib, diHarvest, diUseG, diUseO, diPool, diFundGain, diDiversified, diFlow, diFee, diValue: sum(chunks.filter((c) => c.di), (c) => c.v), diBasis: sum(chunks.filter((c) => c.di), (c) => c.c), gainsRaw: realized + harvested + evGain + diFundGain, edu, eduPaid, eduNeed, eduContrib, taxable, pretax: pre, pretaxS: preS, pretaxP: preP, roth, liquid, property: propV, debt: debtV, nw: liquid + edu + propV - debtV,
        spend, health, tax, fica, casdi, wages, pre401, match, rothC, housingOut: housingOut + propTaxCash, propTax: propTaxP, rentNet, rentTaxable, saleNet, ss, ordInc, divs, rmd, conv, fromTax, fromPre, fromRoth, realized, harvested, magi, ptc, irmaa, short, penalty,
        events: evIn - evOut, evIn, evOut, freeInc, reinvest: take.reinvest, taxParts, itemized: lastTx.itemizedUsed, deduction: lastTx.deduction * cpiStart,
        od, qd, ex, capGain: realized + harvested + evGain, ssTax, evOrd, penalizedPre: penalty / 0.1, rmdS, rmdP, rentSheltered: Math.max(0, rentPreDep - rentTaxable), depY, spendCats, rentals: rentalDetail, acaGross, medicare, acaPeople: [aliveS && age < 65 ? age : null, aliveP && sAge < 65 ? sAge : null].filter((a) => a != null),
        ded: { std: lastTx.itemizedUsed ? 0 : lastTx.std * cpiStart, salt: lastTx.itemizedUsed ? lastTx.saltAllowed * cpiStart : 0, mort: lastTx.itemizedUsed ? mortIntFed : 0, senior: lastTx.senior * cpiStart, k401: pre401, depr: depY } });
    }
    const last = rows[rows.length - 1] || { taxable: 0, pretax: 0, roth: 0, property: 0, debt: 0, cpiEnd: 1, liquid: 0, nw: 0 };
    // --- legacy at second death: step-up on taxable + real estate; heirs pay tax on inherited pre-tax (10-yr rule) ---
    const gross = last.taxable + last.pretax + last.roth + last.property - last.debt;
    const exemption = (settings.ref.estateExemption || E.DEFAULT_REF.estateExemption) * last.cpiEnd * (ES.portability ? 2 : 1);
    const estateTax = 0.4 * Math.max(0, gross - exemption);
    const legacy = last.taxable + last.roth + last.pretax * (1 - (+ES.heirRate || 0) / 100) + last.property - last.debt - estateTax + (last.edu || 0); // 529 is outside the taxable estate (completed gift) but stays in the family
    return { rows, failed, success: failed == null, lifetimeTax: tot.tax, totalConv: tot.conv, totals: tot, firstDeath,
      endReal: last.liquid / last.cpiEnd, endNWReal: last.nw / last.cpiEnd, legacyReal: legacy / last.cpiEnd, estateTaxReal: estateTax / last.cpiEnd,
      effRate: tot.gross ? tot.tax / tot.gross : 0 };
  };

  // ---------- tax strategy comparison (ProjectionLab "Optimize"-style) ----------
  L.STRATEGIES = [
    { id: 'none', name: 'No strategy', desc: 'No conversions, no shielding, no harvesting.', tax: { convert: 'none', shield: false, harvest: false } },
    { id: 'current', name: 'Current plan', desc: 'Your current tax strategy settings.', tax: null },
    ...[0.12, 0.22, 0.24, 0.32].map((b) => ({ id: 'cs' + b, name: `Convert and shield to ${b * 100}%`, desc: `Roth-convert up to the top of the ${b * 100}% bracket each year and cap pre-tax withdrawals there.`, tax: { convert: 'bracket', convertBracket: b, shield: true, shieldBracket: b, harvest: false, protectACA: false } })),
    ...[0.12, 0.22].map((b) => ({ id: 'csh' + b, name: `Convert, shield and harvest to ${b * 100}%`, desc: `As above, and harvest long-term gains in the 0% federal bracket (most states still tax them).`, tax: { convert: 'bracket', convertBracket: b, shield: true, shieldBracket: b, harvest: true, harvestProtectACA: false, protectACA: false } })),
    { id: 'aca22', name: 'ACA-aware, then 22%', desc: 'Before 65, convert and harvest only up to the ACA 400% cliff. From 65, convert and shield to 22%.', tax: { convert: 'aca', convertBracket: 0.22, shield: true, shieldBracket: 0.22, harvest: true, harvestProtectACA: true, protectACA: true } },
    { id: 'aca24', name: 'ACA-aware, then 24%', desc: 'Same, but fill the 24% bracket after 65.', tax: { convert: 'aca', convertBracket: 0.24, shield: true, shieldBracket: 0.24, harvest: true, harvestProtectACA: true, protectACA: true } },
    { id: 'irmaa', name: 'Stay under IRMAA tier 1', desc: 'Convert up to the first Medicare-surcharge threshold (capped at 24%), shield at 24%.', tax: { convert: 'irmaa', convertBracket: 0.24, shield: true, shieldBracket: 0.24, harvest: false, protectACA: true } },
    { id: 'harvest', name: 'Harvest gains only', desc: 'No conversions. Use the 0% federal capital-gains bracket each year, staying under the ACA cliff.', tax: { convert: 'none', shield: false, harvest: true, harvestProtectACA: true } },
  ];
  const stratPlan = (plan, st, settings) => { const p = L.normalizePlan(JSON.parse(JSON.stringify(plan)), settings); if (st.tax) p.tax = { ...p.tax, ...st.tax, convertStart: '', convertEnd: 74 }; return p; };
  const stratMetrics = (d) => { const T = d.totals; return { lifetimeTax: T.tax, irmaa: T.irmaa, propTax: T.propTax, legacy: d.legacyReal, estateTax: d.estateTaxReal, effRate: d.effRate, endNW: d.endNWReal, aca: T.ptc, rmd: T.rmd, conv: T.conv, harvest: T.harvest }; };
  L.compareStrategies = (plan, init, settings, { withBacktest = true } = {}) => {
    return L.STRATEGIES.map((st) => {
      const p = stratPlan(plan, st, settings);
      const d = L.deterministic(p, init, settings);
      const bt = withBacktest ? L.backtest(p, init, settings) : null;
      return { id: st.id, name: st.name, desc: st.desc, tax: p.tax, ...stratMetrics(d), failed: d.failed, success: bt ? bt.success : null };
    });
  };
  // Same strategies under Monte Carlo market scenarios. Every strategy sees the *same* simulated market paths.
  // Paths are ranked by how the current plan ends (liquid, today's $); each scenario averages the paths in a band
  // around that percentile (e.g. 20th–30th for "25th"), so one lucky or unlucky path doesn't decide the answer.
  L.compareStrategiesMC = (plan, init, settings, { runs = 200, band = 0.05, qs = [0.25, 0.5, 0.75] } = {}) => {
    const n = L.horizon(plan, init, settings); const r = rng((plan.sim?.seed || 7) + 101);
    const paths = Array.from({ length: runs }, () => L.adjustPath(plan, L.bootPath(n, r, plan.sim.block || 5, plan.returns.googExtraVol || 0, plan.returns.cryptoVol ?? 60)));
    const base = L.normalizePlan(JSON.parse(JSON.stringify(plan)), settings);
    const ends = paths.map((p, i) => ({ i, v: L.simulate(base, init, settings, p).endNWReal })).sort((a, b) => a.v - b.v);
    const pick = (q) => { const lo = Math.max(0, Math.floor((q - band) * runs)), hi = Math.min(runs, Math.ceil((q + band) * runs)); return ends.slice(lo, Math.max(lo + 1, hi)).map((e) => e.i); };
    const out = {};
    for (const q of qs) {
      const idx = pick(q); const key = 'p' + Math.round(q * 100);
      out[key] = { q, paths: idx.length, baseEnd: ends[Math.floor(q * (runs - 1))].v, rows: L.STRATEGIES.map((st) => {
        const p = stratPlan(plan, st, settings); const ms = idx.map((i) => { const d = L.simulate(p, init, settings, paths[i]); return { ...stratMetrics(d), failed: d.failed }; });
        const avg = (f) => ms.reduce((a, m) => a + (m[f] || 0), 0) / ms.length;
        const row = { id: st.id, name: st.name, desc: st.desc, tax: p.tax }; for (const f of ['lifetimeTax', 'irmaa', 'propTax', 'legacy', 'estateTax', 'effRate', 'endNW', 'aca', 'rmd', 'conv', 'harvest']) row[f] = avg(f);
        row.failPct = ms.filter((m) => m.failed != null).length / ms.length; row.failed = row.failPct >= 0.5 ? Math.round(ms.filter((m) => m.failed != null).reduce((a, m) => a + m.failed, 0) / Math.max(1, ms.filter((m) => m.failed != null).length)) : null;
        return row; }) };
    }
    return out;
  };

  // Direct indexing analysis: keep the cash vs. the same money in a plain index fund vs. direct indexing
  L.diCompare = (plan, init, settings) => {
    const mk = (di) => { const p = L.normalizePlan(JSON.parse(JSON.stringify(plan)), settings); p.di = { ...p.di, ...di }; return L.deterministic(p, init, settings); };
    const cash = mk({ enabled: false }), fund = mk({ enabled: true, harvestPct: 0, feeType: 'pct', feePct: 0.03, feeYears: '', diversify: false }), di = mk({ enabled: true });
    const R = di.rows; const lastContrib = R.reduce((a, r, i) => (r.diContrib > 1 ? i : a), -1);
    const fade = R.find((r, i) => i > lastContrib && r.diValue > 0 && r.diHarvest < 0.005 * r.diValue);
    const fadeIdx = fade ? R.indexOf(fade) : -1;
    const empty = fadeIdx >= 0 ? R.find((r, i) => i >= fadeIdx && r.diPool < 1000 * r.cpiEnd) : null;
    const lastRow = R[R.length - 1];
    return { cash, fund, di, fadeYear: fade?.year ?? null, emptyYear: empty?.year ?? null, unusedEnd: lastRow ? lastRow.diPool / lastRow.cpiEnd : 0 };
  };
  L.deterministic = (plan, init, settings) => L.simulate(plan, init, settings, L.fixedPath(plan, L.horizon(plan, init, settings)));

  const pctl = (arr, q) => { const a = arr.slice().sort((x, y) => x - y); const i = (a.length - 1) * q; const lo = Math.floor(i), hi = Math.ceil(i); return a[lo] + (a[hi] - a[lo]) * (i - lo); };
  // historical average real returns (geometric, 1928–2025): what the Monte Carlo and backtest sample from
  L.HIST_REAL = (() => { const geo = (f) => (Math.pow(HIST.reduce((p, h) => p * (1 + f(h)) / (1 + h.infl), 1), 1 / HIST.length) - 1) * 100;
    return { stock: geo((h) => h.stock), bond: geo((h) => h.bond), cash: geo((h) => h.cash), re: geo((h) => h.re), gold: geo((h) => h.gold), infl: (Math.pow(HIST.reduce((p, h) => p * (1 + h.infl), 1), 1 / HIST.length) - 1) * 100 }; })();
  // optional: keep history's ups and downs but shift each asset so its long-run average equals the plan's fixed real return
  L.adjustPath = (plan, path) => {
    if (!plan.sim?.matchMeans || !path) return path;
    const R = plan.returns, H = L.HIST_REAL; const f = (r, h) => (1 + r / 100) / (1 + h / 100) - 1; // multiplicative, so the shifted geometric mean equals the plan's rate exactly
    const d = { stock: f(R.stock, H.stock), bond: f(R.bond, H.bond), cash: f(R.cash, H.cash), re: f(R.re, H.re), gold: f(R.gold ?? 1, H.gold) };
    const sh = (v, infl, dd) => ((1 + v) / (1 + infl) * (1 + dd)) * (1 + infl) - 1;
    return path.map((h) => ({ ...h, stock: sh(h.stock, h.infl, d.stock), goog: sh(h.goog, h.infl, d.stock), crypto: sh(h.crypto, h.infl, d.stock), bond: sh(h.bond, h.infl, d.bond), cash: sh(h.cash, h.infl, d.cash), bank: sh(h.bank, h.infl, d.cash), re: sh(h.re, h.infl, d.re), gold: sh(h.gold, h.infl, d.gold) }));
  };
  L.monteCarlo = (plan, init, settings, runs, opts = {}) => {
    const n = L.horizon(plan, init, settings); const r = rng(plan.sim.seed || 7);
    const sims = []; for (let k = 0; k < runs; k++) sims.push(L.simulate(plan, init, settings, L.adjustPath(plan, L.bootPath(n, r, plan.sim.block || 5, plan.returns.googExtraVol || 0, plan.returns.cryptoVol ?? 60)), opts));
    return L.aggregate(sims);
  };
  L.backtest = (plan, init, settings, opts = {}) => {
    const n = L.horizon(plan, init, settings); const sims = [];
    for (let s = 0; s < HIST.length; s++) { const path = L.adjustPath(plan, L.histPath(s, n, true)); const res = L.simulate(plan, init, settings, path, opts); res.startYear = HIST[s].year; res.wrapped = s + n > HIST.length; sims.push(res); }
    const agg = L.aggregate(sims);
    agg.byStart = sims.map((x) => ({ year: x.startYear, success: x.success, failed: x.failed, endReal: x.endReal, wrapped: x.wrapped }));
    return agg;
  };
  L.aggregate = (sims) => {
    const n = sims[0].rows.length; const bands = [];
    for (let t = 0; t < n; t++) {
      const vals = sims.map((s) => (s.rows[t] ? s.rows[t].liquid / s.rows[t].cpiEnd : 0));
      bands.push({ year: sims[0].rows[t].year, age: sims[0].rows[t].age, p10: pctl(vals, 0.1), p25: pctl(vals, 0.25), p50: pctl(vals, 0.5), p75: pctl(vals, 0.75), p90: pctl(vals, 0.9) });
    }
    const succ = sims.filter((s) => s.success).length / sims.length;
    return { success: succ, bands, runs: sims.length, medianEnd: pctl(sims.map((s) => s.endReal), 0.5), p10End: pctl(sims.map((s) => s.endReal), 0.1), medianTax: pctl(sims.map((s) => s.lifetimeTax), 0.5), failAges: sims.filter((s) => !s.success).map((s) => s.failed) };
  };
  // highest base spending (today's $) with ≥ target success
  L.maxSpending = (plan, init, settings, target = 0.9, runs = 300) => {
    let lo = 0.3, hi = 2.0;
    for (let i = 0; i < 11; i++) { const mid = (lo + hi) / 2; const mc = L.monteCarlo({ ...plan, sim: { ...plan.sim, seed: 11 } }, init, settings, runs, { spendScale: mid }); if (mc.success >= target) lo = mid; else hi = mid; }
    const pn = L.normalizePlan(JSON.parse(JSON.stringify(plan)), settings); const base = sum(pn.spending.categories, (c) => (c.startAge === '' && c.endAge === '' ? +c.amount || 0 : 0));
    return { scale: lo, amount: base * lo };
  };

  // ---------- ProjectionLab CSV ----------
  L.parsePL = (text) => {
    const lines = text.replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim());
    const hi = lines.findIndex((l) => /^Year,/.test(l)); if (hi < 0) throw new Error('No "Year," header found');
    const hdr = lines[hi].split(',');
    const rows = [];
    for (const l of lines.slice(hi + 1)) {
      const f = l.match(/("[^"]*"|[^,]+|(?<=,)(?=,)|^(?=,))/g)?.map((x) => x.replace(/"/g, '')) || l.split(',');
      const o = {}; hdr.forEach((h, i) => (o[h.trim()] = f[i] === '' || f[i] == null ? null : +f[i]));
      if (o.Year) rows.push(o);
    }
    const start = rows[0]; const years = rows.slice(1).filter((r) => r.Expenses != null);
    return { start, years, header: hdr };
  };

  // ---------- ProjectionLab account export (JSON) ----------
  // The JSON export holds PL *inputs* (accounts, assets, milestones, income/expense events, assumptions) —
  // not yearly results. We keep only the fields needed for reconciliation; settings (incl. any plugin API key) are dropped.
  L.parsePLJson = (text) => {
    const d = JSON.parse(text.replace(/^﻿/, ''));
    if (!d || !d.today || !Array.isArray(d.plans)) throw new Error('Not a ProjectionLab account export (missing "today"/"plans")');
    const T = d.today;
    const bucket = (t) => (/roth/.test(t) ? 'roth' : /^(401k|403b|457b?|ira|sep-ira|simple-ira|traditional-ira|pension)$/.test(t) || /401k|403b|457|ira/.test(t) ? 'pretax' : t === 'savings' ? 'cash' : t === 'hsa' ? 'hsa' : t === '529' ? '529' : t === 'crypto' ? 'crypto' : 'taxable');
    const acct = (a) => ({ name: a.name, type: a.type, bucket: bucket(String(a.type || '')), owner: a.owner === 'me' ? 'self' : a.owner || 'joint', balance: +a.balance || 0, costBasis: a.costBasis != null ? +a.costBasis : null });
    const when = (x) => { if (!x) return null; if (typeof x !== 'object') return { type: 'date', value: String(x) }; return { type: x.type, value: x.value }; };
    const yearOf = (w) => (w && (w.type === 'date' || w.type === 'year') ? +String(w.value).slice(0, 4) : null);
    const asset = (a) => {
      const val = +a.amount || 0;
      const amt = (v, t) => (v == null ? null : t === '%' ? val * (+v || 0) / 100 : +v || 0);
      return { name: a.name, kind: a.title || a.type, owner: a.owner === 'me' ? 'self' : a.owner || 'joint', value: val, purchase: a.initialValue != null ? +a.initialValue : null,
        loan: +a.balance || 0, rate: +a.interestRate || 0, payment: +a.monthlyPayment || 0, financed: a.paymentMethod === 'financed',
        propertyTax: amt(a.taxRate, a.taxRateType), insurance: amt(a.insuranceRate, a.insuranceRateType), maintenance: amt(a.maintenanceRate, a.maintenanceRateType),
        management: a.managementRateType === '%' ? null : amt(a.managementRate, a.managementRateType),
        income: a.generateIncome ? (a.incomeRateType === '%' ? null : +a.incomeRate || 0) : 0, incomeRaw: a.generateIncome ? { v: +a.incomeRate || 0, t: a.incomeRateType } : null,
        pctRented: +a.percentRented || 0, appreciation: a.yearlyChange?.type === 'appreciate' ? +a.yearlyChange.amount || 0 : null };
    };
    const perYr = (e) => { const f = { yearly: 1, annually: 1, monthly: 12, quarterly: 4, weekly: 52, biweekly: 26, once: 1 }[e.frequency || 'yearly'] ?? 1; return (+e.amount || 0) * f; };
    const ev = (e) => ({ name: e.name, type: e.type, owner: e.owner === 'me' ? 'self' : e.owner || 'joint', perYear: perYr(e), amount: +e.amount || 0, frequency: e.frequency || 'yearly',
      amountType: e.amountType, growth: e.yearlyChange ? { type: e.yearlyChange.type, amount: +e.yearlyChange.amount || 0 } : null, spendingType: e.spendingType || null,
      start: when(e.start), end: when(e.end), startYear: yearOf(when(e.start)), endYear: yearOf(when(e.end)) });
    const plans = d.plans.map((p) => {
      const ms = (p.milestones || []).map((m) => { const c = (m.criteria || [])[0] || {}; return { id: m.id, name: m.name, type: c.type, date: (c.type === 'date' || c.type === 'year') ? String(c.value) : null }; });
      const V = p.variables || {};
      const pick = ['investmentReturn', 'inflation', 'dividendRate', 'bondInvestmentReturn', 'filingStatus', 'incomeTaxMode', 'effectiveIncomeTaxRate', 'capGainsMode', 'capGainsTaxRate', 'dividendTaxRate', 'localIncomeTaxRate', 'estimateTaxes', 'tcjaReversion', 'assumptionsMode'];
      return { name: p.name, active: !!p.active, milestones: ms, vars: Object.fromEntries(pick.filter((k) => k in V).map((k) => [k, V[k]])),
        accounts: (p.accounts?.events || []).map(acct), assets: (p.assets?.events || []).filter((a) => a.type === 'real-estate' || a.amount).map(asset),
        income: (p.income?.events || []).map(ev), expenses: (p.expenses?.events || []).map(ev),
        withdrawal: p.withdrawalStrategy ? { enabled: !!p.withdrawalStrategy.enabled, type: p.withdrawalStrategy.strategy || p.withdrawalStrategy.type || null } : null,
        mc: p.montecarlo ? { mode: p.montecarlo.mode || p.montecarlo.type || null, trials: p.montecarlo.trials ?? null } : null };
    });
    const accounts = [...(T.savingsAccounts || []), ...(T.investmentAccounts || [])].map(acct);
    const progress = ((d.progress && d.progress.data) || []).map((r) => ({ date: new Date(r.date).toLocaleDateString('en-CA'), netWorth: r.netWorth, taxable: r.taxable, taxDeferred: r.taxDeferred, taxFree: r.taxFree, savings: r.savings, assets: r.assets, loans: r.loans, debt: r.debt, crypto: r.crypto }));
    const hasSecret = !!(d.settings && JSON.stringify(d.settings).match(/apiKey|token|secret/i));
    return { kind: 'json', version: d.meta?.version || null, exportedAt: d.meta?.lastUpdated ? new Date(d.meta.lastUpdated).toLocaleDateString('en-CA') : null,
      people: { self: { name: T.yourName || 'You', birthYear: +T.birthYear || null, birthMonth: +T.birthMonth || null }, spouse: T.partnerStatus === 'couple' ? { name: T.spouseName || 'Spouse', birthYear: +T.spouseBirthYear || null, birthMonth: +T.spouseBirthMonth || null } : null },
      state: T.location?.state || null, accounts, assets: (T.assets || []).map(asset), debts: (T.debts || []).map((x) => ({ name: x.name, balance: +x.balance || 0, rate: +x.interestRate || 0 })),
      plans, progress, droppedSecret: hasSecret };
  };
  // ---------- ProjectionLab "Income" report CSV: income by source, per year ----------
  L.PL_INC_GROUPS = [['work', 'Work (salary, RSU, bonus)'], ['ss', 'Social Security'], ['rent', 'Rental income'], ['divs', 'Interest & dividends'], ['rmd', 'Required withdrawals (RMDs)'], ['conv', 'Roth conversions'], ['gains', 'Realized capital gains'], ['tfw', 'Roth / 529 / HSA withdrawals'], ['other', 'Other income']];
  L.plIncGroup = (name, workNames = []) => {
    const n = String(name);
    if (workNames.includes(n) || /salary|rsu|bonus|wage|self-employ|commission|paycheck/i.test(n)) return 'work';
    if (/^RMD:/i.test(n)) return 'rmd';
    if (/^Roth Conversion/i.test(n)) return 'conv';
    if (/social security/i.test(n)) return 'ss';
    if (/rental income|rent\b/i.test(n)) return 'rent';
    if (/realized gain|harvested gain|capital gain/i.test(n)) return 'gains';
    if (/savings yield|dividend|interest|bond yield/i.test(n)) return 'divs';
    if (/withdrawal|roth ira|roth 401|hsa|529/i.test(n)) return 'tfw';
    return 'other';
  };
  const splitCsv = (l) => { const out = []; let cur = '', q = false; for (const ch of l) { if (ch === '"') q = !q; else if (ch === ',' && !q) { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out; };
  L.parsePLIncome = (text) => {
    const lines = text.replace(/^﻿/, '').split(/\r?\n/).filter((l) => l.trim());
    const hi = lines.findIndex((l) => /^Year,/.test(l)); if (hi < 0) throw new Error('No "Year," header found');
    const hdr = splitCsv(lines[hi]).map((h) => h.trim());
    let rows = lines.slice(hi + 1).map((l) => { const f = splitCsv(l); const o = {}; hdr.forEach((h, i) => (o[h] = f[i] === '' || f[i] == null ? 0 : +f[i] || 0)); return o; }).filter((o) => o.Year);
    if (rows.length > 1 && rows[0].Year === rows[1].Year) rows = rows.slice(1); // PL repeats the starting year
    const cols = hdr.filter((h) => h !== 'Year' && h !== 'Income').map((name) => ({ name, group: L.plIncGroup(name) }));
    return { cols, years: rows };
  };
  // accept any ProjectionLab export: JSON account data (inputs), CSV report summary / income / rates
  L.parsePLAny = (text) => {
    const t = text.replace(/^﻿/, '').trimStart();
    if (t[0] === '{') return L.parsePLJson(t);
    const hdr = (t.split(/\r?\n/).find((l) => /^Year,/.test(l)) || '');
    if (/Net Worth/.test(hdr)) return { kind: 'csv', ...L.parsePL(t) };
    if (/Plan Stock Growth Rate|Plan Inflation Rate/.test(hdr)) return { kind: 'csv-rates' };
    if (/^Year,Income,/.test(hdr)) return { kind: 'csv-income', ...L.parsePLIncome(t) };
    throw new Error('Unrecognized ProjectionLab CSV. Use the Summary or Income report, or the account data JSON.');
  };

  root.FirePlanner = L;
  if (typeof module !== 'undefined') module.exports = L;
})(typeof window !== 'undefined' ? window : globalThis);
