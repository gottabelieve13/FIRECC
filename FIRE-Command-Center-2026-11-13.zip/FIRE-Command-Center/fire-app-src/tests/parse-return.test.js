const P=require(require('path').join(__dirname,'../src/parsers.js'));
const lines=`Form 1040 Department of the Treasury—Internal Revenue Service U.S. Individual Income Tax Return 2025 OMB No. 1545-0074
Your first name and middle initial  JANE   Last name DOE   Your social security number 123-45-6789
Filing Status  Married filing jointly
1a Total amount from Form(s) W-2, box 1 (see instructions) . . . 1a 456,000
1z Add lines 1a through 1h . . . . . . . . . . . . 1z 456,000
2a Tax-exempt interest . . 2a 1,250 b Taxable interest . . . 2b 8,400
3a Qualified dividends . . . 3a 42,100 b Ordinary dividends . . . 3b 51,300
4a IRA distributions . . . 4a b Taxable amount . . 4b 0
6a Social security benefits . . 6a c If you elect to use the lump-sum election method 6b
7 Capital gain or (loss). Attach Schedule D if required . . . 7 (3,000)
8 Additional income from Schedule 1, line 10 . . . . . . 8 12,500
9 Add lines 1z, 2b, 3b, 4b, 5b, 6b, 7, and 8. This is your total income . . . 9 525,200
10 Adjustments to income from Schedule 1, line 26 . . . 10 0
11 Subtract line 10 from line 9. This is your adjusted gross income . . . 11 525,200
12 Standard deduction or itemized deductions (from Schedule A) . . 12 40,000
13 Qualified business income deduction from Form 8995 or Form 8995-A . 13 0
15 Subtract line 14 from line 11. If zero or less, enter -0-. This is your taxable income . 15 485,200
16 Tax (see instructions). Check if any from Form(s): 1 8814 2 4972 3 . . . 16 101,234
23 Other taxes, including self-employment tax, from Schedule 2, line 21 . . 23 4,950
24 Add lines 22 and 23. This is your total tax . . . . . . 24 106,184
25d Add lines 25a through 25c . . . . . . . . 25d 98,000
26 2025 estimated tax payments and amount applied from 2024 return . 26 10,000
34 If line 33 is more than line 24, subtract line 24 from line 33. This is the amount you overpaid 34 1,816
SCHEDULE 2 (Form 1040) 2025
Additional Taxes
1 Alternative minimum tax. Attach Form 6251 . . . . 1 0
11 Additional Medicare Tax. Attach Form 8959 . . . 11 1,854
12 Net investment income tax. Attach Form 8960 . . . 12 3,096
SCHEDULE D (Form 1040) 2025
Capital Gains and Losses
6 Short-term capital loss carryover. Enter the amount, if any, from line 8 of your Capital Loss Carryover Worksheet 6 (12,000)
14 Long-term capital loss carryover. Enter the amount, if any, from line 13 of your Capital Loss Carryover Worksheet 14 (40,000)
16 Combine lines 7 and 15 and go to line 17 below . . . 16 (35,500)
21 If line 16 is a loss, enter here and on Form 1040, line 7, the smaller of: ... 21 (3,000)
FORM 540 2025 California Resident Income Tax Return
17 California adjusted gross income. Combine line 15 and line 16 . . 17 525,200
18 Enter the larger of your California itemized deductions or standard deduction . 18 18,000
19 Subtract line 18 from line 17. This is your taxable income. If less than zero, enter -0- 19 507,200
31 Tax. Check the box if from: Tax Table Tax Rate Schedule . . . 31 40,123
62 Mental Health Services Tax . . . 62 0
64 Add line 48, line 61, and line 62. This is your total tax . . 64 40,123
71 California income tax withheld . . . 71 36,000
72 2025 California estimated tax and other payments . . 72 5,000`.split('\n');
const r=P.parseText(P.detect('r.pdf',lines.join('\n')),lines);console.log(r.kind,r.taxReturn.year,JSON.stringify(r.taxReturn.fields));console.log('ssn leak?',/6789/.test(JSON.stringify(r)));
const F=r.taxReturn.fields;const exp={agi:525200,taxableIncome:485200,totalTax:106184,qualDiv:42100,capGain:-3000,niit:3096,caTaxable:507200,caTotalTax:40123,capLossCarryOut:32500,taxExemptInt:1250,withheld:98000};
let bad=0;for(const[k,v]of Object.entries(exp))if(F[k]!==v){bad++;console.log('FAIL',k,F[k],'expected',v);}console.log(`${Object.keys(exp).length-bad} passed, ${bad} failed (synthetic TurboTax-style layout)`);
{const base=lines;const pre=['2026 Form 1040-ES Estimated Tax Payment Voucher 1 Calendar year—Due April 15, 2026','Two-Year Comparison 2024 2025','Wages, salaries, tips 1z 401,000 456,000','Federal Information Worksheet 2025','Total amount from Form(s) W-2, box 1 (see instructions) 1a 222,333'];
 const post=['Form 8959 Additional Medicare Tax 2025','1z Add lines 1a through 1h 1z 999,999'];const q=P.parseTaxReturn([...pre,...base,...post]).taxReturn;
 const ok=q.year===2025&&q.fields.wages===456000&&q.fields.totalIncome===525200;console.log(`${ok?'PASS':'FAIL'}  Cover pages, vouchers, comparisons and later forms don't change the year or wages [year ${q.year}, wages ${q.fields.wages}]`);}
{const ca=['TAXABLE YEAR 2025 CALIFORNIA RESIDENT INCOME TAX RETURN FORM 540','Form 540 2025 Side 1','17 California adjusted gross income. Combine line 15 and line 16 17 525200 00','19 Subtract line 18 from line 17. This is your taxable income. 19 507200 00','31 Tax. Check the box if from: Tax Table 31 40123 00','Form 540 2025 Side 2','64 Add line 48, line 61, and line 62. This is your total tax 64 40123 00','SCHEDULE CA (540) California Adjustments','19 Total taxable income 19 999999 00'];
 const fedLines=lines.slice(0,lines.findIndex(l=>/^FORM 540/.test(l)));const q=P.parseTaxReturn([...fedLines,...ca]).taxReturn.fields;
 const ok=q.caAgi===525200&&q.caTaxable===507200&&q.caTax===40123&&q.caTotalTax===40123&&q.wages===456000;console.log(`${ok?'PASS':'FAIL'}  California 540 in the same PDF: uppercase title, no commas, cents in a separate box [${q.caAgi}, ${q.caTaxable}, ${q.caTax}, ${q.caTotalTax}]`);}
