# FIRE-data

This folder holds your FIRE Command Center data. Each `.fire` file is encrypted with your password (AES-256-GCM) and can't be opened without it.

| Folder | What's in it | Written when |
|---|---|---|
| `autosave/FIRE-autosave.fire` | Your latest full data: accounts, snapshots, plans, settings | After every change, about 1.5 seconds later |
| `autosave/FIRE-autosave-YYYY-MM-DD.fire` | One copy per day; the last 30 are kept | First change of each day |
| `snapshots/FIRE-snapshot-<date>.fire` | Your full data as of each **Save snapshot** | When you click Save snapshot |
| `statements/` | Optional place for original statements (PDF/CSV). **Not encrypted.** | You copy them in |

## Set up (once per computer)
1. Open `../FIRE-Command-Center.html` in Chrome or Edge.
2. On the Import tab, under **Data folder & backups**, click **Choose data folder** and select this `FIRE-data` folder.
3. Pick a password. Store it in your password manager; it isn't saved anywhere else.

After a browser restart, click **Auto-save** in the header to resume. You'll re-enter the password and may be asked to allow folder access again.

## Move to a new computer
1. Copy or unzip the whole FinancialTest folder.
2. Open `FIRE-Command-Center.html`.
3. On the Import tab, click **Load data file**, choose `FIRE-data/autosave/FIRE-autosave.fire`, and enter your password.
4. Click **Choose data folder** and select this folder again to keep auto-saving.

## Back up to Google Drive
Double-click `Backup to Zip.command` in the FinancialTest folder. It zips everything into `Backups/` and copies the zip to your personal (@gmail.com) Google Drive if Google Drive for desktop is installed. Other accounts are skipped; to use a different personal account, run it with `FIRE_DRIVE_ACCOUNT=you@example.com`. Otherwise it opens Finder so you can drag the zip to drive.google.com.

Use a personal Google account for these backups, not a work account.
